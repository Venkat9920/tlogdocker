/**
 * SigConfigSpec.java
 */

package com.gianteagle.is.sig.base;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.gianteagle.is.net.NetUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.NvList;
import com.gianteagle.is.util.NvPair;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import com.gianteagle.is.xml.XmlDoc;

/**
 * Base class used to manage SIG configuration elements.
 * <p>
 * @author sr44189
 */

public abstract class SigConfigSpec
{
	/**
	 * Constructor given the name of the base configuration specification
	 * file and the store specific configuration file.
	 * <p>
	 * @param	sBaseConfigSpec		Base configuration specification file.
	 * @param	sStoreConfigSpec	Store specific configuration file.
	 */
	
	public SigConfigSpec(final String sBaseConfigSpec, 
						 final String sStoreConfigSpec)
	{
		this.sBaseConfig = sBaseConfigSpec;
		this.sStoreConfig = sStoreConfigSpec;
		this.sDocParentElement = SigConfigSpec.DEF_DOC_PARENT_ELEMENT;
	}
	
	/**
	 * Constructor given the name of the base configuration specification
	 * file, the store specific configuration file, and the root
	 * element of the configuration file.
	 * <p>
	 * @param	sBaseConfigSpec		Base configuration specification file.
	 * @param	sStoreConfigSpec	Store specific configuration file.
	 * @param	sRootElement		Root element of the configuration.
	 */
	
	public SigConfigSpec(final String sBaseConfigSpec, 
						 final String sStoreConfigSpec,
						 final String sRootElement)
	{
		this.sBaseConfig = sBaseConfigSpec;
		this.sStoreConfig = sStoreConfigSpec;
		
		if (StringUtil.isEmpty(sRootElement) == true)
		{
			this.sDocParentElement = SigConfigSpec.DEF_DOC_PARENT_ELEMENT;
		}
		else
		{
			this.sDocParentElement = sRootElement;
		}
	}
	
	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	public final void destroy()
	{
		this.sBaseConfig = null;
		this.sStoreConfig = null;
		this.sDocParentElement = null;
		
		this.clearConfig();
	}
	
	/**
	 * Reloads the configuration if the base configuration file or the store
	 * configuration file has changed.
	 * <p>
	 * @return		<code>true</code> if the configuration has been
	 * 				reloaded, otherwise <code>false</code>.
	 */
	
	public final boolean reloadConfig()
	{
		boolean bRet = false;
		boolean bBaseConfigHasChanged = false;
		boolean bConfigHasChanged = false;
		
		if (this.checkReload() == true)
		{
			bBaseConfigHasChanged =
				FileUtil.fileHasChanged(this.sBaseConfig, 
										this.nBaseConfigLastModified, 
										this.nBaseConfigLength);
			bConfigHasChanged =	
				FileUtil.fileHasChanged(this.sStoreConfig, 
										this.nConfigLastModified, 
										this.nConfigLength);
		
			if (bBaseConfigHasChanged == true || bConfigHasChanged == true)
			{
				this.clearConfig();
				this.loadConfigSpecs();
				bRet = true;
			}
			SigLogger.logDebug(this.getClass(), "reloadConfig()",
					"Configuration changed = " +
					StringUtil.format(bRet) + '.');
		}
		return bRet;
	}
	
	/**
	 * Method used to determine whether or not to reload the configuration
	 * based on the the reload interval.
	 * <p>
	 * @return		<code>true</code> if the configuration should
	 * 				be reloaded, if it has changed, otherwise
	 * 				<code>false</code>.
	 */
	
	private final boolean checkReload()
	{
		boolean bReload = false;
		long nCurrentTime = 0;
		long nReloadInterval = 0;
		
		if (this.nLastReloadCheck <= 0)
		{
			// Load if the configuration has not yet been set.
			
			this.nLastReloadCheck = SigUtil.currentUTCTimeMillis().longValue();
			
			bReload = true;
		}
		else if (this.nConfigReloadInterval == null)
		{
			// Load if the configuration has not yet been set.
			
			this.nLastReloadCheck = SigUtil.currentUTCTimeMillis().longValue();

			bReload = true;
		}
		else if (this.nConfigReloadInterval.longValue() <= 0)
		{
			// Load if the reload interval is 0 (or less).
			
			this.nLastReloadCheck = SigUtil.currentUTCTimeMillis().longValue();

			bReload = true;
		}
		else
		{
			// Load if the reload interval has been exceeded.

			nCurrentTime = SigUtil.currentUTCTimeMillis().longValue();
			nReloadInterval = this.nConfigReloadInterval.longValue();
			
			if ((nCurrentTime - this.nLastReloadCheck) > nReloadInterval)
			{
				this.nLastReloadCheck = nCurrentTime;
				
				bReload = true;
			}
		}
		return bReload;
	}
	
	/**
	 * Returns the VSA name from the configuration specifications.
	 * <p>
	 * @return		The VSA name from the configuration specifications.
	 */
	
	public final String getVSAName()
	{
		return this.sVSAName;
	}

	/**
	 * Returns the store name from the configuration specifications.
	 * <p>
	 * @return		The store name from the configuration specifications.
	 */
	
	public final String getStoreName()
	{
		return this.sStoreName;
	}
	
	/**
	 * Returns the store number from the configuration specifications.
	 * <p>
	 * @return		The store number from the configuration specifications.
	 */
	
	public final String getStoreNumber()
	{
		return this.sStoreNumber;
	}
	
	/**
	 * Returns the division number from the configuration specifications.
	 * <p>
	 * @return		The division number from the configuration specifications.
	 */
	
	public final String getDivisionNumber()
	{
		return this.sDivisionNumber;
	}

	/**
	 * Returns the division from the configuration specifications.
	 * <p>
	 * @return		The division from the configuration specifications.
	 */
	
	public final String getDivision()
	{
		return this.sDivision;
	}
	
	/**
	 * Returns whether or not the store and division number received from
	 * a client should be validated against the store and division number
	 * in the service configuration.
	 * <p>
	 * @return		<code>true</code> if the client store and division should
	 * 				be validated, otherwise <code>false</code>.
	 */
	
	public final Boolean validateStoreDivision()
	{
		return this.bValidateStoreDivision;
	}

	/**
	 * Returns whether or not the store and division number received from
	 * a client should be validated against the list of stores and divisions
	 * instead of the configured store and division.
	 * <p>
	 * @return		<code>true</code> if the client store and division should
	 * 				be validated against the list, otherwise <code>false</code>.
	 */
	
	public final Boolean useStoreValidationList()
	{
		return this.bUseStoreValidationList;
	}

	/**
	 * Returns the name of the store validation list file or <code>null</code>
	 * if it has not been set in the configuration.
	 * <p>
	 * @return		The name of the store validation list file or
	 * 				<code>null</code> if it has not been set.
	 */
	
	public final String getStoreValidationListFile()
	{
		return this.sStoreValidationListFile;
	}
	
	/**
	 * Returns the name of the logger configuration file or <code>null</code>
	 * if it has not been set in the configuration.
	 * <p>
	 * @return		The name of the logger configuration file or
	 * 				<code>null</code> if it has not been set.
	 */
	
	public final String getLoggerConfigFile()
	{
		return this.sLoggerConfigFile;
	}
	
	/**
	 * Returns whether or not SigRoute messages should be logged.
	 * <p>
	 * @return		<code>true</code> if SigRoute messages should be logged,
	 * 				otherwise <code>false</code>.
	 */
	
	public final Boolean logSigRouteMessage()
	{
		return this.bLogRouteMessage;
	}

	/**
	 * Returns whether or not SigRoute messages should include
     * an attribute that identifies the message as a test message.
	 * <p>
	 * @return		<code>true</code> if SigRoute messages should be identified
	 * 				as test messages, otherwise <code>false</code>.
	 */
	
	public final Boolean testSigRouteMessage()
	{
		return this.bTestRouteMessage;
	}

	/**
	 * Returns the max backout count for message rollback.
	 * <p>
	 * @return		The max backout count for message rollback. A value
	 * 				of 0 indicates the max backout count should be
	 * 				ignored.
	 */
	
	public final Long getMaxBackoutCount()
	{
		return this.nMaxBackoutCount;
	}
	
	/**
	 * Returns whether or not the max backout count on message rollback
	 * is enforced.
	 * <p>
	 * @return		<code>true</code> if the max backout count on message
	 * 				rollback is enforced, otherwise <code>false</code>.
	 */
	
	public final Boolean isMaxBackoutCountEnabled()
	{
		return this.bEnableMaxBackoutCount;
	}

	/**
	 * Returns the delay, in milliseconds, for message rollback.
	 * <p>
	 * @return		The delay, in milliseconds, for message rollback.
	 * 				A value of <code>0</code> indicates no delay.
	 */
	
	public final Long getRollbackDelay()
	{
		return this.nRollbackDelay;
	}

	/**
	 * Returns the interval, in milliseconds, between checks to determine
	 * if the configuration file has changed.
	 * <p>
	 * @return		The interval, in milliseconds, between checks to
	 * 				determine if the configuration file has changed.
	 * 				A value of <code>0</code> will cause the check
	 * 				to occur on every configuration access.
	 */
	
	public final Long getConfigReloadInterval()
	{
		return this.nConfigReloadInterval;
	}
	
	/**
	 * Returns whether or not ERRORs should be published.
	 * <p>
	 * @return		<code>true</code> if ERRORs should be published,
	 * 				otherwise <code>false</code>.
	 */
	
	public final Boolean publishErrors()
	{
		return this.bPublishErrors;
	}

	/**
	 * Returns the base topic string used to publish ERRORs.
	 * <p>
	 * @return		The base topic string used to publish ERRORs.
	 */
	
	public final String getErrorTopicString()
	{
		return this.sErrorTopicString;
	}
	
	/**
	 * Returns the value in  bytes to use when accessing a file. 
	 * This value is typically supplied to a FileRead node as the 
	 * Record Length when reading a raw file.
	 * <p>
	 * @return		The file buffer length to use when accessing a file.
	 */
	
	public final Long getFileBufferLength()
	{
		return this.nFileBufferLength;
	}
	
	/**
	 * Returns the base topic string used to publish status.
	 * <p>
	 * @return		The base topic string used to publish status.
	 */
	
	public final String getStatusTopicString()
	{
		return this.sStatusTopicString;
	}
	
	/**
	 * Returns whether or not this object is in an error state.
	 * <p>
	 * @return		<code>true</code> if in an error state, otherwise
	 * 				<code>false</code>.
	 */
	
	public final boolean isErrorState()
	{
		return this.errorInformation == null ? false : true;
	}
	
	/**
	 * Returns the error information as a <code>Throwable</code> object
	 * if this object is in an error state.
	 * <p>
	 * @return		The <code>Throwable</code> object containing the
	 * 				error information if this object is in an error state.
	 */
	
	public final Throwable getErrorInformation()
	{
		return this.errorInformation;
	}
	
	/**
	 * Returns the set of system properties for this configuration.
	 * <p>
	 * @return	The set of system properties as a <code>LinkedHashMap</code>,
	 * 			which maintains the order in which the list was prepared.
	 */
	
	public final LinkedHashMap<String, String> getSystemProperties()
	{
		LinkedHashMap<String, String> map = null;
		
		map = new LinkedHashMap<>();
		
		map.put(SigConstants.VSA_NAME,
					   StringUtil.format(this.getVSAName()));
		
		map.put(SigConstants.STORE_NAME,
					   StringUtil.format(this.getStoreName()));
		
		map.put(SigConstants.STORE_NUMBER,
					   StringUtil.format(this.getStoreNumber()));
		
		map.put(SigConstants.DIVISION,
					   StringUtil.format(this.getDivision()));

		map.put(SigConstants.DIVISION_NUMBER,
					   StringUtil.format(this.getDivisionNumber()));
		
		map.put(SigConstants.VALIDATE_STORE_DIVISION,
					   StringUtil.format(this.validateStoreDivision()));
		
		map.put(SigConstants.USE_STORE_VALIDATION_LIST, 
				StringUtil.format(this.useStoreValidationList()));
		
		map.put(SigConstants.STORE_VALIDATION_LIST_FILE, 
				StringUtil.format(this.getStoreValidationListFile()));
		
		map.put(SigConstants.LOGGER_CONFIG_FILE,
					   StringUtil.format(this.getLoggerConfigFile()));
		
		map.put(SigConstants.LOG_ROUTE_MESSAGE,
					   StringUtil.format(this.logSigRouteMessage()));
		
		map.put(SigConstants.MAX_BACKOUT_COUNT,
					   this.getMaxBackoutCount().toString());

		map.put(SigConstants.ENABLE_MAX_BACKOUT_COUNT,
					   StringUtil.format(this.isMaxBackoutCountEnabled()));
		
		map.put(SigConstants.ROLLBACK_DELAY,
					   this.getRollbackDelay().toString());
		
		map.put(SigConstants.CONFIG_RELOAD_INTERVAL,
					   this.getConfigReloadInterval().toString());
		
		map.put(SigConstants.PUBLISH_ERRORS,
					   StringUtil.format(this.publishErrors()));

		map.put(SigConstants.ERROR_TOPIC_STRING,
					   StringUtil.format(this.getErrorTopicString()));

		map.put(SigConstants.FILE_BUFFER_LENGTH,
					   this.getFileBufferLength().toString());
		
		map.put(SigConstants.STATUS_TOPIC_STRING,
					   StringUtil.format(this.getStatusTopicString()));

		map.put(SigConstants.BASE_DIRECTORY,
					   StringUtil.format(SigConfig.getBaseDir()));
		
		map.put(SigConstants.CONFIG_DIRECTORY,
					   StringUtil.format(SigConfig.getConfigDir()));
		
		map.put(SigConstants.LOG_DIRECTORY,
					   StringUtil.format(SigConfig.getLogDir()));

		map.put(SigConstants.DATA_FILE_DIRECTORY,
					   StringUtil.format(SigConfig.getDataFileDir()));
		
		map.put(SigConstants.TEMP_DIRECTORY,
					   StringUtil.format(SigConfig.getTmpDir()));
		
		map.put(SigConstants.XFER_DIRECTORY,
					   StringUtil.format(SigConfig.getXferDir()));

		map.put(SigConstants.OUTBOUND_XFER_DIRECTORY,
					   StringUtil.format(SigConfig.getOutboundXferDir()));
		
		map.put(SigConstants.INBOUND_XFER_DIRECTORY,
					   StringUtil.format(SigConfig.getInboundXferDir()));
		
		return map;
	}
	
	/**
	 * Returns a string containing details about the object, primarily
	 * used for debugging purposes.
	 * <p>
	 * @return		A string containing details about the object.
	 */

	@Override
	public String toString()
	{
		String sRet = null;
		StringBuilder sb = null;
		Long nLongVal = null;
		
		try
		{
			sb = new StringBuilder(Defines.IO_BUF_SIZE);
			
			sb.append(this.getClass().getName());
			sb.append(':');
			sb.append(Util.lineSeparator());
			sb.append("  VSAName=");
			sb.append(StringUtil.format(this.getVSAName()));
			sb.append(Util.lineSeparator());
			sb.append("  StoreName=");
			sb.append(StringUtil.format(this.getStoreName()));
			sb.append(Util.lineSeparator());
			sb.append("  StoreNumber=");
			sb.append(StringUtil.format(this.getStoreNumber()));
			sb.append(Util.lineSeparator());
			sb.append("  DivisionNumber=");
			sb.append(StringUtil.format(this.getDivisionNumber()));
			sb.append(Util.lineSeparator());
			sb.append("  Division=");
			sb.append(StringUtil.format(this.getDivision()));
			sb.append(Util.lineSeparator());
			sb.append("  validateStoreDivision=");
			sb.append(StringUtil.format(this.validateStoreDivision()));
			sb.append(Util.lineSeparator());
			sb.append("  useStoreValidationList=");
			sb.append(StringUtil.format(this.useStoreValidationList()));
			sb.append(Util.lineSeparator());
			sb.append("  storeValidationListFile=");
			sb.append(StringUtil.format(this.getStoreValidationListFile()));
			sb.append(Util.lineSeparator());
			sb.append("  loggerConfigFile=");
			sb.append(StringUtil.format(this.getLoggerConfigFile()));
			sb.append(Util.lineSeparator());
			sb.append("  logSigRouteMessage=");
			sb.append(StringUtil.format(this.logSigRouteMessage()));
			sb.append(Util.lineSeparator());
			sb.append("  testSigRouteMessage=");
			sb.append(StringUtil.format(this.testSigRouteMessage()));
			sb.append(Util.lineSeparator());
			nLongVal = this.getMaxBackoutCount();
			sb.append("  maxBackoutCount=");
			sb.append(nLongVal == null ? "{null}" : nLongVal.toString());
			sb.append(Util.lineSeparator());
			sb.append("  enableMaxBackoutCount=");
			sb.append(StringUtil.format(this.isMaxBackoutCountEnabled()));
			sb.append(Util.lineSeparator());
			nLongVal = this.getRollbackDelay();
			sb.append("  rollbackDelay=");
			sb.append(nLongVal == null ? "{null}" : nLongVal.toString());
			sb.append(Util.lineSeparator());
			nLongVal = this.getConfigReloadInterval();
			sb.append("  configReloadInterval=");
			sb.append(nLongVal == null ? "{null}" : nLongVal.toString());
			sb.append(Util.lineSeparator());
			sb.append("  publishErrors=");
			sb.append(StringUtil.format(this.publishErrors()));
			sb.append(Util.lineSeparator());
			sb.append("  errorTopicString=");
			sb.append(StringUtil.format(this.getErrorTopicString()));
			sb.append(Util.lineSeparator());
			nLongVal = this.getFileBufferLength();
			sb.append("  fileBufferLength=");
			sb.append(nLongVal == null ? "{null}" : nLongVal.toString());
			sb.append(Util.lineSeparator());
			sb.append("  statusTopicString=");
			sb.append(StringUtil.format(this.getStatusTopicString()));
			
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			nLongVal = null;
		}
		return sRet;
	}
	
	//----------------------------------------------------------------
	// Abstract methods that must be implemented by derived classes.
	//----------------------------------------------------------------

	/**
	 * Called to setup the application specific configuration.
	 * <p>
	 * @param	appListBase		Application List from base config.
	 * @param	appListStore	Application List from store config. 
	 */
	
	protected abstract void setApplicationConfigSpecs(
									final ArrayList<Element> appListBase,
									final ArrayList<Element> appListStore);

	/**
	 * Called to clear any application configuration data.
	 */

	protected abstract void clearApplicationConfigSpecs();

	/**
	 * Returns the set of components and their associated properties.
	 * <p>
	 * @return		The set of components and their associated properties.
	 */
	
	protected abstract LinkedHashMap<String, LinkedHashMap<String, String>>	getComponentProperties();
	
	//----------------------------------------------------------------
	// Protected methods available to derived classes.
	//----------------------------------------------------------------

	/**
	 * Returns the value of the named property from the set of base 
	 * properties and store properties. If the store property is not
	 * set, the value of the base property is used.
	 * <p>
	 * @param	basePropertyElements	Set of base properties.
	 * @param	storePropertyElements	Set of store properties.
	 * @param	sName					The name of the property.
	 * <p>
	 * @return		The value of the named property.
	 */
	
	protected final String getPropertyValue(
								final ArrayList<Element> basePropertyElements,
								final ArrayList<Element> storePropertyElements,
								final String sName)
	{
		String sRet = null;
		String sStoreValue = null;
		
		try
		{
			sRet = this.getPropertyValue(basePropertyElements, sName);
			
			sStoreValue = this.getPropertyValue(storePropertyElements, sName);
			
			if (StringUtil.isEmpty(sStoreValue) == false)
			{
				sRet = sStoreValue;
			}
		}
		finally
		{
			sStoreValue = null;
		}
		return sRet;
	}

	/**
	 * Returns the Boolean value of the named property from the set of base 
	 * properties and store properties. If the store property is not
	 * set, the value of the base property is used.
	 * <p>
	 * @param	basePropertyElements	Set of base properties.
	 * @param	storePropertyElements	Set of store properties.
	 * @param	sName				The name of the property.
	 * <p>
	 * @return		The value of the named property as a Boolean.
	 */
	
	protected final Boolean getBooleanPropertyValue(
							final ArrayList<Element> basePropertyElements,
							final ArrayList<Element> storePropertyElements,
							final String sName)
	{
		Boolean bRet = Boolean.FALSE;
		String sValue = null;
		String sStoreValue = null;
		
		try
		{
			sValue = this.getPropertyValue(basePropertyElements, sName);
			
			sStoreValue = this.getPropertyValue(storePropertyElements, sName);
			
			if (StringUtil.isEmpty(sStoreValue) == false)
			{
				sValue = sStoreValue;
			}
			if (StringUtil.isEmpty(sValue) == false)
			{
				bRet = Boolean.valueOf(StringUtil.parseBoolean(sValue));
			}
		}
		finally
		{
			sValue = null;
			sStoreValue = null;
		}
		return bRet;
	}
	
	/**
	 * Returns the Long value of the named property from the set of base 
	 * properties and store properties. If the store property is not
	 * set, the value of the base property is used.
	 * <p>
	 * @param	basePropertyElements	Set of base properties.
	 * @param	storePropertyElements	Set of store properties.
	 * @param	sName				The name of the property.
	 * <p>
	 * @return		The value of the named property as a Long.
	 */
	
	protected final Long getLongPropertyValue(
							final ArrayList<Element> basePropertyElements,
							final ArrayList<Element> storePropertyElements,
							final String sName)
	{
		Long nRet = new Long(0);
		String sValue = null;
		String sStoreValue = null;
		
		try
		{
			sValue = this.getPropertyValue(basePropertyElements, sName);
			
			sStoreValue = this.getPropertyValue(storePropertyElements, sName);
			
			if (StringUtil.isEmpty(sStoreValue) == false)
			{
				sValue = sStoreValue;
			}
			if (StringUtil.isEmpty(sValue) == false)
			{
				nRet = Long.valueOf(StringUtil.parseLong(sValue, 0));
			}
		}
		finally
		{
			sValue = null;
			sStoreValue = null;
		}
		return nRet;
	}

	/**
	 * Returns the value of the named property from the list of property
	 * elements.
	 * <p>
	 * @param	propertyElements	The list of property elements.
	 * @param	sName			The property name.
	 * <p>
	 * @return		The value of the property.
	 */
	
	protected final String getPropertyValue(
									final ArrayList<Element> propertyElements,
									final String sName)
	{
		String sRet = null;
		Element element = null;
		String sPropertyName = null;
		
		try
		{
			if (propertyElements != null && StringUtil.isEmpty(sName) == false)
			{
				for (int i = 0 ; i < propertyElements.size() && sRet == null ; ++i)
				{
					element = propertyElements.get(i);
					
					if (element != null)
					{
						sPropertyName = 
							element.getAttribute(
									SigConstants.NAME_ATTRIBUTE);
						
						if (sPropertyName != null)
						{
							if (sPropertyName.equals(sName))
							{
								sRet = element.getTextContent();
							}
						}
					}
				}
			}
		}
		finally
		{
			element = null;
			sPropertyName = null;
		}
		return sRet;
	}
		
	/**
	 * Returns the specified application Element from the list of 
	 * application Elements.
	 * <p> 
	 * @param	appList		The list of application Elements.
	 * @param	sName		The name of the application Element to return.
	 * <p>
	 * @return		The specified application element, or <code>null</code>
	 * 				if it is not found.
	 */
	
	protected final Element getApplicationElement(
										final ArrayList<Element> appList,
										final String sName)
	{
		Element appElement = null;
		Element element = null;
		String sAppName = null;
		
		try
		{
			if (appList != null && StringUtil.isEmpty(sName) == false)
			{
				for (int i = 0 ; i < appList.size() && appElement == null ; ++i)
				{
					element = appList.get(i);
					
					if (element != null)
					{
						sAppName = 
							element.getAttribute(
									SigConstants.NAME_ATTRIBUTE);
						
						if (sAppName != null)
						{
							if (sAppName.equals(sName))
							{
								appElement = element;
							}
						}
					}
				}
			}
		}
		finally
		{
			element = null;
			sAppName = null;
		}
		return appElement;
	}

	/**
	 * Loads the configuration specifications from the base and store
	 * specific configuration files.
	 */
	
	protected final void loadConfigSpecs()
	{
		this.readConfigSpecFiles();
		
		this.setConfigSpecs();
		
		this.nBaseConfigLastModified = FileUtil.lastModified(this.sBaseConfig);
		this.nBaseConfigLength = FileUtil.length(this.sBaseConfig);
		this.nConfigLastModified = FileUtil.lastModified(this.sStoreConfig);
		this.nConfigLength = FileUtil.length(this.sStoreConfig);
	}

	/**
	 * Returns the set of base properties associated with the specified
	 * application.
	 * <p>
 	 * @param	appListBase		List of application Elements in the base
 	 * 							config.
	 * @param	sApplication	The application name.
	 * <p>
	 * @return		The set of properties associated with the specified
	 * 				application, or <code>null</code> if there are none.
	 */
	
	protected final ArrayList<Element> getBasePropertyElements(
								final ArrayList<Element> appListBase,
								final String sApplication)
	{
		ArrayList<Element> propList = null;
		Element element = null;
		
		try
		{
			if (appListBase != null)
			{
				element = 
					this.getApplicationElement(appListBase, sApplication);
			}
			propList = this.getBasePropertyElements(element);
		}
		finally
		{
			element = null;
		}
		return propList;
	}

	/**
	 * Returns the set of store properties associated with the specified
	 * application.
	 * <p>
 	 * @param	appListStore	List of application Elements in the store
 	 * 							config.
	 * @param	sApplication	The application name.
	 * <p>
	 * @return		The set of properties associated with the specified
	 * 				application, or <code>null</code> if there are none.
	 */
	
	protected final ArrayList<Element> getStorePropertyElements(
									final ArrayList<Element> appListStore,
									final String sApplication)
	{
		ArrayList<Element> propList = null;
		Element element = null;
		
		try
		{
			if (appListStore != null)
			{
				element = 
					this.getApplicationElement(appListStore, sApplication);
			}
			propList = this.getStorePropertyElements(element);
		}
		finally
		{
			element = null;
		}
		return propList;
	}

	/**
	 * Returns the specified properties list for the specified
	 * application.
	 * <p>
	 * @param	appListBase		List of application Elements in the base
	 * 							config.
 	 * @param	appListStore	List of application Elements in the store
 	 * 							config.
	 * @param	sApplication	The application name.
	 * @param	sName			The name of the properties list.
	 * <p>
	 * @return		The properties list for the specified
	 * 				application, or <code>null</code> if there is none.
	 */
	
	protected final NvList getApplicationPropertyList(
									final ArrayList<Element> appListBase,
									final ArrayList<Element> appListStore,
									final String sApplication,
									final String sName)
	{
		NvList nvList = null;
		Properties propList = null;
		Element propListElement = null;
		Enumeration<?> e = null;
		String sKey = null;
		String sValue = null;

		try
		{
			/**
			 * Check for the propertyList in the Store configuration first.
			 * The Store configuration overrides the base configuration. If
			 * the propertyList is not present in the Store configuration,
			 * then check the base configuration.
			 */
			
			propListElement = this.getPropertyListElement(appListStore, sApplication, sName);
			
			if (propListElement == null)
			{
				propListElement = this.getPropertyListElement(appListBase, sApplication, sName);
			}
			propList = this.getPropertyList(propListElement);

			if (propList == null)
			{
				SigLogger.logWarn(this.getClass(), "getApplicationPropertyList()", 
						"Did not find propertyList named " +
						StringUtil.format(sName) +
						" for application " +
						StringUtil.format(sApplication) + '!');
			}
			else
			{
				// Convert the Properties object to an NvList object.
				
				nvList = new NvList(propList.size());
				
				e = propList.propertyNames();
				
				while (e.hasMoreElements() == true)
				{
					sKey = (String)e.nextElement();
						
					if (sKey != null)
					{
						sValue = propList.getProperty(sKey);
						
						if (sValue != null)
						{
							nvList.add(sKey, sValue);
						}
					}
				}
			}
		}
		finally
		{
			if (propList != null)
			{
				propList.clear();
				propList = null;
			}
			propListElement = null;
		}
		return nvList;
	}

	/**
	 * Helper method used to return the size of the <code>NvList</code>
	 * containing the specified <code>propertyList</code>.
	 * <p>
	 * @param	nvList		The list containing the propertyList keys
	 * 						and values.
	 * <p>
	 * @return		The size of the list.
	 */
	
	protected final int getPropertyListSize(final NvList nvList)
	{
		int nRet = 0;
		
		if (nvList != null)
		{
			nRet = nvList.length();
		}
		return nRet;
	}
	
	/**
	 * Helper method used to return the key at the specified index within
	 * the <code>propertyList</code>.
	 * <p>
	 * @param	nvList		The list containing the propertyList keys
	 * 						and values.
	 * @param	ndx			The index within the list.
	 * <p>
	 * @return		The key at the specified index.
	 */
	
	protected final String getPropertyListKey(final NvList nvList, final int ndx)
	{
		String sRet = null;
		NvPair nvPair = null;
		
		try
		{
			if (nvList != null)
			{
				nvPair = nvList.get(ndx);
				
				if (nvPair != null)
				{
					sRet = nvPair.getName();
				}
			}
		}
		catch(Throwable th)
		{
			SigLogger.logError(this.getClass(), "getPropertyListKey()",
				"Error gettting key at index " + Integer.toString(ndx) + '!', th);
			
			sRet = null;
		}
		finally
		{
			// Note: Do not clear the NvPair, it is a reference and not
			// a copy. Clearing it will result in altering the list itself.
		}
		return sRet;
	}
	
	/**
	 * Helper method used to return the value at the specified index within
	 * the <code>propertyList</code>.
	 * <p>
	 * @param	nvList		The list containing the propertyList keys
	 * 						and values.
	 * @param	ndx			The index within the list.
	 * <p>
	 * @return		The key at the specified index.
	 */
	
	protected final String getPropertyListValue(final NvList nvList, final int ndx)
	{
		String sRet = null;
		NvPair nvPair = null;
		
		try
		{
			if (nvList != null)
			{
				nvPair = nvList.get(ndx);
				
				if (nvPair != null)
				{
					sRet = nvPair.getValue();
				}
			}
		}
		catch(Throwable th)
		{
			SigLogger.logError(this.getClass(), "getPropertyListValue()",
				"Error gettting value at index " + Integer.toString(ndx) + '!', th);
			
			sRet = null;
		}
		finally
		{
			// Note: Do not clear the NvPair, it is a reference and not
			// a copy. Clearing it will result in altering the list itself.
		}
		return sRet;
	}

	/**
	 * Helper method used to add the specified <code>propertyList</code> 
	 * values to the set of properties associated with a component. This
	 * is typically used when retrieving the status of the service.
	 * <p>
	 * @param	prop		The set of properties associated with the
	 * 						component to which the list keys and values
	 * 						will be added.
	 * @param	nvList		The list containing the propertyList keys
	 * 						and values.
	 * @param	sName		The name of the propertyList as specified in
	 * 						the configuration.
	 */
	
	protected final void setComponentPropertyList(
							final LinkedHashMap<String, String> prop,
							final NvList nvList,
							final String sName)
	{
		String sKey = null;
		String sValue = null;
		NvPair nvPair = null;
		
		try
		{
			if (prop != null)
			{
				if (nvList == null)
				{
					prop.put(SigConstants.PROPERTY_LIST_ELEMENT + '.' + 
						 StringUtil.format(sName), null);
				}
				else
				{
					for (int i = 0 ; i < nvList.length() ; ++i)
					{
						nvPair = nvList.get(i);
						
						if (nvPair != null)
						{
							sKey = nvPair.getName();
							sValue = nvPair.getValue();
					
							prop.put(SigConstants.PROPERTY_LIST_ELEMENT + '.' +
									StringUtil.format(sName) + '[' + 
									Integer.toString(i) + ']',
									StringUtil.format(sKey) + '=' + 
									StringUtil.format(sValue));
						}
					}
				}
			}
		}
		catch (Throwable ignore)
		{
			SigLogger.logError(this.getClass(), "setComponentPropertyList()",
					"Error setting propertyList elements in set of properties!",
					ignore);
			
			// Ignore errors. If an error does occur it is because of an
			// array index out of range.
		}
		finally
		{
			sKey = null;
			sValue = null;
			nvPair = null;
		}
	}
	
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	/**
	 * Clears the configuration specifications.
	 */
	
	private final void clearConfig()
	{
		if (this.xmlDocBase != null)
		{
			this.xmlDocBase.destroy();
			this.xmlDocBase = null;
		}
		if (this.xmlDocStore != null)
		{
			this.xmlDocStore.destroy();
			this.xmlDocStore = null;
		}
		this.sVSAName = null;
		this.sStoreName = null;
		this.sStoreNumber = null;
		this.sDivisionNumber = null;
		this.sDivision = null;
		this.bValidateStoreDivision = null;
		this.bUseStoreValidationList = null;
		this.bLogRouteMessage = null;
		this.bTestRouteMessage = null;
		this.nMaxBackoutCount = null;
		this.bEnableMaxBackoutCount = null;
		this.nRollbackDelay = null;
		this.nConfigReloadInterval = null;
		this.errorInformation = null;
		this.sErrorTopicString = null;
		this.nFileBufferLength = null;
		this.sStatusTopicString = null;
		
		this.clearApplicationConfigSpecs();
	}
	
	/**
	 * Gets and initializes the core XML documents containing the base and
	 * store configuration specifications.
	 */
	
	private final void readConfigSpecFiles()
	{
		File fileBaseConfigSpec = null;
		File fileStoreConfigSpec = null;
		
		try
		{
			if (StringUtil.isEmpty(this.sBaseConfig) == false)
			{
				fileBaseConfigSpec = new File(this.sBaseConfig);

				this.xmlDocBase = new XmlDoc(fileBaseConfigSpec);
			}
			if (StringUtil.isEmpty(this.sStoreConfig) == false)
			{
				fileStoreConfigSpec = new File(this.sStoreConfig);
				
				/**
				 * If we can't read the store config file, then
				 * we will use the defaults in the base config.
				 */
				
				if (fileStoreConfigSpec.canRead() == true)
				{
					this.xmlDocStore = new XmlDoc(fileStoreConfigSpec);
				}
			}
		}
		catch (ParserConfigurationException e)
		{
			this.errorInformation = e;
		}
		catch (IOException e)
		{
			this.errorInformation = e;
		}
		catch (SAXException e)
		{
			this.errorInformation = e;
		}
		finally
		{
			fileBaseConfigSpec = null;
			fileStoreConfigSpec = null;
		}
	}

	/**
	 * Sets the configuration specs from the base configuration 
	 * and the store configuration.
	 */
	
	private final void setConfigSpecs()
	{
		ArrayList<Element> appListBase = null;
		ArrayList<Element> appListStore = null;
		Element parentElement = null;
		
		try
		{
			this.setSystemConfigSpecs();
			
			if (this.xmlDocBase != null)
			{
				parentElement = 
					this.xmlDocBase.getElement(this.sDocParentElement);
				
				appListBase =
					this.xmlDocBase.getElementList(
						parentElement, SigConstants.APPLICATION_ELEMENT);
			}
			if (this.xmlDocStore != null)
			{
				parentElement =
					this.xmlDocStore.getElement(this.sDocParentElement);
				
				appListStore =
					this.xmlDocStore.getElementList(
						parentElement, SigConstants.APPLICATION_ELEMENT);
			}
			this.setApplicationConfigSpecs(appListBase, appListStore);
		}
		finally
		{
			if (appListBase != null)
			{
				appListBase.clear();
				appListBase = null;
			}
			if (appListStore != null)
			{
				appListStore.clear();
				appListStore = null;
			}
			parentElement = null;
		}
	}
	
	/**
	 * Returns the <code>property</code> list contained within the 
	 * specified element of the base configuration document.
	 * <p>
	 * @param	parent		The parent element containing the property list.
	 * <p>
	 * @return			The list of <code>property</code> elements
	 * 					contained within the specified parent element.
	 */
	
	private final ArrayList<Element> getBasePropertyElements(final Element parent) 
	{
		return this.getPropertyElements(this.xmlDocBase, parent);
	}
	
	/**
	 * Returns the <code>property</code> list contained within the 
	 * specified element of the store configuration document.
	 * <p>
	 * @param	parent		The parent element containing the property list.
	 * <p>
	 * @return			The list of <code>property</code> elements
	 * 					contained within the specified parent element.
	 */
	
	private final ArrayList<Element> getStorePropertyElements(final Element parent) 
	{
		return this.getPropertyElements(this.xmlDocStore, parent);
	}
	
	/**
	 * Returns the <code>property</code> list contained within the 
	 * specified element of the specified document.
	 * <p>
	 * @param	xmlDoc		The XML document.
	 * @param	parent		The parent element containing the property list.
	 * <p>
	 * @return			The list of <code>property</code> elements
	 * 					contained within the specified parent element.
	 */
	
	private final ArrayList<Element> getPropertyElements(
									final XmlDoc xmlDoc, final Element parent) 
	{
		ArrayList<Element> propertyElements = null;

		if (parent != null && xmlDoc != null)
		{
			propertyElements = 
				xmlDoc.getElementList(
					parent, SigConstants.PROPERTY_ELEMENT);
		}
		return propertyElements;
	}
	
	/**
	 * Returns the <code>property</code> list contained within the 
	 * named parent element of the specified document.
	 * <p>
	 * @param	xmlDoc		The document containing named element.
	 * @param	sName		The name of the property element.
	 * <p>
	 * @return			The list of <code>property</code> elements
	 * 					contained within the specified parent element.
	 */
	
	private final ArrayList<Element> getPropertyElements(final XmlDoc xmlDoc, 
													   final String sName)
	{
		ArrayList<Element> propertyElements = null;
		Element element = null;
		
		try
		{
			if (xmlDoc != null && StringUtil.isEmpty(sName) == false)
			{
				element = xmlDoc.getElement(sName);
			
				if (element != null)
				{
					propertyElements = 
						xmlDoc.getElementList(
								element, SigConstants.PROPERTY_ELEMENT);
				}
			}
		}
		finally
		{
			element = null;
		}
		return propertyElements;
	}

	/**
	 * Sets the system configuration specs from the base configuration
	 * and the store configuration.
	 */

	private final void setSystemConfigSpecs()
	{
		ArrayList<Element> systemBaseProperties = null;
		ArrayList<Element> systemStoreProperties = null;
		
		try
		{
			systemBaseProperties = 
					this.getPropertyElements(this.xmlDocBase, 
										 SigConstants.SYSTEM_ELEMENT);
			systemStoreProperties = 
					this.getPropertyElements(this.xmlDocStore, 
										SigConstants.SYSTEM_ELEMENT);
			this.sVSAName =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.VSA_NAME);
			
			this.setVSAName();		// Set if not set in the config.
			
			this.sStoreName = 
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.STORE_NAME);

			this.setStoreName();	// Set if not set in the config.
			
			this.sStoreNumber =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.STORE_NUMBER);
			
			this.setStoreNumber();	// Set if not set in the config.
			
			this.sStoreNumber = 
					StringUtil.rightJustify(this.sStoreNumber, 
							SigConfigSpec.STORE_NUMBER_LENGTH, '0');
			
			this.sDivisionNumber =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.DIVISION_NUMBER);
			 
			this.sDivisionNumber = 
					StringUtil.rightJustify(this.sDivisionNumber, 
							SigConfigSpec.DIVISION_NUMBER_LENGTH, '0');
			
			this.sDivision =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.DIVISION);
			
			this.bValidateStoreDivision =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.VALIDATE_STORE_DIVISION);

			this.bUseStoreValidationList =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.USE_STORE_VALIDATION_LIST);

			this.sStoreValidationListFile =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.STORE_VALIDATION_LIST_FILE);

			this.sLoggerConfigFile =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.LOGGER_CONFIG_FILE);

			this.bLogRouteMessage =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.LOG_ROUTE_MESSAGE);
			
			this.bTestRouteMessage =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.TEST_ROUTE_MESSAGE);

			this.nMaxBackoutCount =
				this.getLongPropertyValue(
					systemBaseProperties, 
					systemStoreProperties, 
					SigConstants.MAX_BACKOUT_COUNT);
			
			this.bEnableMaxBackoutCount =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.ENABLE_MAX_BACKOUT_COUNT);
						
			this.nRollbackDelay =
				this.getLongPropertyValue(
					systemBaseProperties, 
					systemStoreProperties, 
					SigConstants.ROLLBACK_DELAY);

			if (this.nRollbackDelay == null)
			{
				this.nRollbackDelay = new Long(0);
			}
			this.nConfigReloadInterval =
				this.getLongPropertyValue(
					systemBaseProperties, 
					systemStoreProperties, 
					SigConstants.CONFIG_RELOAD_INTERVAL);

			if (this.nConfigReloadInterval == null)
			{
				this.nConfigReloadInterval = new Long(0);
			}
			this.bPublishErrors =
				this.getBooleanPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.PUBLISH_ERRORS);
						
			this.sErrorTopicString =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.ERROR_TOPIC_STRING);

			this.nFileBufferLength =
				this.getLongPropertyValue(
					systemBaseProperties, 
					systemStoreProperties, 
					SigConstants.FILE_BUFFER_LENGTH);

			this.sStatusTopicString =
				this.getPropertyValue(
					systemBaseProperties, systemStoreProperties, 
					SigConstants.STATUS_TOPIC_STRING);

			if (this.nFileBufferLength == null)
			{
				this.nFileBufferLength = 
							new Long(SigConfigSpec.DEF_FILE_BUFFER_LENGTH);
			}
			if (this.nFileBufferLength.longValue() <= 0)
			{
				this.nFileBufferLength = 
							new Long(SigConfigSpec.DEF_FILE_BUFFER_LENGTH);
			}
		}
		finally
		{
			if (systemBaseProperties != null)
			{
				systemBaseProperties.clear();
				systemBaseProperties = null;
			}
			if (systemStoreProperties != null)
			{
				systemStoreProperties.clear();
				systemStoreProperties = null;
			}
		}
	}
	
	/**
	 * Private method used to set the VSA name if it is not set.
	 */
	
	private final void setVSAName()
	{
		String sHost = null;
		int ndx = 0;
		
		try
		{
			if (StringUtil.isEmpty(this.sVSAName) == true)
			{
				sHost = NetUtil.getHostName();
				
				if (StringUtil.isEmpty(sHost) == false)
				{
					ndx = sHost.indexOf(".");
					
					if (ndx > 0)
					{
						this.sVSAName = sHost.substring(0, ndx);
					}
					else
					{
						this.sVSAName = sHost;
					}
				}
			}
		}
		finally
		{
			sHost = null;
		}
	}
	
	/**
	 * Private method used to set the Store name if it is not set.
	 */
	
	private final void setStoreName()
	{
		if (StringUtil.isEmpty(this.sStoreName) == true)
		{
			this.setVSAName();		// Set if not set.
		
			if (StringUtil.isEmpty(this.sVSAName) == false)
			{
				if (this.sVSAName.length() > 5)
				{
					this.sStoreName = this.sVSAName.substring(0, 5);
				}
				else
				{
					this.sStoreName = this.sVSAName;
				}
			}
		}
	}

	/**
	 * Private method used to set the store number if it is not set.
	 */
	
	private final void setStoreNumber()
	{
		if (StringUtil.isEmpty(this.sStoreNumber) == true)
		{
			this.setStoreName();		// Set if not set.
		
			if (StringUtil.isEmpty(this.sStoreName) == false)
			{
				if (this.sStoreName.length() == 5)
				{
					this.sStoreNumber = this.sStoreName.substring(2);
				}
				else
				{
					this.sStoreNumber = this.sStoreName;
				}
			}
		}
	}

	/**
	 * Returns the <code>propertyList</code> element of the specified name
	 * within the specified application.
	 * <p>
	 * @param	appList			List of application elements in the config.r
	 * @param	sApplication	The application name.
	 * @param	sName			The name of the properties list.
	 * <p>
	 * @return		The <code>propertyList</code> element for the specified
	 * 				name within the specified application.
	 */
	
	private final Element getPropertyListElement(final ArrayList<Element> appList,
												 final String sApplication,
												 final String sName)
	{
		Element propListElement = null;
		ArrayList<Element> propertyListElements = null;
		Element element = null;
		
		try
		{
			SigLogger.logDebug(this.getClass(), "getPropertyListElement()",
					"Searching for propertyList named " +
					StringUtil.format(sName) +
					" for application " +
					StringUtil.format(sApplication) + "...");
			
			if (appList != null)
			{
				element = 
					this.getApplicationElement(appList, sApplication);
			}
			propertyListElements = this.getPropertyListElements(this.xmlDocStore, element);
			
			propListElement = this.getPropertyListElement(propertyListElements, sName);
			
			if (propListElement == null)
			{
				SigLogger.logDebug(this.getClass(), "getPropertyListElement()", 
						"Did not find propertyList named " +
						StringUtil.format(sName) +
						" for application " +
						StringUtil.format(sApplication) + '!');
			}
			else
			{
				SigLogger.logDebug(this.getClass(), "getPropertyListElement()",
					"Found propertyList named " +
					StringUtil.format(sName) +
					" for application " +
					StringUtil.format(sApplication) + ".");
			}
		}
		finally
		{
			if (propertyListElements != null)
			{
				propertyListElements.clear();
				propertyListElements = null;
			}
			element = null;
		}
		return propListElement;
		
	}

	/**
	 * Returns the set of <code>propertyList</code> elements contained 
	 * within the specified element of the specified document.
	 * <p>
	 * @param	xmlDoc		The XML document.
	 * @param	parent		The parent element containing the propertyList
	 * 						elements.
	 * <p>
	 * @return			The list of <code>propertyList</code> elements
	 * 					contained within the specified parent element.
	 */
	
	private final ArrayList<Element> getPropertyListElements(
									final XmlDoc xmlDoc, final Element parent) 
	{
		ArrayList<Element> propertyListElements = null;

		if (parent != null && xmlDoc != null)
		{
			propertyListElements = 
				xmlDoc.getElementList(
					parent, SigConstants.PROPERTY_LIST_ELEMENT);
		}
		return propertyListElements;
	}

	/**
	 * Returns the element containing the named propertyList.
	 * <p>
	 * @param	propertyListElements	The set of propertyList elements.
	 * @param	sName					The propertyList name.
	 * <p>
	 * @return		The element containing the named propertyList.
	 */
	
	private final Element getPropertyListElement(
									final ArrayList<Element> propertyListElements,
									final String sName)
	{
		Element propertyListElement = null;
		Element element = null;
		String sPropertyName = null;
		
		try
		{
			if (propertyListElements != null && StringUtil.isEmpty(sName) == false)
			{
				for (int i = 0 ; i < propertyListElements.size() && propertyListElement == null ; ++i)
				{
					element = propertyListElements.get(i);
					
					if (element != null)
					{
						sPropertyName = 
							element.getAttribute(
									SigConstants.NAME_ATTRIBUTE);
						
						if (sPropertyName != null)
						{
							if (sPropertyName.equals(sName))
							{
								propertyListElement =  element;
							}
						}
					}
				}
			}
		}
		finally
		{
			element = null;
			sPropertyName = null;
		}
		return propertyListElement;
	}
	
	/**
	 * Builds the list of properties (key/value pairs) from the specified
	 * <code>propertyList</code> element.
	 * <p>
	 * @param	propListElement		The propertyList element containing
	 * 								the key/value pairs.
	 * <p>
	 * @return		A Properties object containig the set of key/value pairs. 
	 */
	
	private Properties getPropertyList(final Element propListElement)
	{
		Properties propList = null;
		ArrayList<Element> itemElements = null;
		Element element = null;
		String sPropKey = null;
		String sPropValue = null;
		
		try
		{
			if (propListElement != null)
			{	
				itemElements = this.getItemElements(this.xmlDocStore, propListElement);
				
				if (itemElements != null)
				{
					SigLogger.logDebug(this.getClass(), "getPropertyList()", "Found " +
							Integer.toString(itemElements.size()) + " property items.");

					for (int i = 0 ; i < itemElements.size() ; ++i)
					{
						element = itemElements.get(i);
					
						if (element != null)
						{
							sPropKey = 
								element.getAttribute(
									SigConstants.KEY_ATTRIBUTE);
						
							sPropValue =
								element.getAttribute(
									SigConstants.VALUE_ATTRIBUTE);
							
							if (sPropKey != null && sPropValue != null)
							{
								if (propList == null)
								{
									propList = new Properties();
								}
								propList.setProperty(sPropKey, sPropValue);
							}
						}
					}
				}
				else
				{
					SigLogger.logDebug(this.getClass(), "getPropertyList()", 
							"Array of itemElements is null!");
				}
			}
			else
			{
				SigLogger.logDebug(this.getClass(), "getPropertyList()", "propListElement is null!");
			}
		}
		finally
		{
			if (itemElements != null)
			{
				itemElements.clear(); 
				itemElements = null;
			}
			element = null;
			sPropKey = null;
			sPropValue = null;
		}
		return propList;
	}

	/**
	 * Returns the set of <code>item</code> elements contained 
	 * within the specified <propertyList> element of the document.
	 * <p>
	 * @param	xmlDoc		The XML document.
	 * @param	parent		The parent element containing the item
	 * 						elements.
	 * <p>
	 * @return			The list of <code>item</code> elements
	 * 					contained within the specified element.
	 */
	
	private final ArrayList<Element> getItemElements(
									final XmlDoc xmlDoc, final Element parent) 
	{
		ArrayList<Element> itemElements = null;

		if (parent != null && xmlDoc != null)
		{
			itemElements = 
				xmlDoc.getElementList(
					parent, SigConstants.ITEM_ELEMENT);
		}
		return itemElements;
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------

	private static final String DEF_DOC_PARENT_ELEMENT = "ServiceConfig";

	private static final int STORE_NUMBER_LENGTH = 5;
	private static final int DIVISION_NUMBER_LENGTH = 3;
	
	private static final long DEF_FILE_BUFFER_LENGTH = (1024 * 512);
	
	private String sBaseConfig = null;
	private String sStoreConfig = null;
	
	private String sDocParentElement = null;
	
	private XmlDoc xmlDocBase = null;
	private XmlDoc xmlDocStore = null;
	
	private String sVSAName = null;
	private String sStoreName = null;
	private String sStoreNumber = null;
	private String sDivisionNumber = null;
	private String sDivision = null;
	private Boolean bValidateStoreDivision = null;
	private Boolean bUseStoreValidationList = null;
	private String sStoreValidationListFile = null;
	private String sLoggerConfigFile = null;
	private Boolean bLogRouteMessage = null;
	private Boolean bTestRouteMessage = null;
	private Long nMaxBackoutCount = null;
	private Boolean bEnableMaxBackoutCount = null;
	private Long nRollbackDelay = null;
	private Long nConfigReloadInterval = null;
	private Boolean bPublishErrors = null;
	private String sErrorTopicString = null;
	private Long nFileBufferLength = null;
	private String sStatusTopicString = null;
	private Throwable errorInformation = null;
	
	private long nLastReloadCheck = -1;
	private long nBaseConfigLastModified = -1;
	private long nBaseConfigLength = -1;
	private long nConfigLastModified = -1;
	private long nConfigLength = -1;
}
