/**
 * SigUtil.java
 */

package com.gianteagle.is.sig.base;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TimeZone;

import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.net.HttpUtil;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

import com.gianteagle.is.sig.base.SigLogger;

/**
 * Class used to manage service related utility methods.
 * <p>
 * @author	ReichertSF
 */

public final class SigUtil
{
	/**
	 * Default constructor.
	 */
	
	private SigUtil()
	{
	}

	/**
	 * Returns the current time in milliseconds as a <code>Long</code>.
	 * <p>
	 * @return		The current time in milliseconds.
	 */
	
	public static Long currentTimeMillis()
	{
		return new Long(System.currentTimeMillis());
	}
	
	/**
	 * Returns the current UTC time in milliseconds as a <code>Long</code>.
	 * <p>
	 * This method should be used when the time needs to be daylight saving
	 * time agnostic. The value will continue to increment, as expected,
	 * where as currentTimeMillis() is affected by a 1 hour time differentail
	 * when changing to/from daylight saving time.
	 * <p>
	 * @return		The current UTC time in milliseconds.
	 */
	
	public static Long currentUTCTimeMillis()
	{
		Long nRet = null;
		TimeZone tz = null;
		Calendar cal = null;
		Date date = null;
		
		try
		{
			tz = TimeZone.getTimeZone("GMT");
			cal = Calendar.getInstance(tz);
			date = cal.getTime();
			
			nRet = new Long(date.getTime());
		}
		finally
		{
			tz = null;
			cal = null;
			date = null;
		}
		return nRet;
	}
	
	/**
	 * Returns the short timezone name for this system (EST, EDT, CST, etc.
	 * <p>
	 * @return		The short timezone name.
	 */
	
	public static String getShortTimeZoneName()
	{
		String sRet = null;
		TimeZone tz = null;
		
		try
		{
			tz = TimeZone.getDefault();
			
			sRet = tz.getDisplayName(tz.useDaylightTime(), TimeZone.SHORT);
		}
		finally
		{
			tz = null;
		}
		return sRet;
	}
	
	/**
	 * Returns the contents of a file as a byte array.
	 * <p>
	 * @param	sFile	The name of the file.
	 * <p>
	 * @return		The contents of the file as a byte array, or 
	 * 				<code>null</code> if the file does not exist.
	 */
	
	public static byte[] getFileAsBtyeArray(final String sFile)
	{
		byte[] byteRet = null;
		
		try
		{
			if (StringUtil.isEmpty(sFile) == false)
			{
				byteRet = FileUtil.fileToByteArray(sFile);
			}
		}
		catch (Throwable th)
		{
			byteRet = null;
		}
		return byteRet;
	}
	
	/**
	 * Convenience method used to construct a file name from the specified
	 * directory and file name. This method concatentates the directory
	 * name, a <code>file.separator</code>, and the file name.
	 * <p>
	 * @param	sDir		The directory name.
	 * @param	sName		The file name.
	 * <p>
	 * @return		The complete path name for the file.
	 */
	
	public static String makeFileName(final String sDir, final String sName)
	{
		return FileUtil.makeFileName(sDir, sName);
	}
	
	/**
	 * Method used to delete the specified file.
	 * <p>
	 * @param	sFullPathName	The full path name of the file.
	 */

	public static void deleteFile(final String sFullPathName)
	{
		try
		{
			if (StringUtil.isEmpty(sFullPathName) == false)
			{
				FileUtil.delete(sFullPathName);
			}
		}
		catch (Throwable th)
		{
		}
	}

	/**
	 * Method used to copy the specified file.
	 * <p>
	 * @param	sSourceFile		The full path name of the source file.
	 * @param	sDestFile		The full path name of the destination file.
	 */

	public static void copyFile(final String sSourceFile, final String sDestFile)
	{
		try
		{
			if (StringUtil.isEmpty(sSourceFile) == false &&
				StringUtil.isEmpty(sDestFile) == false)
			{
				FileUtil.copy(sSourceFile, sDestFile, false);
			}
		}
		catch (Throwable th)
		{
		}
	}

	/**
	 * Method used to rename the specified file.
	 * <p>
	 * @param	sSourceFile		The full path name of the source file.
	 * @param	sDestFile		The full path name of the destination file.
	 */

	public static void renameFile(final String sSourceFile, final String sDestFile)
	{
		try
		{
			if (StringUtil.isEmpty(sSourceFile) == false &&
				StringUtil.isEmpty(sDestFile) == false)
			{
				FileUtil.rename(sSourceFile, sSourceFile);
			}
		}
		catch (Throwable th)
		{
		}
	}

	/**
	 * Returns the size of the specified file in bytes. If the file does not
	 * exist, 0 is returned.
	 * <p>
	 * @param	sFullPathName	The full path name of the file.
	 * <p>
	 * @return		The size of the specified file in bytes.
	 */
	
	public static Long getFileSize(final String sFullPathName)
	{
		Long nRet = null;
		
		try
		{
			nRet = new Long(0);
			
			if (FileUtil.exists(sFullPathName) == true)
			{
				nRet = Long.valueOf(FileUtil.length(sFullPathName));
			}
		}
		catch (Throwable ignore)
		{
			nRet = new Long(0);
		}
		return nRet;
	}
	
	/**
	 * Returns the last modification time, in epoch time, for the specified
	 * file. If the file does not exist, 0 is returned.
	 * <p>
	 * @param	sFullPathName	The full path name of the file.
	 * <p>
	 * @return		The last modification time of the file.
	 */
	
	public static Long getFileLastModificationTime(final String sFullPathName)
	{
		Long nRet = null;
		
		try
		{
			nRet = new Long(0);
			
			if (FileUtil.exists(sFullPathName) == true)
			{
				nRet = Long.valueOf(FileUtil.lastModified(sFullPathName));
			}
		}
		catch (Throwable ignore)
		{
			nRet = new Long(0);
		}
		return nRet;
	}
	
	/**
	 * Returns whether or not the specified file has changed based on
	 * the modification time and length.
	 * <p>
	 * @param	sFullPathName	The file to check.
	 * @param	nLastMod		The last modification time to check against.
	 * @param	nLastLen		The last file length to check against.
	 * <p>
	 * @return		<code>true</code> if the file has changed, otherwise
	 *				<code>false</code>.
	 */
	
	public static Boolean fileHasChanged(final String sFullPathName,
										 final Long nLastMod,
										 final Long nLastLen)
	{
		Boolean bRet = Boolean.TRUE;
		
		try
		{
			if (StringUtil.isEmpty(sFullPathName) == false && nLastMod != null && nLastLen != null)
			{
				if (FileUtil.exists(sFullPathName) == true)
				{
					if (FileUtil.fileHasChanged(sFullPathName, nLastMod.longValue(), nLastLen.longValue()) == false)
					{
						bRet = Boolean.FALSE;
					}
				}
			}
		}
		catch (Throwable th)
		{
			bRet = Boolean.TRUE;
		}
		return bRet;
	}

	/**
	 * Method which writes the contents of a string to the specified
	 * file. The file is created if this method is called and the
	 * previous contents are lost if it exists.
	 * <p>
	 * @param		sStr		The string to write to the file.
	 * @param		sFile		Name of the file to write the string to.
	 */

	public static void stringToFile(final String sStr, final String sFile)
	{
		try
		{
			FileUtil.stringToFile(sStr, sFile, false);
		}
		catch (Throwable ignore)
		{
		}
	}

	/**
	 * Method which returns the contents of the specified file as a String.
	 * <p>
	 * @param		sFile		Name of the file to read.
	 * <p>
	 * @return		Returns a String object containing the contents
	 *				of the file or <code>null</code> if the file does
	 *				not exist or is empty.
	 */
	
	public static String fileToString(final String sFile)
	{
		String sRet = null;
		
		try
		{
			sRet = FileUtil.fileToString(sFile);
			
			if (sRet != null)
			{
				sRet = sRet.trim();
			}
		}
		catch (Throwable ignore)
		{
			sRet = null;
		}
		return sRet;
	}

	/**
	 * Method which indicates whether the specified file exists.
	 * <p>
	 * @param		sName			Name of the file to check.
	 * <p>
	 * @return		<code>true</code> if the file exists, <code>false</code>
	 *				otherwise.
	 */
	
	public static Boolean fileExists(final String sName)
	{
		Boolean bRet = Boolean.FALSE;
		
		try
		{
			if (FileUtil.exists(sName) == true)
			{
				bRet = Boolean.TRUE;
			}
		}
		catch (Throwable th)
		{
			bRet = Boolean.FALSE;
		}
		return bRet;
	}

	/**
	 * Returns whether or not the specified file can be deleted by
	 * checking write permission on both the directory and file.
	 * <p>
	 * @param	sDir		Directory containing the file.
	 * @param	sFile		The name of the file.
	 * <p>
	 * @return		<code>TRUE</code> if the file can be deleted, otherwise
	 * 				<code>FALSE</code>.
	 */
	
	public static Boolean canDeleteFile(final String sDir, final String sFile)
	{
		Boolean bRet = Boolean.FALSE;
		String sFullPathName = null;
		
		try
		{
			if (sDir != null && sFile != null)
			{
				if (FileUtil.canWrite(sDir) == true)
				{
					sFullPathName = SigUtil.makeFileName(sDir, sFile);
					
					if (sFullPathName != null)
					{
						if (FileUtil.canWrite(sFullPathName) == true)
						{
							bRet = Boolean.TRUE;
						}
					}
				}
			}
		}
		finally
		{
			sFullPathName = null;
		}
		return bRet;
	}
	
	/**
	 * Returns whether or not the specified file can be read.
	 * <p>
	 * @param	sDir		Directory containing the file.
	 * @param	sFile		The name of the file.
	 * <p>
	 * @return		<code>TRUE</code> if the file can be read, otherwise
	 * 				<code>FALSE</code>.
	 */
	
	public static Boolean canReadFile(final String sDir, final String sFile)
	{
		Boolean bRet = Boolean.FALSE;
		String sFullPathName = null;
		
		try
		{
			if (sDir != null && sFile != null)
			{
				sFullPathName = SigUtil.makeFileName(sDir, sFile);
					
				if (sFullPathName != null)
				{
					if (FileUtil.canRead(sFullPathName) == true)
					{
						bRet = Boolean.TRUE;
					}
				}
			}
		}
		finally
		{
			sFullPathName = null;
		}
		return bRet;
	}

	/**
	 * Method used to delay for the specified number of milliseconds.
	 * <p>
	 * @param	nMillis		The number of milliseconds to delay.
	 */
	
	public static void delay(final Long nMillis)
	{
		long nVal;
		
		if (nMillis != null)
		{
			nVal = nMillis.longValue();
			
			if (nVal > 0)
			{
				try
				{
					Thread.sleep(nVal);
				}
				catch (Throwable ignore)
				{
				}
			}
		}
	}
	
	/**
	 * Copies the message headers from the input message to the output message.
	 * <p>
	 * @param	inMessage	The input message.
	 * @param 	outMessage	The output message.
	 * <p>
	 * @throws	MbException		Thrown if an error occurs in copying the
	 * 							headers.
	 */
	
	public static void copyMessageHeaders(final MbMessage inMessage, 
								   final MbMessage outMessage)
												throws MbException
	{
		MbElement inRoot = null;
		MbElement outRoot = null; 
		MbElement header = null;
		
		try
		{
			if (inMessage != null && outMessage != null)
			{
				inRoot = inMessage.getRootElement();
				outRoot = outMessage.getRootElement();
				
				if (inRoot != null && outRoot != null)
				{
					// iterate though the headers starting with the first
					// child of the root element
		
					header = inRoot.getFirstChild();
		
					if (header != null)
					{
						// stop before the last child (body)
						
						while (header.getNextSibling() != null) 
						{
							// Get the header and add it to the out message.
							
							header = header.getNextSibling();
							
							outRoot.addAsLastChild(header.copy());
						}
					}
				}
			}
		}
		finally
		{
			inRoot = null;
			outRoot = null;
			header = null;
		}
	}
	
	/**
	 * Returns the value of the specified HTTPInputHeader of a MbMessageAssembly.
	 * <p>
	 * @param	mbAssembly		The message assembly.
	 * @param	sHeaderName		The header name.
	 * <p>
	 * @return		The value from the <code>HttpInputHeader</code>
	 * 				of an MbMessageAssembly, or <code>null</code> if it
	 * 				does not exist.
	 */
	
	public static String getHttpHeader(final MbMessageAssembly mbAssembly,
										 final String sHeaderName)
	{
		String sRet = null;
		MbMessage mbMessage = null;
		MbElement rootElement = null;
		MbElement httpInputHeaderElement = null;
		MbElement headerElement = null;
		
		try
		{
			if (mbAssembly != null && sHeaderName != null)
			{
				mbMessage = mbAssembly.getMessage();
				
				if (mbMessage != null)
				{
					rootElement = mbMessage.getRootElement();
					
					if (rootElement != null)
					{
						httpInputHeaderElement = 
							rootElement.getFirstElementByPath("HTTPInputHeader");

						if (httpInputHeaderElement != null)
						{
							headerElement =
								httpInputHeaderElement.getFirstElementByPath(sHeaderName);
							
							if (headerElement != null)
							{
								sRet = headerElement.getValueAsString();
							}
						}
					}
				}
			}
		}
		catch (MbException ex)
		{
		}
		finally
		{
			mbMessage = null;
			rootElement = null;
			httpInputHeaderElement = null;
			headerElement = null;
		}
		return sRet;
	}

	/**
	 * Returns the value of the Accept header from the HTTPInputHeader of a
	 * MbMessageAssembly.
	 * <p>
	 * @param	mbAssembly		The message assembly.
	 * <p>
	 * @return		The Accept header value from the <code>HttpInputHeader</code>
	 * 				of an MbMessageAssembly, or <code>null</code> if it
	 * 				does not exist.
	 */
	
	public static String getHttpAcceptHeader(final MbMessageAssembly mbAssembly)
	{
		return SigUtil.getHttpHeader(mbAssembly, "Accept");
	}
	
	/**
	 * Returns the Query String from the HTTPInputHeader of a
	 * MbMessageAssembly.
	 * <p>
	 * @param	mbAssembly		The message assembly.
	 * <p>
	 * @return		The query string from the <code>HttpInputHeader</code>
	 * 				of an MbMessageAssembly, or <code>null</code> if it
	 * 				does not exist.
	 */
	
	public static String getHttpQueryString(final MbMessageAssembly mbAssembly)
	{
		return SigUtil.getHttpHeader(mbAssembly, "X-Query-String");
	}
	
	/**
	 * Puts the output response in the message broker output assembly.
	 * <p>
	 * @param	outputMessage		The output message that will carry the
	 * 								response.
	 * @param	httpContentType		The content type of the message.
	 * @param	byteContent			Byte array containing the contents of
	 * 								the response.
	 */
	
	public static void setOuputHttpResponse(final MbMessage outputMessage,
								     		final HttpContentType httpContentType,
								     		final byte[] byteContent)
	{
		String sMethod = "setOutputResponse()";
		
		MbElement rootElement = null;
		MbElement propertiesElement = null;
		MbElement contentTypeElement = null;
		MbElement parserElement = null;
		
		try
		{			
    		rootElement = outputMessage.getRootElement();
    		
    		if (rootElement != null)
    		{
    			propertiesElement = 
    				rootElement.getFirstElementByPath("Properties");
    			
    			if (propertiesElement != null)
    			{
    				contentTypeElement = 
    					propertiesElement.getFirstElementByPath("ContentType");
    			
    				if (contentTypeElement != null && httpContentType != null)
    				{
    					contentTypeElement.setValue(httpContentType.toString());
    				}
    			}
    			parserElement = 
    				rootElement.createElementAsLastChild(MbBLOB.PARSER_NAME);
    		
    			if (parserElement != null)
    			{
    				parserElement.createElementAsFirstChild(
    						MbElement.TYPE_NAME_VALUE, "BLOB", byteContent);
    			}
    		}
		}
		catch (MbException ex)
		{
			SigLogger.logError(SigUtil.class, sMethod, 
								"Fatal error creating response!", ex);
		}
		finally
		{
			sMethod = null;

			rootElement = null;
			propertiesElement = null;
			contentTypeElement = null;
			parserElement = null;
		}
	}

	/**
	 * Returns the form fields from an HTTP GET request.
	 * <p>
	 * @param	mbAssembly		The message assembly.
	 * <p>
	 * @return		A <code>Hashtable</code> containing the form fields
	 * 				in the GET request, or <code>null</code> if there
	 * 				are none.
	 */
	
	public static Hashtable<String, String[]> 
				getHttpGetRequestFields(final MbMessageAssembly mbAssembly)
	{
		Hashtable<String, String[]> hFields = null;
		String sQueryString = null;
		
		try
		{
			sQueryString = SigUtil.getHttpQueryString(mbAssembly);
			
			hFields = HttpUtil.parseQueryString(sQueryString);
		}
		finally
		{
			sQueryString = null;
		}
		return hFields;
	}

	/**
	 * Removes the named element from the root of the specified message.
	 * <p>
	 * @param	message		The message to remove the element from.
	 * @param	sName		The name of the element to remove.
	 */
				
	public static void removeNamedElement(final MbMessage message, final String sName)
	{
		String sMethod = "removeNamedElement()";
		
		MbElement rootElement = null;
		
		try
		{
			if (message != null && StringUtil.isEmpty(sName) == false)
			{
				rootElement = message.getRootElement();
				
				if (rootElement != null)
				{
					SigUtil.removeNamedElement(rootElement, sName);
				}
			}
		}
		catch (MbException ex)
		{
			SigLogger.logError(
					SigUtil.class, sMethod, 
					"Error retrieving root element!", ex);
		}
		finally
		{
			rootElement = null;
			sMethod = null;
		}
	}
	
	/**
	 * Removes the first occurrence of the named element from the
	 * specified element.
	 * <p>
	 * @param	parentElement	The parent element to remove the child from.
	 * @param	sChildName		Name of the child element to remove.
	 */
	
	public static void removeNamedElement(
					final MbElement parentElement, final String sChildName)
	{
		String sMethod = "removeNamedElement()";
		
		MbElement childElement = null;
		
		try
		{
			if (parentElement != null && StringUtil.isEmpty(sChildName) == false)
			{
				childElement = parentElement.getFirstElementByPath(sChildName);
				
				if (childElement != null)
				{
					childElement.detach();
				}
			}
		}
		catch (MbException ex)
		{
			SigLogger.logError(
					SigUtil.class, sMethod, 
					"Error removing child element!", ex);
		}
		finally
		{
			childElement = null;
			sMethod = null;
		}
	}
	
	/**
	 * Based on the specified set of FORM fields in an HTTP request, returns
	 * <code>true</code> if the <code>format</code> field is specified
	 * with a value of <code>xml</code>, otherwise <code>false</code> is
	 * returned.
	 * <p>
	 * @param	hFields		<code>Hashtable</code> containing the set
	 * 						of form fields.
	 * <p>
	 * @return		<code>true</code> if <code>format=xml</code> is 
	 * 				specified, otherwise <code>false</code>.
	 */
	
	public static boolean isFormatXml(final Hashtable<String, String[]> hFields)
	{
		boolean bRet = false;
		
		Enumeration<String> enumFields = null;
		String sField = null;
		String[] sValueArray = null;
		
		try
		{
			if (hFields != null)
			{
				enumFields = hFields.keys();
				
				if (enumFields != null)
				{
					while (bRet == false && enumFields.hasMoreElements())
					{
						sField = enumFields.nextElement();
						
						if (sField != null)
						{
							if (sField.equalsIgnoreCase("format"))
							{
								sValueArray = hFields.get(sField);

								if (sValueArray != null)
								{
									if (sValueArray.length > 0)
									{
										if (sValueArray[0] != null)
										{
											bRet = sValueArray[0].equalsIgnoreCase("xml");
										}
									}
								}
							}
						}
					}
				}
			}
		}
		finally
		{
			enumFields = null;
			sField = null;
			sValueArray = null;
		}
		return bRet;
	}
	
	/**
	 * Returns whether or not the specified string represents a decimal
	 * number.
	 * <p>
	 * @param	sVal		The string containing the decimal value.
	 * <p>
	 * @return		<code>true</code> if the string represents a decimal
	 * 				value, otherwise <code>false</code>.
	 */
	
	public static Boolean isDecimal(final String sVal)
	{
		Boolean bRet = Boolean.FALSE;
		@SuppressWarnings("unused")
		BigDecimal bd = null;
		
		if (StringUtil.isEmpty(sVal) == false)
		{
			try
			{
				bd = new BigDecimal(sVal);
				
				bRet = Boolean.TRUE;
			}
			catch (NumberFormatException ex)
			{
				bRet = Boolean.FALSE;
			}
			finally
			{
				bd = null;
			}
		}
		return bRet;
	}

	/**
	 * Returns whether or not the specified string is represents an 
	 * integer. Note that an integer may start with a leading minus sign.
	 * <p>
	 * @param	sVal		The string containing the value.
	 * <p>
	 * @return		<code>true</code> if the string is an integer,
	 * 				otherwise <code>false</code>.
	 */
	
	public static Boolean isInteger(final String sVal)
	{
		Boolean bRet = Boolean.FALSE;
		@SuppressWarnings("unused")
		BigInteger bi = null;
		
		if (StringUtil.isEmpty(sVal) == false)
		{
			try
			{
				bi = new BigInteger(sVal);
				
				bRet = Boolean.TRUE;
			}
			catch (NumberFormatException ex)
			{
				bRet = Boolean.FALSE;
			}
			finally
			{
				bi = null;
			}
		}
		return bRet;
	}
	
	/**
	 * Returns whether or not the specified string contains only digits.
	 * <p>
	 * @param	sVal		The string containing the value.
	 * <p>
	 * @return		<code>true</code> if the string contains only digits,
	 * 				otherwise <code>false</code>.
	 */
	
	public static Boolean isNumeric(final String sVal)
	{
		Boolean bRet = Boolean.FALSE;
		
		if (StringUtil.isEmpty(sVal) == false)
		{
			/**
			 * Regular expression match for only digits.
			 */
			
			bRet = Boolean.valueOf(sVal.matches("\\d+"));
		}
		return bRet;
	}

	/**
	 * Formats the specified time into the standard XML format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * <p>
	 * @param	nTime	The time value to format.
	 * <p>
	 * @return			A String containing the formatted date and time.
	 */

	public static String getStandardXmlFormatDateFromTime(final Long nTime)
	{
		String sRet = null;
		
		if (nTime != null)
		{
			sRet = DateUtil.getStandardXmlFormatDate(nTime.longValue());
		}
		return sRet;
	}
	
	/**
	 * Formats the specified time into the standard XML date and time
	 * format with a UTC time. This format does not include a time
	 * zone offset.
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssZ
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
	 *   2003-12-23T16:32:58
	 * </pre>
	 * @param	nTime	The time value to format.
	 * <p>
	 * @return		A string containing the formatted date and time. 
	 */
	
	public static String getStandardXmlFormatUTCDateFromTime(final Long nTime)
	{
		String sRet = null;
		SimpleDateFormat sdf = null;
		Date d = null;
		
		try
		{
			sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
			if (nTime == null)
			{
				d = new Date();
			}
			else
			{
				d = new Date(nTime.longValue());
			}
			sRet = sdf.format(d);
		}
		finally
		{
			sdf = null;
			d = null;
		}
		return sRet;
	}
	
	/**
	 * Public method used to log the current stack trace to the
	 * application log.
	 */
	
	public static void logStackTrace()
	{
		StackTraceElement[] stackTraceElement = null;
		StringBuilder sb = null;
		try
		{
			sb = new StringBuilder(Defines.IO_BUF_SIZE);
		
			sb.append("Current Thread Call Stack:");
		
			stackTraceElement = Thread.currentThread().getStackTrace();
		
			if (stackTraceElement != null)
			{
				for (int i = 0 ; i < stackTraceElement.length ; ++i)
				{
					sb.append(Util.lineSeparator());
					sb.append("  ");
					sb.append(stackTraceElement[i].getClassName());
					sb.append('.');
					sb.append(stackTraceElement[i].getMethodName());
					sb.append(" at ");
					sb.append(
						Integer.toString(
								stackTraceElement[i].getLineNumber()));
				}
			}
			else
			{
				sb.append(" Empty");
			}

			/**
			 * WARNING: We let this go to stdout (standard broker
			 * log (/var/mqsi/components/broker-name/exec-group/stdout)
			 * because we may or may not be fully initialized.
			 */
			
			System.out.print(SigUtil.class.getName());
			System.out.print(".logStackTrace(): ");
			System.out.println(sb.toString());
			
//			SigLogger.logDebug(SigUtil.class,
//									  "logStackTrace()", 
//									  sb.toString());
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			stackTraceElement = null;
		}
	}
}
