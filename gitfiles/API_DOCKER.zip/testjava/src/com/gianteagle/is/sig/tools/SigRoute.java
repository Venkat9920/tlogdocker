/**
 * SigRoute.java
 */

package com.gianteagle.is.sig.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.util.Base64Util;
import com.gianteagle.is.util.GZipUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import com.gianteagle.is.xml.XmlDoc;

/**
 * Class used to parse a <code>SigRoute</code> message and extract the
 * Payload and RawPayload.
 * <p>
 * @author	ReichertSF
 */

public final class SigRoute
{
	/**
	 * Default constructor.
	 */

	private SigRoute()
	{
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */

	private void destroy()
	{
		if (this.xmlDoc != null)
		{
			this.xmlDoc.destroy();
			this.xmlDoc = null;
		}
		this.bytePayload = null;
		this.byteRawPayload = null;
	}

	/**
	 * Sets the XML document to validate against the schema.
	 * <p>
	 * @param	sDoc	The name of the file containing the XML document.
	 * <p>
	 * @exception	ParserConfigurationException	Thrown if an error
	 *												occurs in creating the
	 * 												DOM parser.
	 * @exception	IOException		Thrown if an I/O error occurs.
	 * @exception	SAXException	Thrown if an error occurs in parsing
	 * 								the XML document.
	 */

	private void setDocument(final String sDoc)
			throws ParserConfigurationException, IOException, SAXException
	{
		File docFile = null;
		
		try
		{
			if (sDoc == null)
			{
				throw new NullPointerException("Document file is null!");
			}
			docFile = new File(sDoc);

			this.xmlDoc = new XmlDoc(docFile);
		}
		finally
		{
			docFile = null;
		}
	}

	/**
	 * Retrieves the payload data as a byte array.
	 * <p>
	 * @param	sTagName	The name of the payload element.
	 * <p>
	 * @return		The payload data as a byte array.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in obtaining
	 * 								the payload.
	 * @exception	ParserConfigurationException	Thrown if an error occurs
	 * 												in creating the XML 
	 * 												document.
	 * @exception	SAXException	Thrown if an error occurs parsing the
	 * 								XML document.  
	 */
	
	private byte[] getPayloadData(final String sTagName) 
		throws ParserConfigurationException, IOException, SAXException
	{
		byte[] byteValue = null;
		
		Element element = null;
		String sValue = null;
		String sXmlValue = null;
		XmlDoc xmlPayload = null;
		
		try
		{
			if (StringUtil.isEmpty(sTagName) == false)
			{
				element = this.xmlDoc.getElement(sTagName);
			}
			if (element != null)
			{
				sValue = element.getTextContent();
				
				if (StringUtil.isEmpty(sValue) == false)
				{
					/**
					 * If the element value is Base64 encoded, decode as
					 * a byte array.
					 */
					
					if (SigRoute.isPayloadBase64Encoded(element) == true)
					{
						byteValue = Base64Util.decode(sValue);
					}
					else
					{
						byteValue = sValue.getBytes();
					}
					
					/**
					 * If the element value is gzip compressed, decompress
					 * into a byte array.
					 */
					
					if (SigRoute.isPayloadGZipCompressed(element) == true)
					{
						byteValue = GZipUtil.gunzip(byteValue);
					}
					
					/**
					 * If the element value is XML, stuff it into an
					 * XML document, then let the XML document return
					 * a formatted string representation. Finally,
					 * convert the string representation to a byte array.
					 */
					
					if (SigRoute.isPayloadXml(element) == true)
					{
						sXmlValue = new String(byteValue);
						
						xmlPayload = new XmlDoc(sXmlValue);
						
						byteValue = xmlPayload.toString().getBytes();
					}
				}
			}
		}
		finally
		{
			if (xmlPayload != null)
			{
				xmlPayload.destroy();
				xmlPayload = null;
			}
			sValue = null;
			sXmlValue = null;
		}
		return byteValue;
	}
	
	/**
	 * Returns whether or not the payload element is base64 encoded.
	 * <p>
	 * @param	element		The payload element.
	 * <p>
	 * @return		True if base64 encoded, otherwise false.
	 */
	
	private static boolean isPayloadBase64Encoded(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = 
					element.getAttributeNS(
							SigRoute.SIGROUTE_NAMESPACE_URI, "Encoding");
				
				if (sValue != null)
				{
					bRet = sValue.equalsIgnoreCase("base64");
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}

	/**
	 * Returns whether or not the payload element is gzip compressed.
	 * <p>
	 * @param	element		The payload element.
	 * <p>
	 * @return		True if gzip compressed, otherwise false.
	 */
	
	private static boolean isPayloadGZipCompressed(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = 
					element.getAttributeNS(
							SigRoute.SIGROUTE_NAMESPACE_URI, "Compression");
				
				if (sValue != null)
				{
					bRet = sValue.equalsIgnoreCase("gzip");
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}

	/**
	 * Returns whether or not the payload element is an XML document.
	 * <p>
	 * @param	element		The payload element.
	 * <p>
	 * @return		True if the elment is an XML document, otherwise false.
	 */
	
	private static boolean isPayloadXml(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = 
					element.getAttributeNS(
							SigRoute.SIGROUTE_NAMESPACE_URI, "Content-Type");
				
				if (HttpContentType.ApplicationXml.equals(sValue) ||
					HttpContentType.TextXml.equals(sValue))
				{
					bRet = true;
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}
	
	/**
	 * Writes the data bytes to the specified output file.
	 * <p>
	 * @param	sFile		The name of the file to write.
	 * @param	bytes		The bytes to write to the file.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in writing
	 * 								the file.
	 */
	
	private static void writeFile(final String sFile, final byte[] bytes) 
						throws IOException
	{
		FileOutputStream fos = null;
		
		try
		{
			if (bytes != null && StringUtil.isEmpty(sFile) == false)
			{
				fos = new FileOutputStream(sFile);
				
				fos.write(bytes);
				
				fos.flush();
			}
		}
		finally
		{
			if (fos != null)
			{
				try { fos.close(); } catch (Throwable ignore) { }
				fos = null;
			}
		}
	}
	
	/**
	 * Writes the string to the specified output file.
	 * <p>
	 * @param	sFile		The name of the file to write.
	 * @param	sStr		The string to write to the file.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in writing
	 * 								the file.
	 */
	
	private static void writeFile(final String sFile, final String sStr) 
						throws IOException
	{
		if (StringUtil.isEmpty(sStr) == false)
		{
			SigRoute.writeFile(sFile, sStr.getBytes());
		}
	}
	
	/**
	 * Method used to process a SigRoute file.
	 * <p>
	 * @param	sSigRouteFile			The starting SigRoute file.
	 * @param	sFormattedSigRouteFile	The formatted SigRoute file.
	 * @param	sRawPayloadFile			The raw payload file.
	 * @param	sPayloadFile			The payload file.
	 */
	
	private static void processFile(final String sSigRouteFile,
									   final String sFormattedSigRouteFile,
									   final String sRawPayloadFile,
									   final String sPayloadFile)
				throws Exception
	{
		SigRoute sigRoute = null;
		
		try
		{
			sigRoute = new SigRoute();

			System.out.print("Initializing document using ");
			System.out.print(sSigRouteFile);
			System.out.println(" ...");
			
			sigRoute.setDocument(sSigRouteFile);

			sigRoute.xmlDoc.setNamespaceURI(SigRoute.SIGROUTE_NAMESPACE_URI);
			
			if (sFormattedSigRouteFile == null)
			{
				System.out.println(sigRoute.xmlDoc.toString());
			}
			else
			{
				System.out.print("Writing output file ");
				System.out.print(sFormattedSigRouteFile);
				System.out.println(" ...");
			
				SigRoute.writeFile(sFormattedSigRouteFile, sigRoute.xmlDoc.toString());
			}
			sigRoute.byteRawPayload = sigRoute.getPayloadData("RawPayload");
			
			if (sigRoute.byteRawPayload != null)
			{
				if (sRawPayloadFile != null)
				{
					System.out.print("Writing RawPayload file ");
					System.out.print(sRawPayloadFile);
					System.out.println(" ...");
			
					SigRoute.writeFile(sRawPayloadFile, sigRoute.byteRawPayload);
				}
			}
			sigRoute.bytePayload = sigRoute.getPayloadData("Payload");
			
			if (sigRoute.bytePayload != null)
			{
				if (sPayloadFile != null)
				{
					System.out.print("Writing Payload file ");
					System.out.print(sPayloadFile);
					System.out.println(" ...");
					
					SigRoute.writeFile(sPayloadFile, sigRoute.bytePayload);
				}
			}
			System.out.println("SigRoute processing complete.");
			
		}
		finally
		{
			if (sigRoute != null)
			{
				sigRoute.destroy();
				sigRoute = null;
			}
		}
	}
	
	/**
	 * Process a list of SigRoute files.
	 * <p>
	 * @param	sListFile		The file containing the list.
	 */
	
	private static void processList(final String sListFile) throws Exception
	{
		String sSigRouteFile = null;
		String sFormattedSigRouteFile = null;
		String sRawPayloadFile = null;
		String sPayloadFile = null;
		String sLine = null;
		String[] sElements = null;

		try
		{
			if (sListFile != null)
			{
				try (BufferedReader br = new BufferedReader(new FileReader(sListFile)))
				{
					while ((sLine = br.readLine()) != null)
					{
						sElements = sLine.split(" ");

						if (sElements.length > 0)
						{
							sSigRouteFile = sElements[0];
							
							if (sElements.length > 1)
							{
								sFormattedSigRouteFile = sElements[1];
							}
							if (sElements.length > 2)
							{
								sRawPayloadFile = sElements[2];
							}
							if (sElements.length > 3)
							{
								sPayloadFile = sElements[3];
							}
						}
						System.out.print("Processing: ");
						System.out.print(StringUtil.format(sSigRouteFile));
						System.out.print(' ');
						System.out.print(StringUtil.format(sFormattedSigRouteFile));
						System.out.print(' ');
						System.out.print(StringUtil.format(sRawPayloadFile));
						System.out.print(' ');
						System.out.print(StringUtil.format(sPayloadFile));
						System.out.println();
						
						SigRoute.processFile(sSigRouteFile, sFormattedSigRouteFile, sRawPayloadFile, sPayloadFile);
					}
				}
			}
		}
		finally
		{
			sSigRouteFile = null;
			sFormattedSigRouteFile = null;
			sRawPayloadFile = null;
			sPayloadFile = null;
		}
		
	}
	
	/**
	 * Application used to extract the Payload and RawPayload from a
	 * SigRoute message.
	 * <p>
	 * Usage: java SigRoute SourceSigRoute OutputSigRoute RawPayload Payload
	 * <p>
	 * @param	args		Command line arguments.
	 */

	public static void main(final String[] args)
	{
		String sSigRouteFile = null;
		String sFormattedSigRouteFile = null;
		String sRawPayloadFile = null;
		String sPayloadFile = null;

		try
		{
			if (args.length < 1)
			{
				System.out.println(USAGE);
			}
			else if (args[0].equals("-l") && args.length < 2)
			{
				System.out.println(USAGE);
			}
			else
			{
				if (args[0].equals("-l"))
				{
					SigRoute.processList(args[1]);
				}
				else
				{
					sSigRouteFile = args[0];
					
					if (args.length > 1)
					{
						sFormattedSigRouteFile = args[1];
					}
					if (args.length > 2)
					{
						sRawPayloadFile = args[2];
					}
					if (args.length > 3)
					{
						sPayloadFile = args[3];
					}
					SigRoute.processFile(sSigRouteFile, 
										 sFormattedSigRouteFile, 
										 sRawPayloadFile, 
										 sPayloadFile);
				}
			}
		}
		catch (IOException ex)
		{
			System.out.println("FATAL I/O ERROR!");

			ex.printStackTrace();
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println("FATAL ERROR: Parser Configuration error!");

			ex.printStackTrace();
		}
		catch (SAXException ex)
		{
			System.out.println("FATAL ERROR: Document is INVALID.");

			ex.printStackTrace();
		}
		catch (Throwable th)
		{
			System.out.println("FATAL ERROR: Unknown error occurred!");

			th.printStackTrace();
		}
		finally
		{
			sSigRouteFile = null;
			sFormattedSigRouteFile = null;
			sRawPayloadFile = null;
			sPayloadFile = null;
		}
	}

	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------

	private static final String SIGROUTE_NAMESPACE_URI =
				"http://webservices.sig.gianteagle.com/ws/SigRoute/namespace";
	
	private XmlDoc xmlDoc = null;
	private transient byte[] byteRawPayload = null;
	private transient byte[] bytePayload = null;
	
	private static final String USAGE = 
		"SigRoute 4.1.0.0003 12-03-2014" +
		Util.lineSeparator() +
		"Usage: java com.gianteagle.is.sig.tools.SigRoute " +
		"[-l list] | " +
		Util.lineSeparator() +
		"             " +
		"[ SrcSigRouteFile [OutSigRouteFile] [RawPayloadFile] [PayloadFile] ]" +
		Util.lineSeparator() + 
		Util.lineSeparator() +
		"   If a list is specified (-l list) each line of the file must be" +
		Util.lineSeparator() + 
		"   in the following format:"+
		Util.lineSeparator() + 
		Util.lineSeparator() +
		"      SigRoute-File Formatted-SigRoute-File RawPayload-File PayloadFile" +
		Util.lineSeparator() +
		"      SigRoute-File Formatted-SigRoute-File RawPayload-File PayloadFile" +
		Util.lineSeparator() +
        "        ..."		
		;
}
