/**
 * SigConfig.java
 */

package com.gianteagle.is.sig.base;

import com.gianteagle.is.util.Util;

/**
 * Class used to manage standard configuration values.
 * <p>
 * @author sr44189
 */

public final class SigConfig
{
	/**
	 * Private constructor. Only static methods provided.
	 */
	
	private SigConfig()
	{
	}
	
	/**
	 * Returns the base directory used by this broker instance for
	 * log files, config files, etc.
	 * <p>
	 * @return		The base directory name.
	 */
	
	public static String getBaseDir()
	{
		if (SigConfig.sBaseDir == null)
		{
			if (SigConfig.sEnvBaseVar != null)
			{
				// User specified Environment variable specifying base dir.
				SigConfig.sBaseDir = System.getenv(sEnvBaseVar);
			}
			
			// If either a user specified environment variable was not used
			// or it's not in the environment, then use the default 
			// environment variable.
			
			if (SigConfig.sBaseDir == null)
			{
				// Default Environment variable specifying the base dir.

				SigConfig.sBaseDir = System.getenv(SigConfig.ENV_BASE_VAR);
			}
			
			// If we have not picked up the base directory from the environment,
			// the resort to the default.
			
			if (SigConfig.sBaseDir == null)
			{
				SigConfig.sBaseDir = SigConfig.DEF_BASE_DIR;
			}
			
			// Set the system property containing the base directory.
			//SigUtil.logStackTrace();
			System.setProperty(SigConstants.SIG_BASE, SigConfig.sBaseDir);
		}
		return SigConfig.sBaseDir;
	}

	/**
	 * Returns the name of the log file directory.
	 * <p>
	 * @return		The name of the log file directory.
	 */
	
	public static String getLogDir()
	{
		String sLogDir = null;
		
		sLogDir = SigConfig.getBaseDir();
			
		if (sLogDir != null)
		{
			if (sLogDir.endsWith(Util.fileSeparator()) == false)
			{
				sLogDir += Util.fileSeparator();
			}
			sLogDir += SigConfig.LOG_DIR;
		}
		return sLogDir;
	}
	
	/**
	 * Returns the name of the config file directory.
	 * <p>
	 * @return		The name of the config file directory.
	 */
	
	public static String getConfigDir()
	{
		String sConfigDir = null;
		
		sConfigDir = SigConfig.getBaseDir();
			
		if (sConfigDir != null)
		{
			if (sConfigDir.endsWith(Util.fileSeparator()) == false)
			{
				sConfigDir += Util.fileSeparator();
			}
			sConfigDir += SigConfig.CONFIG_DIR;
		}
		return sConfigDir;
	}

	/**
	 * Returns the name of the data file directory.
	 * <p>
	 * @return		The name of the data file directory.
	 */
	
	public static String getDataFileDir()
	{
		String sDataFileDir = null;
		
		sDataFileDir = SigConfig.getBaseDir();
			
		if (sDataFileDir != null)
		{
			if (sDataFileDir.endsWith(Util.fileSeparator()) == false)
			{
				sDataFileDir += Util.fileSeparator();
			}
			sDataFileDir += SigConfig.DATA_FILE_DIR;
		}
		return sDataFileDir;
	}

	/**
	 * Returns the name of the tmp directory.
	 * <p>
	 * @return		The name of the tmp directory.
	 */
	
	public static String getTmpDir()
	{
		String sRet = null;
		
		sRet = SigConfig.getBaseDir();
			
		if (sRet != null)
		{
			if (sRet.endsWith(Util.fileSeparator()) == false)
			{
				sRet += Util.fileSeparator();
			}
			sRet += SigConfig.TMP_DIR;
		}
		return sRet;
	}
	
	/**
	 * Returns the name of the xfer directory.
	 * <p>
	 * @return		The name of the xfer directory.
	 */
	
	public static String getXferDir()
	{
		String sRet = null;
		
		sRet = SigConfig.getBaseDir();
			
		if (sRet != null)
		{
			if (sRet.endsWith(Util.fileSeparator()) == false)
			{
				sRet += Util.fileSeparator();
			}
			sRet += SigConfig.XFER_DIR;
		}
		return sRet;
	}
	
	/**
	 * Returns the name of the out-bound xfer directory.
	 * <p>
	 * @return		The name of the out-bound xfer directory.
	 */
	
	public static String getOutboundXferDir()
	{
		String sRet = null;
		
		sRet = SigConfig.getBaseDir();
			
		if (sRet != null)
		{
			if (sRet.endsWith(Util.fileSeparator()) == false)
			{
				sRet += Util.fileSeparator();
			}
			sRet += SigConfig.XFER_DIR;
			sRet += Util.fileSeparator();
			sRet += SigConfig.OUTBOUND_XFER_DIR;
		}
		return sRet;
	}
	
	/**
	 * Returns the name of the in-bound xfer directory.
	 * <p>
	 * @return		The name of the in-bound xfer directory.
	 */
	
	public static String getInboundXferDir()
	{
		String sRet = null;
		
		sRet = SigConfig.getBaseDir();
			
		if (sRet != null)
		{
			if (sRet.endsWith(Util.fileSeparator()) == false)
			{
				sRet += Util.fileSeparator();
			}
			sRet += SigConfig.XFER_DIR;
			sRet += Util.fileSeparator();
			sRet += SigConfig.INBOUND_XFER_DIR;
		}
		return sRet;
	}
	
	/**
	 * Sets the name of the base environment variable that contains
	 * the path that will be used as the base directory tree by
	 * getBaseDir(). This environment variable must be setup in
	 * <code>/var/mqsi/common/SigService.sh</code> and specified in 
	 * the application's ServiceConfig implementation by calling
	 * this method.
	 * <p>
	 * Note: The default setup is to use the environment variable
	 * <code>SIG_SERVICE_HOME</code> which specifies the directory
	 * <code>/home/sigservice</code>.
	 * <p>
	 * @param	sEnvVar		The environment variable specifying the base path.
	 */
	
	public static void setEnvBaseVar(final String sEnvVar)
	{
		SigConfig.sEnvBaseVar = sEnvVar;
	}
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private static final String ENV_BASE_VAR = "SIG_SERVICE_HOME";
	
	private static final String DEF_BASE_DIR = "/var/tmp";
	private static final String LOG_DIR = "logs";
	private static final String CONFIG_DIR = "config";
	private static final String DATA_FILE_DIR = "files";
	private static final String TMP_DIR = "tmp";
	private static final String XFER_DIR = "xfer";
	private static final String OUTBOUND_XFER_DIR = "outbound";
	private static final String INBOUND_XFER_DIR = "inbound";
	
	private static String sEnvBaseVar = null;
	private static String sBaseDir = null;
}
