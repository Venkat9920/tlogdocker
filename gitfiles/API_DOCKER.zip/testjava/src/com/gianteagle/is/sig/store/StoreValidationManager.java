package com.gianteagle.is.sig.store;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import com.gianteagle.is.sig.base.SigUtil;
import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.xml.XmlFileStore;

public final class StoreValidationManager
{
	/**
	 * Default constructor.
	 */
	
	private StoreValidationManager()
	{
	}

	/**
	 * Sets the name of the StoreValidationList file to use.
	 * <p>
	 * @param	sFile		The name of the StoreValidationList file.
	 */
	
	public static void setFileName(final String sFile)
	{
		StoreValidationManager.sFileName = sFile;
	}
	
	/**
	 * Sets the reload interval. This is the interval used to check as to
	 * whether or not the StoreValidationList file has changed and needs to be 
	 * reloaded.
	 * <p>
	 * @param	nInterval		The interval in milliseconds.
	 */
	
	public static void setReloadInterval(final long nInterval)
	{
		StoreValidationManager.nFileReloadInterval = nInterval;
	}

	/**
	 * Method used to initialize the StoreValidationList.
	 * <p>
	 * @param	sFile			The name of the StoreValidationList file.
	 * @param	nInterval		The reload interval in milliseconds.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */

	public static void initialize(final String sFile, final long nInterval) 
			throws IOException, JAXBException
	{
		StoreValidationManager.setFileName(sFile);
		StoreValidationManager.setReloadInterval(nInterval);
		
		StoreValidationManager.init();
	}
	
	/**
	 * Returns whether or not the specified store and division is valid.
	 * <p>
	 * @param	sStore		The store number.
	 * @param	sDivision	The division number.
	 * <p>
	 * @return		<code>true</code> if the store and division is valid,
	 * 				otherwise <code>false</code>.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	public static boolean isValid(final String sStore, final String sDivision) throws IOException, JAXBException
	{
		boolean bRet = false;
		String sStoreToCheck = null;
		String sDivisionToCheck = null;
		
		try
		{
    		if (sStore != null && sDivision != null)
    		{
        		StoreValidationManager.init();
        		
        		if (StoreValidationManager.storeValidationList != null)
        		{
        			sStoreToCheck = 
        				StringUtil.rightJustify(
        					sStore, StoreValidationManager.STORE_NUMBER_LEN, '0');
        			sDivisionToCheck = 
        				StringUtil.rightJustify(
        					sDivision, StoreValidationManager.DIVISION_NUMBER_LEN, '0');
        			
        			for (StoreValidationList.Store store : StoreValidationManager.storeValidationList.getList())
        			{
        				if (store.storeNumber != null && store.divisionNumber != null)
        				{
        					if (sStoreToCheck.equalsIgnoreCase(store.storeNumber) &&
        							sDivisionToCheck.equalsIgnoreCase(store.divisionNumber))
        					{
        						bRet = true;
        						break;
        					}
        				}
        			}
        		}
    		}
		}
		finally
		{
			sStoreToCheck = null;
			sDivisionToCheck = null;
		}
		return bRet;
	}
	
	/**
	 * Returns whether or not the store with the specified ID is valid.
	 * <p>
	 * @param	sId		The ID of the store.
	 * <p>
	 * @return		Whether or not the store is valid.
	 * <p>
 	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	public static boolean isValid(final String sId) 
								throws IOException, JAXBException
	{
		boolean bRet = false;
	
		if (sId != null)
		{
			StoreValidationManager.init();
			
			for (StoreValidationList.Store store : StoreValidationManager.storeValidationList.getList())
			{
				if (sId.equalsIgnoreCase(store.id))
				{
					bRet = true;
					break;
				}
			}
		}
		return bRet;
	}
	
	/**
	 * Returns the StoreValidationList as an XML string.
	 * <p>
	 * @return		The StoreValidationList as an XML string.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */

	public static String getAsXmlString() throws IOException, JAXBException
	{
		StoreValidationManager.init();
		
		return StoreValidationManager.getAsString();
	}
	
	/**
	 * Returns a reference to the store validation list.
	 * <p>
	 * @return		A reference to the store validation list.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	public static List<StoreValidationList.Store> getStoreValidationList() throws IOException, JAXBException
	{
		StoreValidationManager.init();
		
		if (StoreValidationManager.storeValidationList == null)
		{
			return null;
		}
		return StoreValidationManager.storeValidationList.getList();
	}
	
	/**
	 * Test application used to verify operation.
	 * <p>
	 * @param	args		Command line arguments.
	 */
	
	public static void main(final String[] args)
	{
		String sFile = null;
		String sXml = null;
		
		try
		{
			if (args.length < 1 || args.length > 3)
			{
				System.out.print("Usage: java StoreValidationManager <fileName>");
				System.out.print(" [id] [store division]");
				System.out.println();
			}
			else
			{
				sFile = args[0];
				
				System.out.print("Processing file: ");
				System.out.println(StringUtil.format(sFile));
				
				StoreValidationManager.initialize(sFile, 5000);
				
				sXml = StoreValidationManager.getAsXmlString();
				
				System.out.println(StringUtil.format(sXml));
				
				if (args.length == 2)
				{
					System.out.print("Checking Store: Id=");
					System.out.print(StringUtil.format(args[1]));
					System.out.println("...");
					
					System.out.print("isValid=");
					System.out.print(
						Boolean.toString(StoreValidationManager.isValid(args[1])));
					System.out.println();
					
				}
				else if (args.length == 3)
				{
					System.out.print("Checking Store: Store=");
					System.out.print(StringUtil.format(args[1]));
					System.out.print(", Division=");
					System.out.print(StringUtil.format(args[2]));
					System.out.println("...");
					
					System.out.print("isValid=");
					System.out.print(
							Boolean.toString(
									StoreValidationManager.isValid(args[1], args[2])));
					System.out.println();
				}
			}
		}
		catch(Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			StoreValidationManager.clearStoreValidationList();
			sFile = null;
			sXml = null;
		}
	}
	
	/**
	 * Reads the StoreValidationList file.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	private static void readStoreValidationListFile() throws IOException, JAXBException
	{
		FileReader fr = null;
		XmlFileStore xmlFileStore = null;
		
		try
		{
			if (StoreValidationManager.sFileName != null)
			{
    			if (FileUtil.canRead(StoreValidationManager.sFileName))
    			{
    				StoreValidationManager.clearStoreValidationList();
    				
    				fr = new FileReader(StoreValidationManager.sFileName);
    			
    				xmlFileStore = new XmlFileStore();
    				
    				StoreValidationManager.storeValidationList = 
    							xmlFileStore.toObject(StoreValidationList.class, fr);

    				StoreValidationManager.nFileLastModified = 
    						FileUtil.lastModified(StoreValidationManager.sFileName);
    				
    				StoreValidationManager.nFileLength = 
    						FileUtil.length(StoreValidationManager.sFileName);
    			}
			}
		}
		finally
		{
			if (fr != null)
			{
				try { fr.close(); } catch (Throwable ignore) { }
				fr = null;
			}
		}
	}
	
	/**
	 * Returns the StoreValidationList as an XML string.
	 * <p>
	 * @return		The StoreValidationList as an XML String.
	 * <p>
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	private static String getAsString() throws JAXBException
	{
		String sRet = null;
		XmlFileStore xmlFileStore = null;
		
		try
		{
			if (StoreValidationManager.storeValidationList != null)
			{
				xmlFileStore = new XmlFileStore();
				
				sRet = xmlFileStore.toXmlString(StoreValidationManager.storeValidationList, true);
			}
		}
		finally
		{
			xmlFileStore = null;
		}
		return sRet;
	}
	
	/**
	 * Clears the StoreValidationList.
	 */
	
	private static void clearStoreValidationList()
	{
		if (StoreValidationManager.storeValidationList != null)
		{
			StoreValidationManager.storeValidationList.destroy();
			StoreValidationManager.storeValidationList = null;
		}
	}
	
	/**
	 * Initializes the store list if necessary.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	private static void init() throws IOException, JAXBException 
	{
		if (StoreValidationManager.storeValidationList == null)
		{
			// First time in.
			
			synchronized (StoreValidationManager.class)
			{
				if (StoreValidationManager.storeValidationList == null)
				{
					StoreValidationManager.readStoreValidationListFile();
				}
			}
		}
		else
		{
			// Subsequent calls. Reload if necessary.
			
			synchronized(StoreValidationManager.class)
			{
				StoreValidationManager.reload();
			}
		}
	}
	
	/**
	 * Reloads the StoreLilst if necessary.
	 * <p>
	 * @throws	IOException		Thrown if an I/O error occurs.
	 * @throws	JAXBException	Thrown if an XML error occurs.
	 */
	
	private static void reload() throws IOException, JAXBException
	{
		if (StoreValidationManager.checkReload() == true)
		{
			StoreValidationManager.readStoreValidationListFile();
		}
	}
	
	/**
	 * Returns whether or not the StoreValidationList should be reloaded.
	 * <p>
	 * @return	<code>true</code> if the StoreValidationList should be reloaded,
	 * 			otherwise <code>false</code>.
	 */
	
	private static boolean checkReload()
	{
		boolean bRet = false;
		long nCurrentTime = 0;
		
		if (StoreValidationManager.nLastReloadCheck <= 0)
		{
			StoreValidationManager.nLastReloadCheck = SigUtil.currentUTCTimeMillis().longValue();

			bRet = true;
		}
		else if (StoreValidationManager.nFileReloadInterval <= 0)
		{
			StoreValidationManager.nLastReloadCheck = SigUtil.currentUTCTimeMillis().longValue();

			bRet = true;
		}
		else
		{
			nCurrentTime = SigUtil.currentUTCTimeMillis().longValue();
			
			if ((nCurrentTime - StoreValidationManager.nLastReloadCheck) > StoreValidationManager.nFileReloadInterval)
			{
				StoreValidationManager.nLastReloadCheck = nCurrentTime;
				
				bRet = FileUtil.fileHasChanged(StoreValidationManager.sFileName, 
											   StoreValidationManager.nFileLastModified,
											   StoreValidationManager.nFileLength);
			}
		}
		return bRet;
	}
	
	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------

	private static final long DEFAULT_RELOAD_INTERVAL = 60000;
	private static final int STORE_NUMBER_LEN = 5;
	private static final int DIVISION_NUMBER_LEN = 3;
			
	private static String sFileName = null;
	private static long nFileLength = 0;
	private static long nFileLastModified = -1;
	private static long nLastReloadCheck = -1;
	private static long nFileReloadInterval = StoreValidationManager.DEFAULT_RELOAD_INTERVAL;
	
	private static StoreValidationList storeValidationList = null;
}
