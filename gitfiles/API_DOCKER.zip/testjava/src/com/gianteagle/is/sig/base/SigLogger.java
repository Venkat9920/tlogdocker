/**
 * SigServiceLogger.java
 */

package com.gianteagle.is.sig.base;

import com.gianteagle.is.logging.Logger;
import com.gianteagle.is.util.*;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;

/**
 * Class used to manage logging methods used within SigServcce.
 * <p>
 * @author	ReichertSF
 */

public final class SigLogger
{
	/**
	 * Default constructor.
	 */
	public static void main(String[] args) {
		logInfo("Test");
		System.out.println("Test");
	}
	
	
	private SigLogger()
	{
	}
	
	/**
	 * Returns whether or not DEBUG level logging is enabled for the
	 * application log.
	 * <p>
	 * @return		<code>true</code> if DEBUG level is enabled, otherwise
	 * 				<code>false</code>.
	 */
	
	public static boolean isDebugEnabled()
	{
		boolean bRet = false;
		
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			bRet = SigLogger.appLogger.isDebugEnabled();
		}
		return bRet;
	}
	
	/**
	 * Returns whether or not DEBUG level logging is enabled for the
	 * application log. This method returns a Boolean object that makes
	 * it usable in an ESQL context.
	 * <p>
	 * @return		<code>TRUE</code> if DEBUG level is enabled, otherwise
	 * 				<code>FALSE</code>.
	 */
	
	public static Boolean isAppLogDebugEnabled()
	{
		Boolean bRet = new Boolean(SigLogger.isDebugEnabled());
		
		return bRet;
	}
	
	/**
	 * Logs the specified message to the application log at the INFO level.
	 * <p>
	 * @param	sMesg	The message to log.
	 */
	
	public static void logInfo(final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.info(sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the INFO level.
	 * <p>
	 * @param	sComponent	The component logging the message.
	 * @param	sMesg		The message to log.
	 */
	
	public static void logInfo(final String sComponent, final String sMesg) 
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			threadContext.put(EchoFields.COMPONENT_ID.asString(), sComponent);
			SigLogger.appLogger.info(null, sComponent, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the INFO level.
	 * <p>
	 * @param	sMessageFlow	The message flow logging the message.
	 * @param	sNodeLabel		The node label logging the message.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logInfo(final String sMessageFlow, 
							   final String sNodeLabel, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			String component = getComponentName(sMessageFlow, sNodeLabel);
			threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
			SigLogger.appLogger.info(
					null, component, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the INFO level.
	 * <p>
	 * @param	clazz	Reference to the class that called the log method.
	 * @param	sMethod	Name of the method that called the log method.
	 * @param	sMesg	The message to log.
	 */
	
	public static void logInfo(final Class<?> clazz, final String sMethod,
							   final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.info(clazz, sMethod, sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the DEBUG level.
	 * <p>
	 * @param	sMesg	The message to log.
	 */
	
	public static void logDebug(final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.debug(sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the DEBUG level.
	 * <p>
	 * @param	sComponent	The component logging the message.
	 * @param	sMesg		The message to log.
	 */
	
	public static void logDebug(final String sComponent, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			threadContext.put(EchoFields.COMPONENT_ID.asString(), sComponent);
			SigLogger.appLogger.debug(null, sComponent, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the DEBUG level.
	 * <p>
	 * @param	sMessageFlow	The message flow logging the message.
	 * @param	sNodeLabel		The node label logging the message.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logDebug(final String sMessageFlow, 
							   final String sNodeLabel, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			String component = getComponentName(sMessageFlow, sNodeLabel);
			threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
			SigLogger.appLogger.debug(
					null, component, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the DEBUG level.
	 * <p>
	 * @param	clazz	Reference to the class that called the log method.
	 * @param	sMethod	Name of the method that called the log method.
	 * @param	sMesg	The message to log.
	 */
	
	public static void logDebug(final Class<?> clazz, final String sMethod,
							   	final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.debug(clazz, sMethod, sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the WARN level.
	 * <p>
	 * @param	sMesg	The message to log.
	 */
	
	public static void logWarn(final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.warn(sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the WARN level.
	 * <p>
	 * @param	sComponent	The component logging the message.
	 * @param	sMesg		The message to log.
	 */
	
	public static void logWarn(final String sComponent, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			threadContext.put(EchoFields.COMPONENT_ID.asString(), sComponent);
			SigLogger.appLogger.warn(null, sComponent, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the WARN level.
	 * <p>
	 * @param	sMessageFlow	The message flow logging the message.
	 * @param	sNodeLabel		The node label logging the message.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logWarn(final String sMessageFlow, 
							   final String sNodeLabel, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			String component = getComponentName(sMessageFlow, sNodeLabel);
			threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
			SigLogger.appLogger.warn(
					null, component, sMesg, threadContext);
		}
	}

	/**
	 * Logs the specified message to the application log at the WARN level.
	 * <p>
	 * @param	clazz	Reference to the class that called the log method.
	 * @param	sMethod	Name of the method that called the log method.
	 * @param	sMesg	The message to log.
	 */
	
	public static void logWarn(final Class<?> clazz, final String sMethod,
							   final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.warn(clazz, sMethod, sMesg);
		}
	}

	/**
	 * Logs the specified message to the application log at the ERROR level.
	 * <p>
	 * @param	sMessageFlow	The message flow logging the message.
	 * @param	sNodeLabel		The node label logging the message.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logErrorMessage(final String sMessageFlow, 
							   		   final String sNodeLabel, 
							   		   final String sMesg)
	{
		SigLogger.init();
		HashMap<String,String> threadContext = new HashMap<>();
		if (SigLogger.appLogger != null)
		{
			String component = getComponentName(sMessageFlow, sNodeLabel);
			threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
			SigLogger.appLogger.error(
				null, component , sMesg, null, threadContext);
		}
	}

	/**
	 * Logs the error to the error log and application log.
	 * <p>
	 * @param	sMesg	The message to log.
	 */
	
	public static void logError(final String sMesg)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.error(sMesg);
		}
		if (SigLogger.errorLogger != null)
		{
			SigLogger.errorLogger.error(sMesg);
		}
	}

	/**
	 * Logs the error to the error log and application log.
	 * <p>
	 * @param	sComponent	The component logging the message.
	 * @param	sMesg		The message to log.
	 */
	
	public static void logError(final String sComponent, final String sMesg)
	{
		SigLogger.init();
		HashMap<String, String> threadContext = new HashMap<>();
		threadContext.put(EchoFields.COMPONENT_ID.asString(), sComponent);
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.error(null, sComponent, sMesg, null, threadContext);
		}
		if (SigLogger.errorLogger != null)
		{
			SigLogger.errorLogger.error(null, sComponent, sMesg, null, threadContext);
		}
	}

	/**
	 * Logs the error to the error log.
	 * <p>
	 * @param	sComponent		The component logging the message.
	 * @param	sCorrelationId	The correlation ID associated with the error.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logError(final String sComponent, 
							    final String sCorrelationId,
							    final String sMesg)
	{
		StringBuilder sb = null;
		HashMap<String, String> threadContext = new HashMap<>();
		try
		{
			SigLogger.init();
		
			sb = new StringBuilder(Defines.IO_BUF_SIZE);
				
			sb.append("----- BEGIN ERROR LOG ENTRY -----");
			sb.append(Util.lineSeparator());
				
			sb.append("Component: ");
			String component = StringUtil.format(sComponent);
			threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
			sb.append(component);
			sb.append(Util.lineSeparator());
			sb.append("Correlation ID: ");
			String correlationId = StringUtil.format(sCorrelationId);
			threadContext.put(EchoFields.CORRELATION_ID.asString(), correlationId);
			sb.append(correlationId);
			sb.append(Util.lineSeparator());
				
			if (StringUtil.isEmpty(sMesg) == false)
			{
				sb.append(sMesg);
				
				if (sMesg.endsWith(Util.lineSeparator()) == false)
				{
					sb.append(Util.lineSeparator());
				}
			}
			sb.append("----- END ERROR LOG ENTRY -----");
				
			if (SigLogger.errorLogger != null)
			{
				SigLogger.errorLogger.error(sb.toString(), threadContext);
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}

	/**
	 * Logs the error to the error log and application log.
	 * <p>
	 * @param	clazz	Reference to the class that called the log method.
	 * @param	sMethod	Name of the method that called the log method.
	 * @param	sMesg	The message to log.
	 * @param	th		The error to log.
	 */
	
	public static void logError(final Class<?> clazz, final String sMethod,
								final String sMesg, final Throwable th)
	{
		SigLogger.init();
		
		if (SigLogger.appLogger != null)
		{
			SigLogger.appLogger.error(clazz, sMethod, sMesg, th);
		}
		if (SigLogger.errorLogger != null)
		{
			SigLogger.errorLogger.error(clazz, sMethod, sMesg, th);
		}
	}
	
	/**
	 * Logs the fatal error to the error log.
	 * <p>
	 * @param	sComponent		The component logging the message.
	 * @param	sCorrelationId	The correlation ID associated with the error.
	 * @param	sMesg			The message to log.
	 */
	
	public static void logFatal(final String sComponent, 
							    final String sCorrelationId,
							    final String sMesg)
	{
		StringBuilder sb = null;
		HashMap<String, String> threadContext = new HashMap<>();
		try
		{
			SigLogger.init();
		
			if (SigLogger.errorLogger != null)
			{
				sb = new StringBuilder(Defines.IO_BUF_SIZE);
				
				sb.append("----- BEGIN FATAL ERROR LOG ENTRY -----");
				sb.append(Util.lineSeparator());
				
				sb.append("Component: ");
				String component = StringUtil.format(sComponent);
				threadContext.put(EchoFields.COMPONENT_ID.asString(), component);
				sb.append(component);
				sb.append(Util.lineSeparator());
				sb.append("Correlation ID: ");
				String correlationId = StringUtil.format(sCorrelationId);
				threadContext.put(EchoFields.CORRELATION_ID.asString(), correlationId);
				sb.append(correlationId);
				sb.append(Util.lineSeparator());
					
				if (StringUtil.isEmpty(sMesg) == false)
				{
					sb.append(sMesg);
					
					if (sMesg.endsWith(Util.lineSeparator()) == false)
					{
						sb.append(Util.lineSeparator());
					}
				}
				sb.append("----- END FATAL ERROR LOG ENTRY -----");
				
				SigLogger.errorLogger.fatal(sb.toString(), threadContext);
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}

	/**
	 * Method used to log timing related information.
	 * <p>
	 * @param	sEntry		The timing log entry to write.
	 */
	
	public static void logTiming(final String sEntry)
	{
		StringBuilder sb = null;
		HashMap<String, String> threadContext = new HashMap<>();
		try
		{
			SigLogger.init();
		
			if (SigLogger.timingLogger != null)
			{
				sb = new StringBuilder(Defines.IO_BUF_SIZE);
				
				sb.append(SigLogger.TIMING_LOG_VERSION);
				sb.append(',');
				sb.append(DateUtil.getStandardFormatDate());
				sb.append(',');
				
				if (sEntry != null)
				{
					populateTimingLogMap(sEntry, threadContext);
					sb.append(sEntry);
				}
				SigLogger.timingLogger.info(sb.toString(), threadContext);
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}

	/**
	 * Method used to log transaction related information.
	 * <p>
	 * @param	sEntry		The transaction log entry to write.
	 */
	
	public static void logTransaction(final String sEntry)
	{
		StringBuilder sb = null;
		HashMap<String,String> threadContext = new HashMap<>();
		try
		{
			SigLogger.init();
		
			if (SigLogger.transactionLogger != null)
			{
				sb = new StringBuilder(Defines.IO_BUF_SIZE);
				
				sb.append(SigLogger.TRANSACTION_LOG_VERSION);
				sb.append(',');
				sb.append(DateUtil.getStandardFormatDate());
				sb.append(',');
				
				if (sEntry != null)
				{
					populateTransactionalLogMap(sEntry, threadContext);
					sb.append(sEntry);
				}
				SigLogger.transactionLogger.debug(sb.toString(), threadContext);
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}
	
	/**
	 * Method used to log the Java System Properties.
	 */
	
	public static void logSystemProperties()
	{
		StringWriter sw = null;
		PrintWriter pw = null;
		
		try
		{
			if (SigLogger.isDebugEnabled())
			{
				sw = new StringWriter(Defines.IO_BUF_SIZE);
				pw = new PrintWriter(sw);
			
				PropUtil.listSystemProperties(pw);
			
				SigLogger.logDebug(SigLogger.class, 
									  "logSystemProperties()", sw.toString());
			}
		}
		finally
		{
			if (sw != null)
			{
				try { sw.close(); } catch (Throwable ignore) { }
				sw = null;
			}
			if (pw != null)
			{
				try { pw.close(); } catch (Throwable ignore) { }
				pw = null;
			}
		}
	}

	/**
	 * Logs the specified message to the message log.
	 * <p>
	 * @param	sMessageFlow		Message flow name.
	 * @param	sCorrelationId		Correlation ID for the message.
	 * @param	sMessage			The message to log.
	 */
	
	public static void logMessage(final String sMessageFlow,
								  final String sCorrelationId,
								  final String sMessage)
	{
		StringBuilder sb = null;
		HashMap<String, String> threadContext = new HashMap<>();
		try
		{
			SigLogger.init();
		
			if (SigLogger.messageLogger != null)
			{
				sb = new StringBuilder(Defines.MEM_BUF_SIZE);

				sb.append("MESSAGE PROCESSED");
				
				if (StringUtil.isEmpty(sMessageFlow) == false ||
					StringUtil.isEmpty(sCorrelationId) == false)
				{
					sb.append(" [");
				}
				if (StringUtil.isEmpty(sMessageFlow) == false)
				{
					threadContext.put(EchoFields.COMPONENT_ID.asString(), sMessageFlow);
					sb.append(sMessageFlow);
				}
				if (StringUtil.isEmpty(sCorrelationId) == false)
				{
					if (sb.length() > 0)
					{
						sb.append(", ");
					}
					threadContext.put(EchoFields.CORRELATION_ID.asString(), sCorrelationId);
					sb.append("ID=");
					sb.append(sCorrelationId);
				}
				if (sb.length() > 0)
				{
					sb.append(']');
				}
				sb.append(Util.lineSeparator());

				sb.append("----- Begin -----");
				sb.append(Util.lineSeparator());
				
				sb.append(StringUtil.format(sMessage));
				
				if (sMessage == null)
				{
					sb.append(Util.lineSeparator());
				}
				else if (sMessage.endsWith(Util.lineSeparator()) == false)
				{
					sb.append(Util.lineSeparator());
				}
				sb.append("----- End -----");
				
				SigLogger.messageLogger.info(sb.toString(), threadContext);
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}

	/**
	 * Specifies the logger configuration file to use. The default
	 * configuration file is <code>log4j.properties</code>.
	 * <p>
	 * @param	sName	The name of the logger configuration file. No
	 * 					path information should be supplied as the
	 * 					configuration directory is used as the location
	 * 					of the file.
	 */
	
	public static void setLoggerConfigFile(final String sName)
	{
		SigLogger.sLoggerConfigFile = sName;
	}
	
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Front end to initialize the logging subsystem. This method
	 * is here only to prevent repeated calls the synchronized
	 * initialization method, which could impede performance.
	 */
	
	private static void init()
	{
		if (SigLogger.bInitialized == false)
		{
			SigLogger.initialize();
		}
	}
	/**
	 * Method used to initialize the logging subsystem.
	 */
	
	private static synchronized void initialize()
	{
		String sConfigFile = null;
		
		try
		{
			if (SigLogger.bInitialized == false)
			{
    			if (Logger.isConfigured() == false)
    			{
    				sConfigFile = SigLogger.getLogConfig();
    				
    				Logger.configure(sConfigFile);
    			}
    			if (SigLogger.appLogger == null)
    			{
    				SigLogger.appLogger = 
    							new Logger(SigConstants.APP_LOGGER);
    			}
    			if (SigLogger.errorLogger == null)
    			{
    				SigLogger.errorLogger = 
    							new Logger(SigConstants.ERROR_LOGGER);
    			}
    			if (SigLogger.timingLogger == null)
    			{
    				SigLogger.timingLogger = 
    							new Logger(SigConstants.TIMING_LOGGER);
    			}
    			if (SigLogger.transactionLogger == null)
    			{
    				SigLogger.transactionLogger = 
    							new Logger(SigConstants.TRANSACTION_LOGGER);
    			}
    			if (SigLogger.messageLogger == null)
    			{
    				SigLogger.messageLogger =
    							new Logger(SigConstants.MESSAGE_LOGGER);
    			}
    			
				SigLogger.bInitialized = true;
			}
		}
		finally
		{
			sConfigFile = null;
		}
	}
	
	/**
	 * Returns the full path to the log file configuration.
	 * <p>
	 * @return		The full path to the log file configuration.
	 */
	
	private static String getLogConfig()
	{
		String sRet = null;
		StringBuilder sb = null;
		
		try
		{
			sb = new StringBuilder();
			
			sb.append(SigConfig.getConfigDir());
			sb.append(Util.fileSeparator());
			
			if (StringUtil.isEmpty(SigLogger.sLoggerConfigFile) == true)
			{
				sb.append(SigConstants.LOG_CONFIG);
			}
			else
			{
				sb.append(SigLogger.sLoggerConfigFile);
			}
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet; 
	}
	
	

	/**
	 * Private method used to construct a Component name from a
	 * Message Flow Name and Node Name.
	 * <p>
	 * @param	sMessageFlow		The message flow name.
	 * @param	sNodeLabel			The node name.
	 * <p>
	 * @return		The component name as a concatenation of the
	 * 				flow and node names.
	 */
	
	private static String getComponentName(final String sMessageFlow,
										   final String sNodeLabel)
	{
		String sRet = null;
		StringBuilder sb = null;
		
		try
		{
			sb = new StringBuilder(Defines.IO_BUF_SIZE);
				
			/**
			 * Build up the Component from the Message Flow Label
			 * and Name Label so that it at least resembles the
			 * ESQL procedure name.
			 */
				
			if (sMessageFlow != null)
			{
				sb.append(sMessageFlow);
			}
			if (sb.length() > 0)
			{
				sb.append('_');
			}
			if (sNodeLabel != null)
			{
				sb.append(sNodeLabel);
			}
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}

		return sRet;
	}

	/**
	 * Private method used to construct a map for echo logging
	 * TimingLog is based on PROCEDURE logTimingData, in  kt/mid-sigcommon/blob/master/SigBaseLib/SigTimingTransaction.esql
	 * <p>
	 * @param	sValue	   Comma separated string
	 * @param	map		   HashMap, to map all the string values.
	 */
	private static void populateTimingLogMap (String sValue, HashMap <String, String> map) {
		String[] values = sValue.split(",");
		if (values.length >= 7 ) {
			map.put(EchoFields.TRANSACTION_ID.asString(), values[0]);
			map.put(EchoFields.APPLICATION_REQUEST_ID.asString(), values[1]);
			map.put(EchoFields.CORRELATION_ID.asString(), values[2]);
			map.put(EchoFields.BUSINESS_FUNCTION_ID.asString(), values[3]);
			map.put(EchoFields.COMPONENT_ID.asString(), values[4]);
			map.put(EchoFields.COMPONENT_VERSION.asString(), values[5]);
			map.put(EchoFields.TOTAL_TIME.asString(), values[6]);
		}
		String[] name = {EchoFields.TOTAL_COMPONENT_TIME.asString(),EchoFields.RETRY_COUNT.asString(),EchoFields.HOST.asString(),
				EchoFields.SYSTEM_NAME.asString(),EchoFields.DIVISION_NUMBER.asString(),EchoFields.STORE_NUMBER.asString(),
				EchoFields.ORIGIN_DATE_TIME.asString(),EchoFields.ORIGIN.asString(),EchoFields.ORIGIN_EVENT.asString(),
				EchoFields.ORIGIN_VERSION.asString(),EchoFields.SOURCE.asString(),EchoFields.SOURCE_EVENT.asString(),
				EchoFields.DESTINATION.asString(), EchoFields.RESPONSE_CODE.asString(),EchoFields.OPERATION_STATUS.asString()};
		for (int i = 7; i < values.length  && i < 22; i++) {
			map.put(name[i - 7], values[i]);
		}
	}

	/**
	 * Private method used to construct a map for echo logging
	 * TransactionalLog is based on PROCEDURE logTransactionData, in  kt/mid-sigcommon/blob/master/SigBaseLib/SigTimingTransaction.esql
	 * <p>
	 * @param	sValue	   Comma separated string
	 * @param	map		   HashMap, to map all the string values.
	 */
	private static void populateTransactionalLogMap (String sValue, HashMap <String, String> map) {
		String[] values = sValue.split(",");

		if (values.length >= 8 ) {
			map.put(EchoFields.TRANSACTION_ID.asString(), values[0]);
			map.put(EchoFields.APPLICATION_REQUEST_ID.asString(), values[1]);
			map.put(EchoFields.CORRELATION_ID.asString(), values[2]);
			map.put(EchoFields.SERVICE_ID.asString(), values[3]);
			map.put(EchoFields.WSG_CERT_ID.asString(), values[4]);
			map.put(EchoFields.BUSINESS_FUNCTION_ID.asString(), values[5]);
			map.put(EchoFields.COMPONENT_ID.asString(), values[6]);
			map.put(EchoFields.TOTAL_TIME.asString(), values[7]);
		}
	}
	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------
	
	private static final String TIMING_LOG_VERSION = "2.0";
	private static final String TRANSACTION_LOG_VERSION = "1.0";
	
	private static String sLoggerConfigFile = null;
	
	private static Logger appLogger = null;
	private static Logger timingLogger = null;
	private static Logger transactionLogger = null;
	private static Logger errorLogger = null;
	private static Logger messageLogger = null;
	
	private static boolean bInitialized = false;
}
