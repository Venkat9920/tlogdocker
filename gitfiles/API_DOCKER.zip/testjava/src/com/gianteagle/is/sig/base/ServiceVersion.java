/**
 * ServiceVersion.java
 */

package com.gianteagle.is.sig.base;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.w3c.dom.Element;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.gianteagle.is.net.Html;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.net.ServiceInfoBase;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used in an HTTP request context to dump the version information
 * within the current execution group. Since this is used in an
 * HTTP context, the result is either XML or HTML based on the value
 * of the <code>format</code> field specified in the request.
 * <p> 
 * @author	ReichertSF
 */

public final class ServiceVersion
{
	/**
	 * Default constructor.
	 */
	
	private ServiceVersion()
	{
	}
	
	/**
	 * Constructs the HTTP response containing the version information.
	 * <p>
	 * @param	mbNode			Reference to the MbJavaComputeNode calling 
	 * 							this method.
	 * @param	inAssembly		Reference to the top level assembly (InputRoot).
	 * @param	outTerminal		The output terminal.
	 * @param 	sServiceName	The name of the service
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getServiceVersion(final MbJavaComputeNode mbNode,
										 final MbMessageAssembly inAssembly,
									     final MbOutputTerminal outTerminal,
									     final String sServiceName)
							throws MbException
	{
		ServiceVersion.getServiceVersion(
					mbNode, inAssembly, outTerminal, sServiceName, null, null);
	}

	/**
	 * Constructs the HTTP response containing the version information.
	 * <p>
	 * @param	mbNode				Reference to the MbJavaComputeNode calling 
	 * 								this method.
	 * @param	inAssembly			Reference to the top level assembly (InputRoot).
	 * @param	outTerminal			The output terminal.
	 * @param 	sServiceName		The name of the service
	 * @param	sAdditionalJarInfo	Additional Jar Information for HTML output.
	 * @param	propAdditionalJarInfo	Additional Jar Information for XML output.
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getServiceVersion(final MbJavaComputeNode mbNode,
										 final MbMessageAssembly inAssembly,
									     final MbOutputTerminal outTerminal,
									     final String sServiceName,
									     final String sAdditionalJarInfo,
									     final Properties[] propAdditionalJarInfo)
							throws MbException
	{
		MbMessage inMessage = null;
		MbMessage outMessage = null;
		MbMessageAssembly outAssembly = null;
		ByteArrayOutputStream baos = null;
		PrintWriter pw = null;
		HttpContentType httpContentType = null;
		Hashtable<String, String[]> hFields = null;
		String sServiceVersion = null;
		String sBrokerName = null;
		String sExecutionGroupName = null;

		try
		{
			// Reference the input message from the assembly.
			
			inMessage = inAssembly.getMessage();

			// Create the output message and output assembly.
			
			outMessage = new MbMessage(inMessage);
    		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);

			// Remove the existing "HTTPInputHeader". We're done with
   			// it and don't want to propagate it further.
    			
   			SigUtil.removeNamedElement(outMessage, "HTTPInputHeader");
    			
   			// Remove the existing "BLOB" element. In a GET or POST
   			// request with fields, this will contain the form fields
   			// from the original request, and we don't want to 
   			// return them.
    			
   			SigUtil.removeNamedElement(outMessage, "BLOB");
   			
   			if (mbNode != null)
   			{
   				sBrokerName = mbNode.getBroker().getName();
   				sExecutionGroupName = mbNode.getExecutionGroup().getName();
   			}
   			
   			// Retrieve the Service Version from the message flow.

   			sServiceVersion = 
   					BrokerUtil.getComponentVersion(sBrokerName,
   												   sExecutionGroupName,
   												   sServiceName);
 			
    		baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
    		pw = new PrintWriter(baos);

    		hFields = SigUtil.getHttpGetRequestFields(inAssembly);
    		
    		if (SigUtil.isFormatXml(hFields) == true)
    		{
    			httpContentType = HttpContentType.ApplicationXml;

    			ServiceVersion.getXmlVersionInfo(pw, sBrokerName, sExecutionGroupName, sServiceName, sServiceVersion, propAdditionalJarInfo);
    		}
    		else
    		{
    			httpContentType = HttpContentType.TextHtml;
    			
    			ServiceVersion.getHtmlVersionInfo(
    					pw, sBrokerName, sExecutionGroupName, sServiceName, sServiceVersion, sAdditionalJarInfo);
    		}
    		
     		pw.flush();

     		SigUtil.setOuputHttpResponse(
     					outMessage, httpContentType, baos.toByteArray());
		
     		// Propagate the output results to the 'out' terminal.
			
			outTerminal.propagate(outAssembly);
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (baos != null)
			{
				try { baos.close(); } catch (Throwable ignore) { } 
				baos = null;
			}
			if (hFields != null)
			{
				hFields.clear();
				hFields = null;
			}
			inMessage = null;
			outMessage = null;
			outAssembly = null;
			httpContentType = null;
			sServiceVersion = null;
			sBrokerName = null;
			sExecutionGroupName = null;
		}
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Generates the response as XML.
	 * <p>
	 * @param	pw				PrintWriter to send the output to.
	 * @param	sBrokerName		The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param 	sServiceName	The name of the service
	 * @param	sServiceVersion	The version of the service.
	 * @param	propAdditionalJarInfo	Additional Jar Information for XML output.
	 */
	
	private static void getXmlVersionInfo(final PrintWriter pw,
										  final String sBrokerName,
										  final String sExecutionGroupName,
									      final String sServiceName,
									      final String sServiceVersion,
									      final Properties[] propAdditionalJarInfo)
	{
		String sMethod = "getXmlVersionInfo()";
		com.gianteagle.is.net.ServiceVersion serviceVersion = null;
		
		TreeMap<String, String> componentList = null;
		Set<String> keySet = null;
		Iterator<String> it = null;
		Element componentElement = null;
		Element libraryElement = null;
		String sName = null;
		String sVersion = null;
		String sValue = null;
		
		try
		{
			if (pw != null)
			{
				serviceVersion =
					new com.gianteagle.is.net.ServiceVersion(
									sServiceName, sServiceVersion, null);
				
				libraryElement = serviceVersion.newLibraryElement(com.gianteagle.is.sig.base.Versions.getJarName());
				
				serviceVersion.setLibraryItem(libraryElement, 
						ServiceInfoBase.NAME_TYPE,
						ServiceInfoBase.JAVA_LIBRARY);
				serviceVersion.setLibraryItem(libraryElement, 
						ServiceInfoBase.NAME_DESCRIPTION, 
						com.gianteagle.is.sig.base.Versions.getDescription());
				serviceVersion.setLibraryItem(libraryElement, 
						ServiceInfoBase.NAME_VERSION, 
						com.gianteagle.is.sig.base.Versions.getVersion());
				serviceVersion.setLibraryItem(libraryElement, 
						ServiceInfoBase.NAME_VERSION_DATE, 
						com.gianteagle.is.sig.base.Versions.getDate());
				
				serviceVersion.addLibrary(libraryElement);
				
				if (propAdditionalJarInfo != null)
				{
					for (int i = 0 ; i < propAdditionalJarInfo.length ; ++i)
					{
						if (propAdditionalJarInfo[i] != null)
						{
							sValue = propAdditionalJarInfo[i].getProperty(ServiceInfoBase.JAVA_LIBRARY);
					
							if (StringUtil.isEmpty(sValue) == false)
							{
								libraryElement = null;
								libraryElement = serviceVersion.newLibraryElement(sValue);
						
								serviceVersion.setLibraryItem(
									libraryElement, ServiceInfoBase.NAME_TYPE, 
									ServiceInfoBase.JAVA_LIBRARY);

								sValue = propAdditionalJarInfo[i].getProperty(ServiceInfoBase.NAME_DESCRIPTION);
						
								if (StringUtil.isEmpty(sValue) == false)
								{
									serviceVersion.setLibraryItem(libraryElement, ServiceInfoBase.NAME_DESCRIPTION, sValue);
								}
								sValue = propAdditionalJarInfo[i].getProperty(ServiceInfoBase.NAME_VERSION);
						
								if (StringUtil.isEmpty(sValue) == false)
								{
									serviceVersion.setLibraryItem(libraryElement, ServiceInfoBase.NAME_VERSION, sValue);
								}
								sValue = propAdditionalJarInfo[i].getProperty(ServiceInfoBase.NAME_VERSION_DATE);
						
								if (StringUtil.isEmpty(sValue) == false)
								{
									serviceVersion.setLibraryItem(libraryElement, ServiceInfoBase.NAME_VERSION_DATE, sValue);
								}
								serviceVersion.addLibrary(libraryElement);
							}
						}
					}
				}
				componentList = BrokerUtil.getComponentList(sBrokerName, sExecutionGroupName);
				
				if (componentList != null)
				{
					keySet = componentList.keySet();
					
					if (keySet != null)
					{
						for (it = keySet.iterator() ; it.hasNext() ; )
						{
							sName = it.next();
							
							componentElement = 
									serviceVersion.newComponentElement(sName);
							
							sVersion = componentList.get(sName);
							
							serviceVersion.setComponentItem(
												componentElement, 
												ServiceInfoBase.NAME_VERSION, 
												sVersion);
							
							serviceVersion.addComponent(componentElement);
						}
					}
				}
				pw.println(serviceVersion.toString());
			}
		}
		catch (Throwable th)
		{
			SigLogger.logError(ServiceVersion.class, sMethod, 
							"Fatal error creating Version information!", th);
		}
		finally
		{
			if (serviceVersion != null)
			{
				serviceVersion.destroy();
				serviceVersion = null;
			}
			if (componentList != null)
			{
				componentList.clear();
				componentList = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			it = null;
			componentElement = null;
			libraryElement = null;
			sName = null;
			sVersion = null;
			sValue = null;
			sMethod = null;
		}
	}
	
	/**
	 * Generates the response as HTML.
	 * <p>
	 * @param	pw					PrintWriter to send the output to.
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param 	sServiceName		The name of the service
	 * @param	sServiceVersion		The version of the service.
	 * @param	sAdditionalJarInfo	Additional Jar Information for HTML output.
	 */
	
	private static void getHtmlVersionInfo(final PrintWriter pw,
										   final String sBrokerName,
										   final String sExecutionGroupName,
									       final String sServiceName,
									       final String sServiceVersion,
									       final String sAdditionalJarInfo)
	{
		TreeMap<String, String> componentList = null;
		Set<String> keySet = null;
		Iterator<String> it = null;
		String sName = null;
		String sVersion = null;
		String sBgColor = null;
		int i = 0;
		
		try
		{
			pw.println(Html.beginHtml());

			pw.println(Html.beginHead());
			pw.println(Html.title(StringUtil.format(sServiceName) + " Version"));
			pw.println(Html.endHead());
			
			pw.println(Html.beginBody());

			pw.println(Html.h2(
					StringUtil.format(sServiceName) + 
					" Version " + 
					StringUtil.format(sServiceVersion)));
    		
    		pw.println(Html.h3("COMPONENTS"));
    		
    		pw.println(Html.beginTable());
    		
    		pw.println(Html.beginTableRow("bgcolor=\"#90EE90\""));	//LightGreen
    		pw.println(Html.tableData(Html.bold("Component")));
    		pw.println(Html.tableData(Html.bold("Version")));
    		pw.println(Html.endTableRow());
    		
			componentList = BrokerUtil.getComponentList(sBrokerName, sExecutionGroupName);
				
			if (componentList != null)
			{
				keySet = componentList.keySet();
					
				if (keySet != null)
				{
					for (i = 0, it = keySet.iterator() ; it.hasNext() ;  ++i)
					{
						sName = it.next();
							
						sVersion = componentList.get(sName);
						
						if (sVersion == null)
						{
							sVersion = " ";
						}
						
						if ((i % 2) == 0)
						{
							sBgColor = "bgcolor=\"#FAEBD7\"";	// AntiqueWhite
						}
						else
						{
							sBgColor = "bgcolor=\"#FFFFFF\"";	// White
						}
						pw.println(Html.beginTableRow(sBgColor));
						pw.println(Html.tableData(Html.code(sName)));
						pw.println(Html.tableData(Html.code(sVersion)));
						pw.println(Html.endTableRow());
					}
				}
			}
    		pw.println(Html.endTable());
    		    		
    		pw.println(Html.h3("JAVA SUPPORT LIBRARIES"));
    		
    		pw.println(Html.beginPreformatted());
    		pw.println(com.gianteagle.is.tools.Versions.getVersions());
    		pw.println(com.gianteagle.is.sig.base.Versions.getVersions());
    		if (StringUtil.isEmpty(sAdditionalJarInfo) == false)
    		{
    			pw.println(sAdditionalJarInfo);
    		}
    		pw.println(Html.endPreformatted());

			pw.println(Html.rule());

			pw.println(Html.small(Html.italic(DateUtil.getCurrentDateTime())));

			pw.println(Html.endBody());
			
    		pw.println(Html.endHtml());
		}
		finally
		{
			if (componentList != null)
			{
				componentList.clear();
				componentList = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			it = null;
			sName = null;
			sVersion = null;
			sBgColor = null;
		}
	}
}
