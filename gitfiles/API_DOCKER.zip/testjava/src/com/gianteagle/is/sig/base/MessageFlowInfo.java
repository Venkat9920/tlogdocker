/**
 * MessageFlowInfo.java
 */

package com.gianteagle.is.sig.base;


import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import com.ibm.integration.admin.proxy.IntegrationAdminException;
import com.ibm.integration.admin.proxy.IntegrationServerProxy;
import com.ibm.integration.admin.proxy.MessageFlowProxy;
import com.gianteagle.is.sig.base.SigLogger;

/**
 * Class used to hold information about a message flow.
 * <p>
 * @author	ReichertSF
 */

public final class MessageFlowInfo
{
	/**
	 * Constructor give the execution group and the associated message flow
	 * objects.
	 * <p>
	 * @param	execGroup		The execution group containing the flow.
	 * @param	messageFlow		The message flow.
	 */
	
	MessageFlowInfo(final IntegrationServerProxy execGroup, final MessageFlowProxy messageFlow)
	{
		String sMethod = "MessageFlowInfo()";
		int ndx = 0;
		
		try
		{
			if (execGroup == null)
			{
				throw new NullPointerException("ExecutionGroupProxy is null!");
			}
			if (messageFlow == null)
			{
				throw new NullPointerException("MessageFlowProxy is null!");
			}
			this.sName = messageFlow.getName();
			this.sVersion = messageFlow.getMessageFlowModel(true).getDescriptiveProperties().getVersion();
			this.sBarFileName = messageFlow.getMessageFlowModel(true).getDescriptiveProperties().getDeployBarfile();
			if (this.sBarFileName != null)
			{
				ndx = this.sBarFileName.lastIndexOf(Util.fileSeparator());
				
				if (ndx > 0)
				{
					this.sBarFileName = this.sBarFileName.substring(ndx + 1);
				}
			}
			this.sExecutionGroupName = execGroup.getName();
			this.bRunEnabled = messageFlow.getMessageFlowModel(false).getActive().isRunning();
			this.bRunning = messageFlow.getMessageFlowModel(false).getActive().isRunning();
		}
		catch (IntegrationAdminException ex)
		{
			SigLogger.logError(
					MessageFlowInfo.class, sMethod, 
					"Error Initializing MessageFlowInfo!", ex);
		}
	}
	
	/**
	 * Cleans up the object and releases any resources held by it.
	 */
	
	public void destroy()
	{
		this.sName = null;
		this.sVersion = null;
		this.sBarFileName = null;
		this.sExecutionGroupName = null;
	}

	/**
	 * Returns name of the message flow.
	 * <p>
	 * @return		The name of the message flow.
	 */

	public String getName()
	{
		return this.sName;
	}
	
	/**
	 * Returns version of the message flow.
	 * <p>
	 * @return		The version of the message flow.
	 */

	public String getVersion()
	{
		return this.sVersion;
	}
	
	/**
	 * Returns name of the BAR file used to deploy this message flow.
	 * <p>
	 * @return		The name of the BAR file used to deploy this 
	 * 				message flow.
	 */

	public String getBarFileName()
	{
		return this.sBarFileName;
	}
	
	/**
	 * Returns name of the execution group containing this message flow.
	 * <p>
	 * @return		The name of the execution group containing this 
	 * 				message flow.
	 */

	public String getExecutionGroupName()
	{
		return this.sExecutionGroupName;
	}
	
	/**
	 * Returns whether or not the flow is enabled to run when the 
	 * execution group is started.
	 * <p>
	 * @return	<code>true</code> if the flow is enable to run when the
	 * 			execution group is started, otherwise <code>false</code>.
	 */
	
	public boolean isRunEnabled()
	{
		return this.bRunEnabled;
	}
	
	/**
	 * Returns whether or not the flow is currently running.
	 * <p>
	 * @return	<code>true</code> if the flow is currently running,
	 * 			otherwise <code>false</code>.
	 */

	public boolean isRunning()
	{
		return this.bRunning;
	}
	
	/**
	 * Returns a string representation of the is object.
	 * <p>
	 * @return		A String representation of the object.
	 */
	
	@Override
	public String toString()
	{
		String sRet = null;
		
		StringBuilder sb = null;
		
		try
		{
			sb = new StringBuilder(Defines.IO_BUF_SIZE);

			sb.append(this.getClass().getSimpleName());
			sb.append(": ");
			
			sb.append("Name=");
			sb.append(StringUtil.format(this.getName()));

			sb.append(',');

			sb.append("Version=");
			sb.append(StringUtil.format(this.getVersion()));

			sb.append(',');

			sb.append("BarFileName=");
			sb.append(StringUtil.format(this.getBarFileName()));

			sb.append(',');

			sb.append("ExecutionGroup=");
			sb.append(StringUtil.format(this.getExecutionGroupName()));

			sb.append(',');

			sb.append("isRunEnabled=");
			sb.append(StringUtil.format(this.isRunEnabled()));

			sb.append(',');

			sb.append("isRunning=");
			sb.append(StringUtil.format(this.isRunning()));

			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private transient String sName = null;
	private transient String sVersion = null;
	private transient String sBarFileName = null;
	private transient String sExecutionGroupName = null;
	private transient boolean bRunEnabled = false;
	private transient boolean bRunning = false;
}
