/**
 * BrokerUtil.java
 */

package com.gianteagle.is.sig.base;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import com.ibm.integration.admin.proxy.*;

public class BrokerUtil {

  public static void main(String[] args) {
      System.out.println("TEST");
      
      //stopMessageFlow("ACENODE", "default", "test");
      //isFlowRunning("ACENODE", "default", "test");
      //startMessageFlow("ACENODE", "default", "test");
      //isFlowRunning("ACENODE", "default", "test");
      
     // System.out.println(getQueueDepth("ACENODE", "default", "ACE_TLOG_XML_TO_JSON_IN2"));
      
    //  System.out.println(getBrokerName());
      System.out.println(getComponentVersion("ACENODE",  "default",  "AceTlogReceiver"));
     // System.out.println(getMessageFlowList("ACENODE", "default"));
      //System.out.println(isExecutionGroupInitialzed("ACENODE",  "default"));
      }
  
  private BrokerUtil()
	{
	}
  
  
  /**
	 * Returns a <code>TreeMap</code> of the message flows. This is a
	 * snapshot view of the flows because it captures real time info
	 * about each flow, such as whether or not it is running.
	 * <p>
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * <p>
	 * @return 		A <code>TreeMap</code> of the components and their
	 * 				associated versions, or <code>null</code> it the
	 * 				list is empty.
	 */
	
	public static TreeMap<String, MessageFlowInfo>getMessageFlowList(final String sBrokerName, final String sExecutionGroupName)
	{
		TreeMap<String, MessageFlowInfo> messageFlowList = null;
		List<ApplicationProxy> applisit ;
		
		try
		{
			IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
			IntegrationServerProxy server =
				        node.getIntegrationServerByName(sExecutionGroupName);
			if (server != null) {
				
				BrokerUtil.getMessageFlowList(server);
								}	
		
		
		}catch (IntegrationAdminException e) {
			// TODO: handle exception
		}
		
		return messageFlowList;
			
	}
  /**
	 * Returns the broker name.
	 * <p>
	 * This method is safe to call prior to any other initializations or
	 * configuration setup. It will get the name of the broker from 
	 * <code>BrokerProxy.getLocalInstance().getName()</code>. It will also
	 * set the broker name into the Java system properties as:
	 * <pre>
	 *   com.is.gianteagle.sig.broker.name
	 * </pre>
	 * If an error occurs it will be logged in the standard output log
	 * of the broker and execution group: 
	 * <pre>
	 *   /var/mqsi/components/broker-name/execution-group-id/stdout
	 * </pre>
	 * @return		Returns the broker name.
	 */
	
	public static String getBrokerName()
	{
		String sRet = null;
				
		try
		{
			IntegrationNodeProxy node = new IntegrationNodeProxy("localhost", 4416, "", "", false);
			sRet = node.getName();
			//System.setProperty(SigConstants.SIG_BROKER_NAME, StringUtil.format(sRet));
		}
		catch (IntegrationAdminException ex)
		{
			System.out.print(BrokerUtil.class.getName());
			System.out.print(".getBrokerName(): ");
			System.out.println("ERROR getting broker name!");
			System.out.println(Util.getStackTrace(ex));
		}
		
		return sRet;
	}
	
  
  
  
  
  /**
	 * Returns whether or not the named Message flow is running.
	 * <p>
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param	sQueueName			Name of the queue.
	 * <p>
	 * @return		<code>TRUE</code> if the message flow is running,
	 * 				otherwise <code>FALSE</code>.
	 */
	
	public static Long getQueueDepth(final String sBrokerName,
									 final String sExecutionGroupName,
									 final String sQueueName)
	{
		Long nRet = null;
		String sMethod = "getQueueDepth()";
		String sQueueManagerName = null;
		MQQueueManager queueManager = null;
		MQQueue queue = null;
		int nDepth = 0;
		

		try
		{
			if (StringUtil.isEmpty(sBrokerName) == false &&
				StringUtil.isEmpty(sExecutionGroupName) == false &&
				StringUtil.isEmpty(sQueueName) == false)
			{
				
				IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
				IntegrationServerProxy server =
					        node.getIntegrationServerByName(sExecutionGroupName);
				if (server != null) {
				
				{
					sQueueManagerName = node.getIntegrationNodeModel(true).getProperties().getDefaultQueueManagerName();
					
					if (StringUtil.isEmpty(sQueueManagerName) == false)
					{
						queueManager = new MQQueueManager(sQueueManagerName);

						
						queue = queueManager.accessQueue(sQueueName, CMQC.MQOO_BROWSE | CMQC.MQOO_INQUIRE);
						
						if (queue != null)
						{
							nDepth = queue.getCurrentDepth();
							
							nRet = new Long(nDepth);
						}
						else
						{
							SigLogger.logWarn(BrokerUtil.class, sMethod,
								"Bailing out, Queue is null! (Broker=" +
								StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
								StringUtil.format(sExecutionGroupName) + ",QueueName=" + 
								StringUtil.format(sQueueName) + ")!");
						}
					}
					else
					{
						SigLogger.logWarn(BrokerUtil.class, sMethod,
							"Bailing out, QueueManagerName is null! (Broker=" +
							StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
							StringUtil.format(sExecutionGroupName) + ",QueueName=" + 
							StringUtil.format(sQueueName) + ")!");
					}
				}
			}
			}
		}
		catch (IntegrationAdminException ex)
		{
			SigLogger.logError(
					BrokerUtil.class, "getExecutionGroup()", 
					"Error getting QueueManager Name (Broker=" +
					StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
					StringUtil.format(sExecutionGroupName) + ",QueueName=" + 
					StringUtil.format(sQueueName) + ")!", ex);
		}
		catch (MQException ex)
		{
			SigLogger.logError(
					BrokerUtil.class, "getExecutionGroup()", 
					"MQ Access Error (Broker=" +
					StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
					StringUtil.format(sExecutionGroupName) + ",QueueName=" + 
					StringUtil.format(sQueueName) + ")!", ex);
		}
		finally
		{
			sMethod = null;
			sQueueManagerName = null;

			if (queue != null)
			{
				try { queue.close(); } catch(Throwable ignore) { }
				queue = null;
			}
			if (queueManager != null)
			{
				try { queueManager.disconnect(); } catch (Throwable ignore) { }
				queueManager = null;
			}
			if (nRet == null)
			{
				nRet = new Long(0);
			}
		}
		return nRet;
	}

  
  
  
  /**
	 * Returns the version of the named component in the specified broker and
	 * execution group.
	 * <p>
	 * @param	sBrokerName				The name of the broker.
	 * @param	sExecutionGroupName		The execution group name.
	 * @param	sComponentName			The name of the message flow or
	 * 									message set.
	 * <p>
	 * @return		The version of the specified message flow, message set, or 
	 * 				<code>null</code> if either the component does not
	 * 				exist or the version is not specified on the message
	 * 				flow.
	 */
	
  public static String getComponentVersion(final String sBrokerName,
			 final String sExecutionGroupName,
			 final String sComponentName)
  {
	  String sRet = null;
	 
	  try {
		  System.out.println(executionGroupProxy.getName());
		/*IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
		IntegrationServerProxy server =
			        node.getIntegrationServerByName(sExecutionGroupName);
		if (server != null) { */
		  if (executionGroupProxy != null) {
	        List<ApplicationProxy> ap = executionGroupProxy.getAllApplications(true);
			for(int i = 0 ; i<ap.size(); i++)
			{
				
				List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
				for(int j = 0 ; j<mfp.size(); j++)
				{
					if (mfp.get(j).getName().equals(sComponentName))
					
					{
						System.out.println(mfp.get(j).getName());
						MessageFlowProxy mf = 
								executionGroupProxy.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sComponentName,"",false);
										
						sRet= mf.getMessageFlowModel(false).getDescriptiveProperties().getVersion().toString();
	
			        
					}
				}
			}
			
			
			
			
		}
			
		 if (sRet.length() == 0 ) 
			{
				sRet = BrokerUtil.DEFAULT_VERSION;
			}
		
	} catch (IntegrationAdminException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	 
		
	
	  return sRet;
	  
	  
  }
  
   
  
  /**
	 * Returns the version of the named message flow in the specified broker
	 * and execution group.
	 * <p>
	 * WARNING: This method is very expensive because it must determine
	 * the message flow from the execution group and broker.
	 * <p>
	 * @param	sBrokerName				The name of the broker.
	 * @param	sExecutionGroupName		The execution group name.
	 * @param	sMessageFlowName		The name of the message flow or
	 * 									message set.
	 * <p>
	 * @return		The version of the specified message flow, message set, or 
	 * 				<code>null</code> if either the component does not
	 * 				exist or the version is not specified on the message
	 * 				flow.
	 */
	
	public static String getFlowVersion(final String sBrokerName,
							 		    final String sExecutionGroupName,
										final String sMessageFlowName)
	{
		  String sRet = null;
			 
		  try {
			IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
			IntegrationServerProxy server =
				        node.getIntegrationServerByName(sExecutionGroupName);
			if (server != null) {
				
		        List<ApplicationProxy> ap = server.getAllApplications(true);
				for(int i = 0 ; i<ap.size(); i++)
				{
					
					List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
					for(int j = 0 ; j<mfp.size(); j++)
					{
						if (mfp.get(j).getName().equals(sMessageFlowName))
						
						{
							System.out.println(mfp.get(j).getName());
							MessageFlowProxy mf = 
							          server.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sMessageFlowName,"",false);
											
							sRet= mf.getMessageFlowModel(false).getDescriptiveProperties().getVersion().toString();
		
				        
						}
					}
				}
				
				
				
				
			}
				
			 if (sRet.length() == 0 ) 
				{
					sRet = BrokerUtil.DEFAULT_VERSION;
				}
			
		} catch (IntegrationAdminException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		 
			
		
		  return sRet;
		  
		  
	  }
  
	/**
	 * Method used to stop the named message flow.
	 * <p>
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param	sMessageFlow		The message flow to stop.
	 */


	public static void stopMessageFlow(final String sBrokerName,
			   final String sExecutionGroupName,
			   final String sMessageFlow)
	{	
			
		
		try {
			IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
			IntegrationServerProxy server =
				        node.getIntegrationServerByName(sExecutionGroupName);
			if (server != null) {
				
		        List<ApplicationProxy> ap = server.getAllApplications(true);
				for(int i = 0 ; i<ap.size(); i++)
				{
					
					List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
					for(int j = 0 ; j<mfp.size(); j++)
					{
						if (mfp.get(j).getName().equals(sMessageFlow))
						
						{
							System.out.println(mfp.get(j).getName());
							MessageFlowProxy mf = 
							          server.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sMessageFlow,"",false);
											
							System.out.println(mf.stop());
		
				        
						}
					}
				}
			}
			
		}
		catch ( IntegrationAdminException e) {
			// TODO: handle exception
		}
		
		
		
		
	}

	/**
	 * Returns whether or not the named Message flow is running.
	 * <p>
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param	sName				Name of the message flow.
	 * <p>
	 * @return		<code>TRUE</code> if the message flow is running,
	 * 				otherwise <code>FALSE</code>.
	 */
	
	public static Boolean isFlowRunning(final String sBrokerName,
									    final String sExecutionGroupName,
									    final String sMessageFlow)
	{
		Boolean bRet = Boolean.FALSE;
		
		try {
			IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
			IntegrationServerProxy server =
				        node.getIntegrationServerByName(sExecutionGroupName);
			if (server != null) {
				
		        List<ApplicationProxy> ap = server.getAllApplications(true);
				for(int i = 0 ; i<ap.size(); i++)
				{
					
					List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
					for(int j = 0 ; j<mfp.size(); j++)
					{
						if (mfp.get(j).getName().equals(sMessageFlow))
						
						{
							System.out.println(mfp.get(j).getName());
							MessageFlowProxy mf = 
							          server.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sMessageFlow,"",false);
											
							System.out.println(mf.getMessageFlowModel(false).getActive().isRunning());
							bRet = mf.getMessageFlowModel(false).getActive().isRunning();
		
				        
						}
					}
				}
			}
			
		}
		catch ( IntegrationAdminException e) {
			// TODO: handle exception
		}
		
		
		
		return bRet;
	}
	  
	/**
	 * Method used to start the named message flow in the current
	 * execution group.
	 * <p>
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param	sMessageFlow		The message flow to start.
	 */


		public static void startMessageFlow(final String sBrokerName,
				   final String sExecutionGroupName,
				   final String sMessageFlow)
		{	
				
			
			try {
				IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
				IntegrationServerProxy server =
					        node.getIntegrationServerByName(sExecutionGroupName);
				if (server != null) {
					
			        List<ApplicationProxy> ap = server.getAllApplications(true);
					for(int i = 0 ; i<ap.size(); i++)
					{
						
						List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
						for(int j = 0 ; j<mfp.size(); j++)
						{
							if (mfp.get(j).getName().equals(sMessageFlow))
							
							{
								System.out.println(mfp.get(j).getName());
								MessageFlowProxy mf = 
								          server.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sMessageFlow,"",false);
												
								System.out.println(mf.start());
			
					        
							}
						}
					}
				}
				
			}
			catch ( IntegrationAdminException e) {
				// TODO: handle exception
			}
			
			
			
			
		}

	  
		
		/**
		 * Returns a <code>TreeMap</code> of the message flows
		 * within the execution group. 
		 * <p>
		 * @param	execGroup		The execution group to query.
		 * <p>
		 * @return 		A <code>TreeMap</code> of the message flows, or 
		 * 				<code>null</code> it the list is empty.
		 */
		
		private static TreeMap<String, MessageFlowInfo> getMessageFlowList(final IntegrationServerProxy execGroup)
		{
			String sMethod = "getMessageFlowList()";
			
			TreeMap<String, MessageFlowInfo> messageFlowList = null;
			
			Enumeration<MessageFlowProxy> enumMessageFlows = null;
			Enumeration<ApplicationProxy> enumApps = null;
			ApplicationProxy appProxy = null;
			String sAppName = null;
			
			try 
			{
				messageFlowList = new TreeMap<>();
				
				if (execGroup != null)
				{
					//enumMessageFlows = execGroup.getMessageFlows(null);
				
					//BrokerUtil.addMessageFlowsToList(messageFlowList, enumMessageFlows, execGroup);
					
					enumApps = (Enumeration<ApplicationProxy>) execGroup.getAllApplications(true);
					
					if (enumApps != null)
					{
						while (enumApps.hasMoreElements())
						{
							appProxy = enumApps.nextElement();
							
							if (appProxy != null)
							{
								sAppName = appProxy.getName();
								
								if (sAppName != null)
								{
									enumMessageFlows = (Enumeration<MessageFlowProxy>) appProxy.getAllMessageFlows(false);

									BrokerUtil.addMessageFlowsToList(messageFlowList, enumMessageFlows, execGroup);
								}
							}
						}
					}
				}
			}
			catch (IntegrationAdminException ex)
			{
				SigLogger.logError(
						ServiceFlows.class, sMethod, 
						"Error creating list of message flows!", ex);
			}
			finally
			{
				enumMessageFlows = null;
				sMethod = null;
				
				if (messageFlowList != null)
				{
					if (messageFlowList.size() == 0)
					{
						messageFlowList.clear();
						messageFlowList = null;
					}
				}
			}
			return messageFlowList;
		}

		/**
		 * Private method used to add the message flows specified by the
		 * enumeration to the list of message flows.
		 * <p>
		 * @param	messageFlowList		List of message flows.
		 * @param	enumMessageFlows	Enumeration of message flows in the
		 * 								current proxy object (Execution Group,
		 * 								Application, or Library).
		 * @param	execGroup			The exection group proxy.
		 * <p>
		 * @throws ConfigManagerProxyException	Thrown if an error occurs in
		 * 										getting or handling message flow
		 * 										info. 
		 */
		
		private static void addMessageFlowsToList(final TreeMap<String, MessageFlowInfo> messageFlowList, 
												  final Enumeration<MessageFlowProxy> enumMessageFlows,
												  final IntegrationServerProxy execGroup) 
											throws IntegrationAdminException
		{
			String sName = null;
			MessageFlowProxy messageFlow = null;
			MessageFlowInfo messageFlowInfo = null;
			
			try
			{
				if (messageFlowList != null)
				{
					if (enumMessageFlows != null)
					{
						while (enumMessageFlows.hasMoreElements())
						{
							messageFlow = enumMessageFlows.nextElement();
							
							if (messageFlow != null)
							{
								sName = messageFlow.getName();
								
								messageFlowInfo = new MessageFlowInfo(execGroup, messageFlow);
								
								if (sName != null)
								{
									messageFlowList.put(sName, messageFlowInfo);
								}
							}
						}
					}
				}
			}
			finally
			{
				sName = null;
				messageFlow = null;
				messageFlowInfo = null;
			}
		}
	
		/**
		 * Returns a <code>TreeMap</code> of the components and versions
		 * in the specified execution group.
		 * <p>
		 * @param	execGroup	Specifies the execution group to get the
		 * 						component list for.  
		 * <p>
		 * @return 		A <code>TreeMap</code> of the components and their
		 * 				associated versions, or <code>null</code> it the
		 * 				list is empty.
		 */
		
		private static TreeMap<String, String> getComponentList(final IntegrationServerProxy execGroup)
		{
			String sMethod = "getComponentList()";
			
			TreeMap<String, String> componentList = null;
			
			Enumeration<MessageFlowProxy> enumMessageFlows = null;
			Enumeration<Object> enumDeployedObjects = null;
			Enumeration<SubFlowProxy> enumSubFlows = null;
			Enumeration<ApplicationProxy> enumApps = null;
			ApplicationProxy appProxy = null;
			
			try
			{
				componentList = new TreeMap<>();

				if (execGroup != null)
				{
					
					enumApps = (Enumeration<ApplicationProxy>) execGroup.getAllApplications(true);
					
					if (enumApps != null)
					{
						while (enumApps.hasMoreElements())
						{
							appProxy = enumApps.nextElement();
							
							if (appProxy != null)
							{
								enumMessageFlows = (Enumeration<MessageFlowProxy>) appProxy.getAllMessageFlows(true);

								BrokerUtil.addMessageFlowsToComponentList(componentList, enumMessageFlows);
								
								enumDeployedObjects = (Enumeration<Object>) appProxy.getAllStaticLibraries(true);
								
								BrokerUtil.addMessageFlowDependenciesToComponentList(componentList, enumDeployedObjects);
								
								enumSubFlows = (Enumeration<SubFlowProxy>) appProxy.getAllSubFlows(true);
								
								BrokerUtil.addSubFlowsToComponentList(componentList, enumSubFlows);
							}
						}
					}
				}
			}
			catch (IntegrationAdminException ex)
			{
				SigLogger.logError(
						BrokerUtil.class, sMethod, 
						"Error creating list of broker components!", ex);
			}
			finally
			{
				enumMessageFlows = null;
				enumDeployedObjects = null;
				sMethod = null;
				
				if (componentList != null)
				{
					if (componentList.size() == 0)
					{
						componentList.clear();
						componentList = null;
					}
				}
			}
			return componentList;
		}


		/**
		 * Private method used to add message flows, name and version, to the
		 * component list.
		 * <p>
		 * @param	componentList		The list of components.
		 * @param	enumMessageFlows	The set of message flows.
		 * <p>
		 * @throws ConfigManagerProxyException	Thrown if an error occurs in
		 * 										getting or handling message flow
		 * 										info. 
		 */
		
		private static void addSubFlowsToComponentList(final TreeMap<String, String> componentList,
										final Enumeration<SubFlowProxy> enumSubFlows)
									throws IntegrationAdminException
		{
			SubFlowProxy subFlow = null;
			String sName = null;
			String sExtension = null;
			String sComponentName = null;
			String sVersion = null;
			
			try
			{
				if (componentList != null)
				{
					if (enumSubFlows != null)
					{
						while (enumSubFlows.hasMoreElements())
						{
							subFlow = enumSubFlows.nextElement();
							
							if (subFlow != null)
							{
								sName = subFlow.getName();
								sExtension = subFlow.getSubFlowModel(true).getDescriptiveProperties().getLocationOnDisk();
								sVersion = subFlow.getSubFlowModel(true).getDescriptiveProperties().getVersion();
								
								if (sName != null)
								{
									sComponentName = sName;
									
									if (sExtension != null)
									{
										sComponentName += ('.' + sExtension);
									}
									componentList.put(sComponentName, sVersion);
								}
							}
						}
					}
				}
			}
			finally
			{
				subFlow = null;
				sName = null;
				sExtension = null;
				sComponentName = null;
				sVersion = null;
			}
		}
		
  
		/**
		 * Private method used to add message flows, name and version, to the
		 * component list.
		 * <p>
		 * @param	componentList		The list of components.
		 * @param	enumMessageFlows	The set of message flows.
		 * <p>
		 * @throws ConfigManagerProxyException	Thrown if an error occurs in
		 * 										getting or handling message flow
		 * 										info. 
		 */
		
		private static void addMessageFlowsToComponentList(final TreeMap<String, String> componentList,
										final Enumeration<MessageFlowProxy> enumMessageFlows)
									throws IntegrationAdminException
		{
			MessageFlowProxy messageFlow = null;
			String sName = null;
			String sVersion = null;
			
			try
			{
				if (componentList != null)
				{
					if (enumMessageFlows != null)
					{
						while (enumMessageFlows.hasMoreElements())
						{
							messageFlow = enumMessageFlows.nextElement();
							
							if (messageFlow != null)
							{
								sName = messageFlow.getName();
								sVersion = messageFlow.getMessageFlowModel(true).getDescriptiveProperties().getVersion();
								
								if (sName != null)
								{
									componentList.put(sName, sVersion);
								}
							}
						}
					}
				}
			}
			finally
			{
				messageFlow = null;
				sName = null;
				sVersion = null;
			}
		}

		
		/**
		 * Private method used to add message flow dependencies, name and version,
		 * to the component list.
		 * <p>
		 * @param	componentList		The list of components.
		 * @param	enumDeployedObjects	The set of deployed objects.
		 * <p>
		 * @throws ConfigManagerProxyException	Thrown if an error occurs in
		 * 										getting or handling deployed object
		 * 										info. 
		 */
		
		private static void addMessageFlowDependenciesToComponentList(final TreeMap<String, String> componentList,
									final Enumeration<Object> enumDeployedObjects)
								throws IntegrationAdminException
		{
			String sMethod = "addDeployeObjectsToComponentList";
			Object deployedObject = null;
			String sName = null;
			String sExtension = null;
			String sVersion = null;
			String sComponentName = null;
			StringBuilder sbKeywords = null;
			String[] sKeywordList = null;

			try
			{
				if (componentList != null)
				{
					if (enumDeployedObjects != null)
					{
						while (enumDeployedObjects.hasMoreElements())
						{
							deployedObject = enumDeployedObjects.nextElement();
							
							if (deployedObject != null)
							{
								if (SigLogger.isDebugEnabled())
								{
									sKeywordList = null;
		
									sbKeywords = new StringBuilder();
									
									if (sKeywordList == null)
									{
										sbKeywords.append("{null}");
									}
									else if (sKeywordList.length == 0)
									{
										sbKeywords.append("{empty}");
									}
									else
									{
										sbKeywords.append('(');
										for (int i = 0 ; i < sKeywordList.length ; ++i)
										{
											sbKeywords.append('[');
											sbKeywords.append(Integer.toString(i));
											sbKeywords.append("]=");
											sbKeywords.append(StringUtil.format(sKeywordList[i]));
											
											if ((i + 1) < sKeywordList.length) sbKeywords.append(',');
										}
										sbKeywords.append(')');
									}
									/*
									SigLogger.logDebug(
											BrokerUtil.class, sMethod, 
											
											"DeployedObject{Name=" +
											StringUtil.format(deployedObject.getName()) +
											",Version=" +
											StringUtil.format(deployedObject.getVersion()) +
											",FileExtension=" +
											StringUtil.format(deployedObject.getFileExtension()) +
											",FullName=" +
											StringUtil.format(deployedObject.getFullName()) +
											",ModifyTime=" +
											DateUtil.getStandardXmlFormatDate(deployedObject.getModifyTime()) + 
											",Keywords=" + sbKeywords.toString() + '}'); */
								}
								/*
								sName = deployedObject.getName();
								sExtension = deployedObject.getFileExtension();
								sVersion = deployedObject.getVersion(); */
								
								if (sName != null)
								{
									sComponentName = sName;
									
									if (sExtension != null)
									{
										sComponentName += ('.' + sExtension);
									}
									if (componentList.containsKey(sComponentName) == false)
									{
										componentList.put(sComponentName, sVersion);
									}
								}
							}
						}
					}
				}
			}
			finally
			{
				if (sbKeywords != null)
				{
					sbKeywords.setLength(0);
					sbKeywords = null;
				}
				sMethod = null;
				deployedObject = null;
				sName = null;
				sExtension = null;
				sVersion = null;
				sComponentName = null;
				sKeywordList = null;
			}
			
		}
		
		/**
		 * Returns a <code>TreeMap</code> of the components and versions.
		 * <p>
		 * @param	sBrokerName			The name of the broker.
		 * @param	sExecutionGroupName	The name of the execution group.
		 * <p>
		 * @return 		A <code>TreeMap</code> of the components and their
		 * 				associated versions, or <code>null</code> it the
		 * 				list is empty.
		 */
		
		public static TreeMap<String, String> getComponentList(final String sBrokerName, final String sExecutionGroupName)
		{
		
			TreeMap<String, String> componentList = null;
			
			try
			{
				IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
				IntegrationServerProxy server =
					        node.getIntegrationServerByName(sExecutionGroupName);
				if (server != null) {
				componentList = BrokerUtil.getComponentList(server);
				}
			} catch (IntegrationAdminException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return componentList;
		}

		
		/**
		 * Returns whether or not the execution group is initialized.
		 * <p>
		 * @param	sBrokerName				The name of the broker.
		 * @param	sExecutionGroupName		The name of the execution Group
		 * <p>
		 * @return		<code>TRUE</code> if initialized,
		 * 				otherwise <code>FALSE</code>.
		 */
		
		public static Boolean isExecutionGroupInitialzed(final String sBrokerName, final String sExecutionGroupName)
		{
			Boolean bRet = Boolean.TRUE;
			/*
			Enumeration<Object> enumDeployedObjects = null;
			IntegrationServerProxy execGroup = null;
			
			try
			{
				// If we successfully retrieve the execution group and
				// its list of deployed objects, the broker appears
				// to have been initialized.
				
				execGroup = BrokerUtil.getExecutionGroup(sBrokerName, sExecutionGroupName);
				
				if (execGroup != null)
				{
					enumDeployedObjects = BrokerUtil.getDeployedObjects(execGroup);
					
					if (enumDeployedObjects != null)
					{
						bRet = Boolean.TRUE;
					}
				}
			}
			finally
			{
				enumDeployedObjects = null;
				execGroup = null;
			}
			*/
			return bRet;
		}

//--------------------------------------------------addmethods
//----------------------------------------------------------------
// Private methods.
//----------------------------------------------------------------

/**
* Initializes the version list based on the specified broker name
* and execution group.
* <p>
* @param sBrokerName			The name of the broker.
* @param sExecutionGroupName	The name of the execution group.
*/

private synchronized static void initVersionList(final String sBrokerName,
			final String sExecutionGroupName)
{
IntegrationServerProxy execGroup = null; 
TreeMap<String, String> componentList = null;

try
{
if (BrokerUtil.loadVersionList(sBrokerName, sExecutionGroupName) == true)
{
SigLogger.logDebug(BrokerUtil.class, "initVersionList()",
"Initializing version list of components...");

IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
 execGroup =
	        node.getIntegrationServerByName(sExecutionGroupName);


if (execGroup != null)
{
componentList = BrokerUtil.getComponentList(execGroup);

BrokerUtil.setVersionList(componentList);

if (BrokerUtil.propVersion != null)
{
SigLogger.logInfo(BrokerUtil.class, "initVersionList()",
	"BrokerUtil.propVersion=" + BrokerUtil.propVersion.toString());

if (BrokerUtil.propVersion.isEmpty() == false)
{
if (BrokerUtil.bVersionInfoInitialized == false)
{
	BrokerUtil.bVersionInfoInitialized = true;

	SigLogger.logInfo(BrokerUtil.class, "initVersionList()",
			"Successfully initialized version list of components.");
}
else
{
	SigLogger.logInfo(BrokerUtil.class, "initVersionList()",
			"Successfully reloaded version list of components.");
}
BrokerUtil.nVersionInfoLoadedTime = SigUtil.currentUTCTimeMillis().longValue();
}
else
{
SigLogger.logWarn(BrokerUtil.class, "initVersionList()",
		"Version list is empty! BrokerUtil.propVersion=" + 
		BrokerUtil.propVersion.toString());
}
}
else
{
SigLogger.logWarn(BrokerUtil.class, "initVersionList()",
	"Version list is null! BrokerUtil.propVersion={null}!");
}
}
}
} catch (IntegrationAdminException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally
{
if (componentList != null)
{
componentList.clear();
componentList = null;
}
execGroup = null;
}
}

/**
* Returns whether or not the version list should be loaded.
* <p>
* @return		<code>true</code> if the list should be loaded, otherwise
* 				<code>false</code>.
*/

private static boolean loadVersionList(final String sBrokerName, final String sExecutionGroupName)
{
boolean bRet = true;
/*
 * long nCurrentTime = 0;
long nInterval = 0;
String sVersionReloadInterval = null;
IntegrationServerProxy egp = null;
Enumeration<Object> enumDeployedObjects = null;
Object deployedObject = null;

try
{
if (BrokerUtil.nVersionReloadInterval <= 0)
{
sVersionReloadInterval = System.getenv(SigConstants.ENV_VERSION_RELOAD_TIME);

BrokerUtil.nVersionReloadInterval = 
StringUtil.parseLong(sVersionReloadInterval, BrokerUtil.DEFAULT_VERSION_RELOAD_TIME);

// Set the system property containing the reload time. This is
// nice to have since we can then check the system properties
// to make sure it was set correctly.

System.setProperty(SigConstants.SIG_VERSION_RELOAD_TIME, 
	   Long.toString(BrokerUtil.nVersionReloadInterval));
}
if (BrokerUtil.bVersionInfoInitialized == false)
{
bRet = true;

BrokerUtil.nVersionMandatoryReloadCount = 0;
}
else
{
// Ok. This is really a hack. Essentially when broker loads
// the bar file, the java code is loaded ahead of the flows.
// In some cases, this allows the java code to be executed
// ahead of the loading of the flows resulting in potentially
// an old or stale version being kept around. To compensate,
// we init the version list when we start, then we wait the
// delay period before checking to make sure we really pick
// up the new versions. 
//
// To make this process somewhat efficient, we do force a
// reload the first few times through, just to make sure
// we pick up everything. Then, we reload only if the 
// deployment time changes on the deployed artifact.

nCurrentTime = SigUtil.currentUTCTimeMillis().longValue();

nInterval = nCurrentTime - BrokerUtil.nVersionInfoLoadedTime;

if (nInterval > BrokerUtil.nVersionReloadInterval)
{
if (BrokerUtil.nVersionMandatoryReloadCount < BrokerUtil.VERSION_RELOAD_MAX)
{
// Always reload the version info this many times. This 
// is because the version info for all flows may not
// have been updated on the initial pass. Just a quirk
// of how broker comes up and initializes.

++BrokerUtil.nVersionMandatoryReloadCount;

bRet = true;
}
else
{
egp = BrokerUtil.getExecutionGroup(sBrokerName, sExecutionGroupName);

if (egp != null)
{
enumDeployedObjects = BrokerUtil.getDeployedObjects(egp);

if (enumDeployedObjects == null)
{
	bRet = true;
}
else
{
	deployedObject = enumDeployedObjects.nextElement();
	
	if (deployedObject == null)
	{
		bRet = true;
	}
	else
	{
		if (deployedObject.getDeployTime().getTime() > BrokerUtil.nVersionInfoLoadedTime)
		{
			bRet = true;
		}
	}
}
}
else
{
bRet = true;
}
if (bRet == true)
{
// We've reloaded, so set the mandatory reload
// count back to 0.

BrokerUtil.nVersionMandatoryReloadCount = 0;
}
}
}
}
}
finally
{
sVersionReloadInterval = null;
egp = null;
enumDeployedObjects = null;
deployedObject = null;
}
*/
return bRet;
}

/**
* Returns the execution group based on the specified broker name and
* execution group name.
* <p>
* @param sBrokerName 				The broker name.
* @param sExecutionGroupName		The execution group name.
* <p>
* @return		The execution group.
*/

private static synchronized IntegrationServerProxy getExecutionGroup(
		final String sBrokerName,
		final String sExecutionGroupName)
{
String sBroker = null;
String sExecutionGroup = null;

try
{
if (StringUtil.isEmpty(sBrokerName) == false && 
StringUtil.isEmpty(sExecutionGroupName) == false)
{
if (BrokerUtil.executionGroupProxy == null || 
BrokerUtil.brokerProxy == null)
{
BrokerUtil.initProxy(sBrokerName, sExecutionGroupName);
}
else
{
sBroker = BrokerUtil.brokerProxy.getName();
sExecutionGroup = BrokerUtil.executionGroupProxy.getName();

if (sBroker.equalsIgnoreCase(sBrokerName) == false ||
sExecutionGroup.equalsIgnoreCase(sExecutionGroupName) == false)
{
BrokerUtil.initProxy(sBrokerName, sExecutionGroupName);
}
}
}
}
catch (IntegrationAdminException ex)
{
SigLogger.logError(
BrokerUtil.class, "getExecutionGroup()", 
"Error determining execution group (Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
StringUtil.format(sExecutionGroupName) + ")!", ex);
}
finally
{
sBroker = null;
sExecutionGroup = null;
}
return BrokerUtil.executionGroupProxy;
}

/**
* Initializes the execution group and broker proxy objects.
* <p>
* @param sBrokerName			The broker.
* @param sExecutionGroupName	The execution group name.
*/

private static void initProxy(final String sBrokerName,
     final String sExecutionGroupName)
{
String sMethod = "initProxy()";

try
{
if (StringUtil.isEmpty(sBrokerName) == false &&
StringUtil.isEmpty(sExecutionGroupName) == false)
{
if (BrokerUtil.brokerProxy != null)
{
//BrokerUtil.brokerProxy.disconnect();
BrokerUtil.brokerProxy = null;
}

SigLogger.logInfo(
BrokerUtil.class, sMethod, 
"Initializing ExecutionGroupProxy (Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
StringUtil.format(sExecutionGroupName) + ")...");

BrokerUtil.brokerProxy = new IntegrationNodeProxy(sBrokerName);

BrokerUtil.executionGroupProxy = 
BrokerUtil.brokerProxy.getIntegrationServerByName(sExecutionGroupName);

SigLogger.logInfo(
BrokerUtil.class, sMethod, 
"ExecutionGroupProxy initialized (Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
StringUtil.format(sExecutionGroupName) + ")...");
}
}
catch (IntegrationAdminException ex)
{
SigLogger.logError(
BrokerUtil.class, sMethod, 
"Error determining execution group (Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
StringUtil.format(sExecutionGroupName) + ")!", ex);

BrokerUtil.executionGroupProxy = null;
}
finally
{
if (BrokerUtil.executionGroupProxy != null)
{
SigLogger.logInfo(BrokerUtil.class, sMethod,
"Successfully obtained ExecutionGroupProxy for Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" + 
StringUtil.format(sExecutionGroupName) + '.');
}
else
{
SigLogger.logWarn(BrokerUtil.class, sMethod,
"Failed to get ExecutionGroupProxy for Broker=" +
StringUtil.format(sBrokerName) + ",ExecutionGroup=" +
StringUtil.format(sExecutionGroupName) +
"! ExecutionGroupProxy is null!");
}
sMethod = null;
}
}

/**
* Returns the named message flow from the specified broker and execution
* group.
* <p>
* @param sBrokerName			The name of the broker.
* @param sExecutionGroupName	The name of the execution group.
* @param sMessageFlowName		The name of the message flow.
* <p>
* @return		The message flow.
*/

private static MessageFlowProxy getMessageFlow(final String sBrokerName,
				       final String sExecutionGroupName,
				       final String sMessageFlowName)
{
MessageFlowProxy messageFlowProxy = null;
IntegrationServerProxy execGroup = null;

try
{
	IntegrationNodeProxy node = new IntegrationNodeProxy(sBrokerName);
	IntegrationServerProxy server =
		        node.getIntegrationServerByName(sExecutionGroupName);
	if (server != null) {
		
        List<ApplicationProxy> ap = server.getAllApplications(true);
		for(int i = 0 ; i<ap.size(); i++)
		{
			
			List<MessageFlowProxy> mfp = ap.get(i).getAllMessageFlows(true);
			for(int j = 0 ; j<mfp.size(); j++)
			{
				if (mfp.get(j).getName().equals(sMessageFlowName))
				
				{
					System.out.println(mfp.get(j).getName());
					 messageFlowProxy = 
					          server.getApplicationByName(ap.get(i).getName(), true).getMessageFlowByName(sMessageFlowName,"",false);
									

		        
				}
			}
		}
		
		
		
		
	}

} catch (IntegrationAdminException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally
{
execGroup = null;
}
return messageFlowProxy;
}

/**
* Returns the named message flow from the specified execution group.
* <p>
* @param execGroup	The execution group.
* @param sMessageFlowName		The name of the message flow.
* <p>
* @return		The message flow.
*/

private static MessageFlowProxy getMessageFlow(final IntegrationServerProxy execGroup,
					   final String sMessageFlowName)
{
MessageFlowProxy messageFlowProxy = null;
Enumeration<ApplicationProxy> enumApps = null;
ApplicationProxy appProxy = null;
/*
try
{
if (execGroup != null &&
StringUtil.isEmpty(sMessageFlowName) == false)
{
messageFlowProxy = execGroup.getMessageFlowByName(sMessageFlowName);

if (messageFlowProxy == null)
{
enumApps = execGroup.getApplications(null);

if (enumApps != null)
{
while (messageFlowProxy == null && enumApps.hasMoreElements())
{
appProxy = enumApps.nextElement();

if (appProxy != null)
{
	messageFlowProxy = appProxy.getMessageFlowByName(sMessageFlowName, null);
}
}
}
}
}
}
catch (ConfigManagerProxyException ex)
{
SigLogger.logError(
BrokerUtil.class, "getMessageFlow()", 
"Error determining MessageFlowProxy (MessageFlow=" +
StringUtil.format(sMessageFlowName) + ")!", ex);

messageFlowProxy = null;
}
finally
{
enumApps = null;
appProxy = null;
}
*/
return messageFlowProxy;
}

/**
* Sets the version list based on the specified set of components.
* <p>
* @param	componentList		TreeMap of the components.
*/

private static void setVersionList(final TreeMap<String, String> componentList)
{
Set<String> keySet = null;
Iterator<String> it = null;
String sName = null;
String sVer = null;

try
{
if (BrokerUtil.propVersion != null)
{
BrokerUtil.propVersion.clear();
BrokerUtil.propVersion = null;
}
BrokerUtil.propVersion = new Properties();

if (componentList != null)
{
SigLogger.logDebug(BrokerUtil.class, "setVersionList()",
"componentList=" + componentList.toString());

keySet = componentList.keySet();

if (keySet != null)
{
for (it = keySet.iterator() ; it.hasNext() ; )
{
sName = it.next();

if (sName != null)
{
sVer = componentList.get(sName);

if (sVer == null)
{
	sVer = BrokerUtil.DEFAULT_VERSION;
}
BrokerUtil.propVersion.setProperty(sName, sVer);
}
}
}
}
else
{
SigLogger.logWarn(BrokerUtil.class, "setVersionList()",
"Did not set version list! null component list specified!");
}
}
finally
{
if (keySet != null)
{
keySet.clear();
keySet = null;
}
it = null;
sName = null;
}
}


		
		
		
		
				
		
		
//----------------------------------------------------------------
	// Private member variables
	//----------------------------------------------------------------

	private static final String DEFAULT_VERSION = "0.0.0.0";
	private static final long DEFAULT_VERSION_RELOAD_TIME = 300000;
	private static final int VERSION_RELOAD_MAX = 2;
	
	private static boolean bVersionInfoInitialized = false;
	private static long nVersionInfoLoadedTime = 0;
	private static long nVersionReloadInterval = 0;
	private static int nVersionMandatoryReloadCount = 0;
	
	private static Properties propVersion = null;
	
	private static IntegrationNodeProxy brokerProxy = null;
	private static IntegrationServerProxy executionGroupProxy = null;
  
	 static
	  {
		  IntegrationNodeProxy brokerProxy1 = null;
		  IntegrationServerProxy executionGroupProxy1 = null;
		 try {
			brokerProxy1 = new IntegrationNodeProxy("ACENODE");
			executionGroupProxy1 = brokerProxy1.getIntegrationServerByName("default");
			brokerProxy =brokerProxy1;
			executionGroupProxy =executionGroupProxy1;
			System.out.println(executionGroupProxy.getName());
		} catch (IntegrationAdminException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
}