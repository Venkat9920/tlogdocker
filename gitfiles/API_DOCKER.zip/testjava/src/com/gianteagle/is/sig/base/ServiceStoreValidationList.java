/*
 * ServiceStoreValidationList
 */

package com.gianteagle.is.sig.base;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.List;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.gianteagle.is.net.Html;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.sig.store.StoreValidationList;
import com.gianteagle.is.sig.store.StoreValidationManager;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used in an HTTP request context to dump the store validation list
 * within the current execution group. Since this is used in an
 * HTTP context, the result is either XML or HTML based on the value
 * of the <code>format</code> field specified in the request.
 * <p> 
 * @author	ReichertSF
 */

public final class ServiceStoreValidationList
{
	/**
	 * Default constructor.
	 */
	
	private ServiceStoreValidationList()
	{
	}
	
	/**
	 * Constructs the HTTP response containing the store validation list.
	 * <p>
	 * @param	mbNode				Reference to the MbJavaComputeNode calling 
	 * 								this method.
	 * @param	inAssembly			Reference to the top level assembly (InputRoot).
	 * @param	outTerminal			The output terminal.
	 * @param 	sServiceName		The name of the service
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getStoreValidationList(final MbJavaComputeNode mbNode,
										 final MbMessageAssembly inAssembly,
									     final MbOutputTerminal outTerminal,
									     final String sServiceName)
							throws MbException
	{
		MbMessage inMessage = null;
		MbMessage outMessage = null;
		MbMessageAssembly outAssembly = null;
		ByteArrayOutputStream baos = null;
		PrintWriter pw = null;
		HttpContentType httpContentType = null;
		Hashtable<String, String[]> hFields = null;
		String sServiceVersion = null;
		String sBrokerName = null;
		String sExecutionGroupName = null;

		try
		{
			// Reference the input message from the assembly.
			
			inMessage = inAssembly.getMessage();

			// Create the output message and output assembly.
			
			outMessage = new MbMessage(inMessage);
    		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);

			// Remove the existing "HTTPInputHeader". We're done with
   			// it and don't want to propagate it further.
    			
   			SigUtil.removeNamedElement(outMessage, "HTTPInputHeader");
    			
   			// Remove the existing "BLOB" element. In a GET or POST
   			// request with fields, this will contain the form fields
   			// from the original request, and we don't want to 
   			// return them.
    			
   			SigUtil.removeNamedElement(outMessage, "BLOB");
   			
   			if (mbNode != null)
   			{
   				sBrokerName = mbNode.getBroker().getName();
   				sExecutionGroupName = mbNode.getExecutionGroup().getName();
   			}
   			
   			// Retrieve the Service Version from the message flow.

   			sServiceVersion = 
   					BrokerUtil.getComponentVersion(sBrokerName,
   												   sExecutionGroupName,
   												   sServiceName);
 			
    		baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
    		pw = new PrintWriter(baos);

    		hFields = SigUtil.getHttpGetRequestFields(inAssembly);
    		
    		if (SigUtil.isFormatXml(hFields) == true)
    		{
    			httpContentType = HttpContentType.ApplicationXml;

    			ServiceStoreValidationList.getXmlResponse(pw);
    		}
    		else
    		{
    			httpContentType = HttpContentType.TextHtml;
    			
    			ServiceStoreValidationList.getHtmlResponse(pw, sServiceName, sServiceVersion);
    		}
     		pw.flush();

     		SigUtil.setOuputHttpResponse(
     					outMessage, httpContentType, baos.toByteArray());
		
     		// Propagate the output results to the 'out' terminal.
			
			outTerminal.propagate(outAssembly);
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (baos != null)
			{
				try { baos.close(); } catch (Throwable ignore) { } 
				baos = null;
			}
			if (hFields != null)
			{
				hFields.clear();
				hFields = null;
			}
			inMessage = null;
			outMessage = null;
			outAssembly = null;
			httpContentType = null;
			sServiceVersion = null;
			sBrokerName = null;
			sExecutionGroupName = null;
		}
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Generates the response as XML.
	 * <p>
	 * @param	pw				PrintWriter to send the output to.
	 */
	
	private static void getXmlResponse(final PrintWriter pw)
	{
		String sMethod = "getXmlResponse()";
		
		try
		{
			if (pw != null)
			{
				pw.println(StringUtil.format(StoreValidationManager.getAsXmlString()));
			}
		}
		catch (Throwable th)
		{
			SigLogger.logError(ServiceStoreValidationList.class, sMethod, 
							"Fatal error creating StoreValiationList!", th);
		}
		finally
		{
			sMethod = null;
		}
	}
	
	/**
	 * Generates the response as HTML.
	 * <p>
	 * @param	pw					PrintWriter to send the output to.
	 * @param	sBrokerName			The name of the broker.
	 * @param	sExecutionGroupName	The name of the execution group.
	 * @param 	sServiceName		The name of the service
	 * @param	sServiceVersion		The version of the service.
	 * @param	sAdditionalJarInfo	Additional Jar Information for HTML output.
	 */
	
	private static void getHtmlResponse(final PrintWriter pw,
									       final String sServiceName,
									       final String sServiceVersion)
	{
		String sMethod = "getHtmlResponse()";
		String sBgColor = null;
		List<StoreValidationList.Store> storeValidationList = null;
		StoreValidationList.Store store = null;

		try
		{
			pw.println(Html.beginHtml());

			pw.println(Html.beginHead());
			pw.println(Html.title(StringUtil.format(sServiceName) + " StoreValidationList"));
			pw.println(Html.endHead());
			
			pw.println(Html.beginBody());

			pw.println(Html.h2(
					StringUtil.format(sServiceName) + 
					" Version " + 
					StringUtil.format(sServiceVersion)));
    		
    		pw.println(Html.h3("StoreValidationList"));
    		
    		pw.println(Html.beginTable());
    		
    		pw.println(Html.beginTableRow("bgcolor=\"#90EE90\""));	//LightGreen
    		pw.println(Html.tableData(Html.bold("ID")));
    		pw.println(Html.tableData(Html.bold("StoreNumber")));
    		pw.println(Html.tableData(Html.bold("DivisionNumber")));
    		pw.println(Html.tableData(Html.bold("Enabled")));
    		pw.println(Html.endTableRow());
    		
    		storeValidationList = StoreValidationManager.getStoreValidationList();
    		
    		if (storeValidationList != null)
    		{
    			for (int i = 0 ; i < storeValidationList.size() ; ++i)
    			{
					store = storeValidationList.get(i);

					if (store != null)
					{
						if ((i % 2) == 0)
						{
							sBgColor = "bgcolor=\"#FAEBD7\"";	// AntiqueWhite
						}
						else
						{
							sBgColor = "bgcolor=\"#FFFFFF\"";	// White
						}
						pw.println(Html.beginTableRow(sBgColor));
						pw.println(Html.tableData(Html.code(StringUtil.format(store.getId()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(store.getStoreNumber()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(store.getDivisionNumber()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(store.isEnabled()))));
						pw.println(Html.endTableRow());
					}
    			}
    		}
    		else
    		{
    			SigLogger.logWarn(ServiceStoreValidationList.class, sMethod, "StoreValidationList is null!");
    		}
    		pw.println(Html.endTable());

			pw.println(Html.rule());

			pw.println(Html.small(Html.italic(DateUtil.getCurrentDateTime())));

			pw.println(Html.endBody());
			
    		pw.println(Html.endHtml());
		}
		catch (Throwable th)
		{
			SigLogger.logError(ServiceStoreValidationList.class, sMethod, 
							"Fatal error creating StoreValiationList!", th);
		}
		finally
		{
			sBgColor = null;
			storeValidationList = null;
			store = null;
		}
	}
}
