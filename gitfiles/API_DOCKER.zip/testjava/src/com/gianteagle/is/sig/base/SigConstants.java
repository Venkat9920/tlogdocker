 /**
 * SigServiceConstants.java
 */

package com.gianteagle.is.sig.base;

/**
 * Defines common constants.
 * <p>
 * @author ReichertSF
 */

public interface SigConstants
{
	/**
	 * System Property defining the base location for the logs, config, etc.
	 */
	
	String SIG_BASE = "com.gianteagle.is.sig.base";
	
	/**
	 * System Property defining the version reload delay. 
	 */
	
	String SIG_VERSION_RELOAD_TIME = "com.gianteagle.is.sig.version.reload.time";
	
	/**
	 * System Property defining the name of the broker.
	 */
	
	String SIG_BROKER_NAME = "com.gianteagle.is.sig.broker.name";
	
	/**
	 * System environment variable defining the version reload time. The
	 * value of this variable is used to set the associated system property.
	 */
	
	String ENV_VERSION_RELOAD_TIME = "VERSION_RELOAD_TIME";
	
	/**
	 * Name of the resource holding the logger configuration.
	 */
	
	String LOG_CONFIG = "log4j2.xml";
	
	/**
	 * Name of the core application logger.
	 */
	
	String APP_LOGGER = "SIGApplicationLog";
	
	/**
	 * Name of the error logger.
	 */
	
	String ERROR_LOGGER = "SIGErrorLog";
	
	/**
	 * Name of the timing logger.
	 */
	
	String TIMING_LOGGER = "SIGTimingLog";
	
	/**
	 * Name of the transaction logger.
	 */
	
	String TRANSACTION_LOGGER = "SIGTransactionLog";
	
	/**
	 * Name of the message logger.
	 */
	
	String MESSAGE_LOGGER = "SIGMessageLog";
	
	/**
	 * Constant string used to identify Version.
	 */
	
	String VERSION = "Version";
	
	/**
	 * Constant string used to identify the base directory.
	 */
	
	String BASE_DIRECTORY = "BaseDirectory";
	
	/**
	 * Constant string used to identify the configuration directory.
	 */
	
	String CONFIG_DIRECTORY = "ConfigDirectory";
	
	/**
	 * Constant string used to identify the log directory.
	 */
	
	String LOG_DIRECTORY = "LogDirectory";

	/**
	 * Constant string used to identify the data file directory.
	 */
	
	String DATA_FILE_DIRECTORY = "DataFileDirectory";

	/**
	 * Constant string used to identify the temporary directory.
	 */
	
	String TEMP_DIRECTORY = "TempDirectory";
	
	/**
	 * Constant string used to identify the xfer (transfer) directory.
	 */
	
	String XFER_DIRECTORY = "XferDirectory";
	
	/**
	 * Constant string used to identify the out-bound xfer (transfer) directory.
	 */
	
	String OUTBOUND_XFER_DIRECTORY = "OutBoundXferDirectory";
	
	/**
	 * Constant string used to identify the in-bound xfer (transfer) directory.
	 */
	
	String INBOUND_XFER_DIRECTORY = "InBoundXferDirectory";
	
	/**
	 * Configuration constant defining the VSA Name.
	 */
	
	String VSA_NAME = "VSAName";
	
	/**
	 * Configuration constant defining the Store Name.
	 */
	
	String STORE_NAME = "StoreName";
	
	/**
	 * Configuration constant defining the Store Number.
	 */
	
	String STORE_NUMBER = "StoreNumber";
	
	/**
	 * Configuration constant defining the Division number.
	 */
	
	String DIVISION_NUMBER = "DivisionNumber";
	
	/** 
	 * Configuration constant defining the Division. 
	 */

	String DIVISION = "Division";
	
	/**
	 * Configuration constant defining whether or not to validate store
	 * and division.
	 */
	
	String VALIDATE_STORE_DIVISION = "validateStoreDivision";
	
	/**
	 * Configuration constant defining whether or not to validate store
	 * and division based on the list of stores/divisions.
	 */
	
	String USE_STORE_VALIDATION_LIST = "useStoreValidationList";
	
	/**
	 * Configuration constant defining the file containing the list of
	 * valid stores/divisions.
	 */
	
	String STORE_VALIDATION_LIST_FILE = "storeValidationListFile";
	
	/**
	 * Configuration constant defining the Logger Configuration File.
	 */
	
	String LOGGER_CONFIG_FILE = "loggerConfigFile";
	
	/**
	 * Configuration constant defining whether or not to log route messages.
	 */

	String LOG_ROUTE_MESSAGE = "logRouteMessage";
	
	/**
	 * Configuration constant defining whether or not route messages 
	 * are to be sent with the attribute that indicates they are
	 * test messages rather than production messages
	 */
	
	String TEST_ROUTE_MESSAGE = "testRouteMessage";
	
	/**
	 * Configuration constant used to define the maximum queue back out count. 
	 */
	
	String MAX_BACKOUT_COUNT = "maxBackoutCount";
	
	/**
	 * Configuration constant defining whether or no the maximum back out
	 * count is enforced.
	 */
	
	String ENABLE_MAX_BACKOUT_COUNT = "enableMaxBackoutCount";
	
	/**
	 * Configuration constant used to define the rollback delay when 
	 * rolling messages back to a queue.
	 */
	
	String ROLLBACK_DELAY = "rollbackDelay";
	
	/**
	 * Configuration constant used to define the interval between
	 * reload checks of the store level configuration.
	 */

	String CONFIG_RELOAD_INTERVAL = "configReloadInterval";
	
	/**
	 * Configuration constant used to define whether or not ERRORs should
	 * be published.
	 */
	
	String PUBLISH_ERRORS = "publishErrors";
	
	/**
	 * Configuration constant used to define whether or not generation of 
	 * SigEvent messages should be enabled.
	 */
	
	String ENABLE_SIG_EVENTS = "enableSigEvents";

	/**
	 * Configuration constant used to define the base topic string used
	 * to publish errors.
	 */
	
	String ERROR_TOPIC_STRING = "errorTopicString";
	
	/**
	 * Configuration constant used to define the length in  bytes to use 
	 * when accessing a file. This value is typically supplied to a 
	 * FileRead node as the Record Length when reading a raw file.
	 */

	String FILE_BUFFER_LENGTH = "fileBufferLength";
	
	/**
	 * Configuration constant used to define the base topic string used
	 * to publish status.
	 */
	
	String STATUS_TOPIC_STRING = "statusTopicString";
	
	/**
	 * Configuration constant used to define a base topic string.
	 */
	
	String BASE_TOPIC_STRING = "baseTopicString";
	
	/**
	 * Configuration constant used to define a topic string.
	 */
	
	String TOPIC_STRING = "topicString";
	
	/**
	 * Configuration constant used to define a base SigRoute event string.
	 */
	
	String ROUTE_EVENT_STRING = "routeEventString";
	
	/**
	 * Configuration constant defining whether or not a service is enabled.
	 */
	
	String IS_ENABLED = "isEnabled";
	
	/**
	 * Configuration constant defining whether or not debug mode is enabled.
	 */
	
	String DEBUG_MODE = "debugMode";
	
	/**
	 * Configuration constant defining a URL.
	 */
	
	String URL = "url";
	
	/**
	 * Configuration constant defining a host name or host ip address.
	 */
	
	String HOST = "host";
	
	/**
	 * Configuration constant defining an HTTP port number.
	 */
	
	String HTTP_PORT = "http.port";

	/**
	 * Configuration constant defining an HTTP request timeout.
	 */
	
	String HTTP_REQUEST_TIMEOUT = "httpRequestTimeout";
	
	/**
	 * Configuration constant defining an event port number.
	 */
	
	String EVENT_PORT = "event.port";
	
	/**
	 * Configuration constant defining an sftp port number.
	 */
	
	String SFTP_PORT = "sftp.port";
	
	/**
	 * Configuration constant defining an event publication timeout.
	 */
	
	String EVENT_PUBLISH_TIMEOUT = "eventPublishTimeout";

	/**
	 * Configuration constant defining a report resource in a URL.
	 */
	
	String REPORT_RESOURCE = "reportResource";
	
	/**
	 * Configuration constant defining the topic used to publish
	 * report data requests.
	 */
	
	String GET_REPORT_DATA_TOPIC = "getReportDataTopic";
	
	/**
	 * Configuration constant defining a base filter for events.
	 */
	
	String BASE_FILTER = "baseFilter";
	
	/**
	 * Configuration constant defining whether or not events are enabled.
	 */
	
	String EVENTS_ENABLED = "eventsEnabled";
	
	/**
	 * Configuration constant defining whether or not reports are enabled.
	 */

	String REPORTS_ENABLED = "reportsEnabled";
	
	/**
	 * Configuration constant defining whether or not reporting of non-fatal
	 * errors is enabled.
	 */

	String REPORT_NON_FATAL_ERRORS = "reportNonFatalErrors";
	
	/**
	 * Configuration constant defining a publication list.
	 */
	
	String PUBLICATION_LIST = "publicationList";
	
	/**
	 * Configuration constant defining a DataSourceName (DSN).
	 */
	
	String DSN = "DSN";
	
	/**
	 * Configuration constant defining a DataSourceName for JDBC.
	 */
	
	String JDBC_DSN = "JDBCDSN";
	
	/**
	 * Configuration constant defining whether or not ODBC should
	 * be used in database access.
	 */
	
	String USE_ODBC = "useODBC";
	
	/**
	 * Configuration constant defining whether or not JDBC should 
	 * be used in database access.
	 */
	
	String USE_JDBC = "useJDBC";
	
	/**
	 * Configuration constant defining whether or not DB access is enabled.
	 */
	
	String DB_ACCESS_ENABLED = "dbAccessEnabled";
	
	/**
	 * Configuration constant defining a Query Timeout.
	 */
	
	String QUERY_TIMEOUT = "queryTimeout";
	
	/**
	 * Configuration constant defining the error topic type
	 * used to publish errors. The topic type is used to complete 
	 * the error topic string.
	 */
	
	String ERROR_TOPIC_TYPE_STRING = "errorTopicTypeString";
	
	/**
	 * Configuration constant defining a destination directory.
	 */
	
	String DESTINATION_DIRECTORY = "destinationDirectory";
	
	/**
	 * Configuration constant defining a security identity.
	 */
	
	String SECURITY_IDENTITY = "securityIdentity";
	
	/**
	 * Configuration constant defining a test file name.
	 */
	
	String TEST_FILE = "testFile";
	
	/**
	 * Configuration constant defining Payload type.
	 */
	
	String PAYLOAD_TYPE = "payloadType";
	
	/**
	 * Configuration constant defining a Message Expiry time.
	 */
	
	String MESSAGE_EXPIRY = "messageExpiry";
	
	/**
	 * Configuration constant defining whether or not a client specified
	 * timeout is allowable.
	 */

	String ALLOW_CLIENT_SPECIFIED_TIEMOUT = "allowClientSpecifiedTimeout";
	
	/**
	 * Configuration constant defining the route topic for a
	 * SigExpMessage.
	 */
	
	String SIG_EXP_MESSAGE_ROUTE_TOPIC = "SigExpMessageRouteTopic";
	
	/**
	 * Configuration constant defining the publication topic for a
	 * SigExpMessage.
	 */
	
	String SIG_EXP_MESSAGE_PUBLISH_TOPIC = "SigExpMessagePublishTopic";
	
	/**
	 * Configuration constant defining the delivery topic for a 
	 * SigExpMessage.
	 */
	
	String SIG_EXP_MESSAGE_DELIVERY_TOPIC = "SigExpMessageDeliveryTopic";
	
	/**
	 * Configuration constant defining whether or not to include time
	 * stamp data on publication. 
	 */
	
	String INCLUDE_TIME_STAMP_DATA = "includeTimeStampData";
	
	/**
	 * Configuration constant defining the list of time stamp data fields.
	 */
	
	String TIME_STAMP_DATA_LIST = "timeStampDataList";

	/**
	 * Defines the status value of <code>OK</code>.
	 */
	
	String OK_STATUS = "OK";
	
	/**
	 * Defines the status value of <code>ERROR</code>.
	 */
	
	String ERROR_STATUS = "ERROR";
	
	/**
	 * Defines the standard configuration element <code>application</code>. 
	 */
	
	String APPLICATION_ELEMENT = "application";
	
	/**
	 * Defines the standard <code>system</code> configuration element.
	 */
	
	String SYSTEM_ELEMENT = "system";
	
	/**
	 * Defines the standard <code>property</code> configuration element.
	 */
	
	String PROPERTY_ELEMENT = "property";
	
	/**
	 * Defines the standard <code>propertyList</code> configuration element.
	 */
	
	String PROPERTY_LIST_ELEMENT = "propertyList";
	
	/**
	 * Defines the standard <code>item</code> configuration element.
	 */
	
	String ITEM_ELEMENT = "item";
	
	/**
	 * Defines the standard <code>key</code> configuration attribute.
	 */
	
	String KEY_ATTRIBUTE = "key";
	
	/**
	 * Defines the standard <code>name</code> configuration attribute.
	 */
	
	String NAME_ATTRIBUTE = "name";
	
	/**
	 * Defines the standard <code>value</code> configuration attribute.
	 */
	
	String VALUE_ATTRIBUTE = "value";
	
	/**
	 * Defines the standard length of a Store Number.
	 */
	
	int STORE_NUMBER_LEN = 5;
	
	/**
	 * Defines the standard length of a Division Number.
	 */
	
	int DIVISION_NUMBER_LEN = 3;

	String LOGGER_HOST = "loggerHost";

	String LOGGER_PORT = "loggerPort";

	String LOGGER_ROUTING_KEY = "loggerRoutingKey";

	String LOGGER_HOST_PROPERTY = "com.gianteagle.is.sig.base.loggerHost";

	String LOGGER_PORT_PROPERTY = "com.gianteagle.is.sig.base.loggerPort";

	String LOGGER_ROUTING_KEY_PROPERTY = "com.gianteagle.is.sig.base.loggerRoutingKey";
}
