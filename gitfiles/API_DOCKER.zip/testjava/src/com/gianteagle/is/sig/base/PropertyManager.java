/**
 * Collection.java
 */

package com.gianteagle.is.sig.base;

import java.util.Properties;
import java.util.Set;

import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class used to manage properties.
 * The intention is that this is will be used to manage global
 * runtime properties.
 * <p>
 * @author	SandersJL
 */

// The public static methods have signatures that are compatible with
// JAVA calls in IIB. Synchronizing these methods was avoided, out of
// caution, in order to not violate the exact signatures required by
// IIB. Each public static method then utilizes a private static
// synchronized methods to do the actual work. This allows synchronization
// to prevent concurrent access violations.

public final class PropertyManager
{
	/**
	 * Private constructor.
	 */
	
	private PropertyManager()
	{
	}
	
	/**
	 * Sets the specified item to specified value.
	 * Adds the specified item to the propertyManager.
	 * <p>
	 * @param	sPropertyName	Name of the property.
	 * @param	sValue			The value of the property.
	 */

	public static void setPropertyItem(final String sPropertyName, final String sValue)
	{
		if (StringUtil.isEmpty(sPropertyName) == false  && StringUtil.isEmpty(sValue) == false){
			propertyManager.setProperty(sPropertyName, sValue);
		}		
	}
	
	
	/**
	 * Returns the value of specified property.
	 * @param	sPropertyName		The name of the specified property.
	 * <p>
	 * @return	The value of specified property 
	 * 			or <code>null</code> if the property 
	 * 			does not exist
	 */
	
	public static String getPropertyValue(final String sPropertyName)
	{
		String sRtn = null;
		
		if (StringUtil.isEmpty(sPropertyName) == false){
			sRtn = propertyManager.getProperty(sPropertyName);
		}
		
		return sRtn;
	}

	/**
	 * Removes specified property.
	 * <p>
	 * @param	sPropertyName		The name of the specified property.
	 */
	
	public static void removeProperty(final String sPropertyName)
	{
		propertyManager.remove(sPropertyName);
	}

	/**
	 * Removes all of the properties.
	 */
	
	public static void removeAll()
	{
		propertyManager.clear();
	}
	
	/**
	 * Returns a string representation of all properties being
	 * managed. Suitable for logging and debugging.
	 * <p>
	 * @return	A String representation of all properties.
	 */
	public static String getPropertyList()
	{
		String sRtn = null;
		Set<String> keySet = propertyManager.stringPropertyNames();
		StringBuilder sb = new StringBuilder();
		String value = null;
		
		try{
			if(keySet != null){
				for(String key : keySet){
					value = propertyManager.getProperty(key);
					sb.append(key).append(":").append(value).append(Util.lineSeparator());
				}
			}
			
			sRtn = sb.toString();
		} finally {
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
		}
	
		return sRtn;
		
	}
	
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	

	
	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------
	
	private static Properties propertyManager  = new Properties();
}
