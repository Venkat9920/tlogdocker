/**
 * ServiceFlows.java
 */

package com.gianteagle.is.sig.base;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.w3c.dom.Element;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.gianteagle.is.net.Html;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.net.ServiceInfoBase;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used in an HTTP request context to dump the set of flows
 * within the current execution group. Since this is used in an
 * HTTP context, the result is either XML or HTML based on the value
 * of the <code>format</code> field specified in the request.
 * <p> 
 * @author	ReichertSF
 */

public final class ServiceFlows
{
	/**
	 * Default constructor.
	 */
	
	private ServiceFlows()
	{
	}
	
	/**
	 * Constructs the HTTP response containing the flow information.
	 * <p>
	 * @param	mbNode			Reference to the MbJavaComputeNode calling 
	 * 							this method.
	 * @param	inAssembly		Reference to the top level assembly (InputRoot).
	 * @param	outTerminal		The output terminal.
	 * @param 	sServiceName	The name of the service
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getServiceFlows(final MbJavaComputeNode mbNode,
									   final MbMessageAssembly inAssembly,
									   final MbOutputTerminal outTerminal,
									   final String sServiceName)
							throws MbException
	{
		MbMessage inMessage = null;
		MbMessage outMessage = null;
		MbMessageAssembly outAssembly = null;
		ByteArrayOutputStream baos = null;
		PrintWriter pw = null;
		HttpContentType httpContentType = null;
		Hashtable<String, String[]> hFields = null;
		String sServiceVersion = null;
		String sBrokerName = null;
		String sExecutionGroupName = null;

		try
		{
			// Reference the input message from the assembly.
			
			inMessage = inAssembly.getMessage();

			// Create the output message and output assembly.
			
			outMessage = new MbMessage(inMessage);
    		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);

			// Remove the existing "HTTPInputHeader". We're done with
   			// it and don't want to propagate it further.
    			
   			SigUtil.removeNamedElement(outMessage, "HTTPInputHeader");
    			
   			// Remove the existing "BLOB" element. In a GET or POST
   			// request with fields, this will contain the form fields
   			// from the original request, and we don't want to 
   			// return them.
    			
   			SigUtil.removeNamedElement(outMessage, "BLOB");
   			
   			if (mbNode != null)
   			{
   				sBrokerName = mbNode.getBroker().getName();
   				sExecutionGroupName = mbNode.getExecutionGroup().getName();
   			}
   			
   			// Retrieve the Service Version from the message flow.

   			sServiceVersion = 
   					BrokerUtil.getComponentVersion(sBrokerName,
   												   sExecutionGroupName,
   												   sServiceName);
   			
   			baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
    		pw = new PrintWriter(baos);

    		hFields = SigUtil.getHttpGetRequestFields(inAssembly);
    		
    		if (SigUtil.isFormatXml(hFields) == true)
    		{
    			httpContentType = HttpContentType.ApplicationXml;

    			ServiceFlows.getXmlFlowInfo(pw, sBrokerName, sExecutionGroupName, sServiceName, sServiceVersion);
    		}
    		else
    		{
    			httpContentType = HttpContentType.TextHtml;
    			
    			ServiceFlows.getHtmlFlowInfo(pw, sBrokerName, sExecutionGroupName, sServiceName, sServiceVersion);
    		}
    		
     		pw.flush();

     		SigUtil.setOuputHttpResponse(
     					outMessage, httpContentType, baos.toByteArray());
		
     		// Propagate the output results to the 'out' terminal.
			
			outTerminal.propagate(outAssembly);
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (baos != null)
			{
				try { baos.reset(); } catch (Throwable ignore) { }
				try { baos.close(); } catch (Throwable ignore) { } 
				baos = null;
			}
			if (hFields != null)
			{
				hFields.clear();
				hFields = null;
			}
			inMessage = null;
			outMessage = null;
			outAssembly = null;
			httpContentType = null;
			sServiceVersion = null;
			sBrokerName = null;
			sExecutionGroupName = null;
		}
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Generates the response as XML.
	 * <p>
	 * @param	pw				PrintWriter to send the output to.
	 * @param	sBrokerName		The name of the broker.
	 * @param	sExecutionGroupName		The name of the execution group.
	 * @param 	sServiceName	The name of the service
	 * @param	sServiceVersion	The version of the service.
	 */
	
	private static void getXmlFlowInfo(final PrintWriter pw,
									   final String sBrokerName,
									   final String sExecutionGroupName,
									   final String sServiceName,
									   final String sServiceVersion)
	{
		String sMethod = "getXmlFlowInfo()";
		
		com.gianteagle.is.net.ServiceStatus serviceStatus = null;
		
		TreeMap<String, MessageFlowInfo> messageFlowList = null;
		Set<String> keySet = null;
		Iterator<String> it = null;
		Element flowElement = null;
		String sName = null;
		MessageFlowInfo messageFlowInfo = null;
		
		try
		{
			if (pw != null)
			{
				serviceStatus = 
					new com.gianteagle.is.net.ServiceStatus(
							sServiceName, sServiceVersion, null);
				
				messageFlowList = 
					BrokerUtil.getMessageFlowList(sBrokerName, sExecutionGroupName);
				
				if (messageFlowList != null)
				{
					keySet = messageFlowList.keySet();
					
					if (keySet != null)
					{
						for (it = keySet.iterator() ; it.hasNext() ; )
						{
							sName = it.next();
							
							flowElement = 
									serviceStatus.newComponentElement(sName);
							
							messageFlowInfo = messageFlowList.get(sName);
							
							serviceStatus.setComponentItem(
												flowElement, 
												ServiceInfoBase.NAME_VERSION, 
												StringUtil.format(messageFlowInfo.getVersion()));
							
							serviceStatus.setComponentItem(
												flowElement, 
												"BarFile", 
												StringUtil.format(messageFlowInfo.getBarFileName()));
							
							serviceStatus.setComponentItem(
												flowElement, 
												"ExecutionGroup", 
												StringUtil.format(messageFlowInfo.getExecutionGroupName()));

							serviceStatus.setComponentItem(
												flowElement, 
												"isRunEnabled", 
												StringUtil.format(messageFlowInfo.isRunEnabled()));
							
							serviceStatus.setComponentItem(
												flowElement, 
												"isRunning", 
												StringUtil.format(messageFlowInfo.isRunning()));
							
							serviceStatus.addComponent(flowElement);
						}
					}
				}
				pw.println(serviceStatus.toString());
			}
		}
		catch (Throwable th)
		{
			SigLogger.logError(ServiceFlows.class, sMethod, 
							"Fatal error creating Flow information!", th);
		}
		finally
		{
			if (serviceStatus != null)
			{
				serviceStatus.destroy();
				serviceStatus = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			if (messageFlowList != null)
			{
				keySet = messageFlowList.keySet();
					
				if (keySet != null)
				{
					for (it = keySet.iterator() ; it.hasNext() ; )
					{
						sName = it.next();
							
						messageFlowInfo = messageFlowList.get(sName);
					
						messageFlowInfo.destroy();
					}
				}
				messageFlowList.clear();
				messageFlowList = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			it = null;
			flowElement = null;
			sName = null;
			messageFlowInfo = null;
			sMethod = null;
		}
	}
	
	/**
	 * Generates the response as HTML.
	 * <p>
	 * @param	pw				PrintWriter to send the output to.
	 * @param	sBrokerName		The name of the broker.
	 * @param	sExecutionGroupName		The name of the execution group.
	 * @param 	sServiceName	The name of the service
	 * @param	sServiceVersion	The version of the service.
	 */
	
	private static void getHtmlFlowInfo(final PrintWriter pw,
										final String sBrokerName,
										final String sExecutionGroupName,
									    final String sServiceName,
									    final String sServiceVersion)
	{
		TreeMap<String, MessageFlowInfo> messageFlowList = null;
		Set<String> keySet = null;
		Iterator<String> it = null;
		MessageFlowInfo messageFlowInfo = null;
		String sName = null;
		String sBgColor = null;
		int i = 0;
		
		try
		{
			pw.println(Html.beginHtml());

			pw.println(Html.beginHead());
			
			pw.println(Html.title(StringUtil.format(sServiceName) + " Flows"));
			
			pw.println(Html.endHead());
			
			pw.println(Html.beginBody());

			pw.println(Html.h2(StringUtil.format(sServiceName) + " Flows"));
    		
    		pw.println(Html.h3("Version: " + StringUtil.format(sServiceVersion)));
    		
    		pw.println(Html.beginTable());
    		
    		pw.println(Html.beginTableRow("bgcolor=\"#90EE90\""));	//LightGreen
    		pw.println(Html.tableData(Html.bold("Flow")));
    		pw.println(Html.tableData(Html.bold("Version")));
    		pw.println(Html.tableData(Html.bold("BarFile")));
    		pw.println(Html.tableData(Html.bold("ExecutionGroup")));
    		pw.println(Html.tableData(Html.bold("RunEnabled")));
    		pw.println(Html.tableData(Html.bold("Running")));
    		pw.println(Html.endTableRow());
    		
			messageFlowList = 
				BrokerUtil.getMessageFlowList(sBrokerName, sExecutionGroupName);
				
			if (messageFlowList != null)
			{
				keySet = messageFlowList.keySet();
					
				if (keySet != null)
				{
					for (i = 0, it = keySet.iterator() ; it.hasNext() ;  ++i)
					{
						sName = it.next();
							
						messageFlowInfo = messageFlowList.get(sName);
						
						if ((i % 2) == 0)
						{
							sBgColor = "bgcolor=\"#FAEBD7\"";	// AntiqueWhite
						}
						else
						{
							sBgColor = "bgcolor=\"#FFFFFF\"";	// White
						}
						pw.println(Html.beginTableRow(sBgColor));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.getName()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.getVersion()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.getBarFileName()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.getExecutionGroupName()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.isRunEnabled()))));
						pw.println(Html.tableData(Html.code(StringUtil.format(messageFlowInfo.isRunning()))));
						pw.println(Html.endTableRow());
					}
				}
			}
    		pw.println(Html.endTable());
    		    		
			pw.println(Html.rule());

			pw.println(Html.small(Html.italic(DateUtil.getCurrentDateTime())));

			pw.println(Html.endBody());
			
    		pw.println(Html.endHtml());
		}
		finally
		{
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			if (messageFlowList != null)
			{
				keySet = messageFlowList.keySet();
					
				if (keySet != null)
				{
					for (i = 0, it = keySet.iterator() ; it.hasNext() ;  ++i)
					{
						sName = it.next();
							
						messageFlowInfo = messageFlowList.get(sName);
					
						messageFlowInfo.destroy();
					}
				}
				messageFlowList.clear();
				messageFlowList = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			it = null;
			sName = null;
			sBgColor = null;
		}
	}
}
