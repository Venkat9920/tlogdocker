package com.gianteagle.is.sig.base;

import com.gianteagle.is.config.LoggingInterface;

public class LoggingInterfaceImpl implements LoggingInterface {

	
	public LoggingInterfaceImpl(){
		
	}


	@Override
	public void logError(String applicationName, String message,String loggerName, String log4jfilename) {
		SigLogger.setLoggerConfigFile(log4jfilename);
		SigLogger.logError(message);
		
	}

	@Override
	public void logMessage(String applicationName, String message,String loggerName, String log4jfilename) {
		SigLogger.setLoggerConfigFile(log4jfilename);
		SigLogger.logInfo(message);
		
	}



}
