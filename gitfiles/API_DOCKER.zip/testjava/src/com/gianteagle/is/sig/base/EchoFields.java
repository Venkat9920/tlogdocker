package com.gianteagle.is.sig.base;

public enum EchoFields {
    APPLICATION_VERSION("applicationVersion"),
    CLIENT_HOST_NAME("clientHostName"),
    CORRELATION_ID("correlationId"),
    DATA_CENTER("dataCenter"),
    DESTINATION_HOST_NAME("destinationHostName"),
    DESTINATION_PATH("destinationPath"),
    DURATION("duration"),
    DURATION_IN_MS("durationInMs"),
    HOST("host"),
    PAYLOAD_SIZE("payloadSize"),
    RESPONSE("response"),
    RESPONSE_CODE("responseCode"),
    TRANSACTION_ID("transactionId"),
    APPLICATION_REQUEST_ID("applicationRequestId"),
    BUSINESS_FUNCTION_ID("businessFunctionId"),
    COMPONENT_ID("componentId"),
    COMPONENT_VERSION("componentVersion"),
    TOTAL_TIME("totalTime"),
    TOTAL_COMPONENT_TIME("totalComponentTime"),
    RETRY_COUNT("retryCount"),
    SYSTEM_NAME("systemName"),
    DIVISION_NUMBER("divisionNumber"),
    STORE_NUMBER("storeNumber"),
    ORIGIN_DATE_TIME("originDateTime"),
    ORIGIN("origin"),
    ORIGIN_EVENT("originEvent"),
    ORIGIN_VERSION("originVersion"),
    SOURCE("source"),
    SOURCE_EVENT("sourceEvent"),
    DESTINATION("destination"),
    OPERATION_STATUS("operationStatus"),
    SERVICE_ID("serviceId"),
    WSG_CERT_ID("wsgcertid");
    private String echoFieldName;

    EchoFields(String echoFieldName)
    {
        this.echoFieldName = echoFieldName;
    }

    public String asString()
    {
        return echoFieldName;
    }
}
