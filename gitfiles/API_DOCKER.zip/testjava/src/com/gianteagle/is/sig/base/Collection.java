/**
 * Collection.java
 */

package com.gianteagle.is.sig.base;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class used to manage collections of <code>String</code> objects. The
 * intention is that this is somewhat of a substitute for the Collector
 * Node.
 * <p>
 * @author	ReichertSF
 */

// The public static methods have signatures that are compatible with
// JAVA calls in IIB. Synchronizing these methods was avoided, out of
// caution, in order to not violate the exact signatures required by
// IIB. Each public static method then utilizes a private static
// synchronized methods to do the actual work. This allows synchronization
// to prevent concurrent access violations.

public final class Collection
{
	/**
	 * Private constructor.
	 */
	
	private Collection()
	{
	}
	
	/**
	 * Creates a new collection and adds it to the set of available
	 * collections.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	public static void newCollection(final String sName)
	{
		Collection._newCollection(sName);
	}
	
	/**
	 * Removes a collection from the set of available collections and
	 * destroys its contents.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	public static void removeCollection(final String sName)
	{
		Collection._removeCollection(sName);
	}
	
	/**
	 * Clears the contents of the specified collection.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	public static void clearCollection(final String sName)
	{
		Collection._clearCollection(sName);
	}
	
	/**
	 * Adds the specified item to the named collection.
	 * <p>
	 * @param	sName	Name of the collection.
	 * @param	sItem	The item to add to the collection.
	 */

	public static void addCollectionItem(final String sName, final String sItem)
	{
		Collection._addCollectionItem(sName, sItem);
	}
	
	/**
	 * Returns the number of items in the named collection.
	 * <p>
	 * @param	sName	Name of the collection.
	 * <p>
	 * @return		The size of the collection.
	 */
	
	public static Long sizeofCollection(final String sName)
	{
		return Collection._sizeofCollection(sName);
	}
	
	/**
	 * Returns the item at specified position in the named collection.
	 * <p>
	 * NOTE: Since the intent is that this method is called from ESQL,
	 *       the index value passed in is 1-based rather than 0-based.
	 * <p>
	 * @param	sName		The name of the collection.
	 * @param	nIndex		The position of the specified item.
	 * <p>
	 * @return	The item or <code>null</code> if the position is out of
	 * 			range or the collection does not exist.
	 */
	
	public static String getCollectionItem(final String sName, final Long nIndex)
	{
		return Collection._getCollectionItem(sName, nIndex);
	}
	
	/**
	 * Returns the number of collections currently being managed.
	 * <p>
	 * @return		The number of collections currently being managed.
	 */
	
	public static Long getNumberOfCollections()
	{
		return Collection._getNumberOfCollections();
	}
	
	/**
	 * Returns a string representation of all collections being
	 * managed. Suitable for logging and debugging.
	 * <p>
	 * @return	A String representation of all collections.
	 */
	
	public static String collectionsToString()
	{
		return Collection._collectionsToString();
	}
	
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Creates a new collection and adds it to the set of available
	 * collections.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	private static synchronized void _newCollection(final String sName)
	{
		@SuppressWarnings("unused")
		ArrayList<String> collectionArray = null;
		
		/**
		 * In a typical implementation, this method would not exist and
		 * would be replaced by the addCollection() method. However,
		 * when using with WMB you cannot return an ArrayList. So, we
		 * resort to a void method.
		 */

		try
		{
			collectionArray = Collection.addCollection(sName);
		}
		finally
		{
			collectionArray = null;
		}
	}
	
	/**
	 * Removes a collection from the set of available collections and
	 * destroys its contents.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	private static synchronized void _removeCollection(final String sName)
	{
		if (StringUtil.isEmpty(sName) == false)
		{
			if (Collection.collectionMap != null)
			{
				Collection.clearCollection(sName);
				Collection.collectionMap.remove(sName);
			}
		}
	}
	
	/**
	 * Clears the contents of the specified collection.
	 * <p>
	 * @param	sName	The name of the collection.
	 */
	
	private static synchronized void _clearCollection(final String sName)
	{
		ArrayList<String> collectionArray = null;
		
		try
		{
			collectionArray = Collection.getCollection(sName);
		}
		finally
		{
			if (collectionArray != null)
			{
				collectionArray.clear();
				collectionArray = null;
			}
		}
	}
	
	/**
	 * Adds the specified item to the named collection.
	 * <p>
	 * @param	sName	Name of the collection.
	 * @param	sItem	The item to add to the collection.
	 */

	private static synchronized void _addCollectionItem(final String sName, final String sItem)
	{
		ArrayList<String> collectionArray = null;
		
		try
		{
			if (StringUtil.isEmpty(sName) == false && StringUtil.isEmpty(sItem) == false)
			{
				collectionArray = Collection.getCollection(sName);
				
				if (collectionArray != null)
				{
					collectionArray = Collection.addCollection(sName);
					
					collectionArray.add(sItem);
				}
			}
		}
		finally
		{
			collectionArray = null;
		}
	}
	
	/**
	 * Returns the number of items in the named collection.
	 * <p>
	 * @param	sName	Name of the collection.
	 * <p>
	 * @return		The size of the collection.
	 */
	
	private static synchronized Long _sizeofCollection(final String sName)
	{
		Long nRet = null;
		ArrayList<String> collectionArray = null;
		
		try
		{
			collectionArray = getCollection(sName);
			
			if (collectionArray == null)
			{
				nRet = new Long(0); 
			}
			else
			{
				nRet = new Long(collectionArray.size());
			}
		}
		finally
		{
			collectionArray = null;
		}
		return nRet;
	}
	
	/**
	 * Returns the item at specified position in the named collection.
	 * <p>
	 * NOTE: Since the intent is that this method is called from ESQL,
	 *       the index value passed in is 1-based rather than 0-based.
	 * <p>
	 * @param	sName		The name of the collection.
	 * @param	nIndex		The position of the specified item.
	 * <p>
	 * @return	The item or <code>null</code> if the position is out of
	 * 			range or the collection does not exist.
	 */
	
	private static synchronized String _getCollectionItem(final String sName, final Long nIndex)
	{
		String sRet = null;
		ArrayList<String> collectionArray = null;
		int ndx = 0;
	
		try
		{
			if (StringUtil.isEmpty(sName) == false && nIndex != null)
			{
				collectionArray = Collection.getCollection(sName);
				
				if (collectionArray != null)
				{
					ndx = nIndex.intValue();
					
					if (ndx > 0 && ndx <= collectionArray.size())
					{
						sRet = collectionArray.get(ndx - 1);
					}
				}
			}
		}
		finally
		{
			collectionArray = null;
		}
		return sRet;
	}
	
	/**
	 * Returns the number of collections currently being managed.
	 * <p>
	 * @return		The number of collections currently being managed.
	 */
	
	private static synchronized Long _getNumberOfCollections()
	{
		Long nRet = null;
	
		if (Collection.collectionMap == null)
		{
			nRet = new Long(0);
		}
		else
		{
			nRet = new Long(Collection.collectionMap.size());
		}
		return nRet;
	}
	
	/**
	 * Returns a string representation of all collections being
	 * managed. Suitable for logging and debugging.
	 * <p>
	 * @return	A String representation of all collections.
	 */
	
	private static synchronized String _collectionsToString()
	{
		String sRet = null;
		StringBuilder sb = null;
		int nCollections = 0;
		int ndx = 0;
		String sName = null;
		String sValue = null;
		Set<String> keys = null;
		Iterator<String> iter = null;
		long nSize = 0;
		long n = 0;
		
		try
		{
			sb = new StringBuilder();
			
			nCollections = Collection.getNumberOfCollections().intValue();
			sb.append("Number of Collections = ");
			sb.append(Long.toString(nCollections));
		
			if (nCollections > 0)
			{
				for (ndx = 0 ; ndx < nCollections ; ++ndx)
				{
					keys = Collection.collectionMap.keySet();
					
					if (keys != null)
					{
						iter = keys.iterator();
						
						if (iter != null)
						{
							while (iter.hasNext())
							{
								sName = iter.next();

								nSize = Collection.sizeofCollection(sName).longValue();
								
								for (n = 0 ; n < nSize ; ++n)
								{
									sb.append(Util.lineSeparator());
									sb.append(StringUtil.format(sName));
									sb.append('[');
									sb.append(Long.toString(n + 1));
									sb.append("]=");
									
									sValue = getCollectionItem(sName, Long.valueOf(n + 1));
									
									sb.append(StringUtil.format(sValue));
								}
							}
						}
					}
				}
			}
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			if (keys != null)
			{
				keys.clear();
				keys = null;
			}
			sName = null;
			sValue = null;
			iter = null;
		}
		return sRet;
	}
	
	/**
	 * Adds a new collection to the set of collections and returns
	 * a reference to it.
	 * <p>
	 * @param	sName	The name of the collection to add.
	 * <p>
	 * @return		A reference to the collection. If the collection
	 * 				exists, a reference to the existing collection
	 * 				is returned.
	 */
	
	private static ArrayList<String> addCollection(final String sName)
	{
		ArrayList<String> collectionArray = null;
		
		if (StringUtil.isEmpty(sName) == false)
		{
			if (Collection.collectionMap == null)
			{
				Collection.collectionMap = new HashMap<>();
			}
			collectionArray = Collection.getCollection(sName);

			if (collectionArray == null)
			{
				collectionArray = new ArrayList<>();
			
				Collection.collectionMap.put(sName, collectionArray);
			}
		}
		return collectionArray;
	}
	
	/**
	 * Returns a reference to the specified collection if it is in
	 * the collection set, otherwise null is returned.
	 * <p>
	 * @param	sName	The name of the collection.
	 * <p>
	 * @return	A reference to the collection or <code>null</code> if
	 * 			it does not exist.
	 */

	private static ArrayList<String> getCollection(final String sName)
	{
		ArrayList<String> collectionArray = null;
		
		if (StringUtil.isEmpty(sName) == false)
		{
			if (Collection.collectionMap != null)
			{
				collectionArray = Collection.collectionMap.get(sName);
			}
		}
		return collectionArray;
	}
	
	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------
	
	private static HashMap<String, ArrayList<String>> collectionMap = null;
}
