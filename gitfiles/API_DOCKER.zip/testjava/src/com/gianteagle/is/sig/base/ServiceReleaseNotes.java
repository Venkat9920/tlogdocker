/**
 * ServiceReleaseNotes.java
 */

package com.gianteagle.is.sig.base;

import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class used in an HTTP request context to dump the release notes.
 * <p> 
 * @author	ReichertSF
 */

public final class ServiceReleaseNotes
{
	/**
	 * Default constructor.
	 */
	
	private ServiceReleaseNotes()
	{
	}
	
	/**
	 * Constructs the HTTP response containing the release info.
	 * <p>
	 * @param	inAssembly			Reference to the top level assembly.
	 * @param	outTerminal			The output terminal.
	 * @param 	sReleaseNotesFile	The name of the release notes file. It must
	 *                              be located in the config/ directory.
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getServiceReleaseNotes(final MbMessageAssembly inAssembly,
									     final MbOutputTerminal outTerminal,
									     final String sReleaseNotesFile)
							throws MbException
	{
		MbMessage inMessage = null;
		MbMessage outMessage = null;
		MbMessageAssembly outAssembly = null;
		byte[] byteData = null;

		try
		{
			// Reference the input message from the assembly.
			
			inMessage = inAssembly.getMessage();

			// Create the output message and output assembly.
			
			outMessage = new MbMessage(inMessage);
    		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);

			// Remove the existing "HTTPInputHeader". We're done with
   			// it and don't want to propagate it further.
    			
   			SigUtil.removeNamedElement(outMessage, "HTTPInputHeader");
    			
   			// Remove the existing "BLOB" element. In a GET or POST
   			// request with fields, this will contain the form fields
   			// from the original request, and we don't want to 
   			// return them.
    			
   			SigUtil.removeNamedElement(outMessage, "BLOB");

   			byteData = ServiceReleaseNotes.getReleaseNotes(sReleaseNotesFile);
 
     		SigUtil.setOuputHttpResponse(
     				outMessage, HttpContentType.TextPlain, byteData);
    		
			// Propagate the output results to the 'out' terminal.
			
			outTerminal.propagate(outAssembly);
		}
		finally
		{
			inMessage = null;
			outMessage = null;
			outAssembly = null;
		}
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Retrieves the release notes as a byte array.
	 * <p>
	 * @param	sReleaseNotesFile	The name of the file containing the
	 * 								release notes.
	 * <p>
	 * @return		A byte array containing the release notes, or
	 * 				null if there are none.
	 */
	
	private static  byte[] getReleaseNotes(final String sReleaseNotesFile)
	{
		String sMethod = "getReleaseNotes()";
		String sFile = null;
		byte[] byteRet = null;
		StringBuilder sb = null;
		Throwable th = null;
		
		try
		{
			sFile = 
				FileUtil.makeFileName(SigConfig.getConfigDir(), 
									  sReleaseNotesFile);
			
			byteRet = FileUtil.fileToByteArray(sFile);
		}
		catch (Throwable e)
		{
			SigLogger.logError(ServiceReleaseNotes.class, sMethod, 
							"Fatal error reading release notes!", e);
			th = e;
			
			byteRet = null;
		}
		finally
		{
			if (byteRet == null)
			{
				sb = new StringBuilder(Defines.MEM_BUF_SIZE);
				sb.append("Unable to access release notes! ");
				sb.append(Util.lineSeparator());
				sb.append(Util.lineSeparator());
				sb.append("Release Notes File: ");
				sb.append(StringUtil.format(sReleaseNotesFile));
				
				if (th != null)
				{
					sb.append(Util.lineSeparator());
					sb.append(Util.lineSeparator());
					sb.append(Util.getStackTrace(th));
				}
				sb.append(Util.lineSeparator());
				
				byteRet = sb.toString().getBytes();
				
				sb.setLength(0);
			}
			sFile = null;
			sMethod = null;
		}
		return byteRet;
	}
}
