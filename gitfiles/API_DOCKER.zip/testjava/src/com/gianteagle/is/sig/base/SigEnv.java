/**
 * SigEnv.java
 */

package com.gianteagle.is.sig.base;

import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.UUID;

/**
 * Set of utility methods used to interact with the LocalEnvironment.
 * <p>
 * @author sr44189
 */

public final class SigEnv
{
	/**
	 * Default constructor.
	 */
	
	private SigEnv()
	{
	}
	
	/**
	 * Returns the CorrelationId from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The CorrelationId from the local environment. If it 
	 * 				cannot be determined, a new UUID is generated.
	 */
	
	public static String getCorrelationId(final MbMessageAssembly assembly)
	{
		String sRet = null;
		
		sRet = SigEnv.getEnvValue(assembly, "CorrelationId");
		
		return sRet;
	}

	/**
	 * Returns the OperationType from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The OperationType from the local environment. 
	 */
	
	public static String getOperationType(final MbMessageAssembly assembly)
	{
		String sRet = null;
		
		sRet = SigEnv.getEnvValue(assembly, "OperationType");
		
		if (sRet == null)
		{
			sRet = UUID.getUUID();
		}
		return sRet;
	}
	
	
	/**
	 * Sets the StatusCode into the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * @param	sValue		The value of the Status Code.
	 */
	
	public static void setStatusCode(final MbMessageAssembly assembly, final String sValue)
	{
		SigEnv.setEnvValue(assembly, "StatusCode", sValue);
	}
	
	/**
	 * Sets the OperationStatus into the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * @param	sValue		The value of the Operation Status.
	 */
	
	public static void setOperationStatus(final MbMessageAssembly assembly, final String sValue)
	{
		SigEnv.setEnvValue(assembly, "OperationStatus", sValue);
	}
	
	/**
	 * Sets the ErrorDetail into the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * @param	sValue		The value of the ErrorDetail.
	 */
	
	public static void setErrorDetail(final MbMessageAssembly assembly, final String sValue)
	{
		SigEnv.setEnvValue(assembly, "ErrorDetail", sValue);
	}
	
	/**
	 * Sets the DestinationQueue into the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * @param	sValue		The value of the DestinationQueue.
	 */
	public static void setDestination(final MbMessageAssembly assembly, final String sValue)
	{
		SigEnv.setEnvValue(assembly, "Destination", sValue);
	}
	
	/**
	 * Returns the DestinationQueue from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The DestinationQueue from the local environment. 
	 */
	
	public static String getDestination(final MbMessageAssembly assembly)
	{
		String sRet = null;
		
		sRet = SigEnv.getEnvValue(assembly, "Destination");
		
		return sRet;
	}
	
	/**
	 * Returns the Raw Payload from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The Raw Payload from the environment.
	 */
	
	public static String getRawPayload(final MbMessageAssembly assembly)
	{
		String sRet = null;
		
		sRet = SigEnv.getEnvValue(assembly, "RawPayload");
		
		return sRet;
	}

	/**
	 * Returns the MD5 Checksum from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The MD5 Checksum from the environment.
	 */
	
	public static String getMD5Checksum(final MbMessageAssembly assembly)
	{
		String sRet = null;
		
		sRet = SigEnv.getEnvValue(assembly, "MD5Checksum");
		
		return sRet;
	}

	/**
	 * Returns the Raw Payload as an array of bytes from the local environment.
	 * <p>
	 * @param	assembly	The message assembly.
	 * <p>
	 * @return		The Raw Payload from the environment.
	 */
	
	public static byte[] getRawPayloadAsBytes(final MbMessageAssembly assembly)
	{
		byte[] retBytes = null;
		
		retBytes = SigEnv.getEnvByteValue(assembly, "RawPayload");
		
		return retBytes;
	}

	/**
	 * Method used to return the value of the specified variable as an
	 * array of bytes from the local environment. All variables are 
	 * contained in the path "/Variables/".
	 * <p>
	 * @param assembly		The message assembly.
	 * @param sVariable		The variable to retrieve the value of.
	 * <p>
	 * @return				The value of the variable as an array of bytes.
	 */
	
	private static byte[] getEnvByteValue(final MbMessageAssembly assembly, final String sVariable)
	{
		byte[] retBytes = null;
		String sMethod = "getEnvByteValue()";
		MbMessage localEnvironment = null;
		MbElement rootElement = null;
		MbElement element = null;
		StringBuilder sbPath = null;
		
		try
		{
			if (assembly != null && StringUtil.isEmpty(sVariable) == false)
    		{
    			localEnvironment = assembly.getLocalEnvironment();
    			
    			if (localEnvironment != null)
    			{
    				rootElement = localEnvironment.getRootElement();
    				
    				if (rootElement != null)
    				{
    					sbPath = new StringBuilder();
    					
    					sbPath.append("/Variables/");
    					sbPath.append(sVariable);
    					
    					element = 
    						rootElement.getFirstElementByPath(sbPath.toString());
    					
    					if (element != null)
    					{
    						retBytes = (byte[]) element.getValue();
    					}
    				}
    			}
    		}
		}
		catch (MbException ex)
		{
			SigLogger.logError(SigEnv.class, sMethod, 
					"Fatal Error retrieving environment variable value!", ex);
		}
		finally
		{
			if (sbPath != null)
			{
				sbPath.setLength(0);
				sbPath = null;
			}
			localEnvironment = null;
			rootElement = null;
			element = null;
			sMethod = null;
		}
		return retBytes;
	}
	
	/**
	 * Method used to return the value of the specified variable from the
	 * local environment. All variables are contained in the path "/Variables/".
	 * <p>
	 * @param assembly		The message assembly.
	 * @param sVariable		The variable to retrieve the value of.
	 * <p>
	 * @return				The value of the variable.
	 */
	
	private static String getEnvValue(
			final MbMessageAssembly assembly, final String sVariable)
	{
		String sRet = null;
		String sMethod = "getEnvValue()";
		MbMessage localEnvironment = null;
		MbElement rootElement = null;
		MbElement element = null;
		StringBuilder sbPath = null;
		
		try
		{
			if (assembly != null && StringUtil.isEmpty(sVariable) == false)
    		{
    			localEnvironment = assembly.getLocalEnvironment();
    			
    			if (localEnvironment != null)
    			{
    				rootElement = localEnvironment.getRootElement();
    				
    				if (rootElement != null)
    				{
    					sbPath = new StringBuilder();
    					
    					sbPath.append("/Variables/");
    					sbPath.append(sVariable);
    					
    					element = 
    						rootElement.getFirstElementByPath(sbPath.toString());
    					
    					if (element != null)
    					{
    						sRet = element.getValueAsString();
    					}
    				}
    			}
    		}
		}
		catch (MbException ex)
		{
			SigLogger.logError(SigEnv.class, sMethod, 
					"Fatal Error retrieving environment variable value!", ex);
		}
		finally
		{
			if (sbPath != null)
			{
				sbPath.setLength(0);
				sbPath = null;
			}
			localEnvironment = null;
			rootElement = null;
			element = null;
			sMethod = null;
		}
		return sRet;
	}
	
	/**
	 * Method used to set the value of the specified variable in the
	 * local environment. All variables are contained in the path "/Variables/".
	 * <p>
	 * @param assembly		The message assembly.
	 * @param sVariable		The variable to set the value of.
	 * @param sValue		The value.
	 */
	
	private static void setEnvValue(
			final MbMessageAssembly assembly, final String sVariable, final String sValue)
	{
		String sMethod = "setEnvValue()";
		MbMessage localEnvironment = null;
		MbElement rootElement = null;
		MbElement element = null;
		MbElement elementVariables = null;
		StringBuilder sbPath = null;
		
		try
		{
			if (assembly != null && StringUtil.isEmpty(sVariable) == false)
    		{
    			localEnvironment = assembly.getLocalEnvironment();
    			
    			if (localEnvironment != null)
    			{
    				rootElement = localEnvironment.getRootElement();
    				
    				if (rootElement != null)
    				{
    					sbPath = new StringBuilder();
    					
    					sbPath.append("/Variables/");
    					sbPath.append(sVariable);
    					
    					element = 
    						rootElement.getFirstElementByPath(sbPath.toString());
    					
    					if (element != null)
    					{
    						element.setValue(sValue);
    					}
    					else
    					{
    						elementVariables = rootElement.getFirstElementByPath("/Variables");
    						
    						element = 
    							elementVariables.createElementAsLastChild(MbBLOB.PARSER_NAME);
    						
    						element.setName(sVariable);
    						element.setValue(sValue);
    					}
    				}
    			}
    		}
		}
		catch (MbException ex)
		{
			SigLogger.logError(SigEnv.class, sMethod, 
					"Fatal Error setting environment variable value!", ex);
		}
		finally
		{
			if (sbPath != null)
			{
				sbPath.setLength(0);
				sbPath = null;
			}
			localEnvironment = null;
			rootElement = null;
			element = null;
			sMethod = null;
		}
	}

}
