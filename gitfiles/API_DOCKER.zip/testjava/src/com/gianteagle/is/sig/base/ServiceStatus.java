/**
 * ServiceStatus.java
 */

package com.gianteagle.is.sig.base;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import org.w3c.dom.Element;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.gianteagle.is.net.Html;
import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used in an HTTP request context to dump the status information
 * within the current execution group. Since this is used in an
 * HTTP context, the result is either XML or HTML based on the value
 * of the <code>format</code> field specified in the request.
 * <p> 
 * @author	ReichertSF
 */

public final class ServiceStatus
{
	/**
	 * Default constructor.
	 */
	
	private ServiceStatus()
	{
	}
	
	/**
	 * Constructs the HTTP response containing the status information.
	 * <p>
	 * @param	mbNode			Reference to the MbJavaComputeNode calling 
	 * 							this method.
	 * @param	inAssembly				Reference to the top level assembly.
	 * @param	outTerminal				The output terminal.
	 * @param 	sServiceName			The name of the service
	 * @param	mapSystemProperties		The set of system properties.
	 * @param	mapComponentProperties	The set of components and their
	 * 									associated properties.
 	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	public static void getServiceStatus(
							final MbJavaComputeNode mbNode,
							final MbMessageAssembly inAssembly,
							final MbOutputTerminal outTerminal,
							final String sServiceName,
							final LinkedHashMap<String, String> mapSystemProperties,
							final LinkedHashMap<String, LinkedHashMap<String, String>> mapComponentProperties)
						throws MbException
	{
		MbMessage inMessage = null;
		MbMessage outMessage = null;
		MbMessageAssembly outAssembly = null;
		ByteArrayOutputStream baos = null;
		PrintWriter pw = null;
		HttpContentType httpContentType = null;
		Hashtable<String, String[]> hFields = null;
		String sServiceVersion = null;
		String sBrokerName = null;
		String sExecutionGroupName = null;

		try
		{
			// Reference the input message from the assembly.
			
			inMessage = inAssembly.getMessage();

			// Create the output message and output assembly.
			
			outMessage = new MbMessage(inMessage);
    		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);

			// Remove the existing "HTTPInputHeader". We're done with
   			// it and don't want to propagate it further.
    			
   			SigUtil.removeNamedElement(outMessage, "HTTPInputHeader");
    			
   			// Remove the existing "BLOB" element. In a GET or POST
   			// request with fields, this will contain the form fields
   			// from the original request, and we don't want to 
   			// return them.
    			
   			SigUtil.removeNamedElement(outMessage, "BLOB");

    		if (mbNode != null)
   			{
   				sBrokerName = mbNode.getBroker().getName();
   				sExecutionGroupName = mbNode.getExecutionGroup().getName();
   			}
   			
   			// Retrieve the Service Version from the message flow.

   			sServiceVersion = 
   					BrokerUtil.getComponentVersion(sBrokerName,
   												   sExecutionGroupName,
   												   sServiceName);

   			baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
    		pw = new PrintWriter(baos);

    		hFields = SigUtil.getHttpGetRequestFields(inAssembly);
    		
    		if (SigUtil.isFormatXml(hFields) == true)
    		{
    			httpContentType = HttpContentType.ApplicationXml;

    			ServiceStatus.getXmlStatusInfo(
    					pw, sServiceName, sServiceVersion,
    					mapSystemProperties, mapComponentProperties);
    		}
    		else
    		{
    			httpContentType = HttpContentType.TextHtml;
    			
    			ServiceStatus.getHtmlStatusInfo(
    					pw, sServiceName, sServiceVersion,
    					mapSystemProperties, mapComponentProperties);
    		}
    		
     		pw.flush();

     		SigUtil.setOuputHttpResponse(
     					outMessage, httpContentType, baos.toByteArray());
		
     		// Propagate the output results to the 'out' terminal.
			
			outTerminal.propagate(outAssembly);
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (baos != null)
			{
				try { baos.close(); } catch (Throwable ignore) { } 
				baos = null;
			}
			if (hFields != null)
			{
				hFields.clear();
				hFields = null;
			}
			ServiceStatus.clearProperties(
					mapSystemProperties, mapComponentProperties);
			inMessage = null;
			outMessage = null;
			outAssembly = null;
			httpContentType = null;
			sServiceVersion = null;
			sBrokerName = null;
			sExecutionGroupName = null;
		}
	}

	/**
	 * Returns a string containing the status document in XML.
	 * <p>
	 * @param 	sServiceName			The name of the service
	 * @param	sServiceVersion			The version of the service.
	 * @param	mapSystemProperties		The set of system properties.
	 * @param	mapComponentProperties	The set of component properties.
	 * <p>
	 * @return	A String containing the status document in XML.
	 */

	public static String getXmlStatus(
							final String sServiceName,
							final String sServiceVersion,
							final LinkedHashMap<String, String> mapSystemProperties,
							final LinkedHashMap<String, LinkedHashMap<String, String>> mapComponentProperties)
	{
		String sRet = null;
		ByteArrayOutputStream baos = null;
		PrintWriter pw = null;
		
		try
		{
			baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
			
			pw = new PrintWriter(baos);
			
			ServiceStatus.getXmlStatusInfo(
						pw, sServiceName, sServiceVersion, 
						mapSystemProperties, mapComponentProperties);
			
     		pw.flush();
     		
     		sRet = baos.toString();
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (baos != null)
			{
				try { baos.close(); } catch (Throwable ignore) { } 
				baos = null;
			}
		}
		return sRet;
	}
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Private method used to clear the set of system and component
	 * properties.
	 * <p>
	 * @param	mapSystemProperties		The set of system properties.
	 * @param	mapComponentProperties	The set of component properties.
	 */
	
	private static final void clearProperties(
									final LinkedHashMap<String, String> mapSystemProperties,
									final LinkedHashMap<String, LinkedHashMap<String,String>> mapComponentProperties)
	{
		Set<String> keySet = null;
		Iterator<String> it = null;
		String sName = null;
		LinkedHashMap<String, String> prop = null;

		try
		{
			if (mapSystemProperties != null)
			{
				mapSystemProperties.clear();
			}
			if (mapComponentProperties != null)
			{
				keySet = mapComponentProperties.keySet();
				
				if (keySet != null)
				{
					for (it = keySet.iterator() ; it.hasNext() ; )
					{
						sName = it.next();
							
						prop = mapComponentProperties.get(sName);
						
						if (prop != null)
						{
							prop.clear();
						}
					}
				}
				mapComponentProperties.clear();
			}
		}
		finally
		{
			keySet = null;
			it = null;
			sName = null;
			prop = null;
		}
	}

	/**
	 * Generates the response as XML.
	 * <p>
	 * @param	pw						PrintWriter to send the output to.
	 * @param 	sServiceName			The name of the service
	 * @param	sServiceVersion			The version of the service.
	 * @param	mapSystemProperties		The set of system properties.
	 * @param	mapComponentProperties	The set of component properties.
	 */
	
	@SuppressWarnings("null")
	private static void getXmlStatusInfo(final PrintWriter pw,
							final String sServiceName,
							final String sServiceVersion,
							final LinkedHashMap<String, String> mapSystemProperties,
							final LinkedHashMap<String, LinkedHashMap<String, String>> mapComponentProperties)
	{
		String sMethod = "getXmlStatusInfo()";
		com.gianteagle.is.net.ServiceStatus serviceStatus = null;
		Set<String> keySet = null;
		Iterator<String> it = null;
		Set<String> keySetProp = null;
		Iterator<String> itProp = null;
		Element componentElement = null;
		String sName = null;
		LinkedHashMap<String, String> prop = null;
		
		try
		{
			if (pw != null)
			{
				serviceStatus =
					new com.gianteagle.is.net.ServiceStatus(
									sServiceName, sServiceVersion, null);
				
				if (mapSystemProperties != null)
				{
					keySet = mapSystemProperties.keySet();
					
					if (keySet != null)
					{
						for (it = keySet.iterator() ; it.hasNext() ; )
						{
							sName = it.next();
							
							serviceStatus.setInfoItem(
									sName, mapSystemProperties.get(sName));
						}
					}
				}
				if (mapComponentProperties != null)
				{
					keySet = mapComponentProperties.keySet();
					
					if (keySet != null)
					{
						for (it = keySet.iterator() ; it.hasNext() ; )
						{
							sName = it.next();
							
							prop = mapComponentProperties.get(sName);

							if (sName != null && prop != null)
							{
								componentElement =
									serviceStatus.newComponentElement(sName);
							
								keySetProp = prop.keySet();
								
								for (itProp = keySetProp.iterator() ; itProp.hasNext() ; )
								{
									sName = itProp.next();
									
									serviceStatus.setComponentItem(
											componentElement, sName,
											StringUtil.format(prop.get(sName)));
								}
								serviceStatus.addComponent(componentElement);
								
								if (keySetProp != null)
								{
									keySetProp.clear();
									keySetProp = null;
								}
							}
						}
					}
				}
				pw.println(serviceStatus.toString());
			}
		}
		catch (Throwable th)
		{
			SigLogger.logError(ServiceStatus.class, sMethod, 
							"Fatal error creating Status information!", th);
		}
		finally
		{
			if (serviceStatus != null)
			{
				serviceStatus.destroy();
				serviceStatus = null;
			}
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			if (keySetProp != null)
			{
				keySetProp.clear();
				keySetProp = null;
			}
			it = null;
			itProp = null;
			componentElement = null;
			sName = null;
			prop = null;
			sMethod = null;
		}
	}
	
	/**
	 * Generates the response as HTML.
	 * <p>
	 * @param	pw						PrintWriter to send the output to.
	 * @param 	sServiceName			The name of the service
	 * @param	sServiceVersion			The version of the service.
	 * @param	mapSystemProperties		The set of system properties.
	 * @param	mapComponentProperties	The set of component properties.
	 */
	
	@SuppressWarnings("null")
	private static void getHtmlStatusInfo(final PrintWriter pw,
							final String sServiceName,
							final String sServiceVersion,
     						final LinkedHashMap<String, String> mapSystemProperties,
							final LinkedHashMap<String, LinkedHashMap<String, String>> mapComponentProperties)
	{
		String sBgColorAntiqueWhite = "bgcolor=\"#FAEBD7\"";
		String sBgColorWhite = "bgcolor=\"#FFFFFF\"";
		Set<String> keySet = null;
		Iterator<String> it = null;
		LinkedHashMap<String, String> prop = null;
		Set<String> keySetProp = null;
		Iterator<String> itProp = null;
		String sName = null;
		String sValue = null;
		String sBgColor = null;
		
		try
		{
			pw.println(Html.beginHtml());

			pw.println(Html.beginHead());
			pw.println(Html.title(StringUtil.format(sServiceName) + " Status"));
			pw.println(Html.endHead());
			
			pw.println(Html.beginBody());

			pw.println(Html.h2(StringUtil.format(sServiceName) + " Status")); 
    		
    		pw.println(Html.h3("Version: " + StringUtil.format(sServiceVersion)));

    		pw.println(Html.h3("Configuration"));
    		
    		pw.println(Html.beginTable());
    		
    		// First the set of system properties.
    		
    		pw.println(Html.beginTableRow("bgcolor=\"#90EE90\""));	//LightGreen
    		pw.println(Html.tableData(Html.bold("Property")));
    		pw.println(Html.tableData(Html.bold("Value")));
    		pw.println(Html.endTableRow());
    		
    		sBgColor = sBgColorWhite;
    		
			if (mapSystemProperties != null)
			{
				keySet = mapSystemProperties.keySet();
				
				if (keySet != null)
				{
					for (it = keySet.iterator() ; it.hasNext() ; )
					{
						sName = it.next();
						sValue = mapSystemProperties.get(sName);

						if (sBgColor.equalsIgnoreCase(sBgColorWhite))
						{
							sBgColor = sBgColorAntiqueWhite;
						}
						else
						{
							sBgColor = sBgColorWhite;
						}
						pw.println(Html.beginTableRow(sBgColor));
						pw.println(Html.tableData(
								Html.code(StringUtil.format(sName))));
						pw.println(Html.tableData(Html.code(
								StringUtil.format(StringUtil.format(sValue)))));
						pw.println(Html.endTableRow());
					}
				}
			}
			pw.println(Html.endTable());
 
    		if (mapComponentProperties != null)
    		{
    			pw.println(Html.h3("Components and Services"));
    		
    			pw.println(Html.beginTable());
 				
    			keySet = mapComponentProperties.keySet();
				
				if (keySet != null)
				{
					for (it = keySet.iterator() ; it.hasNext() ; )
					{
						sName = it.next();
						
						pw.println(Html.beginTableRow("bgcolor=\"#90EE90\""));	//LightGreen
						pw.println(Html.beginTableData("colspan=\"2\""));
						pw.println(Html.bold(StringUtil.format(sName)));
						pw.println(Html.endTableData());
						pw.println(Html.endTableRow());

						prop = mapComponentProperties.get(sName);
						
						if (prop != null)
						{
							keySetProp = prop.keySet();
							
							sBgColor = sBgColorWhite;

							for (itProp = keySetProp.iterator() ; itProp.hasNext() ; )
							{
								sName = itProp.next();
								
								sValue = prop.get(sName);

								if (sBgColor.equalsIgnoreCase(sBgColorWhite))
								{
									sBgColor = sBgColorAntiqueWhite;
								}
								else
								{
									sBgColor = sBgColorWhite;
								}
								pw.println(Html.beginTableRow(sBgColor));
								pw.println(Html.tableData(
										Html.code(StringUtil.format(sName))));
								pw.println(Html.tableData(Html.code(
										StringUtil.format(StringUtil.format(sValue)))));
								pw.println(Html.endTableRow());
							}
							if (keySetProp != null)
							{
								keySetProp.clear();
								keySetProp = null;
							}
						}
					}
				}
				pw.println(Html.endTable());
    		}
			pw.println(Html.rule());

			pw.println(Html.small(Html.italic(DateUtil.getCurrentDateTime())));

			pw.println(Html.endBody());
			
    		pw.println(Html.endHtml());
		}
		finally
		{
			if (keySet != null)
			{
				keySet.clear();
				keySet = null;
			}
			if (keySetProp != null)
			{
				keySetProp.clear();
				keySetProp = null;
			}
			it = null;
			itProp = null;
			sName = null;
			sValue = null;
			sBgColor = null;
			sBgColorAntiqueWhite = null;
			sBgColorWhite = null;
			prop = null;
		}
	}
}
