/**
 * POSDateTime.java
 */

package com.gianteagle.is.sig.base;

import java.util.Calendar;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.StringUtil;

/**
 * Simple test class used to convert a POS Date and Time stamp to
 * standard XML date time format as well as approximate epoch value
 * (time in milliseconds).
 * <p> 
 * @author sr44189
 */

public final class POSDateTime
{
	/**
	 * Test routine. Pass in a standard POS date "YYMMDDhhmm" to 
	 * convert to standard XML date time format as well as 
	 * approximate epoch value (time in milliseconds).
	 * <p>
	 * @param	args	Command line arguments. POS Date in the
	 * 					format "YYMMDDhhmm".
	 */

	public static void main(final String[] args)
	{
		String sPOSDateTime = null;
		Long nPOSDateTimeInMillis = null;
		
		try
		{
			if (args.length != 1)
			{
				POSDateTime.usage("Date/Time not specified!");
			}
			else if (POSDateTime.isValidPOSDateTime(args[0]) == false)
			{
				POSDateTime.usage("Invalid POS Date/Time specified!");
			}
			else 
			{
				sPOSDateTime = POSDateTime.getPOSDateTimeStamp(args[0]);
				nPOSDateTimeInMillis = POSDateTime.getPOSDateTimeInMillis(args[0]);

				if (sPOSDateTime == null || nPOSDateTimeInMillis == null)
				{
					POSDateTime.usage("Invalid POS Date/Time specified!");
				}
				else
				{
					System.out.println();
					System.out.println("POSDateTime: " + args[0]);
					System.out.print("POSDateTimeStamp: ");
					System.out.println(sPOSDateTime);
					System.out.print("POSDateTimeInMillis: ");
					System.out.println(nPOSDateTimeInMillis.toString());
					System.out.println();
				}
			}
		}
		catch(Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			sPOSDateTime = null;
		}
	}

	/**
	 * Gets the POS Date and Time as a standard XML format date and time
	 * string.
	 * <p>
	 * @param	sPOSDateTime	The POS DateTime string.
	 * <p>
	 * @return		The POS date and time as a standard XML format date, or
	 * 				<code>null</code> if the date is invalid.
	 */
	
	public static String getPOSDateTimeStamp(final String sPOSDateTime)
	{
		String sRet = null;
		Calendar calPOSDateTime = null;
		
		try
		{
			calPOSDateTime = POSDateTime.getCalendarInstance(sPOSDateTime);
			
			if (calPOSDateTime != null)
			{
				sRet = DateUtil.getStandardXmlFormatDate(calPOSDateTime.getTime());
			}
		}
		finally
		{
			calPOSDateTime = null;
		}
		return sRet;
	}
	
	/**
	 * Gets the POS Date and Time in milliseconds.
	 * <p>
	 * @param	sPOSDateTime	The POS date and time string.
	 * <p>
	 * @return		The POS date and time in milliseconds, or 
	 *				<code>null</code> if it is invalid.
	 */
	
	public static Long getPOSDateTimeInMillis(final String sPOSDateTime)
	{
		Long nRet = null;
		long nMillis = -1;
		Calendar calPOSDateTime = null;
		
		try
		{
			calPOSDateTime = POSDateTime.getCalendarInstance(sPOSDateTime);
			
			if (calPOSDateTime != null)
			{
				nMillis = calPOSDateTime.getTimeInMillis();
				nRet = Long.valueOf(nMillis);
			}
		}
		finally
		{
			calPOSDateTime = null;
		}
		return nRet;
	}
		
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Display usage information.
	 * <p>
	 * @param	sErrorMessage	Error message to display.
	 */
	
	private static void usage(final String sErrorMessage)
	{
		if (StringUtil.isEmpty(sErrorMessage) == false)
		{
			System.out.println();
			System.out.print("ERROR: ");
			System.out.println(sErrorMessage);
		}
		System.out.println();
		System.out.println("Usage: java POSDateTime YYMMDDhhmm");
		System.out.println();
	}
	
	/**
	 * Returns the POS Date and Time as a Calendar object.
	 * <p>
	 * @param	sPOSDateTime		The POS Date and Time string.
	 * <p>
	 * @return	The POS Date and Time as a Calendar object or <code>null</code>
	 * 			if the date and time is invalid.
	 */
	
	private static Calendar getCalendarInstance(final String sPOSDateTime)
	{
		Calendar calPOSDateTime = null;
		int nCentury = 0;
		int nYears = 0;
		int nYear = 0;
		int nMonth = 0;
		int nDay = 0;
		int nHour = 0;
		int nMinute = 0;
		
		if (isValidPOSDateTime(sPOSDateTime) == true)
		{
			nYear = POSDateTime.getPOSYear(sPOSDateTime);
			nMonth = POSDateTime.getPOSMonth(sPOSDateTime);
			nDay = POSDateTime.getPOSDay(sPOSDateTime);
			nHour = POSDateTime.getPOSHour(sPOSDateTime);
			nMinute = POSDateTime.getPOSMinute(sPOSDateTime);
	
			calPOSDateTime = Calendar.getInstance();
		
			nCentury = calPOSDateTime.get(Calendar.YEAR);
			nYears = nCentury % 100;
			nCentury -= nYears;
			
			nYear += nCentury;
			
			calPOSDateTime.set(Calendar.YEAR, nYear);
			calPOSDateTime.set(Calendar.MONTH, nMonth - 1);
			calPOSDateTime.set(Calendar.DAY_OF_MONTH, nDay);
			calPOSDateTime.set(Calendar.HOUR_OF_DAY, nHour);
			calPOSDateTime.set(Calendar.MINUTE, nMinute);
			calPOSDateTime.set(Calendar.SECOND, 0);
			calPOSDateTime.set(Calendar.MILLISECOND, 0);
		}
		return calPOSDateTime;
	}
	
	/**
	 * Validate the POSDateTime.
	 * <p>
	 * @param	sVal		The POS Date and Time value.
	 * <p>
	 * @return 		Whether or not the POS Date and Time value is a valid value.
	 */
	
	private static boolean isValidPOSDateTime(final String sVal)
	{
		boolean bRet = false;
		int nYear = 0;
		int nMonth = 0;
		int nDay = 0;
		int nHour = 0;
		int nMinute = 0;
		
		nYear = POSDateTime.getPOSYear(sVal);
		nMonth = POSDateTime.getPOSMonth(sVal);
		nDay = POSDateTime.getPOSDay(sVal);
		nHour = POSDateTime.getPOSHour(sVal);
		nMinute = POSDateTime.getPOSMinute(sVal);
				
		if (nYear >= 0 && 
			nMonth > 0 && nMonth <= 12 &&
			nDay > 0 && nDay <= 31 &&
			nHour >= 0 && nHour < 24 &&
			nMinute >= 0 && nMinute < 60)
		{
			bRet = true;
		}
		return bRet;
	}
	
	/**
	 * Returns the 2 digit year value from the POS Date and Time string.
	 * <p>
	 * @param		sVal	The POS Date and Time value.
	 * <p>
	 * @return		The 2 digit year value from the POS Date and Time string.
	 */
	
	private static int getPOSYear(final String sVal)
	{
		return POSDateTime.getPOSDateTimeValue(
					sVal, POSDateTime.POS_DATE_TIME_YEAR_OFFSET);
	}
	
	/**
	 * Returns the 2 digit month value from the POS Date and Time string.
	 * <p>
	 * @param		sVal	The POS Date and Time value.
	 * <p>
	 * @return		The 2 digit Month value from the POS Date and Time string.
	 */
	
	private static int getPOSMonth(final String sVal)
	{
		return POSDateTime.getPOSDateTimeValue(
					sVal, POSDateTime.POS_DATE_TIME_MONTH_OFFSET);
	}
	
	/**
	 * Returns the 2 digit day value from the POS Date and Time string.
	 * <p>
	 * @param		sVal	The POS Date and Time value.
	 * <p>
	 * @return		The 2 digit day value from the POS Date and Time string.
	 */
	
	private static int getPOSDay(final String sVal)
	{
		return POSDateTime.getPOSDateTimeValue(
					sVal, POSDateTime.POS_DATE_TIME_DAY_OFFSET);
	}
	
	/**
	 * Returns the 2 digit hour value from the POS Date and Time string.
	 * <p>
	 * @param		sVal	The POS Date and Time value.
	 * <p>
	 * @return		The 2 digit hour value from the POS Date and Time string.
	 */
	
	private static int getPOSHour(final String sVal)
	{
		return POSDateTime.getPOSDateTimeValue(
					sVal, POSDateTime.POS_DATE_TIME_HOUR_OFFSET);
	}
	
	/**
	 * Returns the 2 digit minute value from the POS Date and Time string.
	 * <p>
	 * @param		sVal	The POS Date and Time value.
	 * <p>
	 * @return		The 2 digit minute value from the POS Date and Time string.
	 */
	
	private static int getPOSMinute(final String sVal)
	{
		return POSDateTime.getPOSDateTimeValue(
					sVal, POSDateTime.POS_DATE_TIME_MINUTE_OFFSET);
	}
	
	/**
	 * Returns the POS Date and Time value from the specified position.
	 * <p>
	 * @param	sVal		POS Date and Time value.
	 * @param	nOffset		Offset to retrieve the value from.
	 * <p>
	 * @return		The value or -1 if it is not parseable.
	 */
	
	private static int getPOSDateTimeValue(final String sVal, final int nOffset)
	{
		int nRet = -1;
		
		if (StringUtil.isNumeric(sVal) == true)
		{
			if (sVal.length() == POSDateTime.POS_DATE_TIME_LENGTH &&
				nOffset < (POS_DATE_TIME_LENGTH -1))
			{
				nRet = 
					StringUtil.parseInt(
							sVal.substring(nOffset, 
								nOffset + POSDateTime.POS_DATE_TIME_VALUE_LENGTH), -1);
			}
		}
		return nRet;
	}
	
	/**
	 * Private constructor.
	 */
	
	private POSDateTime()
	{
	}
	
	//----------------------------------------------------------------
	// Private Member Variables.
	//----------------------------------------------------------------
	
	private static final int POS_DATE_TIME_LENGTH = 10;
	private static final int POS_DATE_TIME_YEAR_OFFSET = 0;
	private static final int POS_DATE_TIME_MONTH_OFFSET = 2;
	private static final int POS_DATE_TIME_DAY_OFFSET = 4;
	private static final int POS_DATE_TIME_HOUR_OFFSET = 6;
	private static final int POS_DATE_TIME_MINUTE_OFFSET = 8;
	
	private static final int POS_DATE_TIME_VALUE_LENGTH = 2; 
}
