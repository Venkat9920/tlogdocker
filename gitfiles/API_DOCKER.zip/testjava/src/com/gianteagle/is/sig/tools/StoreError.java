/**
 * StoreError.java
 */

package com.gianteagle.is.sig.tools;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.gianteagle.is.net.HttpContentType;
import com.gianteagle.is.util.Base64Util;
import com.gianteagle.is.util.GZipUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import com.gianteagle.is.xml.XmlDoc;

/**
 * Class used to parse a <code>StoreError</code> message and extract the
 * Payload and Detail.
 * <p>
 * @author	ReichertSF
 */

public final class StoreError
{
	/**
	 * Default constructor.
	 */

	private StoreError()
	{
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */

	private void destroy()
	{
		if (this.xmlDoc != null)
		{
			this.xmlDoc.destroy();
			this.xmlDoc = null;
		}
		this.bytePayload = null;
		this.byteDetail = null;
	}

	/**
	 * Sets the XML document to validate against the schema.
	 * <p>
	 * @param	sDoc	The name of the file containing the XML document.
	 * <p>
	 * @exception	ParserConfigurationException	Thrown if an error
	 *												occurs in creating the
	 * 												DOM parser.
	 * @exception	IOException		Thrown if an I/O error occurs.
	 * @exception	SAXException	Thrown if an error occurs in parsing
	 * 								the XML document.
	 */

	private void setDocument(final String sDoc)
			throws ParserConfigurationException, IOException, SAXException
	{
		File docFile = null;
		
		try
		{
			if (sDoc == null)
			{
				throw new NullPointerException("Document file is null!");
			}
			docFile = new File(sDoc);

			this.xmlDoc = new XmlDoc(docFile);
		}
		finally
		{
			docFile = null;
		}
	}

	/**
	 * Retrieves the data as a byte array.
	 * <p>
	 * @param	sTagName	The name of the element.
	 * <p>
	 * @return		The data as a byte array.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in obtaining
	 * 								the data.
	 * @exception	ParserConfigurationException	Thrown if an error occurs
	 * 												in creating the XML 
	 * 												document.
	 * @exception	SAXException	Thrown if an error occurs parsing the
	 * 								XML document.  
	 */
	
	private byte[] getData(final String sTagName) 
		throws ParserConfigurationException, IOException, SAXException
	{
		byte[] byteValue = null;
		
		Element element = null;
		String sValue = null;
		String sXmlValue = null;
		XmlDoc xmlData = null;
		
		try
		{
			if (StringUtil.isEmpty(sTagName) == false)
			{
				element = this.xmlDoc.getElement(sTagName);
			}
			if (element != null)
			{
				sValue = element.getTextContent();
				
				if (StringUtil.isEmpty(sValue) == false)
				{
					/**
					 * If the element value is Base64 encoded, decode as
					 * a byte array.
					 */
					
					if (StoreError.isBase64Encoded(element) == true)
					{
						byteValue = Base64Util.decode(sValue);
					}
					else
					{
						byteValue = sValue.getBytes();
					}
					
					/**
					 * If the element value is gzip compressed, decompress
					 * into a byte array.
					 */
					
					if (StoreError.isGZipCompressed(element) == true)
					{
						byteValue = GZipUtil.gunzip(byteValue);
					}
					
					/**
					 * If the element value is XML, stuff it into an
					 * XML document, then let the XML document return
					 * a formatted string representation. Finally,
					 * convert the string representation to a byte array.
					 */
					
					if (StoreError.isXml(element) == true)
					{
						sXmlValue = new String(byteValue);
						
						xmlData = new XmlDoc(sXmlValue);
						
						byteValue = xmlData.toString().getBytes();
					}
				}
			}
		}
		finally
		{
			if (xmlData != null)
			{
				xmlData.destroy();
				xmlData = null;
			}
			sValue = null;
			sXmlValue = null;
		}
		return byteValue;
	}
	
	/**
	 * Returns whether or not the element is base64 encoded.
	 * <p>
	 * @param	element		The element.
	 * <p>
	 * @return		True if base64 encoded, otherwise false.
	 */
	
	private static boolean isBase64Encoded(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = 
					element.getAttribute("Encoding");
				
				if (sValue != null)
				{
					bRet = sValue.equalsIgnoreCase("base64");
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}

	/**
	 * Returns whether or not the element is gzip compressed.
	 * <p>
	 * @param	element		The element.
	 * <p>
	 * @return		True if gzip compressed, otherwise false.
	 */
	
	private static boolean isGZipCompressed(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = 
					element.getAttribute("Compression");
				
				if (sValue != null)
				{
					bRet = sValue.equalsIgnoreCase("gzip");
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}

	/**
	 * Returns whether or not the element is an XML document.
	 * <p>
	 * @param	element		The element.
	 * <p>
	 * @return		True if the elment is an XML document, otherwise false.
	 */
	
	private static boolean isXml(final Element element)
	{
		boolean bRet = false;
		String sValue = null;
		
		try
		{
			if (element != null)
			{
				sValue = element.getAttribute("Content-Type");
				
				if (HttpContentType.ApplicationXml.equals(sValue) ||
					HttpContentType.TextXml.equals(sValue))
				{
					bRet = true;
				}
			}
		}
		finally
		{
			sValue = null;
		}
		return bRet;
	}
	
	/**
	 * Writes the data bytes to the specified output file.
	 * <p>
	 * @param	sFile		The name of the file to write.
	 * @param	bytes		The bytes to write to the file.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in writing
	 * 								the file.
	 */
	
	private static void writeFile(final String sFile, final byte[] bytes) 
						throws IOException
	{
		FileOutputStream fos = null;
		
		try
		{
			if (bytes != null && StringUtil.isEmpty(sFile) == false)
			{
				fos = new FileOutputStream(sFile);
				
				fos.write(bytes);
				
				fos.flush();
			}
		}
		finally
		{
			if (fos != null)
			{
				try { fos.close(); } catch (Throwable ignore) { }
				fos = null;
			}
		}
	}
	
	/**
	 * Writes the string to the specified output file.
	 * <p>
	 * @param	sFile		The name of the file to write.
	 * @param	sStr		The string to write to the file.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in writing
	 * 								the file.
	 */
	
	private static void writeFile(final String sFile, final String sStr) 
						throws IOException
	{
		if (StringUtil.isEmpty(sStr) == false)
		{
			StoreError.writeFile(sFile, sStr.getBytes());
		}
	}
	
	/**
	 * Application used to extract the Payload and Detail from a
	 * StoreError message.
	 * <p>
	 * Usage: java StoreError SourceStoreError OutputStoreError DetailFile PayloadFile
	 * <p>
	 * @param	args		Command line arguments.
	 */

	public static void main(final String[] args)
	{
		StoreError storeError = null;

		try
		{
			if (args.length < 1)
			{
				System.out.println(USAGE);
			}
			else
			{
				storeError = new StoreError();

				System.out.print("Initializing document using ");
				System.out.print(args[0]);
				System.out.println(" ...");
				
				storeError.setDocument(args[0]);

				if (args.length < 2)
				{
					System.out.println(storeError.xmlDoc.toString());
				}
				else
				{
					System.out.print("Writing output file ");
					System.out.print(args[1]);
					System.out.println(" ...");
				
					StoreError.writeFile(args[1], storeError.xmlDoc.toString());
				}
				storeError.byteDetail = storeError.getData("Detail");
				
				if (storeError.byteDetail != null)
				{
					if (args.length > 2)
					{
						System.out.print("Writing Error Detail file ");
						System.out.print(args[2]);
						System.out.println(" ...");
				
						StoreError.writeFile(args[2], storeError.byteDetail);
					}
				}
				storeError.bytePayload = storeError.getData("Payload");
				
				if (storeError.bytePayload != null)
				{
					if (args.length > 3)
					{
						System.out.print("Writing Payload file ");
						System.out.print(args[3]);
						System.out.println(" ...");
						
						StoreError.writeFile(args[3], storeError.bytePayload);
					}
				}
				System.out.println("StoreError processing complete.");
			}
		}
		catch (IOException ex)
		{
			System.out.println("FATAL I/O ERROR!");

			ex.printStackTrace();
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println("FATAL ERROR: Parser Configuration error!");

			ex.printStackTrace();
		}
		catch (SAXException ex)
		{
			System.out.println("FATAL ERROR: Document is INVALID.");

			ex.printStackTrace();
		}
		catch (Throwable th)
		{
			System.out.println("FATAL ERROR: Unknown error occurred!");

			th.printStackTrace();
		}
		finally
		{
			if (storeError != null)
			{
				storeError.destroy();
				storeError = null;
			}
		}
	}

	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------

	private XmlDoc xmlDoc = null;
	private transient byte[] byteDetail = null;
	private transient byte[] bytePayload = null;
	
	private static final String USAGE = 
		"StoreError 3.0.0.0001 12-27-2012" +
		Util.lineSeparator() +
		"Usage: java com.gianteagle.is.sig.tools.StoreError SrcStoreErrorFile " +
		"[OutStoreErrorFile] [DetailFile] [PayloadFile]";
}
