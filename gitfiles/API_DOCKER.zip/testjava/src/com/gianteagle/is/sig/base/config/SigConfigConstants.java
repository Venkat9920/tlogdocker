package com.gianteagle.is.sig.base.config;

public interface SigConfigConstants 
{
	String SYSTEM = "SYSTEM" ;
	
	String TRUE = "TRUE";
	
	String SYSTEM_NAMESPACE = "System";
}