package com.gianteagle.is.sig.base.config;

import java.util.LinkedHashMap;

import com.gianteagle.is.config.ConfigConstants.FOLDER_TYPE;
import com.gianteagle.is.config.ConfigManager;
import com.gianteagle.is.config.ConfigurationDescriptor;
import com.gianteagle.is.config.LoggingInterface;
import com.gianteagle.is.sig.base.SigConfig;
import com.gianteagle.is.sig.base.SigConstants;
import com.gianteagle.is.util.Util;

/**
 * Class used to access configuration objects and 
 * various values of those objects.
 * <p>
 * @author	SandersJS
 */
public class SigConfigManager {

	/**
     * Constructor is private, because only Class methods and constants
	 * are supported.
	 */
	
	private SigConfigManager()
	{
	}

	/**
      * @param nameSpace        namespace of configuration object
      * @param envVar           environment variable pointing to base folder for service
      * @param baseConfigFile   base configuration file
      * @param customConfigFile custom/override configuration file 
      * @param logInterface     logging interface for calling back to base logger
      * <p>
      * @return     The ConfigurationDescriptor.
      * <p>
      * @exception java.lang.NullPointerException   If any argument is <code>null</code>. 
	 */
	
	public static ConfigurationDescriptor initializeConfigurationDescriptor(
												final String nameSpace,
												final String envVar,
				                                final String baseConfigFile,
				                                final String customConfigFile,
				                                final LoggingInterface logInterface) throws NullPointerException
	{
		ConfigurationDescriptor cd = null;

		SigConfigManager.setEnvBase(envVar);
		
		cd = ConfigurationDescriptor.buildConfigurationDescriptor(nameSpace, envVar, baseConfigFile, customConfigFile, logInterface);
		
		return cd;
	}

			
	/**
	 * Returns the specified property value as a Boolean.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	sysApp						System/Application.
	 * @param	propertyName				The property name.
	 * <p>
	 * @return		The value of the specified property as a Boolean.
	 */	
	
	public static Boolean getBooleanProperty(final ConfigurationDescriptor configurationDescriptor,
											 final String sysApp, 
											 final String propertyName) 
	{
		Boolean rtn = Boolean.FALSE;
		
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, sysApp, propertyName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);		
			
			rtn = ConfigManager.getBooleanProperty(configurationDescriptor, sysApp, propertyName);
			
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getBooleanProperty: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return rtn;
	}

	/**
	 * Returns the specified property value as a String.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	sysApp						System/Application.
	 * @param	propertyName				The property name.
	 * <p>
	 * @return		The value of the specified property as a String.
	 */	
	
	public static String getStringProperty(final ConfigurationDescriptor configurationDescriptor,
										   final String sysApp, 
										   final String propertyName) 
	{

		String sRet = null;		
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, sysApp, propertyName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);	
		
			sRet = ConfigManager.getStringProperty(configurationDescriptor, sysApp, propertyName);
		
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getStringProperty: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return sRet;
	}

	/**
	 * Returns the specified property value as a Long.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	sysApp						System/Application.
	 * @param	propertyName				The property name.
	 * <p>
	 * @return		The value of the specified property as a Long.
	 */
	
	public static Long getLongProperty(final ConfigurationDescriptor configurationDescriptor,
									   final String sysApp,
									   final String propertyName)
	{
		Long nRet = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, sysApp, propertyName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);	
		
			nRet = ConfigManager.getLongProperty(configurationDescriptor, sysApp, propertyName);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getLongProperty: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return nRet;
	}
	
	/**
	 * Returns the specified property list size as a Long.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	applicationName				The application name.
	 * @param	propertyListName			The property list name.
	 * <p>
	 * @return		The value of the specified property list size as a Long.
	 */
	
	public static Long getLongPropertyListSize(final ConfigurationDescriptor configurationDescriptor,
											   final String applicationName, 
											   final String propertyListName) 
	{

		Long nRet = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, applicationName, propertyListName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);

			nRet = ConfigManager.getLongPropertyListSize(configurationDescriptor, applicationName, propertyListName);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getLongPropertyListSize: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return nRet;
	}

	/**
	 * Returns the specified property list key, using index, size as a String.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	applicationName				The application name.
	 * @param	propertyListName			The property list name.
	 * @param	ndx							The index of property list value.
	 * <p>
	 * @return		The value of the specified property list key, using index, size as a String.
	 */
	
	public static String getStringPropertyListKeyByIndex(final ConfigurationDescriptor configurationDescriptor,
														 final String applicationName, 
														 final String propertyListName,
														 final int ndx) 
	{
		String sRet = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, applicationName, propertyListName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);
		
			sRet = ConfigManager.getStringPropertyListKeyByIndex(configurationDescriptor, applicationName, propertyListName, ndx);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getStringPropertyListKeyByIndex: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return sRet;
	}

	/**
	 * Returns the specified property list value, using index, size as a String.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	applicationName				The application name.
	 * @param	propertyListName			The property list name.
	 * @param	ndx							The index of property list value.
	 * <p>
	 * @return		The value of the specified property list value, using index, size as a String.
	 */
	
	public static String getStringPropertyListValueByIndex(final ConfigurationDescriptor configurationDescriptor,
														   final String applicationName, 
														   final String propertyListName,
														   final int ndx) 
	{
		String sRet = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, applicationName, propertyListName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);
		
			sRet = ConfigManager.getStringPropertyListValueByIndex(configurationDescriptor, applicationName, propertyListName, ndx);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getStringPropertyListValueByIndex: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return sRet;
	}

	/**
	 * Returns the specified property list value, using key, size as a String.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	applicationName				The application name.
	 * @param	propertyListName			The property list name.
	 * @param	itemName					The name of property list item.
	 * <p>
	 * @return		The value of the specified property list value, using key, size as a String.
	 */
	
	public static String getStringPropertyListValueByKey(final ConfigurationDescriptor configurationDescriptor,
														 final String applicationName, 
														 final String propertyListName,
														 final String itemName) 
	{
		String sRet = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, applicationName, propertyListName, itemName);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);

			sRet = ConfigManager.getStringPropertyListValueByKey(configurationDescriptor, applicationName, propertyListName, itemName);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getStringPropertyListValueByKey: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return sRet;
	}

	/**
	 * Returns the map of System property values.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * <p>
	 * @return		Returns the map of System property values.
	 */
	
	public static final LinkedHashMap<String, String> getSystemProperties(final ConfigurationDescriptor configurationDescriptor) 
	{
		LinkedHashMap<String, String> systemProperties = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);
		
			systemProperties = ConfigManager.getSystemProperties(configurationDescriptor);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getSystemProperties: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
	
		return systemProperties;
	}
	
	/**
	 * Returns the folder path to specified folder type as a String.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * @param	folderType					The enum representing type of descriptor.
	 * <p>
	 * @return		Returns the folder path to specified folder type as a String.
	 */
	
	public static final String getFolderPath(final ConfigurationDescriptor configurationDescriptor, 
											 final FOLDER_TYPE folderType) 
	{
		String folderPath = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor, folderType);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);
	
			folderPath = ConfigManager.getFolderPath(configurationDescriptor, folderType);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getFolderPath: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}

		return folderPath;
	}
	
	/**
	 * Returns a map of maps representing the component (application) properties.
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * <p>
	 * @return		Returns a map of maps representing the component properties.
	 */
	
	public static final LinkedHashMap<String, LinkedHashMap<String, String>> getComponentProperties(
			final ConfigurationDescriptor configurationDescriptor) {

		LinkedHashMap<String, LinkedHashMap<String, String>> componentProperties = null;
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor);
		
		if(isNonNull)
		{
			SigConfigManager.setEnvProperties(configurationDescriptor);
		
			componentProperties = ConfigManager.getComponentProperties(configurationDescriptor);
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					".getComponentProperties: Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"Null value passed in.");
		}
		
		return componentProperties;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	/**
	 * Initializes logger class and environment variables if and only if
	 * configurationDescriptor is not null and contains non-null instance 
	 * variables
	 * <p>
	 * @param	configurationDescriptor		The configuration descriptor.
	 * <p>
	 * @return		Returns void
	 */	
	

	private static void setEnvProperties(final ConfigurationDescriptor configurationDescriptor)
	{
		boolean isNonNull =  Util.checkAllNonNull(configurationDescriptor);
	
		if (isNonNull)
		{
			if (configurationDescriptor.isComplete())
			{	
				SigConfigManager.setEnvBase(configurationDescriptor.getEnvVar());
			}
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
					": Catastrophic Initialization Error:" +
					Util.lineSeparator()  + 
					"configurationDescriptor is null" +
					Util.lineSeparator());
		}
	}
	
	/**
	 * Initializes logger class and environment variables if and only if
	 * configurationDescriptor is not null and contains non-null instance 
	 * variables
	 * <p>
	 * @param	envVar		The environment variable pointing to
	 *                      the base directory..
	 * <p>
	 * @return		Returns void
	 */	

	private static void setEnvBase(final String envVar)
	{
		if(envVar != null)
		{
			if(SigConfigManager.bLoggerInitialized == false)
			{
				synchronized (SigConfigManager.class) 
				{
					if(SigConfigManager.bLoggerInitialized == false)
					{
						SigConfig.setEnvBaseVar(envVar);
						System.setProperty(SigConstants.SIG_BASE, System.getenv(envVar));
						
						SigConfigManager.bLoggerInitialized = true;
					}
				}
			}
		}
		else
		{
			System.out.println(SigConfigManager.class.getSimpleName() +
						": Catastrophic Initialization Error:" +
						Util.lineSeparator()  + 
						"Base Environment variable is null!" +
						Util.lineSeparator());
		}
	}
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private static boolean bLoggerInitialized = false;
    
}
