/**
 * AceTlogProcessorServiceStatus.java
 */

package com.gianteagle.is.central;


import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.gianteagle.is.sig.base.BrokerUtil;
import com.gianteagle.is.sig.base.ServiceStatus;

/**
 * Handles status information related requests pertaining to AceTlogProcessorService.
 * <p>
 * 
 */

public class AceTlogProcessorServiceStatus extends MbJavaComputeNode
{
	/**
	 * Called when a message is passed to the compute node.
	 * <p>
	 * @param	inAssembly	Reference to the top level assembly (InputRoot).
	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */

	@Override
	public void evaluate(MbMessageAssembly inAssembly) throws MbException
	{
		ServiceStatus.getServiceStatus(this,
									   inAssembly,
									   this.getOutputTerminal("out"), 
									   AceTlogProcessorServiceConfig.getAceTlogProcessorServiceName(),
									   AceTlogProcessorServiceConfig.getSystemProperties(),
									   AceTlogProcessorServiceConfig.getComponentProperties());
	}
	
	/**
	 * Returns a string containing the status document in XML format.
	 * <p>
	 * @param	sBrokerName				The name of the broker.
	 * @param	sExecutionGroupLabel		The name of the execution group.
	 * <p>
	 * @return	A String containing the status document in XML.
	 */
	
	public static String getXmlStatus(final String sBrokerName,
									  final String sExecutionGroupLabel)
	{
		String sRet = null;
		String sServiceVersion = null;
		
		try
		{
			sServiceVersion = 
				BrokerUtil.getComponentVersion(sBrokerName, 
										sExecutionGroupLabel, 
										AceTlogProcessorServiceConfig.getAceTlogProcessorServiceName());
				
			sRet = ServiceStatus.getXmlStatus(
						AceTlogProcessorServiceConfig.getAceTlogProcessorServiceName(),
						sServiceVersion,
						AceTlogProcessorServiceConfig.getSystemProperties(),
						AceTlogProcessorServiceConfig.getComponentProperties());
		}
		finally
		{
			sServiceVersion = null;
		}
		return sRet;
	}
}
