/**
 * AceTlogProcessorServiceConfig.java
 */

package com.gianteagle.is.central;

import java.util.LinkedHashMap;

import com.gianteagle.is.config.ConfigConstants.FOLDER_TYPE;
import com.gianteagle.is.config.ConfigurationDescriptor;
import com.gianteagle.is.sig.base.LoggingInterfaceImpl;
import com.gianteagle.is.sig.base.SigConstants;
import com.gianteagle.is.sig.base.config.SigConfigConstants;
import com.gianteagle.is.sig.base.config.SigConfigManager;
import com.gianteagle.is.util.Util;

/**
 * Class used to manage configuration elements used by the message flows.
 * <p>
 * @author	ReichertSF
 */

public final class AceTlogProcessorServiceConfig
{
	/**
	 * Default constructor.
	 */
	
	private AceTlogProcessorServiceConfig()
	{
	}
	
	/**
	 * Returns the AceTlogProcessor Service name.
	 * <p>
	 * @return		The AceTlogProcessor Service name.
	 */
	
	public static String getAceTlogProcessorServiceName()
	{
		AceTlogProcessorServiceConfig.initialize();
		
		return AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR;
	}

	/**
	 * Returns the name of the release notes file without the path.
	 * <p>
	 * @return		The name of the release notes file.
	 */
	
	public static String getAceTlogProcessorReleaseNotesFileName()
	{
		AceTlogProcessorServiceConfig.initialize();
		
		return AceTlogProcessorServiceConstants.RELEASE_NOTES_FILE;
	}
	
	/**
	 * Returns whether or not ERRORs should be published.
	 * <p>
	 * @return		<code>true</code> if ERRORs should be published.
	 */
	
	public static Boolean publishErrors()
	{
		Boolean bRet = Boolean.FALSE;

		bRet = AceTlogProcessorServiceConfig.getBooleanConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.PUBLISH_ERRORS);

		return bRet;
	}

	
	/**
	 * Returns the base topic string used to publish ERRORs.
	 * <p>
	 * @return		The base topic string used to publish ERRORs.
	 */
	
	public static String getErrorTopicString()
	{
		String sRet = null;
		
		sRet = AceTlogProcessorServiceConfig.getStringConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.ERROR_TOPIC_STRING);

		return sRet;
	}
	

	/**
	 * Returns the Logger Configuration File name.
	 * <p>
	 * @return		The Logger Configuration File name.	
	 */
	
	public static String getLoggerConfigFile()
	{
		String sRet = null;
		
		sRet = AceTlogProcessorServiceConfig.getStringConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.LOG_CONFIG);

		return sRet;
	}
	

	/**
	 * Returns the max backout count for message rollback.
	 * <p>
	 * @return		The max backout count for message rollback. A value
	 * 				of <code>0</code> or <code>null</code> indicates the 
	 * 				max backout count should be	ignored.
	 */
	
	public static Long getMaxBackoutCount()
	{
		Long nRet = null;

		nRet = AceTlogProcessorServiceConfig.getLongConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.MAX_BACKOUT_COUNT);

		return nRet;
	}
	
	/**
	 * Returns whether or not the max backout count on message rollback
	 * is enforced.
	 * <p>
	 * @return		<code>true</code> if the max backout count on message
	 * 				rollback is enforced, otherwise <code>false</code>.
	 */
	
	public static Boolean isMaxBackoutCountEnabled()
	{
		Boolean bRet = Boolean.FALSE;

		bRet = AceTlogProcessorServiceConfig.getBooleanConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.ENABLE_MAX_BACKOUT_COUNT);

		return bRet;
	}

	/**
	 * Returns the delay, in milliseconds, for message rollback.
	 * <p>
	 * @return		The delay, in milliseconds, for message rollback.
	 * 				A value of <code>0</code> indicates no delay.
	 */
	
	public static Long getRollbackDelay()
	{
		Long nRet = null;

		nRet = AceTlogProcessorServiceConfig.getLongConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.ROLLBACK_DELAY);

		return nRet;
	}

	/**
	 * Returns the interval, in milliseconds, between checks to determine
	 * if the configuration file has changed.
	 * <p>
	 * @return		The interval, in milliseconds, between checks to
	 * 				determine if the configuration file has changed.
	 * 				A value of <code>0</code> will cause the check
	 * 				to occur on every configuration access.
	 */
	
	public static Long getConfigReloadInterval()
	{
		Long nRet = null;

		nRet = AceTlogProcessorServiceConfig.getLongConfigValue(SigConfigConstants.SYSTEM_NAMESPACE, SigConstants.ROLLBACK_DELAY);

		return nRet;
	}



	/**
	 * Returns the set of system properties for this configuration.
	 * <p>
	 * @return	The set of system properties as a <code>LinkedHashMap</code>,
	 * 			which maintains the order in which the list was prepared.
	 */
	
	public static LinkedHashMap<String, String> getSystemProperties()
	{
		LinkedHashMap<String, String> map = null;

		AceTlogProcessorServiceConfig.initialize();

		if (AceTlogProcessorServiceConfig.configDescriptor != null)
		{
			map = SigConfigManager.getSystemProperties(AceTlogProcessorServiceConfig.configDescriptor);
		}
		return map;
	}

	/**
	 * Returns the set of components and their associated properties.
	 * <p>
	 * @return		The set of components and their associated properties.
	 */
	
	public static LinkedHashMap<String, LinkedHashMap<String, String>> getComponentProperties()
	{
		LinkedHashMap<String, LinkedHashMap<String, String>> map = null;

		AceTlogProcessorServiceConfig.initialize();

		if (AceTlogProcessorServiceConfig.configDescriptor != null)
		{
			map = SigConfigManager.getComponentProperties(AceTlogProcessorServiceConfig.configDescriptor);
		}
		return map;
	}


	/**
	 * Returns whether or not the ACE TLOG Processor services are enabled.
	 * <p>
	 * @return	<code>true</code> if the ACE TLOG Processor services are 
	 * 			enabled, otherwise <code>false</code>.
	 */
	
	public static Boolean isAceTlogProcessorServiceEnabled()
	{
		Boolean bRet = Boolean.FALSE;

		bRet = AceTlogProcessorServiceConfig.getBooleanConfigValue(
							AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR,
							SigConstants.IS_ENABLED);
		return bRet;
	}
	
	/**
	 * Returns whether or not debug mode is enabled for the 
	 * ACE TLOG Processor services.
	 * <p>
	 * @return	<code>true</code> if debug mode is enabled for the
	 * 			ACE TLOG Processor services, otherwise <code>false</code>.
	 */
	
	public static Boolean isAceTlogProcessorServiceDebugMode()
	{
		Boolean bRet = Boolean.FALSE;

		bRet = AceTlogProcessorServiceConfig.getBooleanConfigValue(
							AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR, 
							SigConstants.DEBUG_MODE);
		return bRet;
	}


	/**
	 * Returns the base topic string used when publishing TLOGs.
	 * <p>
	 * @return		The base topic string used when publishing TLOGs.
	 */
	
	public static String getAceTlogTopicString()
	{
		String sRet = null;
		
		sRet = AceTlogProcessorServiceConfig.getStringConfigValue(
							AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR, 
							SigConstants.TOPIC_STRING);
		return sRet;
	}

	/**
	 * Returns the topic type string to use when publishing errors. This
	 * value is used to complete the topic string used in the publication.
	 * <p>
	 * @return	The topic type string to use when publishing errors.
	 */
	
	public static String getAceTlogErrorTopicTypeString()
	{
		String sRet = null;
		
		sRet = AceTlogProcessorServiceConfig.getStringConfigValue(
							AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR, 
							SigConstants.ERROR_TOPIC_TYPE_STRING);
		return sRet;
	}
	
	/**
	 * Returns the Topic string to use when publishing TLOG XML.
	 * <p>
	 * @return		The Topic string to use when publishing TLOG XML.
	 */
	
	public static String getAceTlogPublishTlogXmlTopicString()
	{
		String sRet = null;
		
		sRet = AceTlogProcessorServiceConfig.getStringConfigValue(
				AceTlogProcessorServiceConstants.ACE_TLOG_PROCESSOR, 
				AceTlogProcessorServiceConstants.PUBLISH_TLOG_XML_TOPIC);
		return sRet;
	}
	

	/**
	 * Returns the full path name to the configuration directory.
	 * <p>
	 * @return		The full path name to the configuration directory.
	 */
	
	public static String getConfigDir()
	{
		String sRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		sRet = SigConfigManager.getFolderPath(AceTlogProcessorServiceConfig.configDescriptor, FOLDER_TYPE.CONFIG);
		
		return sRet;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	/**
	 * Return a String value from the configuration.
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The property name.
	 * <p>
	 * @return		The configuration value as a String.
	 */
	
	private static String getStringConfigValue(final String sService, final String sName)
	{
		String sRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null)
		{
			sRet = SigConfigManager.getStringProperty(
								AceTlogProcessorServiceConfig.configDescriptor, 
								sService, sName);
		}
		return sRet;
	}

	/**
	 * Return a Boolean value from the configuration
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The property name.
	 * <p>
	 * @return		The configuration value as a Boolean.
	 */
	
	private static Boolean getBooleanConfigValue(final String sService, final String sName)
	{
		Boolean bRet = Boolean.FALSE;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null)
		{
			bRet = SigConfigManager.getBooleanProperty(
								AceTlogProcessorServiceConfig.configDescriptor, 
								sService, sName);
		}
		return bRet;
	}
	
	/**
	 * Return a Long value from the configuration
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The property name.
	 * <p>
	 * @return		The configuration value as a Long.
	 */
	
	private static Long getLongConfigValue(final String sService, final String sName)
	{
		Long nRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null)
		{
			nRet = SigConfigManager.getLongProperty(
								AceTlogProcessorServiceConfig.configDescriptor, 
								sService, sName);
		}
		return (nRet == null ? new Long(0) : nRet);
	}

	/**
	 * Returns the number of elements in the specified property list.
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The name of the property list.
	 * <p>
	 * @return		The number of elements in the property list.
	 */
	
	private static Long getPropertyListSize(final String sService, final String sName)
	{
		Long nRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null)
		{
			nRet = SigConfigManager.getLongPropertyListSize(
								AceTlogProcessorServiceConfig.configDescriptor, 
								sService, sName);
		}
		return (nRet == null ? new Long(0) : nRet);
	}

	/**
	 * Returns the property list key at the specified index.
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The name of the property list.
	 * @param	ndx			The index of the key to return.
	 * <p>
	 * @return		The key at the specified index.
	 */
	
	private static String getPropertyListKey(final String sService, final String sName, final Long ndx)
	{
		String sRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null && ndx != null)
		{
			if (ndx.intValue() >= 0)
			{
				sRet = SigConfigManager.getStringPropertyListKeyByIndex(
											AceTlogProcessorServiceConfig.configDescriptor, 
											sService, sName, ndx.intValue());
			}
		}
		return sRet;
	}
	
	/**
	 * Returns the property list value at the specified index.
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The name of the property list.
	 * @param	ndx			The index of the key to return.
	 * <p>
	 * @return		The value at the specified index.
	 */
	
	private static String getPropertyListValue(final String sService, final String sName, final Long ndx)
	{
		String sRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null && ndx != null)
		{
			if (ndx.intValue() >= 0)
			{
				sRet = SigConfigManager.getStringPropertyListValueByIndex(
											AceTlogProcessorServiceConfig.configDescriptor, 
											sService, sName, ndx.intValue());
			}
		}
		return sRet;
	}
	
	/**
	 * Returns the property list value at the specified key.
	 * <p>
	 * @param	sService	The service section of the configuration.
	 * @param	sName		The name of the property list.
	 * @param	key			The key to return value of.
	 * <p>
	 * @return		The value at the specified key.
	 */
	private static String getPropertyListValue(final String sService, final String sName, final String key)
	{
		String sRet = null;
		
		AceTlogProcessorServiceConfig.initialize();
		
		if (sService != null && sName != null && key != null)
		{
			sRet = SigConfigManager.getStringPropertyListValueByKey(
										AceTlogProcessorServiceConfig.configDescriptor, 
										sService, sName, key);
		}
		return sRet;
	}
	
	/**
	 * Initialize the configuration if necessary.
	 */
	
	private static void initialize()
	{
		if (AceTlogProcessorServiceConfig.configDescriptor == null)
		{
			synchronized(AceTlogProcessorServiceConfig.class)
			{
				if (AceTlogProcessorServiceConfig.configDescriptor == null)
				{
					try
					{
						AceTlogProcessorServiceConfig.configDescriptor =
								SigConfigManager.initializeConfigurationDescriptor(
											AceTlogProcessorServiceConfig.SERVICE_CONFIGURATION_NAMESPACE, 
											AceTlogProcessorServiceConfig.SERVICE_ENVIRONMENT_VARIABLE,
											AceTlogProcessorServiceConstants.BASE_CONFIG_FILE,
											AceTlogProcessorServiceConstants.STORE_CONFIG_FILE,
											AceTlogProcessorServiceConfig.loggingInterface);
					}
					catch (Throwable th)
					{
						System.out.println(
								AceTlogProcessorServiceConfig.class.getSimpleName() + 
								": Catastrophic Initialization Error:" +
								Util.lineSeparator() + Util.getStackTrace(th));
					}
				}
			}
		}
	}


	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private static final long DEF_PROCESS_INTERVAL = 600000;
	
	private static final long DEF_PROCESS_MAX = 100;

	private static final String SERVICE_ENVIRONMENT_VARIABLE = "SIG_SERVICE_HOME";
	
	private static final String SERVICE_CONFIGURATION_NAMESPACE = "AceTlogProcessorService";
	
	private static ConfigurationDescriptor configDescriptor = null;
	
	private static final LoggingInterfaceImpl loggingInterface = new LoggingInterfaceImpl();
}
