/**
 * AceTlogProcessorServiceConstants.java
 */

package com.gianteagle.is.central;

/**
 * Defines common constants used by AceTlogProcessorService.
 * <p>
 *
 */

public interface AceTlogProcessorServiceConstants
{
	
	/**
	 * Name of the release notes file.
	 */
	
	String RELEASE_NOTES_FILE = "AceTlogProcessorService-ReleaseNotes.txt";

	/**
	 * Name of the base configuration file.
	 */
	
	String BASE_CONFIG_FILE = "AceTlogProcessorServiceBaseConfig.xml";
	
	/**
	 * Name of the store specific configuration file.
	 */
	
	String STORE_CONFIG_FILE = "AceTlogProcessorServiceConfig.xml";
	
	/**
	 * Name of the ACE TLOG Receiver service.
	 */
	
	String ACE_TLOG_RECEIVER = "AceTlogReceiverService";
	
	/**
	 * Name of the ACE TLOG Processor service.
	 */
	
	String ACE_TLOG_PROCESSOR = "AceTlogProcessorService";
	
	/**
	 * Configuration constant. Defines the topic to publish TLOG XML
	 */
	
	String PUBLISH_TLOG_XML_TOPIC = "publishTlogXmlTopic";
}
