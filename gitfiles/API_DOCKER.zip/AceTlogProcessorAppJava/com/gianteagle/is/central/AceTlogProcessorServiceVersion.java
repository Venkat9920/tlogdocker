/**
 * AceTlogProcessorServiceVersion.java
 */

package com.gianteagle.is.central;


import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.gianteagle.is.sig.base.ServiceVersion;

/**
 * Handles version information related requests pertaining to AceTlogProcessorService.
 * <p>
 * 
 */

public final class AceTlogProcessorServiceVersion extends MbJavaComputeNode
{
	/**
	 * Called when a message is passed to the compute node.
	 * <p>
	 * @param	inAssembly	Reference to the top level assembly (InputRoot).
	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	@Override
	public void evaluate(final MbMessageAssembly inAssembly) throws MbException
	{
		try
		{
			ServiceVersion.getServiceVersion(
					this,
					inAssembly,
					this.getOutputTerminal("out"), 
					AceTlogProcessorServiceConfig.getAceTlogProcessorServiceName());
		}
		finally
		{
		}
	}
}
