/**
 * AceTlogProcessorServiceReleaseNotes.java
 */

package com.gianteagle.is.central;


import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.gianteagle.is.sig.base.ServiceReleaseNotes;

/**
 * Returns release notes for the AceTlogProcessorService.
 * <p>
 * 
 */

public class AceTlogProcessorServiceReleaseNotes extends MbJavaComputeNode
{
	/**
	 * Called when a message is passed to the compute node.
	 * <p>
	 * @param	inAssembly	Reference to the top level assembly (InputRoot).
	 * <p>
	 * @exception	MbException		Thrown if an error occurs in processing
	 * 								the message.
	 */
	
	@Override
	public void evaluate(final MbMessageAssembly inAssembly) throws MbException
	{
		ServiceReleaseNotes.getServiceReleaseNotes(inAssembly,
					this.getOutputTerminal("out"), 
					AceTlogProcessorServiceConfig.getAceTlogProcessorServiceName());
	}
}
