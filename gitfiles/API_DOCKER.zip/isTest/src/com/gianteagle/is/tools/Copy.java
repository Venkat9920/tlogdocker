/**
 * Copy.java
 */

package com.gianteagle.is.tools;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;

/**
 * Simple file copy application.
 * <p>
 * @author sr44189
 */

public final class Copy
{
	/**
	 * Default constructor.
	 */
	
	private Copy()
	{
	}
	
	/**
	 * Main application used to copy a source file to a destination
	 * file.
	 * <pre>
	 *  java com.gianteagle.is.tools.Copy source-file destination-file [max-length]
	 * </pre>
	 * @param	args		Command line arguments
	 */
	
	public static void main(final String[] args)
	{
		int nMaxLen = 0;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		long nBytes = 0;
		
		try
		{
			if (args.length < 2)
			{
				System.out.print("Usage: com.gianteagle.is.tools.Copy ");
				System.out.println("source-file destination-file [max-length]");
			}
			else
			{
				fis = new FileInputStream(args[0]);
				fos = new FileOutputStream(args[1]);
				
				if (args.length > 2)
				{
					nMaxLen = StringUtil.parseInt(args[2], 0);
				}
				System.out.print("Copying ");
				System.out.print(args[0]);
				System.out.print(" to ");
				System.out.print(args[1]);
				System.out.println(" ...");
				
				nBytes = FileUtil.copy(fis, fos, nMaxLen);

				System.out.print(nBytes);
				System.out.println(" bytes copied.");
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (fis != null)
			{
				try { fis.close(); } catch (Throwable ignore) { }
				fis = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch (Throwable ignore) { }
				fos = null;
			}
		}
	}
}
