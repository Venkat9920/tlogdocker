/*
 * GunZip.java
 */

package com.gianteagle.is.tools;

import com.gianteagle.is.util.FileUtil;

/**
 * Application that uncompresses a file from GZIP format.
 * <p>
 * @author	ReichertSF
 */

public final class GunZip
{
	/**
	 * Simple application that uncompresses a file from GZip format.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to uncompress,
	 *					and the second is the name of the output
	 *					file that the uncompressed data is to be 
	 *					written to.
	 */

	public static void main(String[] args)
	{
		if (args.length < 2)
		{
			System.out.println("Usage:  GunZip inputfile outputfile");
		}
		else
		{
			try
			{
				FileUtil.gunzip(args[0], args[1]);
			}
			catch (Throwable th)
			{
				th.printStackTrace();
			}
		}
	}
}
