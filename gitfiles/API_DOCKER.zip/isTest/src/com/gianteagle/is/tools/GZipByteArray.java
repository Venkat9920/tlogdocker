/**
 * GZipByteArray.java
 */

package com.gianteagle.is.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.gianteagle.is.util.GZipUtil;

/**
 * Utility used to read the contents of a file into a byte array, gzip
 * the byte array, and then write the compressed byte array to the 
 * specified output file.
 * <p>
 * @author sr44189
 */

public final class GZipByteArray
{
	/**
	 * Default constructor.
	 */
	
	private GZipByteArray()
	{
	}
	
	/**
	 * Utility used to read the contents of a file into a byte array, gzip
	 * the byte array, and then write the compressed byte array to the 
	 * specified output file.
	 * <p>
	 * @param	args	Command line arguments; the input and output file. 
	 */
	
	public static void main(final String[] args)
	{
		byte[] byteData = null;
		File f = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		int nLen = 0;
		
		try
		{
			if (args.length < 2)
			{
				System.out.println(
						"Usage:  GZipByteArray inputfile outputfile");
			}
			else
			{
				f = new File(args[0]);
				
				if (f.length() > 0)
				{
					fis = new FileInputStream(args[0]);
					fos = new FileOutputStream(args[1], false);
				
					byteData = new byte[(int)f.length()];
					
					nLen = fis.read(byteData);
					
					System.out.println("Read " + nLen + " bytes.");
					
					fos.write(GZipUtil.gzip(byteData));
				}
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (fis != null)
			{
				try { fis.close(); } catch(Throwable ignore) { }
				fis = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch(Throwable ignore) { }
				fos = null;
			}
		}
	}
}
