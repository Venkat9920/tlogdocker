package com.gianteagle.is.tools;

import java.io.ByteArrayInputStream;

import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.HexBinary;
import com.gianteagle.is.util.Util;

public class HexDecode
{
	/**
	 * Simple application used to convert a hex encoded file to binary.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the hex encoded input file,
	 *					and the second is the name of the output
	 *					file that the decoded data is to be 
	 *					written to.
	 */

	public static void main(String[] args)
	{
		String sHexString = null;
		byte[] bytesDecoded = null;
		ByteArrayInputStream bais = null;
		
		try
		{
			if (args.length != 2)
			{
				System.out.println("Usage:  HexEncode inputfile outputfile");
			}
			else
			{
				sHexString = FileUtil.fileToString(args[0]);
				
				if (sHexString != null)
				{
					if (sHexString.endsWith(Util.lineSeparator()))
					{
						sHexString = sHexString.substring(0, sHexString.length() - Util.lineSeparator().length());
					}
					bytesDecoded = HexBinary.parseHexBinary(sHexString);
				
					bais = new ByteArrayInputStream(bytesDecoded);
				
					FileUtil.copy(bais, args[1], false);
				}
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
}
