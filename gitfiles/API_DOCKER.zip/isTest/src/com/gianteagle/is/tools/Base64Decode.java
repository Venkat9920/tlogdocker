package com.gianteagle.is.tools;

import java.io.ByteArrayInputStream;

import com.gianteagle.is.util.Base64Util;
import com.gianteagle.is.util.FileUtil;

public class Base64Decode
{
	/**
	 * Simple application Base 64 Decodes a file.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to decode,
	 *					and the second is the name of the output
	 *					file that the decoded data is to be 
	 *					written to.
	 */

	public static void main(String[] args)
	{
		String sBase64String = null;
		byte[] bytesDecoded = null;
		ByteArrayInputStream bais = null;
		
		try
		{
			if (args.length != 2)
			{
				System.out.println("Usage:  Base64Decode inputfile outputfile");
			}
			else
			{
				sBase64String = FileUtil.fileToString(args[0]);
				
				bytesDecoded = Base64Util.decode(sBase64String);
				
				bais = new ByteArrayInputStream(bytesDecoded);
				
				FileUtil.copy(bais, args[1], false);
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
}
