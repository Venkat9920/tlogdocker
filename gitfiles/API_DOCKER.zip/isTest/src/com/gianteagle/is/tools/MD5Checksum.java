package com.gianteagle.is.tools;

import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

public class MD5Checksum
{
    public static void main(final String[] args)
    {
        String sMD5 = null;

        try
        {
            if (args.length == 1)
            {
                sMD5 = Util.getMD5Checksum(FileUtil.fileToByteArray(args[0]));

                System.out.print(StringUtil.format(sMD5));
                System.out.print("  ");
                System.out.println(args[0]);
            }
            else
            {
            	System.out.println("Usage: java com.kroge.is.tools.MD5Checksum filename");
            }
        }
        catch (Throwable th)
        {   
            th.printStackTrace();
        }
    }


}
