/**
 * SystemProperties.java
 */

package com.gianteagle.is.tools;

import java.io.PrintWriter;

import com.gianteagle.is.util.PropUtil;

/**
 * Command line tool used to list the Java System Properties.
 * <p>
 * @author ReichertSF
 */

public final class SystemProperties
{
	/**
	 * Private constructor.
	 */
	
	private SystemProperties()
	{
	}

	/**
	 * Main application used to list the Java System Properties.
	 * <p>
	 * @param	args	Command line arguments. Not used.
	 */
	
	public static void main(final String[] args)
	{
		PrintWriter pw = null;
		
		try
		{
			pw = new PrintWriter(System.out);
			
			PropUtil.listSystemProperties(pw);
			
			pw.flush();
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			pw = null;
		}
	}
}
