/**
 * Versions.java
 */

package com.gianteagle.is.tools;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Set;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.JarUtil;
import com.gianteagle.is.util.NvList;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Application used to report the versions of the Java packages.
 * <p>
 * <b>Synopsis:</b>
 * <pre>
 *    java com.gianteagle.is.tools.Versions
 * </pre>
 * @author	ReichertSF
 */

public final class Versions
{
	/**
	 * Private constructor. No reason for anyone to create an instance
	 * of this object.
	 */

	private Versions()
	{
	}

	/**
	 * Application used to report the versions of the packages. 
	 * <p>
	 * @param		args		Command line arguments (ignored).
	 */

	public static void main(final String[] args)
	{
		try
		{
			outputVersions(System.out);
			System.out.println();
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
	}

	/**
	 * Method used to send the version information to the specified
	 * output stream.
	 * <p>
	 * @param	os		<code>OutputStream</code> to write the version
	 *					information to.
	 * <p>
	 * @exception	IOException		Thrown if an error occurs in writing
	 *								the version information to the
	 *								output stream.
	 */

	public static void outputVersions(final OutputStream os) throws IOException
	{
		if (os != null)
		{
			os.write(Versions.getVersions().getBytes());
		}
	}

	/**
	 * Method used to send the version information to the specified
	 * <code>PrintWriter</code>.
	 * <p>
	 * @param	pw		<code>PrintWriter</code> to write the version
	 *					information to.
	 */

	public static void outputVersions(final PrintWriter pw)
	{
		if (pw != null)
		{
			pw.print(Versions.getVersions());
		}
	}

	/**
	 * Method used to return the version information as a String.
	 * <p>
	 * @return		A <code>String</code> containing the version 
	 * 				information.
	 */

	public static String getVersions()
	{
		StringBuilder sb = new StringBuilder(Defines.IO_BUF_SIZE);
		Enumeration<?> e = null;
		String sName = null;
		
		try
		{
			Versions.initialize();

			sb.append(StringUtil.format(Versions.getDescription()));
			sb.append(Util.lineSeparator());

			sb.append("  Name: ");
			sb.append(StringUtil.format(Versions.getJarName()));
			sb.append("  Version: ");
			sb.append(StringUtil.format(Versions.getVersion()));
			sb.append("  Date: ");
			sb.append(StringUtil.format(Versions.getDate()));
			sb.append(Util.lineSeparator());

			if (Versions.propPackages != null)
			{
				sb.append("Package Versions: ");
				sb.append(Util.lineSeparator());
	
				e = Versions.propPackages.propertyNames();
				
				if (e != null)
				{
					while (e.hasMoreElements())
					{
						sName = (String)e.nextElement();
						
						sb.append("  ");
						sb.append(StringUtil.format(sName));
						sb.append(": ");
						sb.append(StringUtil.format(
										Versions.getPackageVersion(sName)));
						sb.append(Util.lineSeparator());
						
						sName = null;
					}
				}
			}
		}
		finally
		{
			e = null;
		}
		return sb.toString();
	}

	/**
	 * Returns the version contained in the JAR manifest.
	 * <p>
	 * @return		The version.
	 */

	public static String getVersion()
	{
		Versions.initialize();

		return Versions.sVersion;
	}

	/**
	 * Returns the date contained in the JAR manifest.
	 * <p>
	 * @return		The date.
	 */

	public static String getDate()
	{
		Versions.initialize();

		return Versions.sDate;
	}

	/**
	 * Returns the name of the JAR file.
	 * <p>
	 * @return		The JAR file name.
	 */

	public static String getJarName()
	{
		Versions.initialize();

		return Versions.sJarName;
	}

	/**
	 * Returns the description of the JAR file.
	 * <p>
	 * @return		The description of the JAR file.
	 */

	public static String getDescription()
	{
		Versions.initialize();

		return Versions.sDescription;
	}

	/**
	 * Returns the build date of the JAR file.
	 * <p>
	 * @return		The build date as a string.
	 */

	public static String getBuildDate()
	{
		Versions.initialize();

		return Versions.sBuildDate;
	}

	/**
	 * Returns the build time of the JAR file.
	 * <p>
	 * @return		The build time as a string.
	 */

	public static String getBuildTime()
	{
		Versions.initialize();

		return Versions.sBuildTime;
	}

	/**
	 * Returns the version associated with the specified package,
	 * or <code>null</code> if the package does not exist.
	 * <p>
	 * @param	sName		The name of the package to return the
	 *						version for.
	 * <p>
	 * @return		The version associated with the package or
	 *				<code>null</code> if it does not exist.
	 */

	public static String getPackageVersion(final String sName)
	{
		String sRet = null;

		Versions.initialize();

		if (StringUtil.isEmpty(sName) == false)
		{
			if (Versions.propPackages != null)
			{
				sRet = Versions.propPackages.getProperty(sName);
			}
		}
		return sRet;
	}

	/**
	 * Method used to return a list containing the Jar version
	 * and the version of each of the key packages. The user
	 * should destroy the list when it is no longer needed.
	 * <p>
	 * @return		A list containing the Jar and package versions.
	 */

	public static NvList getVersionList()
	{
		NvList nvList = null;
		Enumeration<?> e = null;
		String sName = null;
		String sVer = null;

		try
		{
			Versions.initialize();

			nvList = new NvList();

			nvList.add(Versions.getJarName(),
				   Versions.getVersion() + ' ' + Versions.getDate());

			if (Versions.propPackages != null)
			{
				e = Versions.propPackages.propertyNames();

				if (e != null)
				{
					while (e.hasMoreElements())
					{
						sName = (String)e.nextElement();
						
						if (StringUtil.isEmpty(sName) == false)
						{
							sVer = Versions.getPackageVersion(sName);

							nvList.add(sName, sVer);
						}
						sName = null;
						sVer = null;
					}
				}
			}
		}
		finally
		{
			e = null;
		}
		return nvList;
	}

	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------

	/**
	 * Initialize the version information from the JAR manifest.
	 */

	private static synchronized void initialize()
	{
		Manifest manifest = null;
		Attributes attributes = null;
		Attributes pkgAttributes = null;
		Set<Object> pkgSet = null;
		String sKey = null;
		String sValue = null;

		try
		{
			if (Versions.bInitialized == false)
			{
				manifest = JarUtil.getManifest(Versions.class);

				if (manifest != null)
				{
					attributes = manifest.getMainAttributes();

					if (attributes != null)
					{
						Versions.sJarName =
							attributes.getValue(JarUtil.MF_JAR_NAME);

						Versions.sDescription =
							attributes.getValue(JarUtil.MF_JAR_DESC);

						Versions.sVersion =
							attributes.getValue(JarUtil.MF_JAR_VERSION);

						Versions.sDate =
							attributes.getValue(JarUtil.MF_JAR_DATE);

						Versions.sBuildDate =
							attributes.getValue(JarUtil.MF_BUILD_DATE);

						Versions.sBuildTime =
							attributes.getValue(JarUtil.MF_BUILD_TIME);
					}
					pkgAttributes =
						manifest.getAttributes(JarUtil.MF_PACKAGES);

					if (pkgAttributes != null)
					{
						pkgSet = pkgAttributes.keySet();

						if (pkgSet != null)
						{
							Versions.propPackages = new Properties();

							for (Object object : pkgSet)
							{
								sKey = object.toString().replace('-', '.');

								sValue =
									pkgAttributes.getValue(object.toString());

								sValue += (' ' + Versions.sBuildDate);

								Versions.propPackages.setProperty(sKey, sValue);
							}
						}
					}
				}
				Versions.bInitialized = true;
			}
		}
		catch(Throwable ex)
		{
			Versions.sJarName = ERROR;
			Versions.sVersion = ERROR;
			Versions.sDescription = ERROR;
			Versions.sDate = ERROR;
			Versions.sBuildDate = ERROR;
			Versions.sBuildTime = ERROR;
		}
		finally
		{
			if (pkgSet != null)
			{
				pkgSet.clear();
				pkgSet = null;
			}
			if (pkgAttributes != null)
			{
				pkgAttributes.clear();
				pkgAttributes = null;
			}
			if (attributes != null)
			{
				attributes.clear();
				attributes = null;
			}
			if (manifest != null)
			{
				manifest.clear();
				manifest = null;
			}
			sKey = null;
			sValue = null;
		}
	}

	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private static boolean bInitialized = false;
	private static String sVersion = null;
	private static String sDate = null;
	private static String sJarName = null;
	private static String sDescription = null;
	private static String sBuildDate = null;
	private static String sBuildTime = null;
	private static Properties propPackages = null;

	private static final String ERROR = "Jar Manifest Error!";
}
