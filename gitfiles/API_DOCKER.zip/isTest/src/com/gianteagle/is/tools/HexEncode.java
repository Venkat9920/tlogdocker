package com.gianteagle.is.tools;

import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.HexBinary;

public class HexEncode
{
	/**
	 * Simple application used to encode a binary file as hex.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to encode,
	 *					and the second is the name of the output
	 *					file that the encoded data is to be 
	 *					written to.
	 */
	
	public static void main(String[] args)
	{
		try
		{
			if (args.length < 1)
			{
				System.out.println("Usage:  HexEncode inputfile [outputfile]");
			}
			else
			{
				if (args.length < 2)
				{
					System.out.println(HexBinary.printHexBinary(FileUtil.fileToByteArray(args[0])));
				}
				else
				{
					FileUtil.stringToFile(
							HexBinary.printHexBinary(FileUtil.fileToByteArray(args[0])),
							args[1]);
				}
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
}
