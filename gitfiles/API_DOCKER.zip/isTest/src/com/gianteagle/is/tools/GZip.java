/*
 * GZip.java
 */

package com.gianteagle.is.tools;

import com.gianteagle.is.util.FileUtil;

/**
 * Application that compresses a file to GZIP format.
 * <p>
 * @author	ReichertSF
 */

public final class GZip
{
	/**
	 * Simple application that compresses a file to GZip format.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to compress,
	 *					and the second is the name of the output
	 *					file that the compressed data is to be 
	 *					written to.
	 */

	public static void main(String[] args)
	{
		if (args.length < 1)
		{
			System.out.println("Usage:  GZip inputfile [outputfile]");
		}
		else
		{
			try
			{
				if (args.length < 2)
				{
					FileUtil.gzip(args[0], null);
				}
				else
				{
					FileUtil.gzip(args[0], args[1]);
				}
			}
			catch (Throwable th)
			{
				th.printStackTrace();
			}
		}
	}
}
