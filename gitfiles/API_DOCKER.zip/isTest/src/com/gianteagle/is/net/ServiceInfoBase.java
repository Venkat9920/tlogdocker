/**
 * ServiceInfoBase.java
 */

package com.gianteagle.is.net;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;

import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.xml.XmlDoc;
import com.gianteagle.is.xml.XmlUtil;

/**
 * Class used to manage the ServiceInfoBase XML document.
 * <p>
 * @author	ReichertSF
 */

public class ServiceInfoBase extends XmlDoc
{
	/**
	 * Constructs a document with the specified root element.
	 * <p>
	 * @param sRoot		The root element name.
	 * <p>
	 * @throws ParserConfigurationException		Thrown if an error occurs in
	 * 											creating the XML doc.
	 */
	
	public ServiceInfoBase(final String sRoot) throws ParserConfigurationException
	{
		super();					// Create an empty XML document.
		
		this.setRoot(sRoot);		// Set the root element.
		
		this.addDateElement();		// Add the date element.
	}
	
	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	@Override
	public void destroy()
	{
		super.destroy();
	}

	/**
	 * Sets the value of the <code>Name</code> element.
	 * <p>
	 * @param	sVal		The value of the <code>Name</code> element.
	 */
	
	public final void setName(final String sVal)
	{
		Element element = null;

		try
		{
			if (StringUtil.isEmpty(sVal) == false)
			{
				element = this.createElement(ServiceInfoBase.NAME_ELEMENT);
				
				element.setTextContent(sVal);
				
				this.addElement(element);
			}
		}
		finally
		{
			element = null;
		}
	}

	/**
	 * Sets the value of the <code>Version</code> element.
	 * <p>
	 * @param	sVal		The value of the <code>Version</code> element.
	 */
	
	public final void setVersion(final String sVal)
	{
		Element element = null;

		try
		{
			if (StringUtil.isEmpty(sVal) == false)
			{
				element = this.createElement(ServiceInfoBase.VERSION_ELEMENT);
				
				element.setTextContent(sVal);
				
				this.addElement(element);
			}
		}
		finally
		{
			element = null;
		}
	}
	
	/**
	 * Sets the value of the <code>VersionDate</code> element.
	 * <p>
	 * @param	sVal		The value of the <code>VersionDate</code> element.
	 */
	
	public final void setVersionDate(final String sVal)
	{
		Element element = null;

		try
		{
			if (StringUtil.isEmpty(sVal) == false)
			{
				element = this.createElement(
									ServiceInfoBase.VERSION_DATE_ELEMENT);
				
				element.setTextContent(sVal);
				
				this.addElement(element);
			}
		}
		finally
		{
			element = null;
		}
	}
	
	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Adds the <code>Date</code> element to the <code>ServiceInfoBase</code>
	 * element.
	 */
	
	private final void addDateElement()
	{
		Element element = null;
		
		try
		{
			element = this.createElement(ServiceInfoBase.DATE_ELEMENT);
				
			element.setTextContent(XmlUtil.getXmlDateTime());
				
			this.addElement(element);
		}
		finally
		{
			element = null;
		}
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------

	private static final String DATE_ELEMENT = "Date";
	private static final String NAME_ELEMENT = "Name";
	private static final String VERSION_ELEMENT = "Version";
	private static final String VERSION_DATE_ELEMENT = "VersionDate";
	
	// Define standard element and attribute names.
	
	/** Defines the <code>Info</code> element. */
	
	protected static final String INFO_ELEMENT = "Info";
	
	/** Defines the <code>Item</code> element. */
	
	protected static final String ITEM_ELEMENT = "Item";

	/** Defines the <code>Details</code> element. */
	
	protected static final String DETAILS_ELEMENT = "Details";
	
	/** Defines the <code>Component</code> element. */

	protected static final String COMPONENT_ELEMENT = "Component";

	/** Defines the <code>Library</code> element. */

	protected static final String LIBRARY_ELEMENT = "Library";

	/** Defines the <code>Properties</code> element. */
	
	protected static final String PROPERTIES_ELEMENT = "Properties";

	/** Defines the <code>Property</code> element. */
	
	protected static final String PROPERTY_ELEMENT = "Property";

	/** Defines the <code>name</code> attribute. */
	
	protected static final String NAME_ATTRIBUTE = "name";
	
	// The "name" attribute values are public to allow clients to reuse them.

	/** Defines the <code>name</code> attribute value <code>Type</code>. */
	
	public static final String NAME_TYPE = "Type";
	
	/** Defines the <code>name</code> attribute value <code>Description</code>. */
	
	public static final String NAME_DESCRIPTION = "Description";
	
	/** Defines the <code>name</code> attribute value <code>Version</code>. */
	
	public static final String NAME_VERSION = "Version";
	
	/** Defines the <code>name</code> attribute value <code>VersionDate</code>. */

	public static final String NAME_VERSION_DATE = "VersionDate";
	
	/** Defines the element value of <code>Java Library</code>. */
	
	public static final String JAVA_LIBRARY = "Java Library";
}
