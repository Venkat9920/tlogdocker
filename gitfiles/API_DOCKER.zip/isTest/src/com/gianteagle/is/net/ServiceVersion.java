/**
 * ServiceVersion.java
 */

package com.gianteagle.is.net;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;

import com.gianteagle.is.tools.Versions;
import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used to manage the ServiceVersion XML document.
 * <p>
 * @author	ReichertSF
 */

public final class ServiceVersion extends ServiceInfoBase
{
	/**
	 * Creates a <code>ServiceVersion</code> document.
	 * <p>
	 * @param	sName			String containing the service name.
	 * @param	sVersion		String containing the version.
	 * @param	sVersionDate	String containing the version date.
	 * <p>
	 * @throws ParserConfigurationException		Thrown if an error occurs in
	 * 											creating the XML doc.
	 */
	
	public ServiceVersion(final String sName, final String sVersion,
				final String sVersionDate) throws ParserConfigurationException
	{
		super(ServiceVersion.ROOT_ELEMENT);
		
		this.setName(sName);
			
		this.setVersion(sVersion);
			
		this.setVersionDate(sVersionDate);
		
		this.setIsLibrary();
	}
	
	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	@Override
	public void destroy()
	{
		this.detailsElement = null;
		
		super.destroy();
	}

	/**
	 * Creates a <code>Library</code> element with the specified 
	 * name.
	 * <p>
	 * @param	sName		The name of the library element.
	 * <p>
	 * @return		A <code>Library</code> element.
	 */
	
	public Element newLibraryElement(final String sName)
	{
		Element element = null;
		
		element = this.createElement(ServiceInfoBase.LIBRARY_ELEMENT);
		
		if (StringUtil.isEmpty(sName) == false)
		{
			element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
		}
		return element;
	}
	
	/**
	 * Creates a <code>Component</code> element with the specified 
	 * name.
	 * <p>
	 * @param	sName		The name of the compnent element.
	 * <p>
	 * @return		A <code>Library</code> element.
	 */
	
	public Element newComponentElement(final String sName)
	{
		Element element = null;
		
		element = this.createElement(ServiceInfoBase.COMPONENT_ELEMENT);
		
		if (StringUtil.isEmpty(sName) == false)
		{
			element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
		}
		return element;
	}
	
	/**
	 * Helper method that adds an <code>Item</code> element to the
	 * specified <code>Library</code> element.
	 * <p>
	 * @param	libraryElement		The <code>Library</code> element
	 * 								to add the <code>Item</code> to.
	 * @param	sName				The <code>name</code> to associate
	 * 								with the <code>Item</code>.
	 * @param	sVal				The value to associate with the
	 * 								<code>Item</code>.
	 */
	
	public void setLibraryItem(final Element libraryElement,
							   final String sName, final String sVal)
	{
		this.setItem(libraryElement, sName, sVal);
	}

	/**
	 * Helper method that adds an <code>Item</code> element to the
	 * specified <code>Component</code> element.
	 * <p>
	 * @param	componentElement	The <code>Component</code> element
	 * 								to add the <code>Item</code> to.
	 * @param	sName				The <code>name</code> to associate
	 * 								with the <code>Item</code>.
	 * @param	sVal				The value to associate with the
	 * 								<code>Item</code>.
	 */
	
	public void setComponentItem(final Element componentElement,
							     final String sName, final String sVal)
	{
		this.setItem(componentElement, sName, sVal);
	}

	/**
	 * Appends the specified <code>Library</code> element to the
	 * <code>Details</code> element.
	 * <p>
	 * @param	libraryElement		The <code>Library</code> element
	 * 								to add to the <code>Details</code>.
	 */
	
	public void addLibrary(final Element libraryElement)
	{
		this.addDetailElement(libraryElement);
	}

	/**
	 * Appends the specified <code>Component</code> element to the
	 * <code>Details</code> element.
	 * <p>
	 * @param	componentElement	The <code>Component</code> element
	 * 								to add to the <code>Details</code>.
	 */
	
	public void addComponent(final Element componentElement)
	{
		this.addDetailElement(componentElement);
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Adds the Integration Services Java Library to the document.
	 */
	
	private void setIsLibrary()
	{
		Element libraryElement = null;

		try
		{
			libraryElement = this.newLibraryElement(Versions.getJarName());
			
			this.setLibraryItem(libraryElement, 
								ServiceInfoBase.NAME_TYPE, 
								ServiceInfoBase.JAVA_LIBRARY);
			
			this.setLibraryItem(libraryElement, 
								ServiceInfoBase.NAME_DESCRIPTION, 
								Versions.getDescription());

			this.setLibraryItem(libraryElement, 
								ServiceInfoBase.NAME_VERSION,
								Versions.getVersion());

			this.setLibraryItem(libraryElement, 
								ServiceInfoBase.NAME_VERSION_DATE,
								Versions.getDate());

			this.addLibrary(libraryElement);
		}
		finally
		{
			libraryElement = null;
		}
	}
	
	/**
	 * Helper method that adds an <code>Item</code> element to the
	 * specified parent element.
	 * <p>
	 * @param	parentElement		The parent element
	 * 								to add the <code>Item</code> to.
	 * @param	sName				The <code>name</code> to associate
	 * 								with the <code>Item</code>.
	 * @param	sVal				The value to associate with the
	 * 								<code>Item</code>.
	 */
	
	public void setItem(final Element parentElement,
							   final String sName, final String sVal)
	{
		Element element = null;
		
		try
		{
			if (parentElement != null) 
			{
				element = this.createElement(ServiceInfoBase.ITEM_ELEMENT);

				if (StringUtil.isEmpty(sName) == false)
				{
					element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
				}
				if (StringUtil.isEmpty(sVal) == false)
				{
					element.setTextContent(sVal);
				}
				parentElement.appendChild(element);
			}
		}
		finally
		{
			element = null;
		}
	}

	/**
	 * Appends the specified element to the
	 * <code>Details</code> element.
	 * <p>
	 * @param	element		The element to add to the <code>Details</code>
	 * 						element.
	 */
	
	public void addDetailElement(final Element element)
	{
		if (element != null)
		{
			if (this.detailsElement == null)
			{
				this.detailsElement = 
					this.createElement(ServiceInfoBase.DETAILS_ELEMENT);
				
				this.addElement(this.detailsElement);
			}
			this.detailsElement.appendChild(element);
		}
	}

	//----------------------------------------------------------------
	// Test Application.
	//----------------------------------------------------------------
	
	/**
	 * Simple test program used to validate operation of the class.
	 * <p>
	 * @param	args		Not used.
	 */
	
	public static void main(final String[] args)
	{
		ServiceVersion serviceVersion = null;
		Element componentElement = null;
		
		try
		{
			serviceVersion = new ServiceVersion(
					"ServiceVersion Test","0.0.0.0001", DateUtil.formatDate());
		
			componentElement = 
					serviceVersion.newComponentElement("SampleComponent");
			
			serviceVersion.setComponentItem(
					componentElement, "Version", "1.0.1.0001");
			serviceVersion.setComponentItem(
					componentElement, "Date", DateUtil.getStandardFormatDate());
			
			serviceVersion.addComponent(componentElement);
			
			System.out.println(serviceVersion);
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (serviceVersion != null)
			{
				serviceVersion.destroy();
				serviceVersion = null;
			}
			componentElement = null;
		}
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------

	private transient Element detailsElement = null;

	private static final String ROOT_ELEMENT = "ServiceVersion";
}
