/**
 * ServiceStatus.java
 */

package com.gianteagle.is.net;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used to manage the ServiceStatus XML document.
 * <p>
 * @author	ReichertSF
 */

public final class ServiceStatus extends ServiceInfoBase
{
	/**
	 * Creates a <code>ServiceVersion</code> document.
	 * <p>
	 * @param	sName			String containing the service name.
	 * @param	sVersion		String containing the version.
	 * @param	sVersionDate	String containing the version date.
	 * <p>
	 * @throws ParserConfigurationException		Thrown if an error occurs in
	 * 											creating the XML doc.
	 */

	public ServiceStatus(final String sName, final String sVersion,
				final String sVersionDate) throws ParserConfigurationException
	{
		super(ServiceStatus.ROOT_ELEMENT);

		this.setName(sName);
			
		this.setVersion(sVersion);
			
		this.setVersionDate(sVersionDate);
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	@Override
	public void destroy()
	{
		this.infoElement = null;
		this.detailsElement = null;

		super.destroy();
	}

	/**
	 * Adds the specifed <code>Info</code> <code>item</code> with
	 * the specified value.
	 * <p>
	 * @param	sName		The name of the <code>info</code> item to add.
	 * @param	sVal		The value of the specified <code>info</code> item
	 * 						to add.
	 */
	
	public void setInfoItem(final String sName, final String sVal)
	{
		Element element = null;
		
		try
		{
			if (StringUtil.isEmpty(sName) == false)
			{
				if (this.infoElement == null)
				{
					this.infoElement = 
						this.createElement(ServiceInfoBase.INFO_ELEMENT);
					
					this.addElement(this.infoElement);
				}
				element = this.createElement(ServiceInfoBase.ITEM_ELEMENT);
				
				element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
				
				if (StringUtil.isEmpty(sVal) == false)
				{
					element.setTextContent(sVal);
				}
				this.infoElement.appendChild(element);
			}
		}
		finally
		{
			element = null;
		}
	}
	
	/**
	 * Creates a <code>Component</code> element with the specified 
	 * name.
	 * <p>
	 * @param	sName		The name of the component element.
	 * <p>
	 * @return		A <code>Component</code> element.
	 */
	
	public Element newComponentElement(final String sName)
	{
		Element element = null;
		
		element = this.createElement(ServiceInfoBase.COMPONENT_ELEMENT);
		
		if (StringUtil.isEmpty(sName) == false)
		{
			element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
		}
		return element;
	}
	
	/**
	 * Helper method that adds an <code>Item</code> element to the
	 * specified <code>Component</code> element.
	 * <p>
	 * @param	componentElement	The <code>Component</code> element
	 * 								to add the <code>Item</code> to.
	 * @param	sName				The <code>name</code> to associate
	 * 								with the <code>Item</code>.
	 * @param	sVal				The value to associate with the
	 * 								<code>Item</code>.
	 */
	
	public void setComponentItem(final Element componentElement,
								 final String sName, final String sVal)
	{
		Element element = null;
		
		try
		{
			if (componentElement != null) 
			{
				element = this.createElement(ServiceInfoBase.ITEM_ELEMENT);

				if (StringUtil.isEmpty(sName) == false)
				{
					element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
				}
				if (StringUtil.isEmpty(sVal) == false)
				{
					element.setTextContent(sVal);
				}
				componentElement.appendChild(element);
			}
		}
		finally
		{
			element = null;
		}
	}
	
	/**
	 * Appends the specified <code>Component</code> element to the
	 * <code>Details</code> element.
	 * <p>
	 * @param	componentElement	The <code>Component</code> element
	 * 								to add to the <code>Details</code>.
	 */
	
	public void addComponent(final Element componentElement)
	{
		if (componentElement != null)
		{
			if (this.detailsElement == null)
			{
				this.detailsElement = 
					this.createElement(ServiceInfoBase.DETAILS_ELEMENT);
				
				this.addElement(this.detailsElement);
			}
			this.detailsElement.appendChild(componentElement);
		}
	}
	
	//----------------------------------------------------------------
	// Test Application.
	//----------------------------------------------------------------
	
	/**
	 * Simple test program used to validate operation of the class.
	 * <p>
	 * @param	args		Not used.
	 */
	
	public static void main(final String[] args)
	{
		ServiceStatus serviceStatus = null;
		
		try
		{
			serviceStatus = 
				new ServiceStatus("ServiceStatus Test", "0.0.0.0001",
								  DateUtil.formatDate());
			
			serviceStatus.setInfoItem("host", "10.10.1.1");
			serviceStatus.setInfoItem("port", "56020");
			
			System.out.println(serviceStatus);
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (serviceStatus != null)
			{
				serviceStatus.destroy();
				serviceStatus = null;
			}
		}
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------

	private transient Element infoElement = null;
	private transient Element detailsElement = null;
	
	private static final String ROOT_ELEMENT = "ServiceStatus";
}
