/**
 * Html.java
 */

package com.gianteagle.is.net;

import com.gianteagle.is.util.StringUtil;

/**
 * Utility methods used in the handling of HTML.
 * <p>
 * @author	ReichertSF
 */

public final class Html
{
	/**
	 * Default constructor is private.
	 */
	
	private Html()
	{
	}

	/**
	 * Returns the beginning HTML tag <code>&lt;HTML&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;HTML&gt;</code>.
	 */

	public static String beginHtml()
	{
		return "<HTML>";
	}

	/**
	 * Returns the ending HTML tag <code>&lt;/HTML&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/HTML&gt;</code>.
	 */

	public static String endHtml()
	{
		return "</HTML>";
	}

	/**
	 * Returns the beginning HEAD tag <code>&lt;HEAD&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;HEAD&gt;</code>.
	 */

	public static String beginHead()
	{
		return "<HEAD>";
	}
	
	/**
	 * Returns the ending HEAD tag <code>&lt;/HEAD&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/HEAD&gt;</code>.
	 */

	public static String endHead()
	{
		return "</HEAD>";
	}

	/**
	 * Returns the beginning BODY tag <code>&lt;BODY&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;BODY&gt;</code>.
	 */

	public static String beginBody()
	{
		return "<BODY>";
	}
	
	/**
	 * Returns the ending BODY tag <code>&lt;/BODY&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/BODY&gt;</code>.
	 */

	public static String endBody()
	{
		return "</BODY>";
	}

	/**
	 * Returns the beginning Paragraph tag <code>&lt;P&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;P&gt;</code>.
	 */

	public static String beginParagraph()
	{
		return "<P>";
	}

	/**
	 * Returns the ending Paragraph tag <code>&lt;/P&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/P&gt;</code>.
	 */

	public static String endParagraph()
	{
		return "</P>";
	}

	/**
	 * Returns the beginning Preformatted tag <code>&lt;PRE&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;PRE&gt;</code>.
	 */

	public static String beginPreformatted()
	{
		return "<PRE>";
	}
	
	/**
	 * Returns the ending Preformatted tag <code>&lt;/PRE&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/PRE&gt;</code>.
	 */

	public static String endPreformatted()
	{
		return "</PRE>";
	}

	/**
	 * Returns the beginning Bold tag <code>&lt;B&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;B&gt;</code>.
	 */

	public static String beginBold()
	{
		return "<B>";
	}
	
	/**
	 * Returns the ending Bold tag <code>&lt;/B&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/B&gt;</code>.
	 */

	public static String endBold()
	{
		return "</B>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Bold tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending bold
	 *					tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;B&gt;<i>sStr</i>&lt;/B&gt;"</code>.
	 */

	public static String bold(String sStr)
	{
		return beginBold() + (sStr == null ? "" : sStr) + endBold();
	}

	/**
	 * Returns the beginning Small tag <code>&lt;small&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;small&gt;</code>.
	 */

	public static String beginSmall()
	{
		return "<small>";
	}
	
	/**
	 * Returns the ending Small tag <code>&lt;/small&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/small&gt;</code>.
	 */

	public static String endSmall()
	{
		return "</small>";
	}
	
	/**
	 * Returns a string wrapped with the beginning and ending small tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending small
	 *					tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;small&gt;string&lt;/small&gt;"</code>.
	 */

	public static String small(String sStr)
	{
		return beginSmall() + (sStr == null ? "" : sStr) + endSmall();
	}
	
	/**
	 * Returns the beginning Italic tag <code>&lt;I&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;I&gt;</code>.
	 */

	public static String beginItalic()
	{
		return "<I>";
	}
	
	/**
	 * Returns the ending Italic tag <code>&lt;/I&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/I&gt;</code>.
	 */

	public static String endItalic()
	{
		return "</I>";
	}
	
	/**
	 * Returns a string wrapped with the beginning and ending italic tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending italic
	 *					tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;I&gt;string&lt;/I&gt;"</code>.
	 */

	public static String italic(String sStr)
	{
		return beginItalic() + (sStr == null ? "" : sStr) + endItalic();
	}
	
	/**
	 * Returns the beginning Computer Code tag <code>&lt;CODE&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;CODE&gt;</code>.
	 */

	public static String beginCode()
	{
		return "<CODE>";
	}
	
	/**
	 * Returns the ending Computer Code tag <code>&lt;/CODE&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/CODE&gt;</code>.
	 */

	public static String endCode()
	{
		return "</CODE>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Computer
	 * Code tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending code
	 *					tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;CODE&gt;<i>sStr</i>&lt;/CODE&gt;"</code>.
	 */

	public static String code(String sStr)
	{
		return beginCode() + (sStr == null ? "" : sStr) + endCode();
	}


	/**
	 * Returns the beginning tag <code>&lt;BLOCKQUOTE&gt;</code>.
	 * <p>
	 * @return	Returns a String containing <code>&lt;BLOCKQUOTE&gt;</code>.
	 */

	public static String beginBlockQuote()
	{
		return "<BLOCKQUOTE>";
	}
	
	/**
	 * Returns the ending Computer Code tag <code>&lt;/BLOCKQUOTE&gt;</code>.
	 * <p>
	 * @return	Returns a String containing <code>&lt;/BLOCKQUOTE&gt;</code>.
	 */

	public static String endBlockQuote()
	{
		return "</BLOCKQUOTE>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Title
	 * tags.
	 * <p>
	 * @param	sTitle	String to wrap with the beginning and ending title
	 *					tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;TITLE&gt;<i>sStr</i>&lt;/TITLE&gt;"</code>.
	 */

	public static String title(String sTitle)
	{
		return "<TITLE>" + (sTitle == null ? "" : sTitle) + "</TITLE>";
	}
	
	/**
	 * Returns a string wrapped with the beginning and ending Level-one
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-one heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H1&gt;<i>sStr</i>&lt;/H1&gt;"</code>.
	 */

	public static String h1(String sStr)
	{
		return "<H1>" + (sStr == null ? "" : sStr) + "</H1>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Level-two
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-two heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H2&gt;<i>sStr</i>&lt;/H2&gt;"</code>.
	 */

	public static String h2(String sStr)
	{
		return "<H2>" + (sStr == null ? "" : sStr) + "</H2>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Level-three
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-three heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H3&gt;<i>sStr</i>&lt;/H3&gt;"</code>.
	 */

	public static String h3(String sStr)
	{
		return "<H3>" + (sStr == null ? "" : sStr) + "</H3>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Level-four
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-four heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H4&gt;<i>sStr</i>&lt;/H4&gt;"</code>.
	 */

	public static String h4(String sStr)
	{
		return "<H4>" + (sStr == null ? "" : sStr) + "</H4>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Level-five
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-five heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H5&gt;<i>sStr</i>&lt;/H5&gt;"</code>.
	 */

	public static String h5(String sStr)
	{
		return "<H5>" + (sStr == null ? "" : sStr) + "</H5>";
	}

	/**
	 * Returns a string wrapped with the beginning and ending Level-six
	 * heading tags.
	 * <p>
	 * @param	sStr	String to wrap with the beginning and ending 
	 *					level-six heading tags.
	 * <p>
	 * @return			Returns a String in the format
	 *					<code>"&lt;H6&gt;<i>sStr</i>&lt;/H6&gt;"</code>.
	 */

	public static String h6(String sStr)
	{
		return "<H6>" + (sStr == null ? "" : sStr) + "</H6>";
	}

	/**
	 * Returns the beginning Line break tag <code>&lt;BR&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;BR&gt;</code>.
	 */

	public static String lineBreak()
	{
		return "<BR>";
	}

	/**
	 * Returns the beginning Horizontal rule tag <code>&lt;HR&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;HR&gt;</code>.
	 */

	public static String rule()
	{
		return "<HR>";
	}

	/**
	 * Returns the beginning Table tag <code>&lt;TABLE&gt;</code> with the
	 * default attributes as follows:
	 * <pre>
	 *   summary=""
	 *   border="1"
	 *   cellpadding="2"
	 *   cellspacing="2"
	 * </pre>
	 * <p>
	 * @return		Returns a String containing <code>&lt;TABLE&gt;</code>.
	 */

	public static String beginTable()
	{
		return Html.beginTable(true);
	}
	
	/**
	 * Returns the beginning Table tag <code>&lt;TABLE&gt;</code> with or
	 * without a border and the following attributes:
	 * <pre>
	 *   summary=""
	 *   cellpadding="2"
	 *   cellspacing="2"
	 * </pre>
	 * <p>
	 * @param	bBorder		Whether or not to include a border.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TABLE&gt;</code>.
	 */
	
	public static String beginTable(final boolean bBorder)
	{
		return Html.beginTable(
				"summary=\"\" cellpadding=\"2\" cellspacing=\"2\"" +
				(bBorder == false ? "border=\"0\"" : "border=\"1\""));
	}
	
	/**
	 * Returns the beginning Table tag <code>&lt;TABLE&gt;</code> with
	 * specified attributes.
	 * <p>
	 * @param	sAttributes		The attributes to be included in the tag.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TABLE&gt;</code>
	 *				with the specified attributes.
	 */

	public static String beginTable(String sAttributes)
	{
		String sRet = null;

		if (StringUtil.isEmpty(sAttributes) == true)
		{
			sRet = "<TABLE>";
		}
		else
		{
			sRet = "<TABLE " + sAttributes + ">";
		}
		return sRet;
	}

	/**
	 * Returns the ending Table tag <code>&lt;/TABLE&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/TABLE&gt;</code>.
	 */

	public static String endTable()
	{
		return "</TABLE>";
	}

	/**
	 * Returns the beginning Table Row tag <code>&lt;TR&gt;</code> with
	 * no attributes.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TR&gt;</code>.
	 */

	public static String beginTableRow()
	{
		return beginTableRow(null);
	}

	/**
	 * Returns the beginning Table Row tag <code>&lt;TR&gt;</code> with
	 * specified attributes.
	 * <p>
	 * @param	sAttributes		The attributes to be included in the tag.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TR&gt;</code>
	 *				with the specified attributes.
	 */

	public static String beginTableRow(String sAttributes)
	{
		String sRet = null;

		if (StringUtil.isEmpty(sAttributes) == true)
		{
			sRet = "<TR>";
		}
		else
		{
			sRet = "<TR " + sAttributes + ">";
		}
		return sRet;
	}

	/**
	 * Returns the ending Table Row tag <code>&lt;/TR&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/TR&gt;</code>.
	 */

	public static String endTableRow()
	{
		return "</TR>";
	}

	/**
	 * Returns the beginning Table Data tag <code>&lt;TD&gt;</code> with
	 * no attributes.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TD&gt;</code>.
	 */

	public static String beginTableData()
	{
		return beginTableData(null);
	}

	/**
	 * Returns the beginning Table Data tag <code>&lt;TD&gt;</code> with
	 * specified attributes.
	 * <p>
	 * @param	sAttributes		The attributes to be included in the tag.
	 * <p>
	 * @return		Returns a String containing <code>&lt;TD&gt;</code>
	 *				with the specified attributes.
	 */

	public static String beginTableData(String sAttributes)
	{
		String sRet = null;

		if (StringUtil.isEmpty(sAttributes) == true)
		{
			sRet = "<TD>";
		}
		else
		{
			sRet = "<TD " + sAttributes + ">";
		}
		return sRet;
	}

	/**
	 * Returns the ending Table Data tag <code>&lt;/TD&gt;</code>.
	 * <p>
	 * @return		Returns a String containing <code>&lt;/TD&gt;</code>.
	 */

	public static String endTableData()
	{
		return "</TD>";
	}
	
	/**
	 * Returns a string wrapped in the beginning and ending table data tags.
	 * <p>
	 * @param	sStr	The string to wrap in the begin and end tags.
	 * <p>
	 * @return		A String containing
	 * 				<code>&lt;TD%gt;string&lt;/TD&gt;</code>.
	 */
	
	public static String tableData(final String sStr)
	{
		return beginTableData() + (sStr == null ? "" : sStr) + endTableData();
	}
}
