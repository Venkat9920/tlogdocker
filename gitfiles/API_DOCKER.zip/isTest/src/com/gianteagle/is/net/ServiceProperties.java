/**
 * ServiceProperties.java
 */

package com.gianteagle.is.net;

import java.util.Enumeration;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Text;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used to manage the ServiceProperties XML document.
 * <p>
 * @author	ReichertSF
 */

public final class ServiceProperties extends ServiceInfoBase
{
	/**
	 * Creates a <code>ServiceProperties</code> document.
	 * <p>
	 * @param	sName			String containing the service name.
	 * @param	sVersion		String containing the version.
	 * @param	sVersionDate	String containing the version date.
	 * <p>
	 * @throws		ParserConfigurationException	Thrown if an error occurs
	 * 												creating the document.
	 */

	public ServiceProperties(final String sName, final String sVersion, 
				final String sVersionDate) throws ParserConfigurationException
	{
		super(ServiceProperties.ROOT_ELEMENT);

		this.setName(sName);
			
		this.setVersion(sVersion);
			
		this.setVersionDate(sVersionDate);
		
		this.setProperties();
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	@Override
	public void destroy()
	{
		this.propertiesElement = null;

		super.destroy();
	}

	/**
	 * Helper method that returns a string containing a complete 
	 * <code>ServiceProperties</code> document.
	 * <p>
	 * @param	sName			String containing the service name.
	 * @param	sVersion		String containing the version.
	 * @param	sVersionDate	String containing the version date.
	 * <p>
	 * @return		A String containing the complete 
	 * 				<code>ServiceProperties</code> document.
	 * <p>
	 * @exception	ParserConfigurationException	Thrown if an error occurs
	 *												in building the version
	 *												document. 						
	 */
	
	public static String getDocument(final String sName,
									 final String sVersion, 
									 final String sVersionDate)
							throws ParserConfigurationException
	{
		String sRet = null;
		
		ServiceProperties serviceProperties = null;

		try
		{
			serviceProperties = 
				new ServiceProperties(sName, sVersion, sVersionDate);
			
			sRet = serviceProperties.toString();
		}
		finally
		{
			if (serviceProperties != null)
			{
				serviceProperties.destroy();
				serviceProperties = null;
			}
		}
		return sRet;
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------

	/**
	 * Adds the system properties to the document.
	 */
	
	private void setProperties()
	{
		Properties properties = null;
		Enumeration<?> e = null;
		String sName = null;
		String sValue = null;
		
		try
		{
			properties = System.getProperties();
			e = properties.propertyNames();

			while (e.hasMoreElements() == true)
			{
				sName = (String)e.nextElement();
				sValue = properties.getProperty(sName);

				this.setProperty(sName, sValue);

				sName = null;
				sValue = null;
			}
		}
		finally
		{
			e = null;
			properties = null;
		}
		
	}

	/**
	 * Adds the specifed <code>Property</code>.
	 * <p>
	 * @param	sName		The name of the property to add.
	 * @param	sVal		The value of the property to add.
	 */
	
	private void setProperty(final String sName, final String sVal)
	{
		Element element = null;
		Text text = null;
		
		try
		{
			if (StringUtil.isEmpty(sName) == false)
			{
				if (this.propertiesElement == null)
				{
					this.propertiesElement = 
							this.createElement(
								ServiceInfoBase.PROPERTIES_ELEMENT);
					
					this.addElement(this.propertiesElement);
				}
				element = this.createElement(ServiceInfoBase.PROPERTY_ELEMENT);
				
				element.setAttribute(ServiceInfoBase.NAME_ATTRIBUTE, sName);
				
				text = this.createTextNode(
						StringUtil.encodeSpecialChars(sVal, false));
				
				if (text != null)
				{
					element.appendChild(text);
				}
				this.propertiesElement.appendChild(element);
			}
		}
		finally
		{
			element = null;
		}
	}
	
	//----------------------------------------------------------------
	// Test Application.
	//----------------------------------------------------------------
	
	/**
	 * Simple test program used to validate operation of the class.
	 * <p>
	 * @param	args		Not used.
	 */
	
	public static void main(final String[] args)
	{
		try
		{
			System.out.println(
					ServiceProperties.getDocument("ServiceProperties Test", 
												  "0.0.0.0001", 
												  DateUtil.formatDate()));
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------

	private transient Element propertiesElement = null;
	
	private static final String ROOT_ELEMENT = "ServiceProperties";
}
