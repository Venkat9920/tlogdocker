/**
 * NetUtil.java
 */

package com.gianteagle.is.net;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URLEncoder;
import java.net.UnknownHostException;

import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Set of network utility methods, mainly for convenience.
 * <p>
 * @author	ReichertSF
 */

public final class NetUtil
{
	/**
	 * Default constructor. Private, no one should create one of these.
	 */
	
	private NetUtil()
	{
	}
	
	/**
	 * Returns the IP address as a string for the specifed
	 * <code>InetSocketAddress</code>.
	 * <p>
	 * @param	inetSocketAddress	The specified 
	 * 								<code>InetSocketAddress</code>.
	 * <p>
	 * @return		The IP address as a string, or <code>null</code> if the
	 * 				address is invalid. 
	 */
	
	public static String getAddress(final InetSocketAddress inetSocketAddress)
	{
		String sRet = null;
		
		InetAddress inetAddress = null;
		
		try
		{
			if (inetSocketAddress != null)
			{
				inetAddress = inetSocketAddress.getAddress();
				
				if (inetAddress != null)
				{
					sRet = inetAddress.getHostAddress();
				}
			}
		}
		finally
		{
			inetAddress = null;
		}
		return sRet;
	}
	
	    /**
     *  Public class (static) method used to get the host name of the
     *  local system. This method utilizes the Java net package
     *  InetAddress class methods getLocalHost() and getHostName()
     *  to esatblish the local host name.
     *  <p>
     *  The use of this method, or the {@link #getLocalHostAddress()}
     *  method is the preferred approach to obtaining the local host
     *  name and / or address for use as an argument to connectivity
     *  related classes and / or methods. Simply using the string
     *  &quot;localhost&quot;, although technically correct, can
     *  result in reliability and / or portability problems,
     *  particularly when all when potential configuration variations
     *  of Reynolds ERA platforms are considered.
	 *  <p>
	 *  @return     A String object containing the host name for the
     *              local system.
     *  <p>
	 *  @exception  UnknownHostException    If no IP address for the
     *                                      host could be found.
     */

    public static String getLocalHostName()
        throws UnknownHostException
    {
        return (InetAddress.getLocalHost().getHostName());    
    }

    /**
     *  Public class (static) method used to get a string
     *  representation of the IP address of the local system.
     *  This method utilizes the Java net package
     *  InetAddress class methods getLocalHost() and 
     *  getHostAddress() to esatblish the local host address.
     *  <p>
     *  The use of this method, or the {@link #getLocalHostName()}
     *  method is the preferred approach to obtaining the local host
     *  name and / or address for use as an argument to connectivity
     *  related classes and / or methods. Simply using the string
     *  &quot;localhost&quot;, although technically correct, can
     *  result in reliability and / or portability problems,
     *  particularly when all when potential configuration variations
     *  of Reynolds ERA platforms are considered.
	 *  <p>
	 *  @return     A String object containing the IP address for
     *              the local system in the form
     *              &quot;%d.%d.%d.%d&quot;.
     *  <p>
	 *  @exception  UnknownHostException    If no IP address for the
     *                                      host could be found.
     */

    public static String getLocalHostAddress()
        throws UnknownHostException
    {
        return (InetAddress.getLocalHost().getHostAddress());    
    }


    
    public static boolean isLocalHost(String sHost)
    {
        boolean bResult = false;
        InetAddress localIP = null;
        InetAddress argIP = null;
        
        if (!StringUtil.isEmpty(sHost))
        {
            try
            {
                argIP = InetAddress.getByName(sHost);
                localIP = InetAddress.getLocalHost();
                if (localIP.equals(argIP))
                {
                    bResult = true;
                }    
                else
                {
                    localIP = InetAddress.getByName(null);
                    if (localIP.equals(argIP))
                        bResult = true;
                }            
            }
            catch(UnknownHostException ex) {}  //  Ignore
        }
        return (bResult);
    }    

	/**
	 * Method used to return a String, for display purposes only,
	 * containing the host name of the system on which the JVM is
	 * running. This method is safe for display purposes and returns
	 * either the name of the system or a string of zero length.
	 * <p>
	 * This method should be used <b>only</b> for display purposes.
	 * <p>
	 * @return	A string containing the name of the 
	 *			system on which the JVM is running.
	 */

	public static String getHostName()
	{
		String sRet = null;

		try
		{
			sRet = NetUtil.getLocalHostName();
		}
		catch(Throwable ignore)
		{
		}
		finally
		{
			sRet = StringUtil.format(sRet);
		}
		return sRet;
	}

	/**
	 * Method used to return a String, for display purposes only,
	 * containing the IP address of the system on which the
	 * JVM is running. This method is safe for display
	 * purposes, and returns either the IP address in a string,
	 * or a string of zero length.
	 * <p>
	 * This method should be used <b>only</b> for display purposes.
	 * <p>
	 * @return	A string containing the IP address of the 
	 *			system on which the JVM is running.
	 */

	public static String getHostAddress()
	{
		String sRet = null;

		try
		{
			sRet = NetUtil.getLocalHostAddress();
		}
		catch(Throwable ignore)
		{
		}
		finally
		{
			sRet = StringUtil.format(sRet);
		}
		return sRet;
	}

	/**
	 * Method used to return a String, for display purposes only,
	 * containing the name and IP address of the system on which
	 * the JVM is running. This method is safe for display purposes,
	 * and returns a string containg both fields separated by a
	 * slash or a string of length 0.
	 * <p>
	 * This method should be used <b>only</b> for display purposes.
	 * <p>
	 * @return	A string containing the name and IP address of the 
	 *			system on which the JVM is running.
	 */

	public static String getHostNameAddress()
	{
		String sRet = null;
		String sName = null;
		String sAddress = null;
		StringBuffer sb = null;

		try
		{
			sb = new StringBuffer(Defines.IO_BUF_SIZE);

			sName = NetUtil.getHostName();
			sAddress = NetUtil.getHostAddress();

			if (StringUtil.isEmpty(sName) == false)
			{
				sb.append(sName);
				sb.append("/");
			}
			sb.append(StringUtil.format(sAddress));

			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			sName = null;
			sAddress = null;
		}
		return sRet;
	}
	
	/**
	 * Returns an url UTF-8 encoded string
	 * 
	 * @param stringToEncode      string to url UTF-8 encode
	 * @param charSet             charater set to use for encoding
	 * @return  an url UTF-8 encoded string.  
	 */
	
	public static String urlEncodeString(final String stringToEncode, final String charSet)
	{
		String rtn = null;
		
		try {
			rtn = URLEncoder.encode(stringToEncode, charSet);
		} catch (UnsupportedEncodingException e) {
			rtn = null;
		}
		
		
		return rtn;
	}
	
	
	/**
	 * Returns an url UTF-8 encoded string
	 * 
	 * @param stringToEncode      string to url UTF-8 encode
	 * @return  an url UTF-8 encoded string.  
	 */
	
	public static String urlEncodeString(final String stringToEncode)
	{
		String rtn = null;
		
		try {
			rtn = URLEncoder.encode(stringToEncode, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			rtn = null;
		}
		
		
		return rtn;
	}

}
