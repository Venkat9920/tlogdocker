/**
 * TransactionInfo.java
 */

package com.gianteagle.is.net;

import java.util.Date;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;

/**
 * Class used to manage standard transaction log information and format.
 * <p>
 * @author	ReichertSF
 */

public final class TransactionInfo
{
	/**
	 * Default constructor.
	 */
	
	public TransactionInfo()
	{
		super();
		
		this.setStartTime();	// Set start time, just in case app doesn't
	}
	
	/**
	 * Destroys the object and releases any resources managed by it.
	 */
	
	public void destroy()
	{
		this.sTransactionId = null;
		this.sAppRequestId = null;
		this.sCorrelationId = null;
		this.sServiceId = null;
		this.sWSGCertId = null;
		this.sBusinessFunctionId = null;
	}
	
	/**
	 * Sets the start time to the current time. This is
	 * used to denote when processing of the request actually began.
	 */
	
	public void setStartTime()
	{
		this.nStartTime = System.currentTimeMillis();
	}
	
	/**
	 * Sets the end time to the current time. This is
	 * used to denote when the operation actually completed.
	 */
	
	public void setEndTime()
	{
		this.nEndTime = System.currentTimeMillis();
	}

	/**
	 * Sets the transaction ID.
	 * <p>
	 * @param	sId		The transaction ID.
	 */
	
	public void setTransactionId(final String sId)
	{
		this.sTransactionId = sId;
	}

	/**
	 * Returns the transaction ID.
	 * <p>
	 * @return		The transaction ID.
	 */
	
	public String getTransactionId()
	{
		return this.sTransactionId;
	}

	/**
	 * Sets the application request ID.
	 * <p>
	 * @param	sId		The application request ID.
	 */
	
	void setAppRequestId(final String sId)
	{
		this.sAppRequestId = sId;
	}

	/**
	 * Returns the application request ID.
	 * <p>
	 * @return		The transaction ID.
	 */
	
	public String getAppRequestId()
	{
		return this.sAppRequestId;
	}

	/**
	 * Sets the correlation ID.
	 * <p>
	 * @param	sId		The correlation ID.
	 */
	
	void setCorrelationId(final String sId)
	{
		this.sCorrelationId = sId;
	}

	/**
	 * Returns the correlation ID.
	 * <p>
	 * @return		The correlation ID.
	 */
	
	public String getCorrelationId()
	{
		return this.sCorrelationId;
	}

	/**
	 * Sets the service ID.
	 * <p>
	 * @param	sId		The service ID.
	 */
	
	void setServiceId(final String sId)
	{
		this.sServiceId = sId;
	}

	/**
	 * Returns the service ID.
	 * <p>
	 * @return		The service ID.
	 */
	
	public String getServiceId()
	{
		return this.sServiceId;
	}

	/**
	 * Sets the Web Service Gateway Certificate ID.
	 * <p>
	 * @param	sId		The Web Service Gateway Certificate ID.
	 */
	
	void setWSGCertId(final String sId)
	{
		this.sWSGCertId = sId;
	}

	/**
	 * Returns the  Web Service Gateway Certificate ID.
	 * <p>
	 * @return		The  Web Service Gateway Certificate ID.
	 */
	
	public String getWSGCertId()
	{
		return this.sWSGCertId;
	}

	/**
	 * Sets the business function ID as AUTH, CAPTURE, etc.
	 * <p>
	 * @param	sId		The business function ID.
	 */
	
	void setBusinessFunctionId(final String sId)
	{
		this.sBusinessFunctionId = sId;
	}

	/**
	 * Returns the business function ID.
	 * <p>
	 * @return		The business function ID.
	 */
	
	public String getBusinessFunctionId()
	{
		return this.sBusinessFunctionId;
	}
	
	/**
	 * Sets the component ID.
	 * <p>
	 * @param	sId		The component ID.
	 */
	
	void setComponentId(final String sId)
	{
		this.sComponentId = sId;
	}

	/**
	 * Returns the component ID.
	 * <p>
	 * @return		The component ID.
	 */
	
	public String getComponentId()
	{
		return this.sComponentId;
	}
	
	/**
	 * Returns a comma delimited string containing all transaction
	 * related values. The fields returned are as follows:
     * <pre>
 	 *  1. Version of the log format
 	 *  2. Timestamp in the format yyyy-mm-ddThh:mm:ss-zzzz
 	 *  3. Transaction ID.
  	 *  4. Application Request Id (x-app-request-id).
 	 *  5. Correlation Id (x-correlation-id).
 	 *  6. Service Id (x-service-id).
 	 *  7. Web Service Gateway Certificate Id (x-wsgcert-id).
 	 *  8. Business function Id.
 	 *  9. Component Id.
	 * 10. Total Time.
     * </pre>
     * @return		A comma delimited string containing all transaction
     * 				related values.
	 */

	@Override
	public String toString()
	{
		String sRet = null;

		StringBuilder sb = null;
		
    	Date dateEnd = null;
    	long nTimeTotal = 0;
    	
    	try
    	{
    		if (this.nEndTime <= 0)
    		{
    			this.setEndTime();
    		}
	    	dateEnd = new Date(this.nEndTime);

	    	nTimeTotal = this.nEndTime - this.nStartTime;
	        
	        sb = new StringBuilder(Defines.IO_BUF_SIZE);

	        sb.append(TransactionInfo.VERSION);
	        sb.append(',');
	        sb.append(DateUtil.getStandardFormatDate(dateEnd));
	        sb.append(',');
	        sb.append(TransactionInfo.format(this.sTransactionId));
	        sb.append(',');
	        sb.append(TransactionInfo.format(this.sAppRequestId));
	        sb.append(',');
        	sb.append(TransactionInfo.format(this.sCorrelationId));
	        sb.append(',');
        	sb.append(TransactionInfo.format(this.sServiceId));
	        sb.append(',');
        	sb.append(TransactionInfo.format(this.sWSGCertId));
	        sb.append(',');
        	sb.append(TransactionInfo.format(this.sBusinessFunctionId));
   	        sb.append(',');
        	sb.append(TransactionInfo.format(this.sComponentId));
   	        sb.append(',');
	        sb.append(nTimeTotal);

	        sRet = sb.toString();
    	}
    	finally
    	{
    		if (sb != null)
    		{
    			sb.setLength(0);
    			sb = null;
    		}
    		dateEnd = null;
    	}
		return sRet;
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Private method used to format a string value for inclusion 
	 * in the timing string. If the string is null, a string of 
	 * length 0 is returned.
	 * <p>
	 * @param	sStr		The string to format.
	 * <p>
	 * @return		The formatted string.
	 */
	
	private static String format(final String sStr)
	{
		return sStr == null ? "" : sStr;
	}

	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private static final String VERSION = "2.0";

	private transient long nStartTime = 0;
	private transient long nEndTime = 0;
	private transient String sTransactionId = null;
	private transient String sAppRequestId = null;
	private transient String sCorrelationId = null;
	private transient String sServiceId = null;
	private transient String sWSGCertId = null;
	private transient String sBusinessFunctionId = null;
	private transient String sComponentId = null;
}
