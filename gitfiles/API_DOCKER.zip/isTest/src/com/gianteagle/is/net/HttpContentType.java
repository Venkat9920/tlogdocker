/**
 * HttpContentType.java
 */

package com.gianteagle.is.net;

/**
 * Enumerated type used to identify the set of valid HTTP
 * <code>content-type</code> header values.
 * <p>
 * @author	ReichertSF
 */

public enum HttpContentType
{
	/**
	 * Defines a <code>content-type</code> of <code>content/unknown</code>.
	 */

	ContentUnknown("content/unknown"),

	/**
	 * Defines a <code>content-type</code> of <code>audio/basic</code>.
	 */

	AudioBasic("audio/basic"),

	/**
	 * Defines a <code>content-type</code> of <code>text/plain</code>.
	 */

	TextPlain("text/plain"),

	/**
	 * Defines a <code>content-type</code> of
	 * <code>application/octet-stream</code>.
	 */

	ApplicationOctetStream("application/octet-stream"),

	/**
	 * Defines a <code>content-type</code> of <code>text/html</code>.
	 */

	TextHtml("text/html"),

	/**
	 * Defines a <code>content-type</code> of <code>application/xml</code>.
	 */

	ApplicationXml("application/xml"),

	/**
	 * Defines a <code>content-type</code> of <code>text/xml</code>.
	 */

	TextXml("text/xml"),

	/**
	 * Defines a <code>content-type</code> of <code>image/gif</code>.
	 */

	ImageGif("image/gif"),

	/**
	 * Defines a <code>content-type</code> of <code>image/png</code>.
	 */

	ImagePng("image/png"),

	/**
	 * Defines a <code>content-type</code> of <code>image/tiff</code>.
	 */

	ImageTiff("image/tiff"), 

	/**
	 * Defines a <code>content-type</code> of <code>image/jpeg</code>.
	 */

	ImageJpeg("image/jpeg"),

	/**
	 * Defines a <code>content-type</code> of 
	 * <code>application/x-www-form-urlencoded</code>.
	 */

	AppFormEncoded("application/x-www-form-urlencoded"),

	/**
	 * Defines a <code>content-type</code> of 
	 * <code>application/postscript</code>.
	 */

	ApplicationPostscript("application/postscript"),

	/**
	 * Defines a <code>content-type</code> of <code>application/x-tar</code>.
	 */

	ApplicationXTar("application/x-tar"),

	/**
	 * Defines a <code>content-type</code> of <code>application/zip</code>.
	 */

	ApplicationZip("application/zip"),

	/**
	 * Defines a <code>content-type</code> of <code>application/pdf</code>.
	 */

	ApplicationPdf("application/pdf"),

	/**
	 * Defines a <code>content-type</code> of <code>audio/x-wav</code>.
	 */

	AudioXWav("audio/x-wav"),

	/**
	 * Defines a <code>content-type</code> of <code>message/http</code>.
     * This is the type generally received as a result of an HTTP TRACE
	 * request.
	 */

	MessageHttp("message/http");

	/**
	 * Constructor given the content type string.
	 * <p>
	 * @param	sContentType		The content type string.
	 */

    HttpContentType(final String sContentType)
	{
		this.sType = sContentType;
	}

	/**
	 * Returns the String representation for the content type.
	 * <p>
	 * @return		A string representing the content type.
	 */

	@Override
	public String toString()
	{
		return this.sType;
	}

	/**
	 * Compares this HttpContentType to the type specified by the string.
	 * Returns <code>true</code> if and only if the argument is not
	 * <code>null</code> and is a <code>String</code> that represents the
	 * same <code>content-type</code> as this object. Case is ignored in
	 * the comparison because case is not significant within the 
	 * <code>content-type</code> of a request, 
	 * <p>
	 * @param	sContentType	The <code>String</code> to compare this 
	 * 							type with.
	 * <p>
	 * @return		Returns <code>true</code> if the content types are
	 *				the same, ignoring case. Otherwise, <code>false</code>
	 * 				is returned.
	 */

	public boolean equals(final String sContentType)
	{
		boolean bRval = false;
	
		if (sContentType != null)
		{
			bRval = this.toString().equalsIgnoreCase(sContentType);
		}
		return bRval;
	}

	/**
	 * Routine that given the content type as a string, returns the
	 * corresponding <code>HttpContentType</code> object. If a match
	 * is not found, <code>HttpContentType.ContentUnknown</code> is
	 * returned.
	 * <p>
	 * @param	sType		String containing the content type.
	 * <p>
	 * @return				The corresponding <code>HttpContentType</code>
	 *						object.
	 */

	public static HttpContentType getType(final String sType)
	{
		HttpContentType contentType = null;

		if (sType != null)
		{
			for (HttpContentType cType : HttpContentType.values())
			{
				if (sType.equals(cType.toString()))
				{
					contentType = cType;
				}
			}
		}
		if (contentType == null)
		{
			contentType = HttpContentType.ContentUnknown;
		}
		return contentType;
	}

	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------

	private String sType = null;

	/**
	 * Test program used to list all of the valid content types.
	 * <p>
	 * @param	args	List of command line args. None are used.
	 */

	public static void main(String[] args)
	{
		System.out.println("HttpContentType List:");

		for (HttpContentType httpContentType : HttpContentType.values())
		{
			System.out.print("  ");
			System.out.print(httpContentType.name());
			System.out.print(" = ");
			System.out.println(httpContentType);
		}
	}
}
