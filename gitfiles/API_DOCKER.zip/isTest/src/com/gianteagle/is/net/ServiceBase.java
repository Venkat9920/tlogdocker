package com.gianteagle.is.net;

import com.gianteagle.is.logging.Logger;
import com.gianteagle.is.logging.Logger.LogLevel;
import com.gianteagle.is.util.*;

import java.util.Properties;

/**
 * Forms the basis for standard services.
 * <p>
 * @author	ReichertSF
 */

public abstract class ServiceBase
{
	/**
	 * Default constructor.
	 */
	
	public ServiceBase()
	{
		super();
	}
	
	/**
	 * Called by the implementing class to initialize the service. This
	 * includes initialization of the logging framework as well as 
	 * initialization of common values, such as the transaction id.
	 * This method MUST be called by the implementing class.
	 */
	
	public final void initService()
	{
		this.initLogging();			// Initialize logging framework.
		
		this.transactionInfo = new TransactionInfo();
			
		this.setTransactionId(UUID.getUUID());
		this.transactionInfo.setTransactionId(this.getTransactionId());
	}

	/**
     * Called by the implementing class to commit all logging operations,
     * destroy the service, and release all resources. This method 
     * MUST be called as follows:
     * <pre>
     *   super.destroyService()
     * </pre>
     */
    
	protected final void destroyService()
	{
		this.commitLogBuffer();
		
		if (this.transactionInfo != null)
		{
			if (this.transactionLogger != null)
			{
				this.transactionLogger.info(this.transactionInfo.toString());
			}
			this.transactionInfo.destroy();
			this.transactionInfo = null;
		}
		this.destroyLogging();
	}

   //----------------------------------------------------------------
    // Protected methods that may be overridden by derived classes.
    //----------------------------------------------------------------
   
    /**
     * Returns whether or not a buffered application log should be used.
     * The default implementation returns <code>false</code>.
     * <p>
     * @return		Whether or not a buffered application log should be used.
     * 				The default implementation returns <code>false</code>.
     */
    
    @SuppressWarnings("static-method")
	protected boolean useBufferedAppLog()
    {
    	return false;
    }
	
    //----------------------------------------------------------------
    // Protected methods that must be implemented by all derived classes.
    //----------------------------------------------------------------
    
    /**
     * Returns a <code>Properties</code> object containing the log subsystem
     * configuration.
     * <p>
     * During the initialization phase, this method is called to initialize
     * the underlying logging subsystem if it has not already been 
     * initialized. The initialization phase will also destroy the 
     * <code>Properties</code> object after it is through with it.
     * <p>
     * @return		The <code>Properties</code> used to configure the
     * 				underlying logging subsystem.
     */
    
    protected abstract Properties getLogConfig();
    
    /**
     * Gets the name of the primary application logger.
     * <p>
     * During the initialization phase, this method is called to setup the
     * primary application logger.
     * <p>
     * @return		The name of the primary application logger.
     */
    
    protected abstract String getAppLogName();
    
    /**
     * Gets the name of the primary error logger.
     * <p>
     * During the initialization phase, this method is called to setup the
     * primary error logger.
     * <p>
     * @return		The name of the primary error logger.
     */
    
    protected abstract String getErrorLogName();
    
    /**
     * Gets the name of the timing logger.
     * <p>
     * During the initialization phase, this method is called to setup the
     * timing logger.
     * <p>
     * @return		The name of the timing logger.
     */
    
    protected abstract String getTimingLogName();

    /**
     * Gets the name of the transaction logger.
     * <p>
     * During the initialization phase, this method is called to setup the
     * transaction logger.
     * <p>
     * @return		The name of the transaction logger.
     */
    
    protected abstract String getTransactionLogName();

    /**
     * Gets the name of the message logger.
     * <p>
     * During the initialization phase, this method is called to setup the
     * message logger.
     * <p>
     * @return		The name of the timing logger.
     */
    
    protected abstract String getMessageLogName();

    //----------------------------------------------------------------
    // Final methods.
    //----------------------------------------------------------------
    
    /**
     * Returns a reference to the primary application logger.
     * <p>
     * @return		A reference to the application logger.
     */
    
    public final Logger getAppLog()
    {
    	return this.appLogger;
    }
    
    /**
	 * Helper method used to log at the info level.
	 * <p>
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logInfo(final String sMethod, final String sMesg)
	{
		this.logInfo(this, sMethod, sMesg);
	}

	/**
	 * Helper method used to log at the info level.
	 * <p>
	 * @param	obj			The object logging the message.
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logInfo(final Object obj, final String sMethod, 
							  final String sMesg)
	{
		if (this.appLogger != null)
		{
			if (this.logBuffer != null)
			{
				if (this.appLogger.isEnabledFor(LogLevel.INFO))
				{
					this.logBuffer.write(
						LogLevel.INFO.toString(), obj, sMethod, sMesg, null);
				}
			}
			else
			{
				this.appLogger.info(
						obj, sMethod, this.formatAppLogMessage(sMesg));
			}
		}
	}

	/**
	 * Helper method used to log debug information.
	 * <p>
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logDebug(final String sMethod, final String sMesg)
	{
		this.logDebug(this, sMethod, sMesg);
	}

	/**
	 * Helper method used to log at the debug level.
	 * <p>
	 * @param	obj			The object logging the message.
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logDebug(final Object obj, final String sMethod, 
							  final String sMesg)
	{
		if (this.appLogger != null)
		{
			if (this.logBuffer != null)
			{
				if (this.appLogger.isEnabledFor(LogLevel.DEBUG))
				{
					this.logBuffer.write(
						LogLevel.DEBUG.toString(), obj, sMethod, sMesg, null);
				}
			}
			else
			{
				this.appLogger.debug(
						obj, sMethod, this.formatAppLogMessage(sMesg));
			}
		}
	}

    /**
	 * Helper method used to log at the warn level.
	 * <p>
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logWarn(final String sMethod, final String sMesg)
	{
		this.logWarn(this, sMethod, sMesg);
	}

	/**
	 * Helper method used to log at the warn level.
	 * <p>
	 * @param	obj			The object logging the message.
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 */
	
	public final void logWarn(final Object obj, final String sMethod, 
							  final String sMesg)
	{
		if (this.appLogger != null)
		{
			if (this.logBuffer != null)
			{
				if (this.appLogger.isEnabledFor(LogLevel.WARN))
				{
					this.logBuffer.write(
						LogLevel.WARN.toString(), obj, sMethod, sMesg, null);
				}
			}
			else
			{
				this.appLogger.warn(
						obj, sMethod, this.formatAppLogMessage(sMesg));
			}
		}
	}

	/**
	 * Helper method used to log errors. The error is written to both 
	 * the application log and, if specified, the error log.
	 * <p>
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 * @param	sErrorInfo	Additional error info.
	 * @param	th			The error that occurred.
	 */
	
	public final void logError(final String sMethod, final String sMesg, 
	 				           final String sErrorInfo, final Throwable th)
	{
		this.logError(this, sMethod, sMesg, sErrorInfo, th);
	}

	/**
	 * Helper method used to log errors. The error is written to both 
	 * the application log and, if specified, the error log.
	 * <p>
	 * @param	obj			The object in which the error occurred.
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 * @param	sErrorInfo	Additional error info.
	 * @param	th			The error that occurred.
	 */
	
	public final void logError(final Object obj, final String sMethod, 
							   final String sMesg, final String sErrorInfo,
							   final Throwable th)
	{
		StringBuilder sb = null;
		String sError = null;
		
		try
		{
			sb = new StringBuilder(Defines.IO_BUF_SIZE);
			
			if (this.appLogger != null)
			{
				// Note: We only log the Throwable message in the application
				// log in order to help manage its size. The full exception
				// is contained in the error log.
				
				sb.append(sMesg);
				
				if (th != null)
				{
					// Remove ending newline, if any, we don't want it.

					sError = StringUtil.rmTrail(th.getMessage(), 
												Util.lineSeparator());

					if (StringUtil.isEmpty(sError) == false)
					{
						sb.append(" [Exception Message: ");
						sb.append(sError);
						sb.append(']');
					}
				}
				if (this.logBuffer != null)
				{
					if (this.appLogger.isEnabledFor(LogLevel.ERROR))
					{
						this.logBuffer.write(
								LogLevel.ERROR.toString(), obj, sMethod, 
								sb.toString(), null);
					}
				}
				else
				{
					this.appLogger.error(obj, sMethod, 
							this.formatAppLogMessage(sb.toString()), null);
				}
			}
			if (this.errorLogger != null)
			{
				this.errorLogger.error(
					this.formatErrorLogEntry(sMesg, sErrorInfo, th));
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			sError = null;
		}
	}

	/**
	 * Helper method used to log fatal errors. The error is written to both 
	 * the application log and, if specified, the error log.
	 * <p>
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 * @param	sErrorInfo	Additional error info.
	 * @param	th			The error that occurred.
	 */
	
	public final void logFatal(final String sMethod, final String sMesg, 
						       final String sErrorInfo, final Throwable th)
	{
		this.logFatal(this, sMethod, sMesg, sErrorInfo, th);
	}
	
	/**
	 * Helper method used to log fatal errors. The error is written to both 
	 * the application log and, if specified, the error log.
	 * <p>
	 * @param	obj			The object where the error occurred.
	 * @param	sMethod		The method logging the message. 
	 * @param	sMesg		The message to log.
	 * @param	sErrorInfo	Additional error info.
	 * @param	th			The error that occurred.
	 */
	
	public final void logFatal(final Object obj, final String sMethod, 
							   final String sMesg, final String sErrorInfo,
							   final Throwable th)
	{
		if (this.appLogger != null)
		{
			if (this.logBuffer != null)
			{
				if (this.appLogger.isEnabledFor(LogLevel.FATAL))
				{
					this.logBuffer.write(
						LogLevel.FATAL.toString(), obj, sMethod, sMesg, th);
				}
			}
			else
			{
				this.appLogger.fatal(obj, sMethod, sMesg, th);
			}
		}
		if (this.errorLogger != null)
		{
			this.errorLogger.fatal(
				this.formatErrorLogEntry(sMesg, sErrorInfo, th));
		}
	}

	/**
	 * Returns whether or not debug logging is enabled.
	 * <p>
	 * @return		<code>true</code> if debug logging is enabled, otherwise
	 * 				<code>false</code>.
	 */
	
	public final boolean isDebugEnabled()
	{
		boolean bRet = false;
		
		if (this.appLogger != null)
		{
			bRet = this.appLogger.isDebugEnabled();
		}
		return bRet;
	}
	
	/**
     * Helper method used to log timing relate information.
     * <p>
     * @param	sEntry		The timing log entry to write.
     */
    
    protected final void logTiming(final String sEntry)
    {
    	if (this.timingLogger != null)
    	{
    		this.timingLogger.info(sEntry);
    	}
    }
    
	/**
	 * Helper method used to log the input message and result message
	 * associated with a request to the message log. 
	 * <p>
	 * @param	sInput			A String containing the input request.
	 * @param	sResult			A String containing the result.
	 */
	
	protected final void logMessage(final String sInput, final String sResult)
	{
		StringBuilder sb = null;

		try
		{
			if (this.messageLogger != null)
			{
				sb = new StringBuilder(Defines.MEM_BUF_SIZE);

				sb.append("MESSAGE PROCESSED");

				if (this.getCorrelationId() != null)
				{
					sb.append(" [ID=");
					sb.append(this.getCorrelationId());
					sb.append("] ");
				}
				sb.append(Util.lineSeparator());

				sb.append("----- Begin Input -----");
				sb.append(Util.lineSeparator());
				if (StringUtil.isEmpty(sInput) == false)
				{
					sb.append(sInput);
					
					if (sInput.endsWith(Util.lineSeparator()) == false)
					{
						sb.append(Util.lineSeparator());
					}
				}
				sb.append("----- End Input -----");
				sb.append(Util.lineSeparator());
				
				sb.append("----- Begin Result -----");
				sb.append(Util.lineSeparator());
				if (StringUtil.isEmpty(sResult) == false)
				{
					sb.append(sResult);
					
					if (sResult.endsWith(Util.lineSeparator()) == false)
					{
						sb.append(Util.lineSeparator());
					}
				}
				sb.append("----- End Result -----");

				this.messageLogger.info(sb.toString());
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}
	
	/**
	 * Sets the transaction ID associated with the service request.
	 * <p>
	 * @param	sId		The service request transaction ID.
	 */
	
	protected final void setTransactionId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setTransactionId(sId);
		}
	}
	
	/**
	 * Returns the transaction ID associated with the service request. 
	 * <p>
	 * @return		The service request transaction ID.
	 */
	
	protected final String getTransactionId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getTransactionId();
	}
	
	/**
	 * Sets the application request ID associated with the service request.
	 * <p>
	 * @param	sId		The application request ID.
	 */
	
	protected final void setAppRequestId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setAppRequestId(sId);
		}
	}
	
	/**
	 * Returns the application request ID associated with the service request. 
	 * <p>
	 * @return		The application request ID.
	 */
	
	protected final String getAppRequestId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getAppRequestId();
	}
	
	/**
	 * Sets the correlation ID associated with the service request.
	 * <p>
	 * @param	sId		The service request correlation ID.
	 */
	
	protected final void setCorrelationId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setCorrelationId(sId);
		}
	}
	
	/**
	 * Returns the correlation ID associated with the service request. 
	 * <p>
	 * @return		The service request correlation ID.
	 */
	
	protected final String getCorrelationId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getCorrelationId();
	}
	
	/**
	 * Sets the service ID associated with the service request.
	 * <p>
	 * @param	sId		The service request service ID.
	 */
	
	protected final void setServiceId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setServiceId(sId);
		}
	}
	
	/**
	 * Returns the service ID associated with the service request. 
	 * <p>
	 * @return		The service request service ID.
	 */
	
	protected final String getServiceId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getServiceId();
	}

	/**
	 * Sets the Web Service Gateway Certificate ID associated with the 
	 * service request.
	 * <p>
	 * @param	sId		The Web Service Gateway Certificate ID.
	 */
	
	protected final void setWSGCertId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setWSGCertId(sId);
		}
	}
	
	/**
	 * Returns the Web Service Gateway Certificate ID associated with the 
	 * service request. 
	 * <p>
	 * @return		The Web Service Gateway Certificate ID.
	 */
	
	protected final String getWSGCertId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getWSGCertId();
	}

	/**
	 * Sets the business function ID associated with the 
	 * service request.
	 * <p>
	 * @param	sId		The business function ID.
	 */
	
	protected final void setBusinessFunctionId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setBusinessFunctionId(sId);
		}
	}
	
	/**
	 * Returns the business function ID associated with the 
	 * service request. 
	 * <p>
	 * @return		The business function ID.
	 */
	
	protected final String getBusinessFunctionId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getBusinessFunctionId();
	}

	/**
	 * Sets the component ID associated with theservice request.
	 * <p>
	 * @param	sId		The component ID.
	 */
	
	protected final void setComponentId(final String sId)
	{
		if (this.transactionInfo != null)
		{
			this.transactionInfo.setComponentId(sId);
		}
	}
	
	/**
	 * Returns the component ID associated with the service request. 
	 * <p>
	 * @return		The component ID.
	 */
	
	protected final String getComponentId()
	{
		return this.transactionInfo == null ? null : 
							this.transactionInfo.getComponentId();
	}

	//----------------------------------------------------------------
    // Private methods.
    //----------------------------------------------------------------
    
	/**
	 * Initializes logging for the service.
	 */
	
	private final void initLogging()
	{
		Properties prop = null;
		String sAppLogName = null;
		String sErrorLogName = null;
		String sTimingLogName = null;
		String sTransactionLogName = null;
		String sMessageLogName = null;

		try
		{
			if (Logger.isConfigured() == false)
			{
				prop = this.getLogConfig();
			
				//Logger.configure(prop);
			}
			sAppLogName = this.getAppLogName();
			
			if (StringUtil.isEmpty(sAppLogName) == false)
			{
				this.appLogger = new Logger(sAppLogName);
			}
			sErrorLogName = this.getErrorLogName();
			
			if (StringUtil.isEmpty(sErrorLogName) == false)
			{
				this.errorLogger = new Logger(sErrorLogName);
			}
			sTimingLogName = this.getTimingLogName();
			
			if (StringUtil.isEmpty(sTimingLogName) == false)
			{
				this.timingLogger = new Logger(sTimingLogName);
			}
			sTransactionLogName = this.getTransactionLogName();
			
			if (StringUtil.isEmpty(sTransactionLogName) == false)
			{
				this.transactionLogger = new Logger(sTransactionLogName);
			}
			sMessageLogName = this.getMessageLogName();
			
			if (StringUtil.isEmpty(sMessageLogName) == false)
			{
				this.messageLogger = new Logger(sMessageLogName);
			}
			if (this.useBufferedAppLog() == true)
			{
				this.logBuffer = new LogBuffer();
			}
		}
		finally
		{
			if (prop != null)
			{
				prop.clear();
				prop = null;
			}
			sAppLogName = null;
			sErrorLogName = null;
			sTimingLogName = null;
			sTransactionLogName = null;
			sMessageLogName = null;
		}
	}

	/**
	 * Commits the application log buffer to the application log if
	 * buffered logging is enabled.
	 */
	
	private final void commitLogBuffer()
	{
		StringBuilder sb = null;
		String sLog = null;
		
		try
		{
			if (this.logBuffer != null)
			{
				sLog = this.logBuffer.toString();
				
				if (StringUtil.isEmpty(sLog) == false)
				{
					sb = new StringBuilder(Defines.MEM_BUF_SIZE);

					sb.append("----- Begin Log Entry ");
					if (this.getCorrelationId() != null)
					{
						sb.append('[');
						sb.append(this.getCorrelationId());
						sb.append("] ");
					}
					sb.append("-----");
					sb.append(Util.lineSeparator());
					sb.append(sLog);
					if (sLog.endsWith(Util.lineSeparator()) == false)
					{
						sb.append(Util.lineSeparator());
					}
					sb.append("----- End Log Entry -----");
					
					this.appLogger.log(sb.toString());
				}
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			sLog = null;
		}
	}
	
	/**
	 * Destroys the logging for the service.
	 */
	
	private final void destroyLogging()
	{
		if (this.logBuffer != null)
		{
			this.logBuffer.destroy();
			this.logBuffer = null;
		}
		if (this.appLogger != null)
		{
			this.appLogger.destroy();
			this.appLogger = null;
		}
		if (this.errorLogger != null)
		{
			this.errorLogger.destroy();
			this.errorLogger = null;
		}
		if (this.timingLogger != null)
		{
			this.timingLogger.destroy();
			this.timingLogger = null;
		}
		if (this.transactionLogger != null)
		{
			this.transactionLogger.destroy();
			this.transactionLogger = null;
		}
		if (this.messageLogger != null)
		{
			this.messageLogger.destroy();
			this.messageLogger = null;
		}
	}

	/**
	 * Private method used to format error log entries.
	 * <p>
	 * @param	sMesg		The message to log.
	 * @param	sErrorInfo	Additional error information.
	 * @param	th			The exception that occurred.
	 * <p>
	 * @return		Returns a formatted string containing the log entry.
	 */
	
	private String formatErrorLogEntry(final String sMesg,
									   final String sErrorInfo,
									   final Throwable th)
	{
		StringBuilder sb = null;
		String sRet = null;
		
		try
		{
			sb = new StringBuilder(Defines.MEM_BUF_SIZE);

			sb.append("----- BEGIN ERROR LOG ENTRY -----");
			sb.append(Util.lineSeparator());

			if (StringUtil.isEmpty(sMesg) == false)
			{
				sb.append("Error Message: ");
				sb.append(sMesg);
					
				if (sMesg.endsWith(Util.lineSeparator()) == false)
				{
					sb.append(Util.lineSeparator());
				}
			}
			sb.append("Correlation ID: ");
			sb.append(StringUtil.format(this.getCorrelationId()));
			sb.append(Util.lineSeparator());
				
			if (StringUtil.isEmpty(sErrorInfo) == false)
			{
				sb.append(sErrorInfo);

				if (sErrorInfo.endsWith(Util.lineSeparator()) == false)
				{
					sb.append(Util.lineSeparator());
				}
			}
			if (th != null)
			{
				sb.append(Util.getStackTrace(th));
			}
			sb.append("----- END ERROR LOG ENTRY -----");

			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Formats the specified application log message by prefixing it
	 * with the correlation ID. This is only called when using non-buffered
	 * logging.
	 * <p>
	 * @param	sMesg		The application log message.
	 * <p>
	 * @return		The application log message with the correlation id.
	 */
	
	private String formatAppLogMessage(final String sMesg)
	{
		String sRet = sMesg;
		
		if (this.getCorrelationId() != null && sMesg != null)
		{
			sRet = '[' + this.getCorrelationId() + "] " + sMesg;
		}
		return sRet;
	}
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private Logger appLogger = null;		// Application Logger
	
	private Logger errorLogger = null;		// Error Logger
	
	private Logger timingLogger = null;		// Timing Logger
	
	private Logger transactionLogger = null;	// Transaction Logger
	
	private Logger messageLogger = null;	// Message (Input/Result) Logger
	
	private LogBuffer logBuffer = null;		// Application log buffer.
	
	private TransactionInfo transactionInfo = null;
}
