/**
 * JaxRpcService.java
 */

package com.gianteagle.is.net;

import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.server.ServiceLifecycle;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.server.ServletEndpointContext;

import com.gianteagle.is.util.StringUtil;

import java.util.Enumeration;
import java.util.Iterator;

/**
 * Class that forms the basis for constructing a JAX-RPC service endpoint.
 * This enables services, such as a JAX-RPC SOAP service to to access life
 * cycle attributes, such as HTTP request information, etc. It also performs
 * common setup and cleanup required for these services and common base
 * functionality.
 * <p> 
 * @author	ReichertSF
 */

public abstract class JaxRpcService 
			extends ServiceBase implements ServiceLifecycle
{
	/**
	 * Default constructor.
	 */

	protected JaxRpcService()
	{
		super();
	}

	/**
	 * Called after a service endpoint is instantiated to initialize
	 * the service.
	 * <p>
	 * @param	context		Endpoint context for the JAX-RPC service endpoint
	 * <p>
	 * @exception	ServiceException		Thrown if an initialization error
	 * 										occurs.
	 */
	
	@Override
	public final void init(final Object context) throws ServiceException
	{
		String sMethod = "init()";
		
		try
		{
			super.initService();		// Allow parent to initialize.
			
			if (context != null)
			{
				this.servletEndpointContext = (ServletEndpointContext)context;
				
				this.logDebug(sMethod, 
						  "Successfully setup ServletEndpointContext.");
			}
			if (this.isDebugEnabled() == true)
			{
				this.logMessageContextProperties();
				this.logHttpRequestHeaders();
			}
			this.setAppRequestId(this.getAppRequestIdHeader());
			
			this.setCorrelationId(this.getCorrelationIdHeader());
			this.setServiceId(this.getServiceIdHeader());
			this.setWSGCertId(this.getWSGCertIdHeader());
		
			this.initJaxRpcService();	// Allow application to initialize.
		}
		finally
		{
			sMethod = null;
		}
	}

	/**
     * JAX-RPC runtime system ends the lifecycle of a service endpoint 
     * instance by invoking the destroy method. The service endpoint releases
     * its resources in the implementation of the destroy method. 
     */
    
	@Override
	public final void destroy()
	{
		this.destroyJaxRpcService();	// Allow application to cleanup.
		
		super.destroyService();			// Allow parent to cleanup.
		
		this.servletEndpointContext = null;
	}

	/**
	 * Returns the IP address of the client/remote system that sent 
	 * the request.
	 * <p>
	 * @return		The IP address of the client/remote system.
	 */

	public final String getRemoteAddress()
	{
		String sRet = null;
		HttpServletRequest req = null;
		
		try
		{
			req = this.getHttpServletRequest();
			
			if (req != null)
			{
				sRet = req.getRemoteAddr();
			}
		}
		finally
		{
			req = null;
		}
		return sRet;
	}

 	/**
	 * Returns the IP address of this service. 
	 * <p>
	 * @return		The IP address of this service.
	 */

	public final String getServiceAddress()
	{
		String sRet = null;
		HttpServletRequest req = null;
		
		try
		{
			req = this.getHttpServletRequest();
			
			if (req != null)
			{
				sRet = req.getLocalAddr();
			}
		}
		finally
		{
			req = null;
		}
		return sRet;
	}

 	/**
	 * Returns the port number used by this service. 
	 * <p>
	 * @return		The port number used by this service.
	 */

	public final int getServicePort()
	{
		int nRet = 0;
		HttpServletRequest req = null;
		
		try
		{
			req = this.getHttpServletRequest();
			
			if (req != null)
			{
				nRet = req.getLocalPort();
			}
		}
		finally
		{
			req = null;
		}
		return nRet;
	}

    /**
     * Returns the value for the specified HTTP request header.
     * <p>
     * @param	sHeader		The header to retrieve the value of.
     * <p>
     * @return		The value of the header.
     */
    
    public final String getHttpRequestHeader(final String sHeader)
    {
    	String sMethod = "getHttpRequestHeader()";
    	
    	String sRet = null;
    	HttpServletRequest req = null;
    	
    	try
    	{
	    	if (sHeader != null)
	    	{
	    		req = this.getHttpServletRequest();
	    			
    			if (req != null)
    			{
    				sRet = req.getHeader(sHeader);
    			}
    			else
    			{
    				this.logWarn(sMethod, "HttpServletRequest is null!");
    			}
	    	}
	    }
    	finally
    	{
    		req = null;
    		sMethod = null;
    	}
    	return sRet;
	}
    
    //----------------------------------------------------------------
    // Protected methods that must be implemented by all derived classes.
    //----------------------------------------------------------------
    
    /**
     * Provides service specific initialization.
     */
    
    protected abstract void initJaxRpcService();
    
    /**
     * Provides service specific cleanup.
     */
    
    protected abstract void destroyJaxRpcService();
    
	//----------------------------------------------------------------
    // Private methods.
    //----------------------------------------------------------------
    
	/**
	 * Returns the value of the <code>x-app-request-id</code> HTTP
	 * header.
	 * <p>
	 * @return		The value of the <code>x-app-request-id</code> HTTP
	 * 				header, or <code>null</code> if it does not exist
	 * 				in the request.
	 */
	
	private final String getAppRequestIdHeader()
	{
		String sRet = this.getHttpRequestHeader(
							StdServiceHeader.APP_REQUEST_ID.toString());
		
		this.logInfo("getAppRequestIdHeader()",
					 StdServiceHeader.APP_REQUEST_ID.toString() + '=' +
					 StringUtil.format(sRet));
					 
		return sRet;
	}

	/**
	 * Returns the value of the <code>x-correlation-id</code> HTTP
	 * header.
	 * <p>
	 * @return		The value of the <code>x-correlation-id</code> HTTP
	 * 				header, or <code>null</code> if it does not exist
	 * 				in the request.
	 */
	
	private final String getCorrelationIdHeader()
	{
		String sRet = this.getHttpRequestHeader(
							StdServiceHeader.CORRELATION_ID.toString());

		this.logInfo("getCorrelationIdHeader()",
					 StdServiceHeader.CORRELATION_ID.toString() + '=' +
					 StringUtil.format(sRet));
					 
		return sRet;
	}

	/**
	 * Returns the value of the <code>x-service-id</code> HTTP
	 * header.
	 * <p>
	 * @return		The value of the <code>x-service-id</code> HTTP
	 * 				header, or <code>null</code> if it does not exist
	 * 				in the request.
	 */
	
	private final String getServiceIdHeader()
	{
		String sRet = this.getHttpRequestHeader(
							StdServiceHeader.SERVICE_ID.toString());

		this.logInfo("getServiceIdHeader()",
					 StdServiceHeader.SERVICE_ID.toString() + '=' +
					 StringUtil.format(sRet));
					 
		return sRet;
	}

	/**
	 * Returns the value of the <code>x-wsgcert-id</code> HTTP
	 * header.
	 * <p>
	 * @return		The value of the <code>x-wsgcert-id</code> HTTP
	 * 				header, or <code>null</code> if it does not exist
	 * 				in the request.
	 */
	
	private final String getWSGCertIdHeader()
	{
		String sRet = this.getHttpRequestHeader(
							StdServiceHeader.WSGCERT_ID.toString());

		this.logInfo("getWSGCertIdHeader()",
					 StdServiceHeader.WSGCERT_ID.toString() + '=' +
					 StringUtil.format(sRet));
					 
		return sRet;
	}

	/**
     * Returns the HttpServletRequest object associated with the service
     * request.
     * <p>
     * @return		The <code>HttpServletRequest</code> object associated
     * 				with the service request. Note that if the HTTP transport
     * 				is not used, this method will return <code>null</code>.
     */

	private final HttpServletRequest getHttpServletRequest()
	{
		String sMethod = "getHttpServletRequest()";
		
		HttpServletRequest req = null;
    	MessageContext messageContext = null;
    	
    	try
    	{
	    	if (this.servletEndpointContext != null)
	    	{
	    		messageContext = 
	    				this.servletEndpointContext.getMessageContext();
	    		
	    		if (messageContext != null)
	    		{
	    			req = (HttpServletRequest)messageContext.getProperty(
	    									"transport.http.servletRequest");
	    		}
	    		else
	    		{
	    			this.logWarn(sMethod, "MessageContext is null!");
	    		}
	    	}
	    	else
	    	{
	    		this.logWarn(sMethod,"ServiceEndpointContext is null!");
	    	}
	    }
    	finally
    	{
    		messageContext = null;
    		sMethod = null;
    	}
    	return req;
	}

	/**
     * Logs the message context properties associated with the service
     */

	private final void logMessageContextProperties()
	{
		String sMethod = "logMessageContextProperties()";
		
    	MessageContext messageContext = null;
    	StringBuilder sb = null;
    	Iterator<?> iter = null;
    	String sProperty = null;
    	
    	try
    	{
			sb = new StringBuilder();
	    				
	    	if (this.servletEndpointContext != null)
	    	{
	    		messageContext = 
	    				this.servletEndpointContext.getMessageContext();
	    		
	    		if (messageContext != null)
	    		{
	    			iter = messageContext.getPropertyNames();
	    			
	    			if (iter != null)
	    			{
	    				while (iter.hasNext())
	    				{
	    					if (sb.length() == 0)
	    					{
	    						sb.append(
	    							"List of MessageContext Properties = ");
	    					}
	    					else
	    					{
	    						sb.append(',');
	    					}
	    					sProperty = (String)iter.next();
	    					
	    					if (sProperty != null)
	    					{
	    						sb.append(sProperty);
	    					}
	    					sProperty = null;
	    				}
	    				if (sb.length() < 1)
	    				{
	    					sb.append(
	    						"List of MessageContext Properties is empty!");
	    				}
	    			}
	    			else
	    			{
	    				sb.append("MessageContext property iterator is null!");
	    			}
	    		}
	    		else
	    		{
	    			sb.append("MessageContext is null!");
	    		}
	    	}
	    	else
	    	{
	    		sb.append("ServiceEndpointContext is null!");
	    	}
   			if (sb.length() > 0)
   			{
   				this.logDebug(sMethod, sb.toString());
   			}
	    }
    	finally
    	{
    		if (sb != null)
    		{
    			sb.setLength(0);
    			sb = null;
    		}
    		iter = null;
    		messageContext = null;
    		sMethod = null;
    	}
	}

	/**
     * Logs the set of HTTP request headers available in this request.
     */
    
    private final void logHttpRequestHeaders()
    {
    	String sMethod = "logHttpRequestHeaders()";
    	
    	HttpServletRequest req = null;
    	StringBuilder sb = null;
    	Enumeration<?> e = null;
    	String sKey = null;
    	
    	try
    	{
    		sb = new StringBuilder();
	    		
    		req = this.getHttpServletRequest();
	    			
   			if (req != null)
   			{
   				e = req.getHeaderNames();
	    				
   				sb.setLength(0);
	    				
   				if (e != null)
   				{
   					while (e.hasMoreElements())
   					{
   						sKey = (String)e.nextElement();
	    						
   						if (sb.length() == 0)
   						{
   							sb.append("List of HTTP Request Headers = ");
   						}
   						else
   						{
   							sb.append(',');
   						}
   						if (sKey != null)
   						{
   							sb.append(sKey);
   						}
   						sKey = null;
   					}
   				}
   				else
   				{
   					sb.append("List of HTTP Request Headers is null!");
   				}
   			}
   			else
   			{
   				sb.append("HttpServletRequest is null!");
   			}
   			if (sb.length() > 0)
   			{
   				this.logDebug(sMethod, sb.toString());
   			}
	    }
    	finally
    	{
    		if (sb != null)
    		{
    			sb.setLength(0);
    			sb = null;
    		}
    		req = null;
    		e = null;
    		sMethod = null;
    	}
	}

	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private ServletEndpointContext servletEndpointContext = null;
}
