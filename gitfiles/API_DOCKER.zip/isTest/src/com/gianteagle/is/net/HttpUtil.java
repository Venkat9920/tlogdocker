/**
 * HttpUtil.java
 */

package com.gianteagle.is.net;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.StringTokenizer;

import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.FileUtil;

/**
 * Collection of utility methods useful when dealing with HTTP requests
 * and responses.
 * <p>
 * @author sr44189
 */

public final class HttpUtil
{
	/**
	 * Private constructor.
	 */
	
	private HttpUtil()
	{
	}

	/**
     * Parses a query string and builds a <code>Hashtable</code> of key-value
     * pairs, where the values are arrays of strings.  The query string
     * should have the form of a string packaged by the GET or POST
     * method.  For example, it should have its key-value pairs
     * delimited by ampersands (<code>&amp;</code>) and its keys separated
	 * from its values by equal signs (<code>=</code>).
     * <p>
     * A key can appear one or more times in the query string. Each time
     * a key appears, its corresponding value is inserted into its string
     * array in the hash table. Keys that appear once in the query string
     * have, in the hash table, a string array of length one as their value.
     * Keys that appear twice have a string array of length two. etc.
     * <p>
	 * When the keys and values are moved into the <code>Hashtable</code>,
	 * any plus signs (<code>+</code>) are returned to spaces and characters
	 * sent in hex notation (<code>%xx</code>) are converted back
	 * to characters.
     * <p>
     * This implementation is based on the deprecated 
     * <code>HttpUtils.parseQueryString()</code> method found in the
     * Servlet API version 2.3.
     * <p>
     * @param	sQuery	Query String to be parsed.
	 * <p>
     * @return		A <code>Hashtable</code> built from the parsed key-value
     * 				pairs, with the values as an array of strings. Returns
     * 				<code>null</code> if the query string is null or empty.
     */

    static public Hashtable<String, String[]> parseQueryString(String sQuery)
	{
    	Hashtable<String, String[]> hFields = null;
    	StringTokenizer st = null;
  		String sFieldValue = null;
   		String sField = null;
   		String sValue = null;
   		String[] arrayCur = null;
   		String[] arrayVal = null;
   		int nEqualSign = 0;
   	
    	try
    	{
    		if (sQuery != null)
    		{
        		hFields = new Hashtable<String, String[]>();
        
        		st = new StringTokenizer(sQuery, "&");
        
        		while (st.hasMoreTokens() == true)
        		{
        			sFieldValue = st.nextToken();		// Get field name/value pair
        
        			nEqualSign = sFieldValue.indexOf("=");
        
        			if (nEqualSign != -1 && nEqualSign > 0)
        			{
        				sField = decode(sFieldValue.substring(0, nEqualSign));
        
        				if ((nEqualSign + 1) < sFieldValue.length())
        				{
        					sValue = decode(sFieldValue.substring(nEqualSign + 1));
        				}
        				else
        				{
        					sValue = "";
        				}
        				if (sField != null && sValue != null)
        				{
        					if (hFields.containsKey(sField) == true)
        					{
        						arrayCur = hFields.get(sField);
        						arrayVal = new String[arrayCur.length + 1];
        						System.arraycopy(arrayCur, 0, arrayVal, 0,
        										 arrayCur.length);
        						arrayVal[arrayCur.length] = sValue;
        						arrayCur = null;
        					}
        					else
        					{
        						arrayVal = new String[1];
        						arrayVal[0] = sValue;
        					}
        					hFields.put(sField, arrayVal);
        					arrayVal = null;
        				}
        			}
        			sField = null;
        			sValue = null;
        			sFieldValue = null;
        		}
        		st = null;
        	}
        }
    	finally
    	{
    		st = null;
    		sFieldValue = null;
    		sField = null;
    		sValue = null;
    		arrayCur = null;
    		arrayVal = null;
    	}
		return hFields;
	}

	/**
	 * Parses FORM data that is posted to the server using the HTTP
	 * POST method and the <code>application/x-www-form-urlencoded</code>
	 * mime type.
	 * <p>
	 * Note: This method does not check the mime type. The user should
	 * check the mime type and make sure that it is of the type
	 * <code>application/x-www-form-urlencoded</code> before calling
	 * this method.
     * <p>
     * This implementation is based on the deprecated 
     * <code>HttpUtils.parsePostData()</code> method found in the
     * Servlet API version 2.3.
	 * <p>
	 * @param	nLen			The maximum amount of data to read.
	 * @param	inputStream		The input stream to read the data from.
	 * <p>
     * @return		A <code>Hashtable</code> built from the parsed key-value
     * 				pairs, with the values as an array of strings. Returns
     * 				<code>null</code> if the input stream is null or empty.
     */

	static public Hashtable<String, String[]>
			parsePostData(final int nLen, final InputStream inputStream)
	{
		Hashtable<String, String[]> hFields = null;
		ByteArrayOutputStream ba = null;
		int nMaxLen = 0;
		
		try
		{
    		if (inputStream != null)
    		{
    			if (nLen <= 0 || nLen > Defines.MEM_BUF_SIZE)
    			{
    				nMaxLen = Defines.MEM_BUF_SIZE;
    			}
    			else
    			{
    				nMaxLen = nLen;
    			}
    			ba = new ByteArrayOutputStream(nMaxLen);
    
   				FileUtil.copy(inputStream, ba, nMaxLen);

   				if (ba.size() > 0)
    			{
    				hFields = parseQueryString(ba.toString());
    			}
    		}
		}
		catch (IOException ignore)
		{
		}
		finally
		{
			if (ba != null)
			{
				try { ba.close(); } catch (Throwable ignore) { }
				ba = null;
			}
		}
		return hFields;
	}

	//--------------------------------------------------------------
	// Private methods.
	//--------------------------------------------------------------

	/**
	 * Decode a query string as follows:
	 * - Change all plus signs (+) to a space.
	 * - Change all %xx values to the appropriate character.
	 *   These are hex values for characters.
	 * <p>
	 * @param	sStr		The query string to decode.
	 * <p>
	 * @return		The decoded query string.
	 * <p>
	 * @exception	IllegalArgumentException	Thrown if a conversion error
	 * 											occurs.
	 */

	static private String decode(String sStr) throws IllegalArgumentException
	{
		String sRet = null;
		StringBuilder sb = null;
		char c;

		try
		{
    		if (sStr != null)
    		{
    			if (sStr.length() > 0)
    			{
    				sb = new StringBuilder(sStr.length());
    
    				for (int i = 0 ; i < sStr.length() ; ++i)
    				{
    					c = sStr.charAt(i);
    
    					switch (c)
    					{
    						case '+':		// Convert plus sign to space
    							sb.append(' ');
    							break;
    
    						case '%':		// Convert hex value to character
    							try
    							{
    								sb.append((char)Integer.parseInt(
    										  sStr.substring(i + 1, i + 3),
    										  16));
    							}
    							catch (NumberFormatException ex)
    							{
    								throw new IllegalArgumentException();
    							}
    							catch (StringIndexOutOfBoundsException ex)
    							{
    								throw new IllegalArgumentException();
    							}
    							i += 2;
    							break;
    
    						default:
    							sb.append(c);
    							break;
    					}
    				}
    				sRet = sb.toString();
    			}
    			else
    			{
    				sRet = sStr;
    			}
    		}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}
}
