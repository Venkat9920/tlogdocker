package com.gianteagle.is.logging;

import java.util.HashMap;
import java.util.Map;

public class LoggerMain {
    public static void main(String[] a) throws InterruptedException {
        com.gianteagle.is.logging.Logger logger = new Logger("IsApplicationLog");
        Logger.configure("C:\\Venkat_INBNG233\\ACE\\ws01\\iib-acetlogprocessor\\isTest\\src\\main\\resources\\log4j2.xml");
        Map<String, String> map = new HashMap<>();
        map.put("testFiled1", "value1");
        map.put("testFiled2", "value2");
        map.put("testFiled3", "value3");
        map.put("testFiled4", "value4");
        Thread.sleep(3000);
        
        logger.info("Hai");
        System.out.println("test");
    }
}
