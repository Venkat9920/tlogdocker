/*
 * CoreLogger.java
 */

package com.gianteagle.is.logging;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;
import org.apache.logging.log4j.ThreadContext;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;

/**
 * Base class used to encapsulate log file handling and logging methods.
 * <p>
 * Why does this class exist? Why don't we just use Log4J directly?
 * Why can't I define my own log levels? etc.
 * <ul>
 *  <li>This class centralizes all dependencies on Log4J rather than scattering 
 *      then about over a multitude of application and system level classes.
 *      </li>
 *  <li>Output to <code>stdout</code> is provided in the event that things
 *      have really gone south and the underlying logger cannot be established.
 *      While this should never be the case in production, it does help in
 *      initial development.
 *      </li>
 *  <li>A well established standard set of log levels can be enforced
 *      to promote uniformity. While this can be said about Log4J, remember
 *      that its authors intentionally left the door open here for 
 *      extension.
 *      </li>
 *  <li>A well defined central logging class is the lynch pin for runtime
 *      modification of the log level via a facility such as JMX.
 *      </li>
 * </ul>
 * @author ReichertSF
 */

public final class Logger
{
	private static final String NULL_LOGGER_NAME =
			"Logger name/category is null!";

	/**
	 * Constructor given the logger name/category.
	 * <p>
	 * @param	sName		The logger name/category.
	 * <p>
	 * @exception	NullPointerException		Thrown if the logger name is
	 * 											<code>null</code>.
	 */

	public Logger(final String sName)
	{
		this.initialize(sName);
	}

	/**
	 * Initializes a <code>CoreLogger</code> object based on the named
	 * resource. The resource must be an XML configuration file.
	 * <p>
	 * @param	url		URL reference to the configuration file.
	 * <p>
	 * @throws	NullPointerException		Thrown if the URL is null.
	 */

	public static void configure(final URL url) throws NullPointerException
	{
		org.apache.logging.log4j.core.config.ConfigurationSource configurationSource = null;

		try
		{
			if (url == null)
			{
				throw new NullPointerException("Configuration URL is null!");
			}
			if (Logger.bInitialized == false)
			{
				synchronized(Logger.class)
				{
					if (Logger.bInitialized == false)
					{
						try (InputStream inputStream = url.openStream())
						{
							configurationSource = new org.apache.logging.log4j.core.config.ConfigurationSource(inputStream);

							org.apache.logging.log4j.core.config.Configurator.initialize(null, configurationSource);
						}
						Logger.bInitialized = true;
					}
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			configurationSource = null;
		}
	}

	/**
	 * Initializes a <code>CoreLogger</code> object based on the named
	 * file. The file must be an XML configuration file.
	 * <p>
	 * @param	sFileName		Name of the configuration file.
	 * <p>
	 * @throws	NullPointerException		Thrown if the file name is null.
	 */

	public static void configure(final String sFileName) throws NullPointerException
	{
		org.apache.logging.log4j.core.config.ConfigurationSource configurationSource = null;

		try
		{
			if (sFileName == null)
			{
				throw new NullPointerException("Configuration URL is null!");
			}
			if (Logger.bInitialized == false)
			{
				synchronized(Logger.class)
				{
					if (Logger.bInitialized == false)
					{
						try (FileInputStream inputStream = new FileInputStream(sFileName))
						{
							configurationSource = new org.apache.logging.log4j.core.config.ConfigurationSource(inputStream);

							org.apache.logging.log4j.core.config.Configurator.initialize(null, configurationSource);
						}
						Logger.bInitialized = true;
					}
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			configurationSource = null;
		}
	}

	/**
	 * Returns whether or not the logging subsystem is initialized.
	 * <p>
	 * @return	<code>true</code> if the logging subsystem is initialized,
	 * 			otherwise <code>false</code>.
	 */

	public static boolean isConfigured()
	{
		return Logger.bInitialized;
	}

	/**
	 * Convert the Log4J log level to a <code>LogLevel</code> value.
	 * <p>
	 * @param	level		The Log4J log level.
	 * <p>
	 * @return		The <code>LogLevel</code>.
	 */

	private static final LogLevel fromLog4JLevel(final org.apache.logging.log4j.Level level)
	{
		LogLevel val = null;

		if (level != null)
		{
			if (level.equals(org.apache.logging.log4j.Level.ALL) ||
					level.equals(org.apache.logging.log4j.Level.DEBUG))
			{
				val = LogLevel.DEBUG;
			}
			else if (level.equals(org.apache.logging.log4j.Level.INFO))
			{
				val = LogLevel.INFO;
			}
			else if (level.equals(org.apache.logging.log4j.Level.WARN))
			{
				val = LogLevel.WARN;
			}
			else if (level.equals(org.apache.logging.log4j.Level.ERROR))
			{
				val = LogLevel.ERROR;
			}
			else if (level.equals(org.apache.logging.log4j.Level.FATAL))
			{
				val = LogLevel.FATAL;
			}
			else if (level.equals(org.apache.logging.log4j.Level.OFF))
			{
				val = LogLevel.OFF;
			}
		}
		return val;
	}

	/**
	 * Convert a <code>LogLevel</code> value to a Log4J log level.
	 * <p>
	 * @param	level		The <code>LogLevel</code> value.
	 * <p>
	 * @return		The Log4J log level.
	 */

	private static final org.apache.logging.log4j.Level toLog4JLevel(final LogLevel level)
	{
		org.apache.logging.log4j.Level val = null;

		if (level != null)
		{
			switch (level)
			{
				case DEBUG:
					val = org.apache.logging.log4j.Level.DEBUG;
					break;
				case INFO:
					val = org.apache.logging.log4j.Level.INFO;
					break;
				case WARN:
					val = org.apache.logging.log4j.Level.WARN;
					break;
				case ERROR:
					val = org.apache.logging.log4j.Level.ERROR;
					break;
				case FATAL:
					val = org.apache.logging.log4j.Level.FATAL;
					break;
				case OFF:
					val = org.apache.logging.log4j.Level.OFF;
					break;

				default:
					break;
			}
		}
		return val;
	}

	/**
	 * Private method used to build a log message from the object,
	 * method name, and message.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * <p>
	 * @return		Returns a String containing the full log message.
	 */

	private static String buildMessage(final Class<?> clazz, final String sMethod,
									   final String sMesg)
	{
		String sRet = null;
		StringBuilder sb = null;

		try
		{
			if (StringUtil.isEmpty(sMesg) == false)
			{
				sb = new StringBuilder(Defines.IO_BUF_SIZE);

				// Tack on the source name followed by the
				// method name -->  source.method()

				if (clazz != null)
				{
					sb.append(clazz.getSimpleName());
				}
				if (StringUtil.isEmpty(sMethod) == false)
				{
					if (sb.length() > 0)
					{
						sb.append('.');
					}
					sb.append(sMethod);
				}
				if (sb.length() > 0)
				{
					sb.append(": ");
				}
				sb.append(sMesg);

				sRet = sb.toString();
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Private method used to spit out debug messages to the
	 * console. Used for troubleshooting this class.
	 * <p>
	 * @param	sMethod		The name of the method to include.
	 * @param	sMesg		The Message to display.
	 */

	@SuppressWarnings("unused")
	private static void debugMesg(final String sMethod, final String sMesg)
	{
		StringBuilder sb = null;
		long nTime = System.currentTimeMillis();

		try
		{
			if (Logger.DEBUGGER == true)
			{
				if (StringUtil.isEmpty(sMesg) == false)
				{
					sb = new StringBuilder(Defines.IO_BUF_SIZE);

					sb.append(DateUtil.formatDate(nTime));
					sb.append(' ');
					sb.append(DateUtil.formatTime(nTime));
					sb.append(' ');
					sb.append(Logger.class.getSimpleName());

					if (StringUtil.isEmpty(sMethod) == false)
					{
						sb.append('.');
						sb.append(sMethod);
					}
					sb.append(": ");
					sb.append(sMesg);

					System.out.println(sb);
				}
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
	}

	/**
	 * Destroy the object and release any resources held by it.
	 */

	public void destroy()
	{
		this.sLoggerName = null;
		this.logger = null;
		this.logLevel = null;
	}

	/**
	 * Returns the current log level.
	 * <p>
	 * @return		The current log level.
	 */

	public LogLevel getLogLevel()
	{
		return this.logLevel;
	}

	/**
	 * Sets the log level to the specified Log4J level.
	 * <p>
	 * @param	level		The Log4J log level.
	 */

	private final void setLogLevel(final org.apache.logging.log4j.Level level)
	{
		this.logLevel = Logger.fromLog4JLevel(level);
	}

	/**
	 * Returns the name of this logger.
	 * <p>
	 * @return		The name of this logger.
	 */

	public String getName()
	{
		String sRet = null;

		if (this.logger != null)
		{
			sRet = this.logger.getName();
		}
		return sRet;
	}

	/**
	 * Method used to log at the <code>DEBUG</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 */

	public void debug(final String sText)
	{
		if (this.isDebugEnabled())
		{
			this.log(LogLevel.DEBUG, sText, null);
		}
	}

	/**
	 * Method used to log at the <code>DEBUG</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void debug(final String sText, final Map<String, String> map)
	{
		if (this.isDebugEnabled())
		{
			if (map != null)
				map.forEach((k, v) -> ThreadContext.put(k,v));
			this.log(LogLevel.DEBUG, sText, null);
		}
	}

	/**
	 * Utility method used to log at the <code>debug</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void debug(final Object obj, final String sMethod,
					  final String sMesg)
	{
		this.debug(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>debug</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void debug(final Object obj, final String sMethod,
					  final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.debug(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>debug</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void debug(final Class<?> clazz, final String sMethod,
					  final String sMesg)
	{
		this.debug(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>debug</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void debug(final Class<?> clazz, final String sMethod,
					  final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.debug(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Method used to log at the <code>INFO</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 */

	public void info(final String sText)
	{
		this.log(LogLevel.INFO, sText, null);
	}

	/**
	 * Method used to log at the <code>INFO</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void info(final String sText, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.INFO, sText, null);
	}

	/**
	 * Utility method used to log at the <code>info</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void info(final Object obj, final String sMethod,
					 final String sMesg)
	{
		this.info(
				Logger.buildMessage(
						(obj == null? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>info</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void info(final Object obj, final String sMethod,
					 final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.info(
				Logger.buildMessage(
						(obj == null? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>info</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void info(final Class<?> clazz, final String sMethod,
					 final String sMesg)
	{
		this.info(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>info</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void info(final Class<?> clazz, final String sMethod,
					 final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.info(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Utility method used to populate ThreadContext fields for ECHO.
	 * <p>
	 * @param	map		    Maps the ThreadContext field for echo
	 */
	public void populateThreadContext(final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
	}

	/**
	 * Method used to log at the <code>WARN</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 */

	public void warn(final String sText)
	{
		this.log(LogLevel.WARN, sText, null);
	}

	/**
	 * Method used to log at the <code>WARN</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final String sText, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.WARN, sText, null);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>WARN</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 */

	public void warn(final String sText, final Throwable throwable)
	{
		this.log(LogLevel.WARN, sText, throwable);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>WARN</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final String sText, final Throwable throwable, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.WARN, sText, throwable);
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void warn(final Object obj, final String sMethod,
					 final String sMesg)
	{
		this.warn(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final Object obj, final String sMethod,
					 final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.warn(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 */

	public void warn(final Class<?> clazz, final String sMethod,
					 final String sMesg)
	{
		this.warn(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final Class<?> clazz, final String sMethod,
					 final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.warn(Logger.buildMessage(clazz, sMethod, sMesg));
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void warn(final Object obj, final String sMethod,
					 final String sMesg, final Throwable th)
	{
		this.warn(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>warn</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final Object obj, final String sMethod,
					 final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.warn(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void warn(final Class<?> clazz, final String sMethod,
					 final String sMesg, final Throwable th)
	{
		this.warn(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void warn(final Class<?> clazz, final String sMethod,
					 final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.warn(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	/**
	 * Method used to log at the <code>ERROR</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 */

	public void error(final String sText)
	{

		this.log(LogLevel.ERROR, sText, null);
	}

	/**
	 * Method used to log at the <code>ERROR</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void error(final String sText, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.ERROR, sText, null);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>ERROR</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 */

	public void error(final String sText, final Throwable throwable)
	{

		this.log(LogLevel.ERROR, sText, throwable);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>ERROR</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void error(final String sText, final Throwable throwable, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.ERROR, sText, throwable);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void error(final Object obj, final String sMethod,
					  final String sMesg, final Throwable th)
	{
		this.error(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void error(final Object obj, final String sMethod,
					  final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.error(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void error(final Class<?> clazz, final String sMethod,
					  final String sMesg, final Throwable th)
	{
		this.error(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>error</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void error(final Class<?> clazz, final String sMethod,
					  final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.error(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	/**
	 * Method used to log at the <code>FATAL</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 */

	public void fatal(final String sText)
	{
		this.log(LogLevel.FATAL, sText, null);
	}

	/**
	 * Method used to log at the <code>FATAL</code> level.
	 * <p>
	 * @param	sText		The information to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void fatal(final String sText, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.FATAL, sText, null);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>FATAL</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 */

	public void fatal(final String sText, final Throwable throwable)
	{
		this.log(LogLevel.WARN, sText, throwable);
	}

	/**
	 * Method used to log the specified exception at the
	 * <code>FATAL</code> level.
	 * <p>
	 * @param	sText		Additional information to log.
	 * @param	throwable	The exception to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void fatal(final String sText, final Throwable throwable, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(LogLevel.WARN, sText, throwable);
	}

	/**
	 * Utility method used to log at the <code>fatal</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void fatal(final Object obj, final String sMethod,
					  final String sMesg, final Throwable th)
	{
		this.fatal(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>fatal</code> level.
	 * <p>
	 * @param	obj			Reference to the object that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void fatal(final Object obj, final String sMethod,
					  final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.fatal(
				Logger.buildMessage(
						(obj == null ? null : obj.getClass()), sMethod, sMesg), th);
	}

	/**
	 * Utility method used to log at the <code>fatal</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 */

	public void fatal(final Class<?> clazz, final String sMethod,
					  final String sMesg, final Throwable th)
	{
		this.fatal(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	//------------------------------------------------------------
	// Private methods.
	//------------------------------------------------------------

	/**
	 * Utility method used to log at the <code>fatal</code> level.
	 * <p>
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * @param	th			The error to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void fatal(final Class<?> clazz, final String sMethod,
					  final String sMesg, final Throwable th, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.fatal(Logger.buildMessage(clazz, sMethod, sMesg), th);
	}

	/**
	 * Lazy log method which logs the specified message at the lowest
	 * log level that is enabled.
	 * <p>
	 * @param	sMesg		The message to log.
	 */

	public void log(final String sMesg)
	{
		this.log(this.logLevel, sMesg, null);
	}

	/**
	 * Lazy log method which logs the specified message at the lowest
	 * log level that is enabled.
	 * <p>
	 * @param	sMesg		The message to log.
	 * @param	map		    Maps the ThreadContext field for echo
	 */

	public void log(final String sMesg, final Map<String, String> map)
	{
		if (map != null)
			map.forEach((k, v) -> ThreadContext.put(k,v));
		this.log(this.logLevel, sMesg, null);
	}

	/**
	 * Returns whether or not the <code>DEBUG</code> level of logging
	 * is enabled.
	 * <p>
	 * @return		<code>true</code> if the logging of <code>DEBUG</code>
	 * 				statements is enabled, otherwise <code>false</code>.
	 */

	public boolean isDebugEnabled()
	{
		boolean bRet = false;

		if (this.logger != null)
		{
			bRet = this.logger.isDebugEnabled();
		}
		return bRet;
	}

	/**
	 * Returns whether or not logging is enabled for the specified level.
	 * <p>
	 * @param	level	The specified log level.
	 * <p>
	 * @return		<code>true</code> if logging is enabled for the specified
	 * 				level, otherwise <code>false</code>
	 */

	public boolean isEnabledFor(final LogLevel level)
	{
		boolean bRet = false;
		org.apache.logging.log4j.Level log4jLevel = null;

		if (level != null)
		{
			log4jLevel = Logger.toLog4JLevel(level);

			if (log4jLevel != null)
			{
				if (this.logger != null)
				{
					bRet = this.logger.isEnabled(log4jLevel);
				}
			}
		}
		return bRet;
	}

	/**
	 * Private method used to establish the logger based on the
	 * logger name.
	 * <p>
	 * @param	sName		The logger name/category.
	 * <p>
	 * @exception	NullPointerException		Thrown if the logger name is
	 * 											<code>null</code>.
	 */

	private void initialize(final String sName)
	{
		if (sName == null)
		{
			throw new NullPointerException(Logger.NULL_LOGGER_NAME);
		}
		this.sLoggerName = sName;

		this.logger = org.apache.logging.log4j.LogManager.getLogger(this.sLoggerName);

		if (this.logger == null)
		{
			throw new NullPointerException(Logger.NULL_LOGGER);
		}
		this.setLogLevel(this.logger.getLevel());
	}

	/**
	 * Performs the Log4J logging operation based on the log level.
	 * <p>
	 * @param	level		The log level.
	 * @param	sText		The message to log.
	 * @param	throwable	The exception to log.
	 */

	private void log(final LogLevel level, final String sText,
					 final Throwable throwable)
	{
		try
		{
			if (level != null && this.logLevel != null)
			{
				if (this.logger != null)
				{
					switch(level)
					{
						case OFF:
							break;

						case DEBUG:
							if (throwable == null)
							{
								this.logger.debug(sText);
							}
							else
							{
								this.logger.debug(sText, throwable);
							}
							break;

						case INFO:
							if (throwable == null)
							{
								this.logger.info(sText);
							}
							else
							{
								this.logger.info(sText, throwable);
							}
							break;

						case WARN:
							if (throwable == null)
							{
								this.logger.warn(sText);
							}
							else
							{
								this.logger.warn(sText, throwable);
							}
							break;

						case ERROR:
							if (throwable == null)
							{
								this.logger.error(sText);
							}
							else
							{
								this.logger.error(sText, throwable);
							}
							break;

						case FATAL:
							if (throwable == null)
							{
								this.logger.fatal(sText);
							}
							else
							{
								this.logger.fatal(sText, throwable);
							}
							break;

						default:
							break;
					}
				}
			}
			else if (throwable == null)
			{
				System.out.println(Logger.class.getName()+": "+StringUtil.format(sText));
			}
			else
			{
				System.out.println(Logger.class.getName()+": "+StringUtil.format(sText) +
						Util.lineSeparator() +
						Util.getStackTrace(throwable));
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}

	//------------------------------------------------------------
	// Private member variables.
	//------------------------------------------------------------

	private static boolean bInitialized = false;

	private static final boolean DEBUGGER = true;

	public enum LogLevel
	{
		/**
		 * Defines the <code>DEBUG</code> log level, which is generally
		 * useful during development and debugging.
		 */

		DEBUG("DEBUG"),

		/**
		 * Defines the <code>INFO</code> log level, which is generally
		 * used to chronicle major application events at a high level.
		 * <code>INFO</code> logging should be sparse as it will generally
		 * always occur.
		 */

		INFO("INFO"),

		/**
		 * Defines the <code>WARN</code> log level, which is used to
		 * identify a potentially harmful situation that does not
		 * prevent an application from continuing to process, but
		 * may cause its outcome to be less than predictable.
		 */

		WARN("WARN"),

		/**
		 * Defines the <code>ERROR</code> log level, which is used to
		 * report errors encountered during execution. Applications
		 * may use this level to report errors that occur during
		 * processing.
		 */

		ERROR("ERROR"),

		/**
		 * Defines the <code>FATAL</code> log level, which is used to
		 * indicate that at fatal system level error has occurred.
		 */

		FATAL("FATAL"),

		/**
		 * Defines that all logging is <code>OFF</code> and that no
		 * messages are logged.
		 */

		OFF("OFF");

		private transient String sDescription = null;

		/**
		 * Private constructor that includes the desription of the level
		 * <p>
		 * @param	sDesc		String containing a description of the level.
		 */

		LogLevel(final String sDesc)
		{
			this.sDescription = sDesc;
		}

		//----------------------------------------------------------------
		// Private member variables.
		//----------------------------------------------------------------

		/**
		 * Returns the descriptive text identifying the level.
		 * <p>
		 * @return		The descriptive text identifying the level.
		 */

		@Override
		public String toString()
		{
			return this.sDescription;
		}
	}

	private static final String NULL_LOGGER = "Logger is null!";

	private transient String sLoggerName = null;
	private transient org.apache.logging.log4j.Logger logger = null;
	private transient LogLevel logLevel = null;
}
