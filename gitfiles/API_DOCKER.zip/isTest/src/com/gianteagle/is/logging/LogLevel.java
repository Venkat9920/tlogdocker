package com.gianteagle.is.logging;

/**
 * Defines the base log levels.
 * <p>
 * @author sr44189
 */

public enum LogLevel
{
    LOG_EMERG(0),
    LOG_ALERT(1),
    LOG_CRIT(2),
    LOG_ERR(3),
    LOG_WARNING(4),
    LOG_NOTICE(5),
    LOG_INFO(6),
    LOG_DEBUG(7);

    LogLevel(final int nValue)
    {
        this.nLevel = nValue;
    }
    
    /**
     * Returns the integer value of this level.
     * <p>
     * @return		The integer value of this level.
     */

    int getValue()
    {
        return this.nLevel;
    }
    
    /**
     * Returns the log level associated with the specified integer value.
     * <p>
     * @param	nVal		The integer value.
     * <p>
     * @return		The LogLevel.
     */
    
    public static LogLevel getLevel(final int nVal)
    {
    	LogLevel retLevel = null;
    	LogLevel[] levels = { LOG_EMERG,
    					   LOG_ALERT,
    					   LOG_CRIT,
    					   LOG_ERR,
    					   LOG_WARNING,
    					   LOG_NOTICE,
    					   LOG_INFO,
    					   LOG_DEBUG };
    	
    	for (int i = 0 ; i < levels.length && retLevel == null ; ++i)
    	{
    		if (levels[i].getValue() == nVal)
    		{
    			retLevel = levels[i];
    		}
    	}
    	if (retLevel == null) retLevel = LOG_ALERT;
    	
    	return retLevel;
    }
    
    //----------------------------------------------------------------
    // Private variables.
    //----------------------------------------------------------------
    
    private int nLevel = 0;
}

