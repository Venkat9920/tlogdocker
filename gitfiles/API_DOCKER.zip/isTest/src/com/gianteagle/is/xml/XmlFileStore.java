package com.gianteagle.is.xml;

import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;

public final class XmlFileStore
{
	private List<Class<?>> classList = null;

	public XmlFileStore()
	{
		this.classList = new ArrayList<Class<?>>();
	}

	public XmlFileStore(final List<Class<?>> zClassList)
	{
		this.classList = zClassList;
	}

	public XmlFileStore(final Class<?>... classes)
	{
		this.classList = new ArrayList<Class<?>>();
		Collections.addAll(this.classList, classes);
	}

	@SuppressWarnings("unchecked")
	public <T> T toObject(final Class<T> clazz, final Reader reader) 
			throws JAXBException
	{
		T result = null;
		JAXBContext context = null;
		Unmarshaller unmarshaller = null;

		try
		{
			if (clazz != null && reader != null)
			{
        		context = this.setJaxbContext(clazz);
        		unmarshaller = context.createUnmarshaller();
        		result = (T) unmarshaller.unmarshal(reader);
			}
		}
		finally
		{
			context = null;
			unmarshaller = null;
		}
		return result;
	}

	public <T> String toXmlString(final T object, final boolean bFormatted) 
			throws JAXBException
	{
		String sRet = null;
		JAXBContext jaxbContext = null;
		StringWriter sw = null;
		Marshaller marshaller = null;
		
		try
		{
			jaxbContext = setJaxbContext(object.getClass());
			sw = new StringWriter();
			marshaller = XmlFileStore.createMarshaller(jaxbContext);
			
			if (bFormatted == true)
			{
				XmlFileStore.setFormatter(marshaller);
			}
			XmlFileStore.marshal(object, sw, marshaller);
			
			sRet = sw.toString();
		}
		finally
		{
			if (sw != null)
			{
				try { sw.close(); } catch (Throwable ignore) { }
				sw = null;
			}
			jaxbContext = null;
			marshaller = null;
		}
		return sRet;
	}

	public <T> void writeXml(final T o, final Writer writer) 
			throws IOException, JAXBException
	{
		String str = null;
		
		try
		{
			if (o != null && writer != null)
			{
				str = this.toXmlString(o, true);
				writer.write(str);
			}
		}
		finally
		{
			str = null;
		}
	}

	private JAXBContext setJaxbContext(final Class<?> clazz) throws JAXBException
	{
		JAXBContext context = null;
		Class<?>[] clazzes = null;
		
		try
		{
    		if (!this.classList.isEmpty())
    		{
    			this.classList.add(clazz);
    			clazzes = new Class[this.classList.size()];
    			this.classList.toArray(clazzes);
    			context = JAXBContext.newInstance();
    		}
    		else
    		{
    			context = JAXBContext.newInstance(clazz);
    		}
		}
		finally
		{
			clazzes = null;
		}
		return context;
	}

	private static Marshaller createMarshaller(final JAXBContext context)
			throws JAXBException
	{
		Marshaller marshaller = null;
		marshaller = context.createMarshaller();
		return marshaller;
	}

	private static void marshal(final Object o, final Writer writer, 
								final Marshaller marshaller)
			throws JAXBException
	{
		marshaller.marshal(o, writer);
	}

	private static void setFormatter(final Marshaller marshaller)
			throws PropertyException
	{
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	}
}
