package com.gianteagle.is.xml;

import java.io.File;

/**
 * Class used to format an XML document contained in a file.
 * <p>
 * @author sr44189
 */

public final class FormatXmlFile
{
	/**
	 * Main application used to format an XML file. Output is directed to
	 * stdout.
	 * <pre>
	 *  java com.gianteagle.is.xml.FormatXmlFile source-file 
	 * </pre>
	 * @param	args		Command line arguments
	 */
	
	public static void main(final String[] args)
	{
		XmlDoc xmlDoc = null;
		File f = null;
		
		try
		{
			if (args.length < 1)
			{
				System.out.print("Usage: ");
				System.out.print(FormatXmlFile.class.getName());
				System.out.print(" xml-source-file");
				System.out.println();
			}
			f = new File(args[0]);
			xmlDoc = new XmlDoc(f);
			System.out.println(xmlDoc);
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
}
