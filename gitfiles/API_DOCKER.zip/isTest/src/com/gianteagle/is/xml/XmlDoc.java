/**
 * DocBase.java
 */

package com.gianteagle.is.xml;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * Base class used to provide core DOM functionality. This class creates
 * the underlying DOM object and manages it through its lifecycle. 
 * <p>
 * @author	ReichertSF
 */

public class XmlDoc
{
	/**
	 * Constructs an empty document.
	 * <p>
	 * @throws		ParserConfigurationException	Thrown if an error occurs
	 * 												creating the document.
	 */
	
	public XmlDoc() throws ParserConfigurationException
	{
		super();
		
		this.createDoc();
	}
	
	/**
	 * Constructs a document from the string which contains a complete XML
	 * document.
	 * <p>
	 * @param	sDoc	String containing the XML document.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the name of the
	 * 											root element is null or
	 * 											empty.
	 */

	public XmlDoc(final String sDoc) 
				throws ParserConfigurationException, IOException,
					SAXException, NullPointerException
	{
		super();
	
		if (StringUtil.isEmpty(sDoc) == true)
		{
			throw new NullPointerException("Document is null!");
		}
		this.createDoc(sDoc);
	}
	
	/**
	 * Constructs a document from the specified file.
	 * <p>
	 * @param	docFile	The file to create the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	public XmlDoc(final File docFile) 
			throws ParserConfigurationException, IOException, SAXException
	{
		super();
		
		this.createDoc(docFile);
	}
	
	/**
	 * Constructs a document from the specified input stream.
	 * <p>
	 * @param	inputStream		The input stream to create the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	public XmlDoc(final InputStream inputStream) 
			throws ParserConfigurationException, IOException, SAXException
	{
		super();
		
		this.createDoc(inputStream);
	}
	
	/**
	 * Sets the document from the specified string.
	 * <p>
	 * @param	sDoc	The String to create the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	public void setDocument(final String sDoc) 
			throws ParserConfigurationException, IOException, SAXException
	{
		this.document = null;
		
		this.createDoc(sDoc);
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */
	
	public void destroy()
	{
		this.document = null;
		this.rootElement = null;
		this.sPublicDoctype = null;
		this.sSystemDoctype = null;
		this.sNamespace = null;
	}

	/**
	 * Sets whether or not the document should be output with additional
	 * whitespace for readability. The default is <code>true</code>.
	 * <p>
	 * @param	bVal		Whether or not to output the document with
	 * 						indentation.
	 */
	
	public final void setIndent(final boolean bVal)
	{
		this.bIndent = bVal;
	}
	
	/**
	 * Sets whether or not this document should be output as a 
	 * standalone document declaration.
	 * <p>
	 * @param	bVal	If <code>true</code>, output as a standalone
	 * 					document declaration, otherwise do not.
	 */
	
	public final void setStandalone(final boolean bVal)
	{
		this.bStandalone = bVal;
	}
	
	/**
	 * Sets the PUBLIC DOCTYPE.
	 * <p>
	 * @param	sType		The PUBLIC DOCTYPE. 
	 */
	
	public final void setPublicDoctype(final String sType)
	{
		this.sPublicDoctype = sType;
	}
	
	/**
	 * Sets the SYSTEM DOCTYPE.
	 * <p>
	 * @param	sType		The SYSTEM DOCTYPE. 
	 */
	
	public final void setSystemDoctype(final String sType)
	{
		this.sSystemDoctype = sType;
	}
	
	/**
	 * Creates an <code>Element</code> of the specified name.
	 * <p>
	 * @param	sTagName	The element name.
	 * <p>
	 * @return		An element with the specified name. 
	 */
	
	public final Element createElement(final String sTagName)
	{
		Element element = null;
		
		if (this.document != null)
		{
			if (StringUtil.isEmpty(sTagName) == false)
			{
				element = this.document.createElement(sTagName);
			}
		}
		return element;
	}
	
	/**
	 * Creates a <code>Text</code> node with the specified value.
	 * <p>
	 * @param	sVal		The value of the node.
	 * <p>
	 * @return	A <code>Text</code> node.
	 */
	
	public final Text createTextNode(final String sVal)
	{
		Text text = null;
		
		if (this.document != null)
		{
			if (StringUtil.isEmpty(sVal) == false)
			{
				text = this.document.createTextNode(sVal);
			}
		}
		return text;
	}
	
	/**
	 * Creates a <code>CDATASection</code> with the specified value.
	 * <p>
	 * @param	sVal		The value of the <code>CDATASection</code>.
	 * <p>
	 * @return	A <code>CDATASection</code> node.
	 */
	
	public final CDATASection createCDATASection(final String sVal)
	{
		CDATASection cdataSection = null;
		
		if (this.document != null)
		{
			if (StringUtil.isEmpty(sVal) == false)
			{
				cdataSection = this.document.createCDATASection(sVal);
			}
		}
		return cdataSection;
	}

	/**
	 * Returns the first <code>Element</code> with the specified name.
	 * <p>
	 * @param	sTagName	The element name.
	 * <p>
	 * @return		The first element with the specified name or 
	 * 				<code>null</code> if it does not exist.
	 */
	
	public final Element getElement(final String sTagName)
	{
		NodeList nodeList = null;
		Element element = null;
		Node node = null;
		int i = 0;
	
		try
		{
			if (this.document != null)
			{
				if (StringUtil.isEmpty(sTagName) == false)
				{
					if (StringUtil.isEmpty(this.sNamespace) == false)
					{
						nodeList = 
							this.document.getElementsByTagNameNS(
													this.sNamespace, sTagName);
					}
					else
					{
						nodeList = this.document.getElementsByTagName(sTagName);
					}
					if (nodeList != null)
					{
						for (i = 0 ; element == null && i < nodeList.getLength() ; ++i)
						{
							node = nodeList.item(i);
							
							if (node != null)
							{
								if (node instanceof Element)
								{
									element = (Element)node;
								}
								node = null;
							}
						}
					}
				}
			}
		}
		finally
		{
			nodeList = null;
		}
		return element;
	}
	
	/**
	 * Returns the set of repeating elements of the specified name contained
	 * in the specified element.
	 * <p>
	 * @param	parent	Element containing the set of repeating elements
	 * 					of the specified name.
	 * @param	sName	The name of the repeating element contained in the node.
	 * <p>
	 * @return		The set of repeating 
	 */
	
	public ArrayList<Element> getElementList(final Element parent, 
											 final String sName)
	{
		ArrayList<Element> elementList = null;
		NodeList nodeList = null;
		Node node = null;
		
		try
		{
			if (parent != null && StringUtil.isEmpty(sName) == false)
			{
				if (StringUtil.isEmpty(this.sNamespace) == false)
				{
					nodeList = 
						parent.getElementsByTagNameNS(this.sNamespace, sName);
				}
				else
				{
					nodeList = parent.getElementsByTagName(sName);
				}
				if (nodeList != null)
				{
					elementList = new ArrayList<Element>(nodeList.getLength());
					
					for (int i = 0 ; i < nodeList.getLength() ; ++i)
					{
						node = nodeList.item(i);
						
						if (node instanceof Element)
						{
							elementList.add((Element)node);
						}
					}
				}
			}
		}
		finally
		{
			nodeList = null;
			node = null;
		}
		return elementList;
	}
	
	/**
	 * Returns the value of the named attribute for the specified element.
	 * <p>
	 * @param	element		The element containing the attribute.
	 * @param	sName		The name of the attribute.
	 * <p>
	 * @return		The value of the named attribute.
	 */
	
	public String getAttribute(final Element element, final String sName)
	{
		String sRet = null;
		Attr attr = null;
		String sAttrName = null;
		
		try
		{
			if (element != null && StringUtil.isEmpty(sName) == false)
			{
				if (StringUtil.isEmpty(this.sNamespace) == false)
				{
					attr = element.getAttributeNodeNS(this.sNamespace, sName);
				}
				else
				{
					attr = element.getAttributeNode(sName);
				}
				if (attr != null)
				{
					sAttrName = attr.getName();
					
					if (StringUtil.isEmpty(sAttrName) == false)
					{
						if (sAttrName.equals(sName))
						{
							sRet = attr.getValue();
						}
					}
				}
			}
		}
		finally
		{
			attr = null;
			sAttrName = null;
		}
		return sRet;
	}
	
	/**
	 * Sets the root element of the document.
	 * <p>
	 * @param	sName		The root element of the document.
	 */
	
	public final void setRoot(final String sName)
	{
		if (this.document != null && StringUtil.isEmpty(sName) == false)
		{
			this.rootElement = this.document.createElement(sName);
			
			this.document.appendChild(this.rootElement);
		}
	}
	
	/**
	 * Adds the specified element to the document.
	 * <p>
	 * @param	sParent		The parent element to add the element to.
	 * @param	element		The <code>Element</code> to add.
	 */

	public final void addElement(final String sParent, final Element element)
	{
		Element parentElement = null;
		
		try
		{
			if (this.document != null)
			{
				if (this.containsElement(element) == false)
				{
					parentElement = this.getElement(sParent);
					
					if (parentElement != null)
					{
						parentElement.appendChild(element);
					}
				}
			}
		}
		finally
		{
			parentElement = null;
		}
	}

	/**
	 * Adds the specified element to the root element.
	 * <p>
	 * @param	element		The <code>Element</code> to add.
	 */
	
	public final void addElement(final Element element)
	{
		if (element != null)
		{
			if (this.rootElement != null)
			{
				this.rootElement.appendChild(element);
			}
		}
	}
	
	/**
	 * Returns whether or not the specified element exists within
	 * the document.
	 * <p>
	 * @param	element		The <code>Element</code> to check for.
	 * <p>
	 * @return	<code>true</code> if the element exists within
	 * 			the document, otherwise <code>false</code>.
	 */
	
	public final boolean containsElement(final Element element)
	{
		boolean bRet = false;
		
		if (this.document != null)
		{
			if (element != null)
			{
				if (this.getElement(element.getTagName()) != null)
				{
					bRet = true;
				}
			}
		}
		return bRet;
	}
	
	/**
	 * Returns a <code>DOMSource</code> object based on the document.
	 * <p>
	 * @return		A new <code>DOMSource</code> based on the document.
	 */
	
	public final DOMSource getDOMSource()
	{
		DOMSource domSource = null;
		
		if (this.document != null)
		{
			domSource = new DOMSource(this.document);
		}
		return domSource;
	}
	
	/**
	 * Sets the Namespace URI to use with the document.
	 * <p>
	 * @param	sURI	The Namespace URI to use.
	 */
	
	public final void setNamespaceURI(final String sURI)
	{
		this.sNamespace = sURI;
	}
	
	/**
	 * Returns the Namespace URI for the document.
	 * <p>
	 * @return		A string containing the Namespace URI.
	 */
	
	public String getNamespaceURI()
	{
		String sRet = null;
		
		if (this.document != null)
		{
			sRet = this.document.getNamespaceURI();
		}
		return sRet;
	}
	
	/**
	 * Sets the default Namespace URI of <code>"*"</code>. This
	 * is used only on retrieval of elements. It is not used on
	 * the creation of elements.
	 */
	
	public final void useDefaultNamespace()
	{
		this.sNamespace = XmlDoc.DEFAULT_NAMESPACE;
	}
	
	/**
	 * Returns a string representation of the document.
	 * <p>
	 * @return	A String containing the entire XML document.
	 */
	
	@Override
	public String toString()
	{
		String sRet = null;
		
		TransformerFactory transformerFactory = null;
		Transformer transformer = null;
		StringWriter sw = null;
		StreamResult streamResult = null;
		DOMSource domSource = null;
		
		try
		{
			if (this.document != null)
			{
				transformerFactory = TransformerFactory.newInstance();
				
				try
				{
					transformerFactory.setAttribute("indent-number", Integer.valueOf(2));
				}
				catch(IllegalArgumentException ignore)
				{
					// If the indent-number attribute is not supported,
					// then ignore and go on.
				}
				
				transformer = transformerFactory.newTransformer();
	
				if (this.bIndent == true)
				{
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				}
				if (this.bStandalone == true)
				{
					transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
				}
				if (this.sPublicDoctype != null)
				{
					transformer.setOutputProperty(
							OutputKeys.DOCTYPE_PUBLIC, this.sPublicDoctype);
				}
				if (this.sSystemDoctype != null)
				{
					transformer.setOutputProperty(
							OutputKeys.DOCTYPE_SYSTEM, this.sSystemDoctype);
				}
				transformer.setOutputProperty(OutputKeys.METHOD, "xml");
				
				// StringWriter to build the output XML in.
				
				sw = new StringWriter(Defines.IO_BUF_SIZE);
				
				// StreamResult wraps the writer for the Transformer.
				
				streamResult = new StreamResult(sw);
				
				// Document source for the transformer to convert to a string.
				
				domSource = this.getDOMSource();
				
				transformer.transform(domSource, streamResult);
				
				sRet = sw.toString();
			}
		}
		catch (TransformerConfigurationException ex)
		{
			// Error occurred in setting up the transformer. 
		}
		catch (TransformerException ex)
		{
			// Error occurred in transforming the document to string.
		}
		finally
		{
			if (sw != null)
			{
				try { sw.close(); } catch (IOException ignore) { }
				sw = null;
			}
			streamResult = null;
			domSource = null;
			transformerFactory = null;
			transformer = null;
		}
		return sRet;
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	/**
	 * Creates the underlying document (DOM object).
	 * <p>
	 * @throws		ParserConfigurationException	Thrown if an error occurs
	 * 												creating the document.
	 */
	
	private final void createDoc() throws ParserConfigurationException
	{
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		
		try
		{
			factory = DocumentBuilderFactory.newInstance();
			
			factory.setNamespaceAware(true);

			builder = factory.newDocumentBuilder();
			
			this.document = builder.newDocument();
		}
		finally
		{
			factory = null;
			builder = null;
		}
	}

	/**
	 * Constructs a document from the specified file.
	 * <p>
	 * @param	docFile		The file to create the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	private final void createDoc(final File docFile) 
			throws ParserConfigurationException, IOException, SAXException
	{
		FileInputStream inputStream = null;
		
		try
		{
			if (docFile == null)
			{
				throw new NullPointerException("File is null!");
			}
			inputStream = new FileInputStream(docFile);
			
			this.createDoc(inputStream);
		}
		finally
		{
			if (inputStream != null)
			{
				try { inputStream.close(); } catch (Throwable ignore) { }
				inputStream = null;
			}
		}
	}
	
	/**
	 * Constructs a document from the specified input stream.
	 * <p>
	 * @param	inputStream		The input stream to parse the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	private final void createDoc(final InputStream inputStream)
			throws ParserConfigurationException, IOException, SAXException
	{
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		
		try
		{
			if (inputStream == null)
			{
				throw new NullPointerException("InputStream is null!");
			}

			factory = DocumentBuilderFactory.newInstance();
			
			factory.setNamespaceAware(true);

			builder = factory.newDocumentBuilder();

			this.document = builder.parse(inputStream);
			
			// This always returns null.
			
			this.sNamespace = this.document.getNamespaceURI();
		}
		finally
		{
			factory = null;
			builder = null;
		}
	}

	/**
	 * Constructs a document from the specified input stream.
	 * <p>
	 * @param	sDoc		The String to parse the document from.
	 * <p>
	 * @throws	ParserConfigurationException	Thrown if an error occurs
	 * 											creating the document.
	 * @throws 	IOException 					Thrown if an I/O error occurs
	 * @throws	SAXException					Throw if an error occurs in
	 * 											parsing the document. 
	 * @throws	NullPointerException			Thrown if the file is
	 * 											<code>null</code>.
	 */

	private final void createDoc(final String sDoc)
			throws ParserConfigurationException, IOException, SAXException
	{
		ByteArrayInputStream ba = null;
		
		try
		{
			if (StringUtil.isEmpty(sDoc) == false)
			{
				ba = new ByteArrayInputStream(sDoc.getBytes());
				
				this.createDoc(ba);
			}
		}
		finally
		{
			if (ba != null)
			{
				try { ba.close(); } catch (Throwable ignore) { }
				ba = null;
			}
		}
	}
	
	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private static final String DEFAULT_NAMESPACE = "*";
	
	private transient Document document = null;
	private transient Element rootElement = null;
	private transient boolean bStandalone = false;
	private transient boolean bIndent = true;
	private transient String sNamespace = null;
	private transient String sSystemDoctype = null;
	private transient String sPublicDoctype = null;
}
