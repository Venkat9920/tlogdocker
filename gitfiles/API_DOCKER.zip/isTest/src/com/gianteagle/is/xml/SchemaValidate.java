/**
 * SchemaValidate.java
 */

package com.gianteagle.is.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.gianteagle.is.util.Util;

/**
 * Class used to validate an XML document against an XML schema.
 * <p>
 * @author	ReichertSF
 */

public final class SchemaValidate
{
	/**
	 * Default constructor.
	 */

	public SchemaValidate()
	{
		this.bValid = true;
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */

	public void destroy()
	{
		if (this.xmlDoc != null)
		{
			this.xmlDoc.destroy();
			this.xmlDoc = null;
		}
		this.domSource = null;
		this.validator = null;
		this.errorHandler = null;
	}

	/**
	 * Sets the schema to use in validation.
	 * <p>
	 * @param	sSchema		The name of the file containing the schema
	 * <p>
	 * @exception	SAXException	Thrown if an error occurrs in initializing
	 *								the schema.
	 */

	public void setSchema(final String sSchema) throws SAXException
	{
		File schemaFile = null;
		SchemaFactory factory = null;
		Schema schema = null;

		try
		{
			if (sSchema == null)
			{
				throw new NullPointerException("Specified schema is null!");
			}
			schemaFile = new File(sSchema);

			// Create instance of W3C XML Schema factory.

			factory = 
				SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		
			schema = factory.newSchema(schemaFile);

			this.validator = schema.newValidator();
		}
		finally
		{
			schemaFile = null;
			factory = null;
			schema = null;
		}
	}

	/**
	 * Sets the XML document to validate against the schema.
	 * <p>
	 * @param	sDoc	The name of the file containing the XML document.
	 * <p>
	 * @exception	ParserConfigurationException	Thrown if an error
	 *												occurs in creating the
	 * 												DOM parser.
	 * @exception	IOException		Thrown if an I/O error occurs.
	 * @exception	SAXException	Thrown if an error occurs in parsing
	 * 								the XML document.
	 */

	public void setDocument(final String sDoc)
			throws ParserConfigurationException, IOException, SAXException
	{
		File docFile = null;
		
		try
		{
			if (sDoc == null)
			{
				throw new NullPointerException("Document file is null!");
			}
			docFile = new File(sDoc);

			this.xmlDoc = new XmlDoc(docFile);
			
			this.domSource = this.xmlDoc.getDOMSource();
		}
		finally
		{
			docFile = null;
		}
	}

	/**
	 * Validates the document using the schema.
	 * <p>
	 * @exception	IOException 	Thrown if an I/O errror occurs.
	 * @exception	SAXException	Thrown if errors occur in the validation.
	 */

	public void validate() throws IOException, SAXException
	{
		if (this.errorHandler == null)
		{
			this.validator.setErrorHandler(new DefaultErrorHandler());
		}
		else
		{
			this.validator.setErrorHandler(this.errorHandler);
		}
		this.validator.validate(this.domSource);
	}
	
	/**
	 * Sets whether or not the document is valid.
	 * <p>
	 * @param	bIsValid	Whether or not the document is valid.
	 */

	public void setValid(final boolean bIsValid)
	{
		this.bValid = bIsValid;
	}

	/**
	 * Returns whether or not the document is valid.
	 * <p>
	 * @return		<code>true</code> if the document is valid, otherwise
	 *				<code>false</code>.
	 */

	public boolean isValid()
	{
		return this.bValid;
	}

	/**
	 * Sets the error handler that will be used in the validation
	 * process. This allows the user to override the default behavior
	 * of displaying the validation errors that occur on the console.
	 * <p>
	 * @param	handler	The <code>ErrorHandler</code> to use.
	 */

	public void setErrorHandler(final ErrorHandler handler)
	{
		this.errorHandler = handler;
	}

	/**
	 * Inner class used to handle errors generated during the 
	 * validation process.
	 * <p>
	 * @author	ReichertSF
	 */

	class DefaultErrorHandler implements ErrorHandler
	{
		/**
		 * Default constructor.
		 */
		
		DefaultErrorHandler()
		{
		}

		/**
	 	 * Receives notification of a warning.
	 	 * <p>
	 	 * @param	ex		The exception that occurred.
	 	 */

		@Override
		public void warning(final SAXParseException ex)
		{
			SchemaValidate.this.setValid(false);

			System.out.print("WARNING: ");
			System.out.print(ex.getMessage());
		}

		/**
	 	 * Receives notification of a error.
	 	 * <p>
	 	 * @param	ex		The exception that occurred.
	 	 */

		@Override
		public void error(final SAXParseException ex)
		{
			SchemaValidate.this.setValid(false);

			System.out.print("ERROR: ");
			System.out.println(ex.getMessage());
		}

		/**
	 	 * Receives notification of a fatal error.
	 	 * <p>
	 	 * @param	ex		The exception that occurred.
	 	 * <p>
	 	 * @exception	SAXException		The exception that occurred
	 	 * 									is re-thrown.
	 	 */

		@Override
		public void fatalError(final SAXParseException ex) throws SAXException
		{
			SchemaValidate.this.setValid(false);

			System.out.print("FATAL ERROR: ");
			System.out.println(ex.getMessage());

			throw ex;
		}
	}
	
	/**
	 * Application used to validate an XML document against a schema.
	 * <p>
	 * Usage: java SchemaValidate schema-file doc-file
	 * <p>
	 * @param	args		Command line arguments. The schema file
	 *						followed by the XML document file.
	 */

	public static void main(final String[] args)
	{
		SchemaValidate schemaValidate = null;

		String sSchema = null;
		String sDoc = null;

		try
		{
			if (args.length < 2)
			{
				System.out.println(USAGE);
			}
			else
			{
				sSchema = args[0];
				sDoc = args[1];

				schemaValidate = new SchemaValidate();

				System.out.print("Initializing schema using ");
				System.out.print(sSchema);
				System.out.println(" ...");

				schemaValidate.setSchema(sSchema);

				System.out.print("Initializing document using ");
				System.out.print(sDoc);
				System.out.println(" ...");
				
				schemaValidate.setDocument(sDoc);

				System.out.println("Validating document...");

				schemaValidate.validate();

				System.out.print("Document is ");

				if (schemaValidate.isValid() == true)
				{
					System.out.println("VALID.");
				}
				else
				{
					System.out.println("INVALID.");
				}
			}
		}
		catch (IOException ex)
		{
			System.out.println("FATAL I/O ERROR!");

			ex.printStackTrace();
		}
		catch (ParserConfigurationException ex)
		{
			System.out.println("FATAL ERROR: Parser Configuration error!");

			ex.printStackTrace();
		}
		catch (SAXException ex)
		{
			System.out.println("FATAL ERROR: Document is INVALID.");

			ex.printStackTrace();
		}
		catch (Throwable th)
		{
			System.out.println("FATAL ERROR: Unknown error occurred!");

			th.printStackTrace();
		}
		finally
		{
			if (schemaValidate != null)
			{
				schemaValidate.destroy();
				schemaValidate = null;
			}
			sSchema = null;
			sDoc = null;
		}
	}

	//----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------

	private Validator validator = null;
	private XmlDoc xmlDoc = null;
	private DOMSource domSource = null;
	private boolean bValid = true;
	private ErrorHandler errorHandler = null;

	private static final String USAGE = 
		"SchemaValidate 1.0.0.0004 12-01-2009" +
		Util.lineSeparator() +
		"Usage: java com.gianteagle.is.xml.SchemaValidate schemaFile documentFile";
}
