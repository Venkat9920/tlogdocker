package com.gianteagle.is.xml;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * XmlDateTime parsing and printing. The methods provide a direct replacement
 * for javax.xml.bind.DatatypeConverter.parseDateTime() and 
 * javax.xml.bind.DatatypeConverter.printDateTime. They are included because
 * Java 9+ deprecates DatatypeConverter.
 * <p>
 * @author sr44189
 */

public final class XmlDateTime
{
	/**
	 * Default constructor.
	 */
	
	private XmlDateTime()
	{
	}

	/**
	 * Converts the string argument into a Calendar value.
	 * <p> 
	 * @param lexicalXSDDateTime
	 *            A string containing lexical representation of xsd:datetime.
	 * <p>
	 * @return A Calendar object represented by the string argument.
	 * <p>
	 * @throws IllegalArgumentException
	 *             if string parameter does not conform to lexical value space
	 *             defined in XML Schema Part 2: Datatypes for xsd:dateTime.
	 */
 
	public static Calendar parseDateTime(final String lexicalXSDDateTime)
	{
		Calendar cal = null;
		
		if (lexicalXSDDateTime != null)
		{
			cal = _parseDateTime(lexicalXSDDateTime);
		}
		return cal;
	}
	
	/**
	 * Converts the current date and time to a string.
	 * <p>
	 * @return A string containing a lexical representation of xsd:dateTime.
	 */
	
	public static String printDateTime()
	{
		return XmlDateTime.printDateTime(System.currentTimeMillis());
	}
	
	/**
	 * Converts the specified time to a string.
	 * <p>
	 * @param	nTime		The time in milliseconds.
	 * <p>
	 * @return A string containing a lexical representation of xsd:dateTime
	 */
	
	public static String printDateTime(final long nTime)
	{
		Date date = (nTime <= 0 ? new Date() : new Date(nTime));
		
		return XmlDateTime.printDateTime(date);
	}
	
	/**
	 * Converts the specified date into a string.
	 * <p>
	 * @param		date		The date to convert.
	 * <p>
	 * @return A string containing a lexical representation of xsd:dateTime
	 */
	
	public static String printDateTime(final Date date)
	{
		String sRet = null;
		
		if (date != null)
		{
			Calendar cal = Calendar.getInstance();
			
			cal.setTime(date);
			
			sRet = XmlDateTime.printDateTime(cal);
		}
		return sRet;
	}
	
	/**
	 * Converts a Calendar value into a string.
	 * <p>
	 * @param val
	 *            A Calendar value
	 * <p>
	 * @return A string containing a lexical representation of xsd:dateTime
	 * <p>
	 * @throws IllegalArgumentException
	 *             if <code>val</code> is null.
	 */
	
 	public static String printDateTime(final Calendar val)
	{
		String sRet = null;
		
		if (val != null)
		{
			sRet = _printDateTime(val);
		}
		return sRet;
	}
	
 	public static void main(final String[] args)
 	{
 		String sXmlDateTime = XmlDateTime.printDateTime();
 		
 		Calendar cal = XmlDateTime.parseDateTime(sXmlDateTime);
 		
 		System.out.println(XmlDateTime.printDateTime(cal));
 	}

 	private static String _printDateTime(Calendar val) 
    {
        return CalendarFormatter.doFormat("%Y-%M-%DT%h:%m:%s%z", val);
    }

	private static GregorianCalendar _parseDateTime(final String s)
	{
		XMLGregorianCalendar xmlGregorianCalendar = null;
		String val = null;
		
		val = s.trim();

		xmlGregorianCalendar = datatypeFactory.newXMLGregorianCalendar(val);
			
		return xmlGregorianCalendar.toGregorianCalendar();
	}

	private static final DatatypeFactory datatypeFactory;
	
	static
	{
		try
		{
			datatypeFactory = DatatypeFactory.newInstance();
		} 
		catch (DatatypeConfigurationException e)
		{
			throw new Error(e);
        }
    }

	private static final class CalendarFormatter
	{

		public static String doFormat(String format, Calendar cal)
				throws IllegalArgumentException
		{
			int fidx = 0;
			int flen = format.length();
			StringBuilder buf = new StringBuilder();

			while (fidx < flen)
			{
				char fch = format.charAt(fidx++);

				if (fch != '%')
				{ // not a meta character
					buf.append(fch);
					continue;
				}

				// seen meta character. we don't do error check against the
				// format
				switch (format.charAt(fidx++))
				{
					case 'Y': // year
						formatYear(cal, buf);
						break;

					case 'M': // month
						formatMonth(cal, buf);
						break;

					case 'D': // days
						formatDays(cal, buf);
						break;

					case 'h': // hours
						formatHours(cal, buf);
						break;

					case 'm': // minutes
						formatMinutes(cal, buf);
						break;

					case 's': // parse seconds.
						formatSeconds(cal, buf);
						break;

					case 'z': // time zone
						formatTimeZone(cal, buf);
						break;

					default:
						// illegal meta character. impossible.
						throw new InternalError();
				}
			}

			return buf.toString();
		}

		private static void formatYear(Calendar cal, StringBuilder buf)
		{
			int year = cal.get(Calendar.YEAR);

			String s;
			if (year <= 0) // negative value
			{
				s = Integer.toString(1 - year);
			} else // positive value
			{
				s = Integer.toString(year);
			}

			while (s.length() < 4)
			{
				s = '0' + s;
			}
			if (year <= 0)
			{
				s = '-' + s;
			}

			buf.append(s);
		}

		private static void formatMonth(Calendar cal, StringBuilder buf)
		{
			formatTwoDigits(cal.get(Calendar.MONTH) + 1, buf);
		}

		private static void formatDays(Calendar cal, StringBuilder buf)
		{
			formatTwoDigits(cal.get(Calendar.DAY_OF_MONTH), buf);
		}

		private static void formatHours(Calendar cal, StringBuilder buf)
		{
			formatTwoDigits(cal.get(Calendar.HOUR_OF_DAY), buf);
		}

		private static void formatMinutes(Calendar cal, StringBuilder buf)
		{
			formatTwoDigits(cal.get(Calendar.MINUTE), buf);
		}

		private static void formatSeconds(Calendar cal, StringBuilder buf)
		{
			formatTwoDigits(cal.get(Calendar.SECOND), buf);
			if (cal.isSet(Calendar.MILLISECOND))
			{ // milliseconds
				int n = cal.get(Calendar.MILLISECOND);
//				if (n != 0)
//				{
					String ms = Integer.toString(n);
					while (ms.length() < 3)
					{
						ms = '0' + ms; // left 0 paddings.
					}
					buf.append('.');
					buf.append(ms);
//				}
			}
		}

		/** formats time zone specifier. */
		private static void formatTimeZone(Calendar cal, StringBuilder buf)
		{
			TimeZone tz = cal.getTimeZone();

			if (tz == null)
			{
				return;
			}

			// otherwise print out normally.
			int offset = tz.getOffset(cal.getTime().getTime());

			if (offset == 0)
			{
				buf.append('Z');
				return;
			}

			if (offset >= 0)
			{
				buf.append('+');
			} else
			{
				buf.append('-');
				offset *= -1;
			}

			offset /= 60 * 1000; // offset is in milli-seconds

			formatTwoDigits(offset / 60, buf);
			buf.append(':');
			formatTwoDigits(offset % 60, buf);
		}

		/** formats Integer into two-character-wide string. */
		private static void formatTwoDigits(int n, StringBuilder buf)
		{
			// n is always non-negative.
			if (n < 10)
			{
				buf.append('0');
			}
			buf.append(n);
		}
	}
}
