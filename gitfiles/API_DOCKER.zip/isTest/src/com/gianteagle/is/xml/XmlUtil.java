/**
 * XmlUtil.java
 */

package com.gianteagle.is.xml;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.gianteagle.is.util.DateUtil;
import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.StringUtil;

/**
 * XML related utility methods.
 * <p>
 * @author	ReichertSF
 */

public final class XmlUtil
{
	/**
	 * Utility method used to "cook" a String object for use in an
	 * XML document. If the string is <code>null</code>, a string of
	 * length 0 is returned in order to simplify display logic.
	 * <p>
	 * @param	sStr		The string to cook.
	 * <p>
	 * @return		The cooked string.
	 */
	
	public static String cook(String sStr)
	{
		String sRet = null;

		if (sStr == null)
		{
			sRet = "";
		}
		else
		{
			sRet = sStr.replaceAll("&", "&amp;");
			sRet = sRet.replaceAll("<", "&lt;");
			sRet = sRet.replaceAll(">", "&gt;");
		}
		return sRet;
	}

	/**
	 * Formats the current date into the standard XML date and time format.
	 * This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getXmlDateTime()
	{
		String sRet = null;
		Date d = null;

		try
		{
			d = new Date();			// Current date and time.

			sRet = XmlUtil.getXmlDateTime(d);
		}
		finally
		{
			d = null;
		}
		return sRet;
	}

	/**
	 * Formats the specified time into the standard XML date and time format.
	 * This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * <p>
	 * @param	nTime	The time value to format.
	 * <p>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getXmlDateTime(final long nTime)
	{
		String sRet = null;
		Date d = null;

		try
		{
			if (nTime >= 0)
			{
				d = new Date(nTime);

				sRet = XmlUtil.getXmlDateTime(d);
			}
		}
		finally
		{
			d = null;
		}
		return sRet;
	}

	/**
	 * Formats a Date object into the standard XML date and timie format.
	 * This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * @param	d		The Date object to format.
	 * <p>
	 * @return			A String containing the formatted date and time.
	 */

	public static String getXmlDateTime(final Date d)
	{
		String sRet = null;
		StringBuffer sbDate = null;
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat timeFormat = null;
		Calendar cal = null;
		String sTime = null;
		int tzOffset = 0;
		int nOffsetTotalMinutes = 0;
		int nOffsetHours = 0;
		int nOffsetMins = 0;

		try
		{
			sbDate = new StringBuffer(Defines.IO_BUF_SIZE);

			dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			sbDate.append(DateUtil.format(d, dateFormat));

			sbDate.append("T");
			
			/**
	 		 * Standard XML "dateTime" format includes a colon in
	 		 * the zone offset. Java doesn't give you a real good 
	 		 * way to do this because it will insert EDT, etc. if
	 		 * it can. So, do it the hard way.
			 */

			timeFormat = new SimpleDateFormat("HH:mm:ss");

			cal = Calendar.getInstance();

			tzOffset =
				cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET);

			tzOffset /= 1000;			// Milliseconds to seconds

			nOffsetTotalMinutes = Math.abs(tzOffset) / 60;
			nOffsetHours = nOffsetTotalMinutes / 60;
			nOffsetMins = nOffsetTotalMinutes % 60;

			sTime = DateUtil.format(d, timeFormat);

			sbDate.append(sTime);

			sbDate.append(tzOffset < 0 ? "-" : "+");
				
			sbDate.append(
					StringUtil.rightJustify(
						Integer.toString(nOffsetHours), 2, '0'));

			sbDate.append(':');
				
			sbDate.append(
					StringUtil.rightJustify(
						Integer.toString(nOffsetMins), 2, '0'));

			sRet = sbDate.toString();
		}
		finally
		{
			if (sbDate != null)
			{
				sbDate.setLength(0);
				sbDate = null;
			}
			dateFormat = null;
			timeFormat = null;
			cal = null;
			sTime = null;
		}
		return sRet;
	}

	/**
	 * Converts a JAXB annotated object to XML.
	 * <p>
	 * @param	object		The object to convert to XML.
	 * @param	clazz		The class representing the object.
	 * <p>
	 * @return		A string containing the JAXB annotated object.
	 * <p>
	 * @throws JAXBException	Thrown if a JAXB error occurs in converting 
	 * 							the object. 
	 * @throws IOException 		Thrown if an I/O error occurs in converting
	 * 							the object.
	 */

	public static String convertToXml(final Object object, final Class<?> clazz) 
			throws JAXBException, IOException 
	{
		String sRet = null;
		JAXBContext jaxbContect = null;
		Marshaller marshaller = null;
		StringWriter sw = null;
		
		try
		{
			jaxbContect = JAXBContext.newInstance(clazz);
			marshaller = jaxbContect.createMarshaller();
			
			sw = new StringWriter();

			marshaller.marshal(object, sw);
			sRet = sw.toString();
		} 
		finally
		{
			if (sw != null)
			{
				sw.close();
				sw = null;
			}
			jaxbContect = null;
			marshaller = null;
		}
		return sRet;
	}
}
