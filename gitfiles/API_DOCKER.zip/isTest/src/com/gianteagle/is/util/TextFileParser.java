/**
 *  TextFileParser.java
 */

package com.gianteagle.is.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Provides basic text file parsing. Support includes opening and
 * closing the specified text file as well as retrieving lines of
 * text from the file. Provisions are also made for skipping blank
 * lines and comment lines, as well as for a line continuation
 * character.
 * <p>
 * @author ReichertSF
 */

public class TextFileParser
{
	/**
	 * Default Constructor.
	 */

	public TextFileParser()
	{
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 * The object is essentially unusable after this call.
	 */
	
	public void destroy()
	{
		this.close();

		this.sCommentId = null;
		this.sContinuation = null;
		this.fileURL = null;
	}
	
	/**
	 * Constructor which sets the name of the text file to parse.
	 * <p>
	 * @param	sName	Name of the text file to read and parse.
	 */

	public TextFileParser(String sName)
	{
		setFileName(sName);
	}

	/**
	 *  Constructor which sets the URL associated with the text file
     *  to parse.
	 *  <p>
	 *  @param	url     A URL reference to the text file to read
     *                  and parse.
	 */

	public TextFileParser(URL url)
	{
		setFileURL(url);
	}

	/**
	 * Sets the name of the text file to read and parse.
	 * <p>
	 * @param	sName	Name of the text file to read and parse.
	 */
	
	public void setFileName(String sName)
	{
		this.sTextFile = sName;
	}

	/**
	 *  Sets the URL URL associated with the text file to read
     *  and parse.
	 *  <p>
	 *  @param	url     A URL reference to the text file to read
     *                  and parse.
	 */
	
	public void setFileURL(URL url)
	{
        this.fileURL = url;
	}

	/**
	 * Sets the string used to identify a comment.
	 * <p>
	 * @param	sComment	String which identifies a comment.
	 */

	public void setCommentId(String sComment)
	{
		this.sCommentId = sComment;
	}

	/**
	 * Sets the string used to indicate the line of text is continued
	 * on the next line.
	 * <p>
	 * @param	sContinue	String which identifies continuation.
	 */

	public void setContinuation(String sContinue)
	{
		this.sContinuation = sContinue;
	}

	/**
	 * Sets whether or not to ignore blank lines when parsing the file.
	 * <p>
	 * @param	bIgnore		If <code>true</code>, blank lines are ignored
	 *                      (skipped) when retrieving lines of text from
	 *                      the file. If <code>false</code>, the blank lines
	 *                      are returned.
	 */

	public void ignoreBlankLines(boolean bIgnore)
	{
		this.bIgnoreBlankLines = bIgnore;
	}

	/**
	 *  Sets whether or not to ignore comment lines when parsing the file.
     *  The default state of this property is <b>true</b>.
	 * <p>
	 * @param	bIgnore		If <code>true</code>, lines that <em>begin</em> with
     *                      the comment &quot;tag&quot; character(s) specified
     *                      with the {@link #setCommentId setCommentId}
     *                      method, are ignored (skipped) when retrieving
     *                      lines of text from the file. If <code>false</code>,
     *                      no leading comment tag processing is performed
     *                      and the line is returned intact.
	 */

	public void ignoreCommentLines(boolean bIgnore)
	{
		this.bIgnoreCommentLines = bIgnore;
	}

	/**
	 *  Sets whether or not to ignore <em>trailing</em> comments
     *  when parsing the file. The default state of this property is
     *  <b>false</b>. When set to true, any characters that occur in
     *  a line after the first occurence of a comment tag character,
     *  regardless of the position within the line of the comment
     *  tag character, are discarded, including the comment tag
     *  character.
	 *  <p>
	 *  @param	bIgnore		If <code>true</code>, any characters in a line
     *                      that appear after the comment &quot;tag&quot;
     *                      character(s) specified with the
     *                      {@link #setCommentId setCommentId}
     *                      method, including the tag character(s), are 
     *                      ignored (skipped) when retrieving lines of text
     *                      from the file. If <code>false</code>, no trailing
     *                      comment tag processing is performed and the
     *                      line is returned intact.
	 */

	public void ignoreTrailingComments(boolean bIgnore)
	{
		this.bIgnoreTrailingComments = bIgnore;
	}

	/**
	 * Open the file for reading an parsing.
	 * <p>
	 * @return		Returns <code>true</code> if the file is successfully
	 * 				opened, or <code>false</code> if it is not.
	 */

	public boolean open()
	{
		boolean bStatus = false;

		if (this.sTextFile != null || this.fileURL != null)
		{
			try
			{
                if (this.fileURL == null)
                {
    				this.inFileReader = new FileReader(this.sTextFile);
    				this.inBuffer = new BufferedReader(this.inFileReader);
    				bStatus = true;
                }
                else if (!StringUtil.isEmpty(this.fileURL.getFile()))
                {
                    this.inStream = this.fileURL.openStream();
                    this.inStreamReader = new InputStreamReader(this.inStream);
                    this.inBuffer = new BufferedReader(this.inStreamReader);
    				bStatus = true;
                }
			}
			catch (IOException ignore)
			{
				//---------------------------------------------------
				// File not found is ignored because the default
				// return value is "false", indicating the file could
				// not be opened.
				//---------------------------------------------------
			}
		}
		return bStatus;
	}
		
	/**
	 * Close the file.
	 */

	public void close()
	{
		if (this.inBuffer != null)
		{
			try { this.inBuffer.close(); } catch (IOException ignore) {}
			this.inBuffer = null;
		}
		if (this.inFileReader != null)
		{
			try { this.inFileReader.close(); } catch (IOException ignore) {}
			this.inFileReader = null;
		}
        if (this.inStreamReader != null)
        {
			try { this.inStreamReader.close(); } catch (IOException ignore) {}
			this.inStreamReader = null;
        }
        if (this.inStream != null)
        {
			try { this.inStream.close(); } catch (IOException ignore) {}
			this.inStream = null;
        }
	}

	/**
	 * Returns the next string of text from the file.
	 * <p>
	 * @return		A String object containing the next string from
	 * 				the file. Returns <b>null</b> if the file contains
	 *              no more strings.
	 */

    public String nextString()
    {
		String sText = null;
		String sRet = null;
		StringBuilder sb = null;
		boolean bDone = false;
		int ofs;

		try
		{
			sb = new StringBuilder();
			
			if (this.inBuffer != null)
			{
				while (bDone == false)
				{
					sText = this.inBuffer.readLine();

					if (sText == null)
					{
						bDone = true;
					}
					else
					{
						sText = sText.trim();

						if (this.sCommentId != null)
						{
							ofs = sText.indexOf(this.sCommentId);

							if (ofs == 0 && this.bIgnoreCommentLines == true)
							{
								sText = "";
							}
							else if (ofs > 0 && this.bIgnoreTrailingComments == true)
							{
								sText = sText.substring(0, ofs - 1);
								sText = sText.trim();
							}
						}
						if (sText != null && sText.length() > 0)
						{
							if (this.sContinuation == null)
							{
								bDone = true;
							}
							else if (sText.endsWith(this.sContinuation) == true)
							{
								if (sText.equals(this.sContinuation) == true)
								{
									sText = "";
								}
								else
								{
									sText = sText.substring(0, 
										sText.length() - this.sContinuation.length() - 1);
									sText = sText.trim();
								}
							}
							else
							{
								bDone = true;
							}
						}
						if (sText != null && sText.length() > 0)
						{
							if (sb.length() > 0)
							{
								sb.append(' ');
							}
							sb.append(sText);
						}
					}
				}
			}
			sRet = (sb.length() > 0 ? sb.toString() : null);
		}
		catch (IOException ex)
		{
			// Exception reading file. Act as if end of file.
			
			sRet = null;
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			sText = null;
		}
		return sRet;
	}

	/**
	 * Returns a String object that includes details (debug info)
	 * about the object.
	 *<p>
	 * @return					A String object containing details
	 * 							about the object.
	 */

	@Override
	public String toString()
	{
		StringBuffer sInfo = new StringBuffer();

		sInfo.append(this.getClass() + ": ");
		sInfo.append("FileName = ");
		sInfo.append(StringUtil.format(this.sTextFile));
		sInfo.append("URL = ");
		sInfo.append(this.fileURL == null ? "<null>" : this.fileURL.toString());
		sInfo.append(", IgnoreBlankLines = ");
		sInfo.append(this.bIgnoreBlankLines);
		sInfo.append(", tbIgnoreCommentLines = ");
		sInfo.append(this.bIgnoreCommentLines);
		sInfo.append(", bIgnoreTrailingComments = ");
		sInfo.append(this.bIgnoreTrailingComments);
		sInfo.append(", CommentId = ");
		sInfo.append(StringUtil.format(this.sCommentId));
		sInfo.append(", Continuation = ");
		sInfo.append(StringUtil.format(this.sContinuation));
		
		return sInfo.toString();
	}

    //---------------------------------------------------------------
    // Private member variables.
    //---------------------------------------------------------------

	private String sTextFile = null;
	private FileReader inFileReader = null;
	private BufferedReader inBuffer = null;
	private boolean bIgnoreBlankLines = false;
    private boolean bIgnoreCommentLines = true;
    private boolean bIgnoreTrailingComments = false;
	private String sCommentId = null;
	private String sContinuation = null;
    
    private URL fileURL = null;
    private InputStreamReader inStreamReader = null;
    private InputStream inStream = null;
}
