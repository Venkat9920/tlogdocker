/**
 *  Base64Encode.java
 */

package com.gianteagle.is.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gianteagle.is.util.StringUtil;

/**
 * @deprecated		Replace with java.xml.bind.DatatypeConverter.
 * <p>
 *  Provides methods to encode data using BASE64 Content Transfer
 *  Encoding as initially specified in RFC 1521. This RFC is part
 *  of the MIME specification as published by the Internet Engineering
 *  Task Force (IETF).
 *  <p>
 *  The companion class {@link com.gianteagle.is.util.Base64Decode} provides
 *  methods to decode data encoded to this standard. The encode and
 *  decode logic is separated into two classes as an efficiency
 *  measure; to avoid encode operations carrying decode logic
 *  overhead as well as the converse. 
 *  <p>
 *  <b>Important Notes:</b>
 *  <ul>
 *  <li>Unlike some other encoding schemes, there is nothing in
 *  this encoding that expressly indicates where a buffer starts
 *  or ends. This means that the encoded text will simply start
 *  with the first line of encoded text and end with the last line
 *  of encoded text.</li>
 *  
 *  <li>As further clarification of the above, the Base64
 *  encode/decode classes deal only with encoding and decoding
 *  <em>data</em>; no attempt is made to generate and / or interpret
 *  MIME headers, etc.</li>
 *  
 *  <li>Each (full) line of encoded data is, by design, terminated
 *  with a CRLF sequence, rather than a platform-dependent line
 *  separator sequence. This is is an attempt to adhere closely
 *  to the specification rather than a &quot;portability
 *  violation&quot;. Decode logic is tolerant of data encoded
 *  with less strict implementations.</li>
 *
 *  <li>The referenced RFC 1521 was &quot;obsoleted&quot; by
 *  RFCs 2045, 2046, 2047, 2048, and 2049 in 1996. RFC 2045 contains
 *  the operative references to BASE64. This implementation adheres,
 *  to the best of the author's knowledge, to RFC 2045 as well.</li>
 *  </ul> 
 *  <p>
 *  <b>BASE64 Content Transfer Encoding Definition</b>
 *  <p>
 *  <em>The following, liberaly excerpted from the RFC, provides a
 *  fairly through discussion of the Base64 encoding scheme. Refer
 *  to one of the standards repositories (such as
 *  <a href="http://sunsite.dk/RFC/rfc/rfc2045.html">
 *  sunsite.dk/RFC/rfc/rfc2045.html</a>) for further detail.</em>
 *  <p>
 *  The encoding process represents 24-bit groups of input bits as
 *  output strings of 4 encoded characters.  Proceeding from left to
 *  right, a 24-bit input group is formed by concatenating 3 8bit input
 *  groups. These 24 bits are then treated as 4 concatenated 6-bit
 *  groups, each of which is translated into a single digit in the
 *  base64 alphabet. When encoding a bit stream via the base64 encoding,
 *  the bit stream must be presumed to be ordered with the
 *  most-significant-bit first. That is, the first bit in the stream
 *  will be the high-order bit in the first 8bit byte, and the eighth
 *  bit will be the low-order bit in the first 8bit byte, and so on.
 *  <p>
 *  Each 6-bit group is used as an index into an array of 64 printable
 *  characters.  The character referenced by the index is placed in the
 *  output string.  These characters, identified below, are selected so
 *  as to be universally representable.
 *  <pre>
 *  Value Encoding  Value Encoding  Value Encoding  Value Encoding
 *       0 A            17 R            34 i            51 z
 *       1 B            18 S            35 j            52 0
 *       2 C            19 T            36 k            53 1
 *       3 D            20 U            37 l            54 2
 *       4 E            21 V            38 m            55 3
 *       5 F            22 W            39 n            56 4
 *       6 G            23 X            40 o            57 5
 *       7 H            24 Y            41 p            58 6
 *       8 I            25 Z            42 q            59 7
 *       9 J            26 a            43 r            60 8
 *      10 K            27 b            44 s            61 9
 *      11 L            28 c            45 t            62 +
 *      12 M            29 d            46 u            63 /
 *      13 N            30 e            47 v
 *      14 O            31 f            48 w         (pad) =
 *      15 P            32 g            49 x
 *      16 Q            33 h            50 y
 *  </pre>    
 *
 *  The encoded output stream must be represented in lines of no more
 *  than 76 characters each. Special processing is performed if fewer
 *  than 24 bits are available at the end of the data being encoded.  A
 *  full encoding quantum is always completed at the end of a body.
 *  When fewer than 24 input bits are available in an input group, zero
 *  bits are added (on the right) to form an integral number of 6-bit
 *  groups.  Padding at the end of the data is performed using the "="
 *  character.  Since all base64 input is an integral number of octets,
 *  only the following cases can arise: (1) the final quantum of
 *  encoding input is an integral multiple of 24 bits; here, the final
 *  unit of encoded output will be an integral multiple of 4 characters
 *  with no "=" padding, (2) the final quantum of encoding input is
 *  exactly 8 bits; here, the final unit of encoded output will be two
 *  characters followed by two "=" padding characters, or (3) the final
 *  quantum of encoding input is exactly 16 bits; here, the final unit
 *  of encoded output will be three characters followed by one "="
 *  padding character.
 *  <p>
 *  Any characters outside of the base64 alphabet are to be ignored in
 *  base64-encoded data.       
 */

@Deprecated
public final class Base64Encode extends Base64Common
{ 
    /**
     *  Default class constructor.
     */
     
    public Base64Encode()
    {
        super();
    }

    /**
     *  Read the entire contents of the argument InputStream, encode
     *  it using BASE64 CTE (Content Transfer Encoding) encoding and
     *  write the encoded data to the argument output stream.
     *  <p>
     *  @param  inStream    Reference to an InputStream class object
     *                      from which data to be encoded is read.
     *  @param  outStream   Reference to an OutputStream class object
     *                      to which encoded data is to be written.
     *  <p>
     *  @throws IllegalArgumentException  If either of the argument
     *                          stream references is null.
     *  @throws IOException If an internal processing or stream related
     *                      error occurs.    
     */
     
    public void encode(InputStream inStream, OutputStream outStream)
        throws IOException, IllegalArgumentException
    {
        if (inStream == null)
            throw new IllegalArgumentException("InputStream arg is null.");
        else if (outStream == null)
            throw new IllegalArgumentException("OutputStream arg is null.");
            
        byte[] workBuff = new byte[BytesPerLineEncode];

        int nBytesRead = 0;

        do
        {
            nBytesRead = readBytes(inStream, workBuff, 0,
                            BytesPerLineEncode);
                            
            for(int i = 0; i < nBytesRead; i += BytesPerGroupEncode)
            {
                Base64Encode.encodeBlock(outStream, workBuff, i, 
                    (i+BytesPerGroupEncode) <= nBytesRead ? BytesPerGroupEncode : nBytesRead - i);                 
            }
            if (nBytesRead >= BytesPerLineEncode)
            {
                outStream.write(CTENewLine, 0, CTENewLine.length);
            }    
        } while (nBytesRead > 0);

        outStream.flush();        
        workBuff = null;
    }

    /**
     *  Encode the contents of the argument String object using
     *  BASE64 CTE (Content Transfer Encoding) encoding and return
     *  the encoded data as a String.
     *  <p>
     *  @param  str Reference to String object containing data to
     *              encode.
     *  <p>
     *  @return A String object containing the encoded data.
     *  <p>
     *  @throws IllegalArgumentException  If the String argument is null
     *                                  or empty.
     *  @throws IOException If an internal processing error occurs.    
     */
     
    public String encode(String str)
        throws IllegalArgumentException, IOException
    {
        String sRtnStr = null;

        if (StringUtil.isEmpty(str))
            throw new IllegalArgumentException("Argument String is null or empty.");

        ByteArrayOutputStream outBAStream = new ByteArrayOutputStream();
        ByteArrayInputStream inBAStream = 
            new ByteArrayInputStream(str.getBytes());
        encode(inBAStream, outBAStream);
        sRtnStr = outBAStream.toString();
        outBAStream.close();
        outBAStream = null;
        inBAStream.close();
        inBAStream = null;

        return (sRtnStr);
    }            

    /**
	 * Simple application that Base64 encodes the contents of a file.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to encode,
	 *					and the second is the name of the output
	 *					file that the compressed data is to be 
	 *					written to. If the output file is omitted,
	 *					the output is written to System.out.
	 */

	public static void main(String[] args)
	{
		Base64Encode base64Encode = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try
		{
			if (args.length < 1)
			{
				System.out.println(
					"Usage:  Base64Encode inputfile [outputfile]");
			}
			else
			{
				base64Encode = new Base64Encode();
				
				fis = new FileInputStream(args[0]);
				
				if (args.length > 1)
				{
					fos = new FileOutputStream(args[1]);
				}
				base64Encode.encode(fis, (fos == null ? System.out : fos));
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (fis != null)
			{
				try { fis.close(); } catch (Throwable ignore) { }
				fis = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch (Throwable ignore) { }
				fos = null;
			}
			base64Encode = null;
		}
	}

    //---------------------------------------------------------------
    // Private Methods
    //---------------------------------------------------------------

    /**
     *  BASE64 encode the next 1 - 3 bytes of data in the argument
     *  byte array, beginning at the given offset, and write the
     *  encoded octet(s) to the argument OutputStream.
     *  <p>
     *  @param  outStream   Reference to an OutputStream class object
     *                      to which encoded data is to be written.
     *  @param  data    Reference to a byte array containing at least
     *                  the given (len argument) number of bytes of
     *                  data at the given offset within the array, to
     *                  be encoded.
     *  @param  offset  The offset within the argument byte array at
     *                  which to obtain the next (len) bytes of data.
     *  @param  len     Number of bytes (1 - 3) of data to encode,
     *                  beginning at the argument offset.
     *  <p>
     * @exception	IllegalArgumentException	Thrown if the arguments are
     * 											invalid.
     * @exception	IOException					Thrown if the output stream is
     * 											<code>null</code> or an I/O
     * 											error occurs.    
     */
     
    private static void encodeBlock(OutputStream outStream, byte[] data, int offset, int len)
        throws IOException, IllegalArgumentException
    {
        byte b1, b2, b3;
        
        if (len < 1 || len > 3)
            throw new IllegalArgumentException("Argument length (" + len + ") out of range.");
        else if (outStream == null)
            throw new IOException("OutputStream arg is null.");
        else if (data == null)
            throw new IllegalArgumentException("Argument byte array must not be null.");
        else if ((offset + len) > data.length)
            throw new IllegalArgumentException("Argument offset/length exceeds array length.");
            
        b1 = data[offset];
        b2 = (len > 1 ? data[offset + 1] : 0);
        b3 = (len > 2 ? data[offset + 2] : 0);

        outStream.write((byte) (B64CodeMap[(b1 >>> 2) & 0x3F] & 0xFF));
        outStream.write((byte) (B64CodeMap[((b1 << 4) & 0x30) + ((b2 >>> 4) & 0x0F)] & 0xFF));
        
        if (len > 1)
            outStream.write((byte) (B64CodeMap[((b2 << 2) & 0x3C) + ((b3 >>> 6) & 0x03)] & 0xFF));
        else
            outStream.write((byte) padChar);            

        if (len > 2)
            outStream.write((byte) (B64CodeMap[(b3 & 0x3F)] & 0xFF));
        else
            outStream.write((byte) padChar);            
            
    }
    
    private static final byte[] CTENewLine = { 0x0D, 0x0A };
}
