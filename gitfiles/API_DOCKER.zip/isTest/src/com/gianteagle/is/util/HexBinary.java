package com.gianteagle.is.util;

/**
 * Hex Binary encode and decode utilities.
 * <p>
 * @author sr44189
 */

public final class HexBinary
{
	/**
	 * Default Constructor.
	 */
	
	private HexBinary()
	{
	}
	
	/**
     * Converts an array of bytes into a hex string.
     * <p>
     * @param	data	An array of bytes
     * <p>
     * @return	A string containing a lexical representation of
     * 			xsd:hexBinary.
     * <p>
     * @throws 	IllegalArgumentException if <code>data</code> is null.
     */

	public static String printHexBinary(final byte[] data)
	{
		String sRet = null;
		StringBuilder sb = null;
		
		try
		{
			sb = new StringBuilder(data.length * 2);
	        
			for (byte b : data) 
	        {
	            sb.append(HEXCODE[(b >> 4) & 0xF]);
	            sb.append(HEXCODE[(b & 0xF)]);
	        }
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
     * Converts a hex string into an array of bytes.
     * <p>
     * @param	lexicalXSDHexBinary 	A string containing lexical 
     * 									representation of xsd:hexBinary.
     * <p>
     * @return	An array of bytes represented by the string argument.
     * <p>
     * @throws	IllegalArgumentException	If string parameter does not 
     * 										conform to lexical value space
     * 										defined in XML Schema Part 2: 
     * 										Datatypes for xsd:hexBinary.
     */

	public static byte[] parseHexBinary(final String lexicalXSDHexBinary)
	{
		final int len = lexicalXSDHexBinary.length();

		// "111" is not a valid hex encoding.
		if (len % 2 != 0)
		{
			throw new IllegalArgumentException(
					"hexBinary needs to be even-length: " + lexicalXSDHexBinary);
		}

		byte[] out = new byte[len / 2];

		for (int i = 0; i < len; i += 2)
		{
			int h = hexToBin(lexicalXSDHexBinary.charAt(i));
			int l = hexToBin(lexicalXSDHexBinary.charAt(i + 1));
			
			if (h == -1 || l == -1)
			{
				throw new IllegalArgumentException(
						"contains illegal character for hexBinary: " + lexicalXSDHexBinary);
			}
			out[i / 2] = (byte) (h * 16 + l);
		}
		return out;
	}

	/**
	 * Private method used to convert a character to its binary value.
	 * <p>
	 * @param	ch	The character to convert.
	 * <p>
	 * @return		The binary value of the character.
	 */
	
	private static int hexToBin(final char ch)
	{
		if ('0' <= ch && ch <= '9')
		{
			return ch - '0';
		}
		if ('A' <= ch && ch <= 'F')
		{
			return ch - 'A' + 10;
		}
		if ('a' <= ch && ch <= 'f')
		{
			return ch - 'a' + 10;
		}
		return -1;
	}

	private static final char[] HEXCODE = "0123456789ABCDEF".toCharArray();

}
