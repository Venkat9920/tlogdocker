/**
 * Defines.java
 */

package com.gianteagle.is.util;

/**
 * This interface provides common definitions.
 * <p>
 * @author	ReichertSF
 */

public interface Defines
{
	/**
	 * Integer value that defines the optimum buffer size to read or write.
	 */

	int IO_BUF_SIZE = 1024;

	/**
	 * Integer value that defines the size for an in-memory buffer.
	 */

	int MEM_BUF_SIZE = 16384;
}
