/**
 * NvPair.java
 */

package com.gianteagle.is.util;

import com.gianteagle.is.util.StringUtil;

/**
 * Class which provides a container for a name/value pair. Both the
 * name and value are specified as strings.
 * <p>
 * @author	ReichertSF
 */

public final class NvPair
{
	/**
	 * Constructor given the name and value.
 	 * <p>
 	 * @param	sName	Name to be associated with the value.
	 * @param	sValue	Vaule to be associated with the name.
	 * <p>
	 * @exception	NullPointerException	Thrown if the name is
	 *										<code>null</code> or
	 *										the empty string.
	 */

	public NvPair(final String sName, final String sValue) 
											throws NullPointerException
	{
		if (StringUtil.isEmpty(sName) == true)
		{
			throw new NullPointerException("Name cannot be null or empty!");
		}
		this.sNvName = sName;
		this.sNvValue = sValue;
	}

	/**
	 * Constructs an <code>NvPair</code> object from the specified
	 * <code>NvPair</code> object.
	 * <p>
	 * @param	nvPair		The <code>NvPair</code> object to make
	 *						a copy of.
	 * <p>
	 * @exception	NullPointerException	Thrown if the specified
	 *										<code>NvPair</code> object is
	 *										<code>null</code>.
	 */

	public NvPair(final NvPair nvPair)
	{
		if (nvPair == null)
		{
			throw new NullPointerException(
							"Specifed NvPair object cannt be null!");
		}
		this.sNvName = nvPair.getName();
		this.sNvValue = nvPair.getValue();
	}

	/**
	 * Destroys the object and release any resources held by it. Even
	 * though this method is public, it should not be called by a user.
	 * Use the <code>destroy()</code> method instead.
	 * <p>
	 * @exception	Throwable	The exception raised by this method, if any.
	 */

	@Override
	protected void finalize() throws Throwable
	{
		this.destroy();
		super.finalize();
	}

	/**
	 * Destroys the object and releases any resources held by it.
	 */

	public void destroy()
	{
		this.sNvName = null;
		this.sNvValue = null;
	}

	/**
	 * Returns the name as a string.
	 * <p>
	 * @return		The name.
	 */

	public String getName()
	{
		return this.sNvName;
	}

	/**
	 * Returns the value as a string.
	 * <p>
	 * @return		The value.
	 */

	public String getValue()
	{
		return this.sNvValue;
	}

	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------

	private String sNvName = null;
	private String sNvValue = null;
}
