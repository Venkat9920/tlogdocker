/**
 *	JarUtil.java
 */

package com.gianteagle.is.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.jar.Manifest;

/**
 * Utility class providing static methods to obtain jar related 
 * information.
 * <p>
 * @author ReichertSF
 */

public class JarUtil
{
	/**
	 * Default constructor.
	 */
	
	private JarUtil()
	{
	}
	
	/**
	 * Returns the manifest from the jar file that contains the argument
	 * class. This method obtains the URL of the manifest through a call
	 * to the {@link #getManifest(Class) getJarManifest(Class)} method
	 * and passes that result to the
	 * {@link #getManifest(URL) getJarManifest(URL)} method.
	 * <p>
	 * @param c		A <code>Class</code> object contained in the target jar
	 *				file.
	 * <p>
	 * @return	A <code>java.util.jar.Manifest</code> object containing
	 *			the manifest for the target jar. A <code>null</code> is
	 *			returned if the argument is <code>null</code>, the argument
	 *			class cannot be located in a jar in the CLASSPATH, or the
	 *			manifest cannot be loaded for any reason.
	 * <p>
	 * @throws	IllegalArgumentException	If the class argument is 
	 * 										<code>null</code>.
	 * @throws	IOException					If an I/O problem is encountered 
	 * 										in opening an InputStream
	 *										to read the manifest file, or 
	 *										constructing a Manifest object
	 *										around that stream.
	 */
	
	public static Manifest getManifest(final Class<?> c)
		throws IllegalArgumentException, IOException
	{
		Manifest manifest = null;
		
		if (c != null)
		{
			manifest = getManifest(getJarManifestURL(c));
		}
		return manifest;
	}

	/**
	 * Returns the manifest from the jar file referenced in the
	 * argument URL object.
	 * <p>
	 * @param manifestURL	A <code>java.net.URL</code> object referencing
	 *						the manifest file (/META-INF/MANIFEST.MF) in a
	 *						jar file.
	 * <p>
	 * @return	A <code>java.util.jar.Manifest</code> object containing
	 *			the manifest for the target jar. A <code>null</code> is
	 *			returned if the argument is <code>null</code>, the argument
	 *			URL does not reference a jar in the CLASSPATH, or the
	 *			manifest cannot be loaded for any other reason.
	 * <p>
	 * @throws	IllegalArgumentException	If the URL argument is 
	 * 										<code>null</code>.
	 * @throws	IOException					If an I/O problem is encountered
	 * 										in opening an InputStream
	 *										to read the manifest file, or 
	 *										constructing a Manifest object
	 *										around that stream.
	 */
	
	public static Manifest getManifest(final URL manifestURL)
		throws IllegalArgumentException, IOException
	{
		Manifest mf = null;
		InputStream is = null;

		try
		{
			if (manifestURL == null)
			{
				throw new IllegalArgumentException(
									"Manifest URL argument is null.");
			}
			is = manifestURL.openStream();
			
			if (is != null)
			{
				mf = new Manifest(is);
			}
		}
		finally
		{
			if (is != null)
			{
				try { is.close(); } catch (Exception ignore) { }
				is = null;
			}
		}
		return (mf);
	}

	/**
	 * Generate a fully qualified URL for the argument class,
	 * including the name / path of the jar containing the class.
	 * <p>
	 * @param clazz		The <code>Class</code> for which the URL is to be
	 *          	established.
	 * <p>
	 * @return		A <code>URL</code> class object containing the fully
	 *				qualified reference to the argument class, or
	 *				<code>null</code> if the argument class could not be
	 *				located in the CLASSPATH.
	 * <p>
	 * @throws	IllegalArgumentException	If the Class argument is 
	 * 										<code>null</code>.
	 */
	
	private static URL getClassURL(final Class<?> clazz)
										throws IllegalArgumentException
	{
		URL url = null;
		String sName = null;
		
		try
		{
			if (clazz != null)
			{
				sName = '/' + clazz.getName().replace('.', '/') + ".class";

				if (JarUtil.DEBUG)
				{
					System.out.print("JarUtil.getClassURL(): ");
					System.out.print("Class Name = ");
					System.out.println(sName);
				}
				url = clazz.getResource(sName);
				
				if (JarUtil.DEBUG)
				{
					System.out.print("JarUtil.getClassURL(): ");
					System.out.print("Class URL = ");
					System.out.println(url.toString());
				}
			}
		}
		finally
		{
			sName = null;
		}
		return url;
	}

	/**
	 * Tests whether the argument URL represents a class located
	 * in a jar file. The String representation of the URL object
	 * is tested for the prefix &quot;jar:&quot; to determine
	 * whether the URL actually references a resource in a jar
	 * file.
	 * <p>
	 * @param classURL	A <code>URL</code> class object containing
	 *					the fully qualified URL of the argument class.
	 * <p>
	 * @return	A <code>true</code> value if the argument URL references
	 *			a jar file, or resource within a jar file.
	 *			A <code>false</code> value is returned under all other
	 *			conditions, including if the argument is <code>null</code>.
	 */
	
	private static boolean isInJar(final URL classURL)
	{
		boolean bResult = false;
		
		if (classURL != null)
		{
			if (classURL.toString().startsWith("jar:") ||
				classURL.toString().startsWith("wsjar:"))
			{
				bResult = true;
			}
		}
		return bResult;
	}

	/**
	 * Generates a URL referencing the MANIFEST.MF file in the jar file
	 * containing the class referenced in the argument URL. The argument
	 * must be in a form such as that generated by the
	 * {@link #getClassURL(Class) getClassURL(Class)} method.
	 * <p>
	 * @param classURL	A <code>java.net.URL</code> object referencing a
	 *					class contained in the target jar file.
	 * <p>
	 * @return	A <code>URL</code> class object referencing the MANIFEST.MF
	 *			file in the target jar file. A <code>null</code> is returned
	 *			if the argument is <code>null</code>, the URL does not
	 *			represent a class loaded from a jar file, or the class cannot
	 *			be found in a jar referenced in the CLASSPATH.
	 * <p>
	 * @throws	IllegalArgumentException
	 *			If the argument URL is <code>null</code>.
	 */

	private static URL getJarManifestURL(final URL classURL)
		throws IllegalArgumentException
	{
		URL manifestURL = null;
		String sTmp = null;
		int ndx = 0;
		
		try
		{
			if (classURL == null)
			{
				throw new IllegalArgumentException("URL Argument is null!");
			}

			if (JarUtil.isInJar(classURL))
			{
				sTmp = classURL.toString();
				ndx = sTmp.lastIndexOf("!");

				if (ndx > 0)
				{
					ndx++;
					sTmp = sTmp.substring(0,ndx);
					sTmp += "/META-INF/MANIFEST.MF";
					
					try
					{
						manifestURL = new URL(sTmp);
					}
					catch (Exception ignore) { }
					
					if (JarUtil.DEBUG)
					{
						System.out.print("JarUtil.getJarManifestURL(): ");
						System.out.print("Manifest URL = ");
						if (manifestURL == null)
						{
							System.out.println("{null}");
						}
						else
						{
							System.out.println(manifestURL);
						}
					}
				}
			}
		}
		finally
		{
			sTmp = null;
		}
		return (manifestURL);
	}

	/**
	 * Generates a URL referencing the MANIFEST.MF file in the jar file
	 * containing the argument class.
	 * <p>
	 * @param c		A <code>Class</code> object contained in the target jar
	 *				file.
	 * <p>
	 * @return	A <code>URL</code> class object referencing the MANIFEST.MF
	 *			file in the target jar file. A <code>null</code> is returned
	 *			if the argument is <code>null</code> or the Class cannot be
	 *			found in a jar referenced in the CLASSPATH.
	 * <p>
	 * @throws	IllegalArgumentException		If the class argument is 
	 * 											<code>null</code>.
	 */
	
	private static URL getJarManifestURL(final Class<?> c)
		throws IllegalArgumentException
	{
		URL url = null;
		url = getClassURL(c);
		
		if (url != null)
		{
			url = getJarManifestURL(url);
		}
		return (url);
	}

	//----------------------------------------------------------------
	//	Identifiers for standard manifest entries generated by the
	//	build processes.
	//----------------------------------------------------------------
	
	/**
	 *	The manifest property containing the UID under which the jar
	 *	was generated.
	 */
	
	public static final String MF_BUILT_BY = "Built-By";

	/**
	 *	The manifest property containing the time (HH:mm zzz) when the
	 *	jar was built.
	 */
	
	public static final String MF_BUILD_TIME = "Build-Time";

	/**
	 *	The manifest property containing the date (MM/dd/yyyy) the
	 *	jar was built.
	 */
	
	public static final String MF_BUILD_DATE = "Build-Date";

	/**
	 *	The manifest property containing the jar version string.
	 */
	
	public static final String MF_JAR_VERSION = "Version";

	/**
	 * The manifest property containing additional version information.
	 */
	
	public static final String MF_JAR_VERSION_INFO = "VersionInfo";
	
	/**
	 *	The manifest property containing the date associated with
	 *	the jar version. This is distinct from the Build-Date in
	 *	that the same set of logic could be archived into a jar
	 *	file more than once, or well after the date the version
	 *	was updated after a code change.
	 */
	
	public static final String MF_JAR_DATE = "Date";

	/**
	 *	The manifest property containing a brief description of the jar
	 *	contents.
	 */
	
	public static final String MF_JAR_DESC = "Desc";

	/**
	 *	The manifest property containing the name of the jar file.
	 */
	
	public static final String MF_JAR_NAME = "JarName";

	/**
	 *	The manifest section containing package level information.
	 */
	
	public static final String MF_PACKAGES = "Packages";
	
	private static final boolean DEBUG = false;
}
