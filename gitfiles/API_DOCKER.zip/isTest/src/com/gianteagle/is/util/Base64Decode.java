/**
 *  Base64Decode.java
 */

package com.gianteagle.is.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.gianteagle.is.util.StringUtil;

/**
 * @deprecated		Replace with java.xml.bind.DatatypeConverter.
 * <p>
 *  Provides methods to decode data encoded using BASE64
 *  Content Transfer Encoding as initially specified in RFC 1521.
 *  This RFC is part of the MIME specification as published by the
 *  Internet Engineering Task Force (IETF).
 *  <p>
 *  The companion class {@link com.gianteagle.is.util.Base64Encode} provides
 *  methods to encode data to this standard. The encode and decode
 *  logic is separated into two classes as an efficiency
 *  measure; to avoid encode operations carrying decode logic
 *  overhead as well as the converse.
 *  <p>
 *  <b>Important Note:</b>
 *  <ul>
 *  <li>Unlike some other encoding schemes there is nothing in this
 *  encoding that tells the decoder where a buffer starts or stops, so
 *  to use it, the encoded data must be first isolated and then fed into
 *  one of the decoded methods.</li>
 *  </ul>
 *  <p>
 *  See the {@link com.gianteagle.is.util.Base64Encode} class documentation
 *  for further information as well as a detailed discussion of the
 *  mechanics of the BASE64 encoding scheme.
 */
 
@Deprecated
public final class Base64Decode extends Base64Common
{ 
    /**
     *  Default class constructor.
     */

	public Base64Decode()
    {
        super();
    }
    
    /**
     *  Read the entire contents of the argument InputStream, encode
     *  it using BASE64 CTE (Content Transfer Encoding) encoding and
     *  write the encoded data to the argument output stream.
     *  <p>
     *  @param  inStream    Reference to an InputStream class object
     *                      from which data to be encoded is read.
     *  @param  outStream   Reference to an OutputStream class object
     *                      to which encoded data is to be written.
     *  <p>
     *  @throws IllegalArgumentException  If either of the argument
     *                          stream references is null.
     *  @throws IOException If an internal processing or stream related
     *                      error occurs.    
     */
     
    public void decode(InputStream inStream, OutputStream outStream)
        throws IOException, IllegalArgumentException
    {
        if (inStream == null)
            throw new IllegalArgumentException("InputStream arg is null.");
        else if (outStream == null)
            throw new IllegalArgumentException("OutputStream arg is null.");
            
        byte[] workBuff = new byte[BytesPerLineDecode];
        int nBytesRead = 0;

        do
        {
            nBytesRead = readByteGroups(inStream, workBuff);
                            
            for(int i = 0; i < nBytesRead; i += BytesPerGroupDecode)
            {
                Base64Decode.decodeBlock(outStream, workBuff, i);
            }
        } while (nBytesRead > 0);

        outStream.flush();

        workBuff = null;
    }
    

    /**
     *  Encode the contents of the argument String object using
     *  BASE64 CTE (Content Transfer Encoding) encoding and return
     *  the encoded data as a String.
     *  <p>
     *  @param  str Reference to String object containing data to
     *              encode.
     *  <p>
     *  @return A String object containing the encoded data.
     *  <p>
     *  @throws IllegalArgumentException  If the String argument is null
     *                                  or empty.
     *  @throws IOException If an internal processing error occurs.    
     */
     
    public String decode(String str)
        throws IllegalArgumentException, IOException
    {
        String sRtnStr = null;

        if (StringUtil.isEmpty(str))
            throw new IllegalArgumentException("Argument String is null or empty.");
              

        ByteArrayOutputStream outBAStream = new ByteArrayOutputStream();
        ByteArrayInputStream inBAStream = 
            new ByteArrayInputStream(str.getBytes());
        decode(inBAStream, outBAStream);
        sRtnStr = outBAStream.toString();
        outBAStream.close();
        outBAStream = null;
        inBAStream.close();
        inBAStream = null;


        return (sRtnStr);
    }            

    
    /**
	 * Simple application that Base64 encodes the contents of a file.
	 * <p>
	 * @param	args	Command line arguments. The first argument
	 *					is the name of the input file to encode,
	 *					and the second is the name of the output
	 *					file that the compressed data is to be 
	 *					written to. If the output file is omitted,
	 *					the output is written to System.out.
	 */

	public static void main(String[] args)
	{
		Base64Decode base64Decode = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try
		{
			if (args.length < 1)
			{
				System.out.println(
					"Usage:  Base64Decode inputfile [outputfile]");
			}
			else
			{
				base64Decode = new Base64Decode();
				
				fis = new FileInputStream(args[0]);
				
				if (args.length > 1)
				{
					fos = new FileOutputStream(args[1]);
				}
				base64Decode.decode(fis, (fos == null ? System.out : fos));
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			if (fis != null)
			{
				try { fis.close(); } catch (Throwable ignore) { }
				fis = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch (Throwable ignore) { }
				fos = null;
			}
			base64Decode = null;
		}
	}

    //---------------------------------------------------------------
    // Private Methods
    //---------------------------------------------------------------
    

    /**
     *  Decode the BASE64 encoded octet (4 bytes) beginning at the 
     *  indicated offset in the argument byte array and write the
     *  results to the argument OutputStream.
     *  <p>
     *  Note: All leading CR/LFs and any other non-BASE64 alphabet
     *  characters must be stripped prior to calling this method.
     *  <p>
     *  @param  outStream   Reference to an OutputStream class object
     *                      to which decoded data is to be written.
     *  @param  data    Reference to a byte array containing at least
     *                  four bytes of BASE64 encoded data, beginning
     *                  at the argument offset.
     *  @param  offset  The offset within the argument byte array at
     *                  which to obtain the next octet.
     *  <p>
     *  @throws IllegalArgumentException  If the OutputStream or byte
     *                      buffer arguments are <tt>null</tt> or if
     *                      fewer than a BASE64 group of bytes remain
     *                      at the argument offset within the buffer.
     *  @throws IOException If an internal processing or stream related
     *                      error occurs.    
     */
     
    private static void decodeBlock(OutputStream outStream, byte[] data, int offset)
        throws IOException, IllegalArgumentException
    {
        byte b1, b2, b3, b4;
        int len;
        
        if (outStream == null)
            throw new IOException("OutputStream arg is null.");
        else if (data == null)
            throw new IllegalArgumentException("Argument byte array must not be null.");
        if ((offset + BytesPerGroupDecode) > data.length)
            throw new IllegalArgumentException("Argument buffer must contain at least 4 bytes.");
        
        if (data[offset + 3] == padChar)
            len = ((data[offset + 2] == padChar) ? 2 : 3);
        else
            len = BytesPerGroupDecode;    
            
        b1 = B64CodeOrdinalMap[data[offset] & 0xFF];
        b2 = B64CodeOrdinalMap[data[offset + 1] & 0xFF];
        
        outStream.write((byte) ( ((b1 << 2) & 0xFC) | ((b2 >>> 4) & 0x03) ));
        
        if (len > 2)
        {
            b3 = B64CodeOrdinalMap[data[offset + 2] & 0xFF];
            outStream.write((byte) ( ((b2 << 4) & 0xF0) | ((b3 >>> 2) & 0x0F) ));
            if (len > 3)
            {
                b4 = B64CodeOrdinalMap[data[offset + 3] & 0xFF]; 
                outStream.write((byte) ( ((b3 << 6) & 0xC0) | (b4 & 0x3F) ));
            }    
        }    
    }
            

    /**
     *  Read groups of encoded bytes from the input stream and store
     *  them in the argument buffer.
     *  <p>
     *  @param  inStream    Reference to InputStream from which to
     *                      read data.
     *  @param  buffer      Reference to a byte array large enough to
     *                      store at least BytesPerGroupDecode (4)
     *                      bytes. The buffer will be filled, given
     *                      enough input, with complete byte groups
     *                      only, up to the allocated size of the
     *                      buffer. 
     *  <p>
     *  @return     Number of bytes read or (-1) if no complete
     *              octets read.
     *  <p>
     *  <p>
     *  @throws IllegalArgumentException  If the InputStream or byte
     *                      buffer arguments are <tt>null</tt> or if
     *                      the buffer size is less than the number
     *                      of bytes in a BASE64 group.
     *  @throws IOException If an internal processing or stream related
     *                      error occurs.    
     */
     
    private int readByteGroups(InputStream inStream, byte[] buffer)
        throws IOException, IllegalArgumentException
    {
        int nByte = 0;
        int nBytesRead = 0;
        int nMaxBytes;
        int nSecondReadBytes;
        
        if (inStream == null)
            throw new IOException("InputStream arg is null.");
        else if (buffer == null)
            throw new IllegalArgumentException("Byte buffer arg is null.");
        else if (buffer.length < BytesPerGroupDecode)
            throw new IllegalArgumentException("Byte buffer must be at least " +
                BytesPerGroupDecode + " bytes.");

        nMaxBytes = (buffer.length / BytesPerGroupDecode) * BytesPerGroupDecode;
        nSecondReadBytes = (BytesPerGroupDecode - 1);
        
        while (nBytesRead < nMaxBytes && nByte != -1)
        {
            do
            {
                nByte = inStream.read();
                if (nByte == -1)
                    break;
            } while (B64CodeOrdinalMap[(nByte & 0xFF)] == -1);
            
            if ( nByte != -1)
            {
                buffer[nBytesRead] = (byte) nByte;
                nByte = readBytes(inStream, buffer, nBytesRead+1,
                    nSecondReadBytes);
                if (nByte == -1)
                    throw new IOException("Input format error - Incomplete code group.");
                nBytesRead += BytesPerGroupDecode;
            }
        }
        return ( (nBytesRead > 0 ? nBytesRead : -1) );            
    }

    //---------------------------------------------------------------
    //  Class Private Constants
    //---------------------------------------------------------------

    private static final int nOrdinalMapSize = 256;    
    private static final byte[] B64CodeOrdinalMap = new byte[nOrdinalMapSize];

    //---------------------------------------------------------------
    //  Private BAS64 Code Ordinal Map Initialization
    //
    //  What, one might reasonably ask, is this fool doing here?
    //  
    //  The short answer is optimizing the decode logic for anything
    //  less than very, very, small decoding jobs.
    //
    //  Translating BASE64 encoded data back into it's original form
    //  involves "looking up" the encoded character in the BASE64
    //  alphabet "map".  This could, in the worst case, involve an
    //  iteration-and-compare passes through the 64 character map
    //  for each character in an encoded group (4). Much thrashing
    //  through the character map array...
    //
    //  We avoid this by creating a "map to the map". The ordinal
    //  (offset into in the BASE64 map) of each character in the
    //  BASE64 alphabet is stored at the offset (in the ordinal map)
    //  cooresponding to it's rank (offset) in the current character
    //  set (i.e. the ordinal for 'A', or zero, is stored at the
    //  offset cooresponding to the integer value of 'A'. The positions
    //  in the ordinal map that aren't associated with the BASE64
    //  alphabet are set to -1, indicating they can be safely ignored.
    //
    //  Now the BASE64 ordinal can be obtained using a simple offset
    //  of the integer value of the encoded character into this map
    //  with the only price tag as one trip each through a 256 and a
    //  64 byte array.
    //
    //  Of course this only works on systems where the integer values
    //  of each of the BASE64 alphabet characters falls between zero
    //  and 255...
    //---------------------------------------------------------------
    
    /**
     *  Initialization of static array.
     */

    static
    {
        int i;
        for (i=0; i<(nOrdinalMapSize-1); i++)
            B64CodeOrdinalMap[i] = (byte)-1;
        for (i=0; i<B64CodeMap.length; i++)
            B64CodeOrdinalMap[B64CodeMap[i]] = (byte) i;
    }        
}
