/**
 * PropUtil.java
 */

package com.gianteagle.is.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * Class used to maintain various utility methods related to Java
 * <code>Properties</code> objects and files.
 * <p>
 * @author ReichertSF
 */

public class PropUtil
{
	/**
	 * Default constructor.
	 */
	
	private PropUtil()
	{
	}

	/**
	 * Reads a ResourceBundle and returns the set of properties contained
	 * in it.
	 * <p>
	 * @param	sResourceBundle		The ResourceBundle to read.
	 * <p>
	 * @return		The Properties list.
	 */

	public static Properties readResourceBundle(final String sResourceBundle)
	{
		Properties prop = null;
		ResourceBundle resourceBundle = null;
    	Enumeration<String> eKeys = null;
    	String sKey = null;
    	String sValue = null;
		
    	try
    	{
   			resourceBundle = ResourceBundle.getBundle(sResourceBundle);
	    		
	    	if (resourceBundle != null)
	    	{
	    		eKeys = resourceBundle.getKeys();
	    			
	    		if (eKeys != null)
	    		{
	    			while (eKeys.hasMoreElements())
	    			{
	    				sKey = eKeys.nextElement();
	    					
	    				if (sKey != null)
	    				{
	    					sValue = resourceBundle.getString(sKey);
	    					
	    					if (sValue != null)
	    					{
	    						if (prop == null)
	    						{
	    							prop = new Properties();
	    						}
	   							prop.setProperty(sKey, sValue);

	   							sKey = null;
	   							sValue = null;
	    					}
	    				}
	    			}
	    		}
    		}
		}
		finally
		{
    		resourceBundle = null;
    		eKeys = null;
    		sKey = null;
    		sValue = null;
		}
		return prop;
	}

	/**
	 * Reads a property list (key and element pairs) from the
	 * specified Properties file.
	 * <p>
	 * @param	sPropFile		The properties file to read.
	 * <p>
	 * @return		The Properties list.
	 * <p>
	 * @exception	IOException				If an error occurs in reading
	 *										the file.
	 * @exception	FileNotFoundException	If the named file does not exist.
	 */

	public static Properties readProperties(final String sPropFile)
					throws IOException {
		Properties prop = null;

		if (sPropFile != null)
		{
			FileInputStream fileInputStream = null;

			try
			{
				fileInputStream = new FileInputStream(sPropFile);

				prop = new Properties();

				prop.load(fileInputStream);
			}
			finally
			{
				if (fileInputStream != null)
				{
					fileInputStream.close();
					fileInputStream = null;
				}
			}
		}
		return prop;
	}

	/**
	 * Writes a Properties object to the specified file.
	 * <p>
	 * Java 1.1.x and Java 1.2.x differ on their approach to
	 * saving a Properties object to file. Java 1.1.x uses the 
     * <code>save()</code> method whereas Java 1.2.x uses the
	 * <code>store()</code> method and deprecates <code>save()</code>.
	 * The developer is then faced with the following:
     * <blockquote>
	 * &quot;<i>To deprecate, or not to deprecate? That is the 
	 * question.</i>&quot;
	 * </blockquote>
	 * This method bypasses both of those methods and is compatible
	 * with both JVM's. The rules of encoding that are applied are
 	 * outlined in <code>StringUtil.encodeSpecialChars()</code>.
	 *
	 * <p>
	 * @param	sPropFile		File to write the Properties object to.
	 * @param	prop			Properties object to write.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static void writeProperties(String sPropFile, Properties prop)
					throws IOException
	{
		FileOutputStream fos = null;
		PrintWriter pw = null;
		Enumeration<Object> e = null;
		
		try
		{
			if (sPropFile != null && prop != null)
			{
				fos = new FileOutputStream(sPropFile, false);
				pw = new PrintWriter(fos, true);

				pw.println("# " + sPropFile + " properties file.");
				pw.println("# " +  DateUtil.getCurrentDateTime());

				e = prop.keys();
				
				if (e != null)
				{
					String sKey = null;
					String sValue = null;

					while (e.hasMoreElements() == true)
					{
						sKey = (String)e.nextElement();
						sValue = (String)prop.get(sKey);
						sValue = StringUtil.encodeSpecialChars(sValue, true);
						pw.println(sKey + "=" + sValue.trim());
					}	
					sKey = null;
					sValue = null;
					e = null;
				}
			}
		}
		finally
		{
			if (pw != null)
			{
				pw.close();
				pw = null;
			}
			if (fos != null)
			{
				fos.close();
				fos = null;
			}
		}
	}

	/**
	 * Method used to list the Java system properties.
	 * <p>
	 * @param	pw	PrintWriter used to write the property list to.
	 */

	public static void listSystemProperties(final PrintWriter pw)
	{
		pw.println("Java System Properties:");

        //-----------------------------------------------------------
		// Loop through the properties and display the information
		// about each one.
		//-----------------------------------------------------------

		Properties sysProp = System.getProperties();
		Enumeration<?> e = sysProp.propertyNames();

		String sPropName = null;

		while (e.hasMoreElements() == true)
		{
			sPropName = (String)e.nextElement();

			pw.print("  ");
			pw.print(sPropName);
			pw.print(" = ");
		
			if (System.getProperty(sPropName) == null)
			{
				pw.print("{null}");
			}
			else
			{
				pw.print(StringUtil.encodeSpecialChars(
							System.getProperty(sPropName), false));
			}
			pw.println();
		}
		sPropName = null;
		e = null;
		sysProp = null;
	}
}
