/**
 * FileUtil.class
 */

package com.gianteagle.is.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Random;
import java.util.zip.GZIPOutputStream;
import java.util.zip.GZIPInputStream;

import com.gianteagle.is.util.Defines;

/**
 * Class used to maintain various File and Stream related utility methods.
 * Each method is a class (static) method and must be referenced
 * by the class name.
 * <pre>
 *     FileUtil.copy(inputStream, outputStream);
 * </pre>
 * 
 * @author ReichertSF
 */

public final class FileUtil implements Defines
{
	/**
     * Constructor is private, because only Class methods and constants
	 * are supported.
	 */

	private FileUtil()
	{
	}

	/**
	 * Method which copies the specified input file to the specified
	 * output file.
	 * <p>
	 * @param		inFile			File to read from.
	 * @param		outFile			Output file to write to.
	 * @param		bAppend			If <code>true</code> the bytes will
	 *								be appended to the output file,
	 *								otherwise the file will be 
	 *								truncated and then the bytes written.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final File inFile, final File outFile, 
							final boolean bAppend) throws IOException
	{
		return copy(inFile == null ? null : inFile.getAbsolutePath(),
					outFile == null ? null : outFile.getAbsolutePath(),
					bAppend);
	}

	/**
	 * Method which copies the specified input file to the specified
	 * output file.
	 * <p>
	 * @param		sInputFile		Name of the input file to read from.
	 * @param		sOutputFile		Name of the output file to write to.
	 * @param		bAppend			If <code>true</code> the bytes will
	 *								be appended to the output file,
	 *								otherwise the file will be 
	 *								truncated and then the bytes written.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final String sInputFile, final String sOutputFile,
							final boolean bAppend) throws IOException
	{
		long nBytes = 0;
	
		if (sInputFile != null)
		{
			FileInputStream fin = null;
			FileOutputStream fos = null;

			try
			{
				fin = new FileInputStream(sInputFile);

				if (sOutputFile != null)
					fos = new FileOutputStream(sOutputFile, bAppend);

				nBytes = FileUtil.copy(fin, fos);

			}
			finally
			{
				if (fin != null)
				{
					try { fin.close(); } catch (IOException ignore) {}
					fin = null;
				}
				if (fos != null)
				{
					try { fos.close(); } catch (IOException ignore) {}
					fos = null;
				}
			}
		}
		return nBytes;
	}

	/**
	 * Method which reads from the specified <code>InputStream</code>
	 * object and writes each byte to the specified output file.
	 * <p>
	 * @param		inputStream		InputStream object to read from.
	 * @param		outFile			Output file to write to.
	 * @param		bAppend			If <code>true</code> the bytes will
	 *								be appended to the output file,
	 *								otherwise the file will be 
	 *								truncated and then the bytes written.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final InputStream inputStream, final File outFile,
							final boolean bAppend) throws IOException
	{
		return copy(inputStream,
					outFile == null ? null : outFile.getAbsolutePath(),
					bAppend);
	}

	/**
	 * Method which reads from the specified <code>InputStream</code>
	 * object and writes each byte to the specified output file.
	 * <p>
	 * @param		inputStream		InputStream object to read from.
	 * @param		sOutputFile		Name of the output file to write to.
	 * @param		bAppend			If <code>true</code> the bytes will
	 *								be appended to the output file,
	 *								otherwise the file will be 
	 *								truncated and then the bytes written.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final InputStream inputStream, 
						    final String sOutputFile,
							final boolean bAppend) throws IOException
	{
		long nBytes = 0;

		if (inputStream != null)
		{
			FileOutputStream fos = null;

			try
			{
				if (sOutputFile != null)
					fos = new FileOutputStream(sOutputFile, bAppend);

				nBytes = FileUtil.copy(inputStream, fos);
			}
			finally
			{
				if (fos != null)
				{
					try { fos.close(); } catch (IOException ignore) {}
					fos = null;
				}
			}
		}
		return nBytes;
	}

	/**
	 * Method which reads from the specified file and writes each byte
	 * of it to the specified <code>OutputStream</code>.
	 * <p>
	 * @param	inFile			File to read from.
	 * @param	outputStream	OutputStream to write to.
	 * <p>
	 * @return		Returns the number of bytes read from the file
	 *				and written to the output stream.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final File inFile, final OutputStream outputStream)
						throws IOException
	{
		return copy(inFile == null ? null : inFile.getAbsolutePath(),
					outputStream);
	}

	/**
	 * Method which reads from the specified file and writes each byte
	 * of it to the specified <code>OutputStream</code>.
	 * <p>
	 * @param	sInputFile		Name of the input file to read from.
	 * @param	outputStream	OutputStream to write to.
	 * <p>
	 * @return		Returns the number of bytes read from the file
	 *				and written to the output stream.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final String sInputFile, 
							final OutputStream outputStream)
								throws IOException
	{
		long nBytes = 0;

		if (sInputFile != null)
		{
			FileInputStream fin = null;

			try
			{
				fin = new FileInputStream(sInputFile);

				nBytes = FileUtil.copy(fin, outputStream);
			}
			finally
			{
				if (fin != null)
				{
					try { fin.close(); } catch (IOException ignore) {}
					fin = null;
				}
			}
		}
		return nBytes;
	}
	
	/**
	 * Method which reads from the specified <code>InputStream</code>
	 * object and writes each byte to the specified <code>OutputStream</code>
	 * object.
	 * <p>
	 * @param		inputStream		InputStream object to read from.
	 * @param		outputStream	OutputStream object to write to.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output stream.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final InputStream inputStream, 
						    final OutputStream outputStream)
									throws IOException
	{
		return FileUtil.copy(inputStream, outputStream, 0);
	}

	/**
	 * Method which reads from the specified <code>InputStream</code>
	 * object and writes each byte to the specified <code>OutputStream</code>
	 * object.
	 * <p>
	 * @param		inputStream		InputStream object to read from.
	 * @param		outputStream	OutputStream object to write to.
	 * @param		nMaxLen			Maximum number of bytes to read. If
	 * 								less than or equal to 0, the input 
	 * 								stream is read until it is exhausted.
	 * <p>
	 * @return		Returns the number of bytes read from the input
	 *				stream and written to the output stream.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */

	public static long copy(final InputStream inputStream, 
						    final OutputStream outputStream,
						    final int nMaxLen) throws IOException
	{
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		long nBytes = 0;
		int nByte = 0;
		boolean bDone = false;

		try
		{
    		if (inputStream != null)
    		{
    			bis = new BufferedInputStream(inputStream);
    			
    			// The output stream is allowed to be null. If it is, the
    			// input stream is essentially emptied as in copy to /dev/null.
    			
    			if (outputStream != null)
    			{
    				bos = new BufferedOutputStream(outputStream);
    			}
    	
    			while (bDone == false && (nByte = bis.read()) != -1)
    			{
    				++nBytes;

    				if (bos != null)
    				{
    					bos.write(nByte);
    				}
    				if (nMaxLen > 0)
    				{
    					if (nBytes >= nMaxLen)
    					{
    						bDone = true;
    					}
    				}
    			}
    			if (bos != null)
    			{
    				bos.flush();
    			}
    		}
		}
		finally
		{
		}
		return nBytes;
	}

	/**
	 * Method which reads the contents of the specified file into
	 * a byte array.
	 * <p>
	 * @param		sFile		Name of the file to read.
	 * <p>
	 * @return		A byte array containing the contents of the file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */
	 
	public static byte[] fileToByteArray(final String sFile) throws IOException
	{
		byte[] byteData = null;

		ByteArrayOutputStream baos = null;
		
		try
		{
			if (StringUtil.isEmpty(sFile) == false)
			{
				baos = new ByteArrayOutputStream(Defines.MEM_BUF_SIZE);
				
				FileUtil.copy(sFile, baos);
				
				byteData = baos.toByteArray();
			}
			
		}
		finally
		{
			if (baos != null)
			{
				try { baos.close(); } catch (Throwable ignore) { }
				baos = null;
			}
		}
		
		return byteData;
	}

	/**
	 * Method which reads the contents of the specified file into
	 * a String object and then returns the String.
	 * <p>
	 * @param		sFile		Name of the file to read.
	 * <p>
	 * @return		Returns a String object containing the contents
	 *				of the file.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs.
	 */
	 
	public static String fileToString(final String sFile) throws IOException
	{
		final StringBuffer sBuf = new StringBuffer();

		if (sFile != null)
		{
			FileInputStream is = null;
			try
			{
				is = new FileInputStream(sFile);
				byte[] buf = new byte[Defines.IO_BUF_SIZE];
				int nRead;
	
				while ((nRead = is.read(buf, 0, Defines.IO_BUF_SIZE)) != -1)
				{
					sBuf.append(new String(buf, 0, nRead));
				}
				buf = null;
			}
			finally
			{
				if (is != null)
				{
					try { is.close(); } catch (IOException ignore) {}
					is = null;
				}
			}
		}
		return sBuf.toString();
	}

	/**
	 * Method which writes the contents of a string to the specified
	 * file. The file is created if this method is called and the
	 * previous contents are lost if it exists.
	 * <p>
	 * @param		sStr		The string to write to the file.
	 * @param		sFile		Name of the file to write the string to.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs
	 */

	public static void stringToFile(final String sStr, final String sFile)
							throws IOException
	{
		FileUtil.stringToFile(sStr, sFile, false);
	}

	/**
	 * Method which writes the contents of a string to the specified
	 * file.
	 * <p>
	 * @param		sStr		The string to write to the file.
	 * @param		sFile		Name of the file to write the string to.
	 * @param		bAppend		Specifies whether or not the string
	 *							should be appended.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occurs
	 */

	public static void stringToFile(final String sStr, final String sFile, 
									final boolean bAppend)
											throws IOException
	{
		FileOutputStream fos = null;

		try
		{
			if (StringUtil.isEmpty(sStr) == false &&
				StringUtil.isEmpty(sFile) == false)
			{
				fos = new FileOutputStream(sFile, bAppend);

				fos.write(sStr.getBytes());

				fos.flush();
			}
		}
		finally
		{
			if (fos != null)
			{
				try { fos.close(); } catch (IOException ignore) {}
				fos = null;
			}
		}
	}
	/**
	 * Method which indicates whether the specified file exists.
	 * <p>
	 * @param		sFilename			Name of the file to check.
	 * <p>
	 * @return		<code>true</code> if the file exists, <code>false</code>
	 *				otherwise.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and read access to the file is denied.
	 */

	public static boolean exists(final String sFilename) throws SecurityException
	{
		boolean bExists = false;

		if (StringUtil.isEmpty(sFilename) == false)
		{
			File file = new File(sFilename);

			bExists = file.exists();

			file = null;
		}
		return bExists;
	}

	/**
	 * Method which indicates whether the specified file can be read.
	 * <p>
	 * @param		sFilename			Name of the file to check.
	 * <p>
	 * @return		<code>true</code> if the specified file exists and
	 *				can be read, <code>false</code> otherwise.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and read access to the file is denied.
	 */

	public static boolean canRead(final String sFilename) throws SecurityException
	{
		boolean bCanRead = false;

		if (sFilename != null)
		{
			File file = new File(sFilename);

			bCanRead = file.canRead();

			file = null;
		}
		return bCanRead;
	}

	/**
	 * Method which indicates whether the specified file can be written to.
	 * <p>
	 * @param		sFilename			Name of the file to check.
	 * <p>
	 * @return		<code>true</code> if the specified file can be
	 *				written to, <code>false</code> otherwise.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and write access to the file is denied.
	 */

	public static boolean canWrite(final String sFilename) throws SecurityException
	{
		boolean bCanWrite = false;

		if (sFilename != null)
		{
			File file = new File(sFilename);

			bCanWrite = file.canWrite();

			file = null;
		}
		return bCanWrite;
	}

	/**
	 * Method used to rename the specified file.
	 * <p>
	 * @param	sFilename		Specifies the name of the file to be
	 *							renamed.
	 * @param	sNewFilename	Specifies the new name of the file.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and write access to both files is
	 *									denied.
	 */

	public static void rename(final String sFilename, final String sNewFilename)
						throws SecurityException
	{
		if (sFilename != null && sNewFilename != null)
		{
			File fileOrg = new File(sFilename);
			File fileNew = new File(sNewFilename);

			if (FileUtil.exists(sFilename) == true)
			{
				fileOrg.renameTo(fileNew);
			}
			fileOrg = null;
			fileNew = null;
		}
	}

	/**
	 * Method used to delete the specified file.
	 * <p>
	 * @param	sFilename		Specifies the name of the file to be
	 *							deleted.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to delete the file.
	 */

	public static void delete(final String sFilename) throws SecurityException
	{
		if (sFilename != null)
		{
			File file = new File(sFilename);

			file.delete();

			file = null;
		}
	}

	/**
	 * Method used to obtain the size in bytes of the specified file.
	 * <p>
	 * @param	sFilename		Specifies the name of the file.
	 * <p>
	 * @return		The length (size in bytes) of the file.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to read the file.
	 */

	public static long length(final String sFilename) throws SecurityException
	{
		long nBytes = 0;
		File file = null;

		try
		{
			if (sFilename != null)
			{
				file = new File(sFilename);

				nBytes = file.length();
			}
		}
		finally
		{
			file = null;
		}
		return nBytes;
	}

	/**
	 * Method used to obtain the last modification time of the specified file.
	 * <p>
	 * @param	sFilename		Specifies the name of the file.
	 * <p>
	 * @return		The last modification time of the file.
	 * <p>
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to read the file.
	 */

	public static long lastModified(final String sFilename) throws SecurityException
	{
		long nRet = 0;
		File file = null;

		try
		{
			if (sFilename != null)
			{
				file = new File(sFilename);

				nRet = file.lastModified();
			}
		}
		finally
		{
			file = null;
		}
		return nRet;
	}

	/**
	 * Creates a new empty file in the specified directory, using
	 * the given prefix and suffix in generating its name. The
	 * base portion of the file name is generated by this routine,
	 * and uses the following system property:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpfile
	 * </pre>
	 * If a directory for the file is not specified, the default
	 * directory defined by the following system property is used:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpdir
	 * </pre>
	 * <b>Notes:</b>
     * <ul>
     *  <li>An application that uses this method <b>must</b>
	 *      remove the temporary file. This can be done by using the
	 *      <code>File.delete()</code> method.
	 *  <li>For standard applications,
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpfile</code> and
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpdir</code> are
	 *		set by <code>runjava</code>. For standard servlets, they
	 *      are set by <code>jserv.properties</code>.
	 * </ul>
	 * @param	sPrefix		The prefix string to be used in generating
	 *						the name of the file.
	 * @param	sSuffix		The suffix string to be used in generating
	 *						the name of the file.
	 * @param	fileDir		The directory in which the file is to be
	 *						created, or <code>null</code> if the 
	 *						default directory is to be used.
	 * <p>
	 * @return		Returns a <code>File</code> object that references
	 * 				the newly created file.
	 * <p>
	 * @exception	IOException			Thrown if a file could not be
	 * 									created.
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to create the file.
	 */

	public static File createTempFile(final String sPrefix, final String sSuffix,
									  final File fileDir)
			throws IOException, SecurityException
	{
		File file = null;

		synchronized(oTempFileLock)
		{
			do
			{
				file = generateTempFile(sPrefix, sSuffix, fileDir);

			} while (checkAndCreateTempFile(file) == false);
		}
		return file;
	}


	/**
	 * Creates a new empty file in the default temporary file directory,
	 * using the given prefix and suffix in generating its name. The
	 * base portion of the file name is generated by this routine,
	 * and uses the following system property:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpfile
	 * </pre>
	 * The default temporary file directory defined by the following
	 * system property:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpdir
	 * </pre>
	 * <b>Notes:</b>
     * <ul>
     *  <li>An application that uses this method <b>must</b>
	 *      remove the temporary file. This can be done by using the
	 *      <code>File.delete()</code> method.
	 *  <li>For standard applications,
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpfile</code> and
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpdir</code> are
	 *		set by <code>runjava</code>. For standard servlets, they
	 *      are set by <code>jserv.properties</code>.
	 * </ul>
	 * @param	sPrefix		The prefix string to be used in generating
	 *						the name of the file.
	 * @param	sSuffix		The suffix string to be used in generating
	 *						the name of the file.
	 * <p>
	 * @return		Returns a <code>File</code> object that references
	 * 				the newly created file.
	 * <p>
	 * @exception	IOException			Thrown if a file could not be
	 * 									created.
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to create the file.
	 */

	public static File createTempFile(final String sPrefix, final String sSuffix)
			throws IOException, SecurityException
	{
		return FileUtil.createTempFile(sPrefix, sSuffix, null);
	}

	
	/**
	 * Creates a new empty file in the the default temporary directory.
	 * The base portion of the name is generated by this routine
	 * and uses the following system property:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpfile
	 * </pre>
	 * The default temporary file directory defined by the following
	 * system property:
     * <pre>
     *  com.gianteagle.is.util.FileUtil.tmpdir
	 * </pre>
	 * <b>Notes:</b>
     * <ul>
     *  <li>An application that uses this method <b>must</b>
	 *      remove the temporary file. This can be done by using the
	 *      <code>File.delete()</code> method.
	 *  <li>For standard applications,
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpfile</code> and
 	 *      <code>com.gianteagle.is.util.FileUtil.tmpdir</code> are
	 *		set by <code>runjava</code>. For standard servlets, they
	 *      are set by <code>jserv.properties</code>.
	 * </ul>
	 * @return		Returns a <code>File</code> object that references
	 * 				the newly created file.
	 * <p>
	 * @exception	IOException			Thrown if a file could not be
	 * 									created.
	 * @exception	SecurityException	Thrown if a security manager exists
	 *									and this application is not permitted
	 *									to create the file.
	 */

	public static File createTempFile() throws IOException, SecurityException
	{
		return FileUtil.createTempFile(null, null, null);
	}

	/**
	 * Returns a String containing the name of the directory used to
	 * hold temporary files. This directory name is identified by the
	 * following system property:
	 * <pre>
     *   com.gianteagle.is.util.FileUtil.tmpdir
	 * </pre>
	 * If this sytem property is not set, <code>null</code> is returned.
	 * <p>
	 * @return	A String containing the name of the directory used to
	 *			hold temporary files, or <code>null</code> if the 
	 *			associated system property is not set.
	 */

	public static String getTempDir()
	{
		return System.getProperty("com.gianteagle.is.util.FileUtil.tmpdir");
	}

	/**
	 * Returns a String containing the base name used to name temporary
	 * files. This name is identified by the following system property:
	 * <pre>
     *   com.gianteagle.is.util.FileUtil.tmpfile
	 * </pre>
	 * If this sytem property is not set, <code>null</code> is returned.
	 * <p>
	 * @return	A String containing the base name used to name
	 *			temporary files, or <code>null</code> if the 
	 *			associated system property is not set.
	 */

	public static String getTempFileBaseName()
	{
		return System.getProperty("com.gianteagle.is.util.FileUtil.tmpfile");
	}

	/**
	 * Returns a String containing the name of the directory used to
	 * hold log files (at a system level). This directory name is
	 * identified by the following system property:
	 * <pre>
     *   com.gianteagle.is.util.FileUtil.logdir
	 * </pre>
	 * If this sytem property is not set, <code>null</code> is returned.
	 * <p>
	 * @return	A String containing the name of the directory used to
	 *			hold log files, or <code>null</code> if the 
	 *			associated system property is not set.
	 */

	public static String getLogDir()
	{
		return System.getProperty("com.gianteagle.is.util.FileUtil.logdir");
	}

	/**
	 * Returns a String containing the name of the directory used to
	 * hold lock files (at a system level). This directory name is
	 * identified by the following system property:
	 * <pre>
     *   com.gianteagle.is.util.FileUtil.lockdir
	 * </pre>
	 * If this sytem property is not set, <code>null</code> is returned.
	 * <p>
	 * @return	A String containing the name of the directory used to
	 *			hold lock files, or <code>null</code> if the 
	 *			associated system property is not set.
	 */

	public static String getLockDir()
	{
		return System.getProperty("com.gianteagle.is.util.FileUtil.lockdir");
	}

	/**
	 * Returns <code>true</code> if the specified name includes path
	 * information. Otherwise <code>false</code> is returned.
	 * <p>
	 * @param	sName		The path or file name to check.
	 * <p>
	 * @return		<code>true</code> if the specified file or directory
	 *				name includes path information, otherwise
	 *				<code>false</code>.
	 */

	public static boolean includesPath(final String sName)
	{
		boolean bRet = false;

		if (StringUtil.isEmpty(sName) == false)
		{
			bRet = (sName.indexOf(Util.fileSeparator()) >= 0);
		}
		return bRet;
	}

	/**
	 * Convenience method used to contruct a file name from the specified
	 * directory and file name. This method concatentates the directory
	 * name, a <code>file.separator</code>, and the file name.
	 * <p>
	 * @param	sDir		The directory name.
	 * @param	sName		The file name.
	 * <p>
	 * @return		The complete path name for the file.
	 */

	public static String makeFileName(final String sDir, final String sName)
	{
		String sRet = null;
		StringBuffer sb = null;

		try
		{
			if (StringUtil.isEmpty(sDir) == false ||
				StringUtil.isEmpty(sName) == false)
			{
				sb = new StringBuffer(Defines.IO_BUF_SIZE);

				if (StringUtil.isEmpty(sDir) == false)
				{
					sb.append(sDir);
				
					if (StringUtil.isEmpty(sName) == false)
					{
						if (sDir.endsWith(Util.fileSeparator()) == false)
						{
							sb.append(Util.fileSeparator());
						}
					}
				}
				if (StringUtil.isEmpty(sName) == false)
				{
					sb.append(sName);
				}
				sRet = sb.toString();
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Returns whether or not the specified file has changed based on
	 * the modification time and length.
	 * <p>
	 * @param	sFile		The file to check.
	 * @param	nLastMod	The last modification time to check against.
	 * @param	nLastLen	The last file length to check against.
	 * <p>
	 * @return		<code>true</code> if the file has changed, otherwise
	 *				<code>false</code>.
	 */

	public static boolean fileHasChanged(final String sFile,
                                         final long nLastMod,
								         final long nLastLen)
	{
		boolean bRet = true;

		if (sFile != null && nLastMod > 0 && nLastLen >= 0)
		{
			File f = null;

			try
			{
				f = new File(sFile);

				if (f.lastModified() == nLastMod && f.length() == nLastLen)
				{
					/**
					 * The only time we want to return false (file has not
					 * changed) is when the modification time and the
					 * the length are identical.
					 */

					bRet = false;
				}
			}
			catch (Throwable ignore)
			{
				// If an error occurs, return true.

				bRet = true;
			}
			finally
			{
				f = null;
			}	
		}
		return bRet;
	}

	/**
	 *	Read a file and write the content into another file in
	 *	GZIP (compressed) format. If a <code>null</code> is
	 *	provided as the output file argument, the output file
	 *	name will be generated internally by appending
	 *	&quot;.gz&quot; to the input file name.
	 *	<p>
	 *	@param sInputFile	The name of the input file.
	 *	<p>
	 *	@param sOutputFile	The name of the file to which
	 *						compressed data is to be written, or
	 *						<code>null</code> for automatic
	 *						output file name generation.
	 *	<p>
	 *	@throws	IllegalArgumentException
	 *			If the InputFile argument is <code>null</code>
	 *			or an empty string.
	 *	<p>
	 *	@throws	FileNotFoundException
	 *			If the argument InputFile does not exist, is a
	 *			directory rather than a regular file, or for some
	 *			other reason cannot be opened for reading. If the
	 *			OutputFile exists but is a directory rather than
	 *			a regular file, does not exist but cannot be
	 *			created, or cannot be opened for any other reason.
	 *	<p>
	 *	@throws	IOException
	 *			If any other I/O error occurs in reading or writing
	 *			file data.
	 */

	public static void gzip(final String sInputFile, final String sOutputFile)
		throws	IllegalArgumentException, FileNotFoundException,
				IOException
	{
		FileInputStream fis = null;
		FileOutputStream fos = null;
		GZIPOutputStream gos = null;
		String sOutFile = null;

		if (StringUtil.isEmpty(sInputFile))
		{
			throw new IllegalArgumentException(
				"InputFile argument is null or empty.");
		}

		if (StringUtil.isEmpty(sOutputFile))
		{
			sOutFile = sInputFile + ".gz";
		}
		else
		{
			sOutFile = sOutputFile;
		}
		byte[] buf = new byte[Defines.IO_BUF_SIZE];
		int nBytes = 0;

		try
		{
			fis = new FileInputStream(sInputFile);
			fos = new FileOutputStream(sOutFile, false);
			gos = new GZIPOutputStream(fos);

			while ((nBytes = fis.read(buf)) != -1)
			{
				gos.write(buf, 0, nBytes);
			}
			gos.finish();
		}
		finally
		{
			if (fis != null)
			{
				try { fis.close(); } catch (IOException ignore) { }
				fis = null;
			}
			if (gos != null)
			{
				try { gos.close(); } catch (IOException ignore) { }
				gos = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch (IOException ignore) { }
				fos = null;
			}
			buf = null;
			sOutFile = null;
		}
	}

	/**
	 *	Read a GZIP compressed file and uncompress the data to
	 *	another file.
	 *	<p>
	 *	@param sInputFile	The name of the file to uncompress.
	 *	<p>
	 *	@param sOutputFile	The name of the file to which the
	 *						uncompressed data is to be written.
	 *	<p>
	 *	@throws	IllegalArgumentException
	 *			If either file name argument is <code>null</code>
	 *			or an empty string.
	 *	<p>
	 *	@throws	FileNotFoundException
	 *			If the argument InputFile does not exist, is a
	 *			directory rather than a regular file, or for some
	 *			other reason cannot be opened for reading. If the
	 *			OutputFile exists but is a directory rather than
	 *			a regular file, does not exist but cannot be
	 *			created, or cannot be opened for any other reason.
	 *	<p>
	 *	@throws	IOException
	 *			If the compressed input data is corrupt or if any other
	 *			I/O error occurs in reading or writing file data.
	 */

	public static void gunzip(final String sInputFile, final String sOutputFile)
		throws	IllegalArgumentException, FileNotFoundException,
				IOException
	{
		FileInputStream fis = null;
		GZIPInputStream gis = null;
		FileOutputStream fos = null;

		if (StringUtil.isEmpty(sInputFile))
		{
			throw new IllegalArgumentException(
				"InputFile argument is null or empty.");
		}

		if (StringUtil.isEmpty(sOutputFile))
		{
			throw new IllegalArgumentException(
				"OutputFile argument is null or empty.");
		}

		byte[] buf = new byte[Defines.IO_BUF_SIZE];
		int nBytes = 0;

		try
		{
			fis = new FileInputStream(sInputFile);
			gis = new GZIPInputStream(fis);
			fos = new FileOutputStream(sOutputFile, false);

			while ((nBytes = gis.read(buf)) != -1)
			{
				fos.write(buf, 0, nBytes);
			}
		}
		finally
		{
			if (gis != null)
			{
				try { gis.close(); } catch (IOException ignore) { }
				gis = null;
			}
			if (fis != null)
			{
				try { fis.close(); } catch (IOException ignore) { }
				fis = null;
			}
			if (fos != null)
			{
				try { fos.close(); } catch (IOException ignore) { }
				fos = null;
			}
			buf = null;
		}
	}

    //--------------------------------------------------------------
	// Private methods.
    //--------------------------------------------------------------

	/**
	 * Private method used to generate a temporary file. The name is
	 * constructed using the specified directory, prefix, and suffix.
	 * In addition, a random number sequence is added to the file
	 * name in order to help make it unique.
	 * <p>
	 * @param	sPrefix		File name prefix to use. May be null.
	 * @param	sSuffix		File name suffix to use. May be null.
	 * @param	fileDir		Directory to create the temporary file in.
	 *						May be null.
	 *<p>
	 *@return		A <code>File</code> object for the temporary file.
	 */

	private static File generateTempFile(final String sPrefix, 
										 final String sSuffix,
										 final File fileDir)
					
	{
		// Note: Do not catch and ignore exceptions. Doing so could
		// cause the temporary file creation process to go into an
		// endless loop.

		String sBase = getTempFileBaseName();
		String sDir = getTempDir();

		final StringBuffer sbFileName = new StringBuffer();

		if (fileDir != null)
		{
			sbFileName.append(fileDir.getAbsolutePath());
		}
		else
		{
			if (StringUtil.isEmpty(sDir) == false)
			{
				sbFileName.append(sDir);
			}
		}
		if (sbFileName.toString().endsWith(Util.fileSeparator()) == false)
		{
			sbFileName.append(Util.fileSeparator());
		}

		if (StringUtil.isEmpty(sPrefix) == false)
		{
			sbFileName.append(sPrefix);
		}
		
		if (StringUtil.isEmpty(sBase) == false)
		{
			sbFileName.append(sBase);
		}
		else
		{
			sbFileName.append("tmpfile");
		}
		
		if (nTempFileCounter == -1)
		{
			nTempFileCounter = new Random().nextInt() & 0xffff;
		}
		nTempFileCounter++;

		sbFileName.append(nTempFileCounter);

		if (StringUtil.isEmpty(sSuffix) == false)
		{
			sbFileName.append(sSuffix);
		}

		sBase = null;
		sDir = null;

		return new File(sbFileName.toString());
	}

	/**
	 * Pivate method used to check and create the specified file.
	 * If the file cannot be created, the method returns false.
	 * <p>
	 * @param	file	File to check and create.
	 * <p>
	 * @return		<code>true</code> if the file was created, otherwise
	 * 				<code>false</code>.
	 * <p>
	 * @exception	IOException		Thrown if an I/O error occrs in checking
	 * 							`	the file.
	 * @exception	SecurityException	Thrown if a security error occurs
	 * 									in checking the file.
	 */

	private static boolean checkAndCreateTempFile(final File file)
							throws IOException, SecurityException
	{
		boolean bRval = false;

		// Note: Do not attempt to catch and handle IOException
	 	// or SecurityException. These exception should be passed
		// back up the call sequence. Catching and handling could
		// cause the temporary file creation logic to get into
	 	// an endless loop - a very bad thing.

		if (file.exists() == false)
		{
			FileOutputStream fos = null;

			try
			{
				fos = new FileOutputStream(file);

				bRval = true;
			}
			finally
			{
				if (fos != null)
				{
					fos.close();
					fos = null;
				}
			}
		}
		return bRval;
	}

    //--------------------------------------------------------------
	// Private member variables.
    //--------------------------------------------------------------

	// oTempFileLock is used to provide a lock around the
	// code that generates a temporary file. Requests to generate
	// a temporary file are effectively queued by synchronizing 
	// on this object.

	private static final Object oTempFileLock = new Object();

	// nTempFileCounter is used in generating the name of the 
	// temporary file. The first request causes the value to be
	// initialized with a random integer. Subsequent requests
	// simply increment the counter.
 
	private static int nTempFileCounter = -1;
}
