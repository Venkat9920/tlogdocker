/**
 * UUID.java
 */

package com.gianteagle.is.util;

/**
 * Class used to generate a UUID/UUID.
 * <p>
 * @author	ReichertSF (cleanup)
 */

public final class UUID
{
	/**
	 * Default constructor is private. No once should construct
	 * an instance of this class.
	 */

	private UUID()
	{
	}

	/**
     * Static method used to generate and return a single UUID.
     * <p>
     * @return Returns a <code>String</code> object containing the UUID.
     */

	public static String getUUID()
	{
		return java.util.UUID.randomUUID().toString();
		
	}

	/**
	 * Test application used to print a couple of UUIDs. 
	 * <p>
	 * @param	args		Command line arguments, ignored.
	 */
	
	public static void main(String[] args)
	{
		try
		{
			// Print a couple of UUIDs.

			System.out.println("UUID: " + UUID.getUUID());
			System.out.println("UUID: " + UUID.getUUID());
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
	}
}
