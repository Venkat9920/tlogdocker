/**
 *  Base64Common.java
 */

package com.gianteagle.is.util;

import java.io.IOException;
import java.io.InputStream;

/**
 *  Package private class used to implement data and methods common
 *  to BASE64 Content Transfer Encoding implementation classes
 *  Base64Encode and Base64Decode. <em>This class contains no
 *  public methods or data and is intended soley to serve as an
 *  &quot;inheritance base&quot; for these implementation classes</em>.
 */
 
class Base64Common
{ 
    /**
     *  Default class constructor.
     */

	protected Base64Common()
    {
    }

    /**
     *  Reads bytes from the input stream into the argument buffer.
     *  An end-of-stream indicator is returned only if no data was
     *  buffered.
     *  <p>
     *  @param  inStream    Reference to an InputStream from which
     *                      data is to be read.
     *  @param  buffer      Reference to a byte array to hold the bytes
     *                      retrieved from the input stream.
     *  @param  offset      The offset into the byte buffer at which to
     *                      begin writing data.
     *  @param  len         The number of bytes to retrieve.
     *  <p>
     *  @return     An int value indicating the number of bytes read
     *              into the argument buffer or (-1) if the end of the
     *              stream was encountered <em>and</em> no data was
     *              read during the call.
     *  <p>
     * @exception	IllegalArgumentException	Thrown if the arguments are
     * 											invalid.
     * @exception	IOException					Thrown if the input stream is
     * 											<code>null</code> or an I/O
     * 											error occurs.    
     */
     
    @SuppressWarnings("static-method")
	protected int readBytes(InputStream inStream, byte[] buffer,
                            int offset, int len)
        throws IOException, IllegalArgumentException
    {
        int nBytesRead = len;
        int nByte = -1;
        
        if (inStream == null)
            throw new IOException("InputStream arg is null.");
        else if (buffer == null)
            throw new IllegalArgumentException("Byte buffer arg is null.");
        else if (offset < 0 || len < 1 || (offset + len) > buffer.length)
            throw new IllegalArgumentException("Offset and/or Len argument(s) out of range.");
            
    	for (int i = 0; i < len; i++)
        {
    	    nByte = inStream.read();
    	    if (nByte == -1)
            {
                nBytesRead = (i == 0 ? -1 : i);
                break;
            }    
    	    buffer[i + offset] = (byte) nByte;
    	}
    	return nBytesRead;
    }
            
    //---------------------------------------------------------------
    //  Package Private Constants
    //---------------------------------------------------------------

    /**
     *  Definition of character used to pad an incomplete BASE64
     *  encoded group of bytes when the raw data totals less than
     *  {@link #BytesPerGroupEncode} (3) bytes.
     */   
    protected static final char padChar = '=';

    /**
     *  Maximum number of bytes of data that can be encoded
     *  into a BASE64 character group.
     */
    protected static final int BytesPerGroupEncode = 3;

    /**
     *  Number bytes in a BASE64 encoded character group.
     */
    protected static final int BytesPerGroupDecode = 4;

    /**
     *  Maximum number of (input) bytes that can be encoded into a
     *  &quot;line&quot; of BASE64 data.
     */
    protected static final int BytesPerLineEncode = 57;

    /**
     *  Maximum number of bytes that can appear in a
     *  &quot;line&quot; of BASE64 encoded data, exclusive of
     *  the line termination sequence.
     */
    protected static final int BytesPerLineDecode = 76;
    
    /**
     *  Base64 Content Transfer Encoding alphabet character
     *  map shared by encode / decode logic.
     */
    protected final static char[] B64CodeMap =
    {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
        'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
        'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3',
        '4', '5', '6', '7', '8', '9', '+', '/'
    };
}
