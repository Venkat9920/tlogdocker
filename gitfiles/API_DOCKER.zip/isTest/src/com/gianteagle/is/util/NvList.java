/**
 * NvList.java
 */

package com.gianteagle.is.util;

import com.gianteagle.is.util.Defines;
import com.gianteagle.is.util.Util;


/**
 * Class used to maintain a fixed capacity list of <code>NvPair</code>
 * objects. By default, the list operates in a FIFO manner when adding
 * items. That is, items are added to the end of the list. If the list
 * is full and an attempt is made to add an item, the first item is
 * removed and the item is added to the end of the list. This behavior
 * of the list may be altered by calling the <code>setBehavior()</code>
 * method.
 * <p>
 * @author	ReichertSF
 */

public final class NvList
{
	/**
	 * Default constructor which fixes the list capacity at 128.
	 */

	public NvList()
	{
		this.nvList = new NvPair[DEF_LIST_SIZE];

		for (int i = 0 ; i < this.nvList.length ; ++i)
		{
			this.nvList[i] = null;
		}
	}

	/**
	 * Constructor which sets the list capacity at the specified size.
	 * <p>
	 * @param	nCapacity	The capacity (size) of the list.
	 * <p>
	 * @exception	IllegalArgumentException	Thrown if the capacity
	 *											is specified as less
	 *											than 1 or greater than
	 *											16K (1024 * 16).
	 */

	public NvList(final int nCapacity) throws IllegalArgumentException
	{
		if (nCapacity <= 0 || nCapacity > NvList.MAX_LIST_SIZE)
		{
			throw new IllegalArgumentException("Invalid list capacity (" +
                    nCapacity + ") specified!");
		}
		this.nvList = new NvPair[nCapacity];

		for (int i = 0 ; i < this.nvList.length ; ++i)
		{
			this.nvList[i] = null;
		}
	}

	/**
	 * Constructor which creates an <code>NvList</code> object
	 * from an existing <code>NvList</code> object.
	 * <p>
	 * @param	srcList		Source <code>NvList</code> to create
	 *						the object from.
	 * <p>
	 * @exception	NullPointerException	Thrown if the source list
	 *										is null.
	 */

	public NvList(final NvList srcList)
	{
		if (srcList == null)
		{
			throw new NullPointerException("Source list is null!");
		}
		this.nvList = new NvPair[srcList.capacity()];

		for (int i = 0 ; i < this.nvList.length ; ++i)
		{
			this.nvList[i] = null;
		}
		for (int i = 0 ; i < srcList.length() ; ++i)
		{
			this.add(new NvPair(srcList.get(i)));
		}
	}

	/**
	 * Destroys the object and releases any resources held by it. Note
	 * that even though this method is publicly available, it should not
	 * be directly called. Use the <code>clear</code> method instead.
	 * <p>
	 * @exception	Throwable	The exception raised by this method, if any.
	 */

	@Override
	protected void finalize() throws Throwable
	{
		this.clear();
		super.finalize();
	}

	/**
	 * Clears the list and releases any resources used by it.
	 */

	public void clear()
	{
		if (this.nvList != null)
		{
			for (int i = 0 ; i < this.nvList.length ; ++i)
			{
				if (this.nvList[i] != null)
				{
					this.nvList[i].destroy();
					this.nvList[i] = null;
				}
			}
			this.nvList = null;
		}
		this.nCount = 0;
	}

	/**
	 * Add an item to the list. Note that if the list has reached
	 * its maximum capacity (size), the first item is removed and
	 * the new one is added to the end.
	 * <p>
	 * @param	nvPair		Item to add to the list.
	 */

	public void add(final NvPair nvPair)
	{
		if (nvPair != null)
		{
			if (this.nvList != null)
			{
				if (this.nCount < this.nvList.length)
				{
					/**
					 * The list has not reached its capacity, add the
					 * item to the end of the list.
					 */

					this.nvList[this.nCount] = nvPair;
					++this.nCount;
				}
				else
				{
					if (this.behavior == null)
					{
						this.behavior = Behavior.FIFO;
					}

					/**
					 * The list has reached its capacity. Take the
					 * appropriate action.
					 * 
					 * FIFO = Drop first, add to end.
					 * EXCEPTION = Throw exception.
					 * IGNORE = Do nothing.
					 */
		
					if (this.behavior == Behavior.FIFO)
					{
						/**		
						 * Behavior is FIFO, drop the first item, and add
						 * the item to the end.
						 */

						for (int i = 0 ; i < (this.nvList.length - 1) ; ++i)
						{
							this.nvList[i] = null;
							this.nvList[i] = this.nvList[i + 1];
						}
						this.nvList[this.nvList.length - 1] = nvPair;
					}
					else if (this.behavior == Behavior.EXCEPTION)
					{
						throw new IndexOutOfBoundsException(
									"Attempt to add item to full list! " +
                                    "Capacity is " +
                                            this.nvList.length +
                                    " items!");
					}
				}
			}
		}
	}

	/**
	 * Add an item (name and value) to the list. Note that if the list
	 * has reached its maximum capacity (size), the first item is removed
	 * and the new one is added to the end.
	 * <p>
	 * @param	sName		Name of the item to add to the list.
	 * @param	sValue		Value of the item to add to the list.
	 * <p>
	 * @exception	NullPointerException	Thrown if the name is
	 *										<code>null</code> or
	 *										the empty string.
	 */

	public void add(final String sName, final String sValue) 
											throws NullPointerException
	{
		this.add(new NvPair(sName, sValue));
	}

	/**
	 * Returns a reference (<b>not a copy</b>) to the name/value pair
	 * corresponding to the specified index. Yep, just like an array
	 * offset start at 0 and go to length - 1 to access all elements.
	 * <p>
	 * @param	nIndex		The index to return the reference for.
	 * <p>
	 * @return		The name/value pair at the specified index.
	 */

	public NvPair get(final int nIndex)
	{
		NvPair nvPair = null;

		if (this.nvList != null)
		{
			if (nIndex < 0 || nIndex >= this.length())
			{
				throw new IndexOutOfBoundsException(
							"Invalid index (" + nIndex +
							") specified!");
			}
			nvPair = this.nvList[nIndex];
		}
		return nvPair;
	}

	/**
	 * Returns the number of items (not the capacity) in the list.
	 * <p>
	 * @return	The number of items in the list
	 */

	public int length()
	{
		return this.nCount;
	}
	
	/**
	 * Returns the capacity of the list.
	 * <p>
	 * @return	The capacity of the list.
	 */

	public int capacity()
	{
		int nCapacity = 0;

		if (this.nvList != null)
		{
			nCapacity = this.nvList.length;
		}
		return nCapacity;
	}

	/**
	 * Set the behavior of the list to the specified behavior.
	 * <p>
	 * @param	b	The specified behavior.
	 */

	public void setBehavior(final Behavior b)
	{
		if (b != null)
		{
			this.behavior = b;
		}
	}

	/**
	 * Returns a string containing the list of events, with a line
	 * separator between the pairs. This method is used primarily
	 * for debugging purposes.
	 * <p>
	 * @return		A string containing the list of name/value pairs.
	 */

	@Override
	public String toString()
	{
		StringBuilder sb = null;
		String sRet = null;
		int i = 0;

		try
		{
			if (this.nvList != null)
			{
				if (this.nvList[0] != null)
				{
					sb = new StringBuilder(Defines.IO_BUF_SIZE);

					for (i = 0 ; i < this.nvList.length ; ++i)
					{
						if (this.nvList[i] != null)
						{
							sb.append(this.nvList[i].getName());
							sb.append(",");
							sb.append(StringUtil.format(
												this.nvList[i].getValue()));

							if ((i + 1) < this.nvList.length)	
							{
								if (this.nvList[i + 1] != null)
								{
									sb.append(Util.lineSeparator());
								}
							}
						}
					}
				}
			}
			if (sb != null)
			{
				sRet = sb.toString();
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Enumerated type used to define the behavior of the list.
	 */

	public enum Behavior
	{
		/**
		 * Defines the default behavior of the list as FIFO. New items
	 	 * are added to the end of the list. When a new item is added
		 * to a full list, the first item is removed and the item is 
		 * added to the end of the list.
		 */

		FIFO,

		/**
	 	 * Defines the behavior that attempts to add items to a full
		 * list are silently ignored.
	 	 */

		IGNORE,

		/**
		 * Defines the behavior that attempts to add items to a full
	 	 * list will result in an <code>IndexOutOfBoundsException</code>
		 * being thrown.
		 */

        EXCEPTION
    }

	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------

	private NvPair[] nvList = null;
	private int nCount = 0;
	private static final int DEF_LIST_SIZE = 128;
	private static final int MAX_LIST_SIZE = (1024 * 16);

	private Behavior behavior = Behavior.FIFO;
}
