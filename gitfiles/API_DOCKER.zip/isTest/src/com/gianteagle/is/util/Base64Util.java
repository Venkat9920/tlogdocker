/**
 * Base64Util.java
 */

package com.gianteagle.is.util;

import java.util.Base64;

/**
 * Base64 encode and decode utilities.
 * <p>
 * @author	Reichertsf
 *
 */

public final class Base64Util
{
	/**
	 * Default constructor.
	 */
	
	private Base64Util()
	{
	}
	
	/**
	 * Base64 encodes the specified string.
	 * <p>
	 * @param	sStr		The string to encode.
	 * <p>
	 * @return		String containing the encoded string, <code>null</code>
	 * 				if unable to encode the string.
	 */
	
	public static String encode(final String sStr)
	{
		String sRet = null;
		
		if (StringUtil.isEmpty(sStr) == false)
		{
			sRet = Base64Util.encode(sStr.getBytes());
		}
		return sRet;
	}

	/**
	 * Base64 encodes the specified byte array.
	 * <p>
	 * @param	byteData		The byte array to encode.
	 * <p>
	 * @return		String containing the encoded byte array, 
	 * 				<code>null</code> if unable to encode..
	 */
	
	public static String encode(final byte[] byteData)
	{
		String sRet = null;
		Base64.Encoder base64Encoder = null;

		try
		{
			if (byteData != null)
			{
				base64Encoder = Base64.getEncoder();
				
				if (base64Encoder != null)
				{
					sRet = base64Encoder.encodeToString(byteData);
				}
			}
		}
		finally
		{
			base64Encoder = null;
		}
		return sRet;
	}

	/**
	 * Base64 decodes the specified string.
	 * <p>
	 * @param	sStr		The string to decode.
	 * <p>
	 * @return		Byte array containing the decoded string, <code>null</code>
	 * 				if unable to decode the string.
	 */
	
	public static byte[] decode(final String sStr)
	{
		byte[] rawBytes = null;
		Base64.Decoder base64Decoder = null;
		
		try
		{
			if (StringUtil.isEmpty(sStr) == false)
			{
				base64Decoder = Base64.getDecoder();
			
				rawBytes = base64Decoder.decode(sStr);
			}
		}
		finally
		{
			base64Decoder = null;
		}
		return rawBytes;
	}
}
