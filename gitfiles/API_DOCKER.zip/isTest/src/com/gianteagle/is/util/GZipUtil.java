/**
 * GZipUtil.java
 */

package com.gianteagle.is.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Class used to maintain various GZIP related utility methods.
 * <p>
 * @author ReichertSF
 */

public final class GZipUtil
{
	/**
     * Constructor is private, because only Class methods and constants
	 * are supported.
	 */

	private GZipUtil()
	{
	}
	
	/**
	 * Compresses a <code>String</code> using GZip and returns a byte
	 * array containing the compressed data.
	 * <p>
	 * @param	sStr		The string to compress.
	 * <p>
	 * @return		A byte array containing the compressed string.
	 */
	
	public static final byte[] gzip(final String sStr)
	{
		byte[] byteGZipData = null;
		
		if (StringUtil.isEmpty(sStr) == false)
		{
			byteGZipData = GZipUtil.gzip(sStr.getBytes());
		}
		return byteGZipData;
	}

	/**
	 * Compresses a byte array using GZip and returns a byte array
	 * containing the compressed data.
	 * <p>
	 * @param	byteData	Byte array containing the input data to be
	 * 						compressed.
	 * <p>
	 * @return		A byte array containing the compressed data.
	 */
	
	@SuppressWarnings("null")
	public static byte[] gzip(final byte[] byteData)
	{
		byte[] byteGZipData = null;
		ByteArrayOutputStream bos = null;
		GZIPOutputStream gos = null;
		
		try
		{
			if (byteData != null)
			{
				bos = new ByteArrayOutputStream();
				gos = new GZIPOutputStream(bos);
				
				gos.write(byteData, 0, byteData.length);
				gos.finish();

				byteGZipData = bos.toByteArray();
			}
		}
		catch (IOException ex)
		{
			byteGZipData = null;
		}
		finally
		{
			if (gos != null)
			{
				try { gos.close(); } catch (Throwable ignore) { }
				gos = null;
			}
			if (bos != null)
			{
				try { bos.close(); } catch (Throwable ignore) { }
				bos = null;
			}
		}
		return byteGZipData;
	}

	/**
	 * Uncompresses a byte array using GZip and returns a byte array
	 * containing the uncompressed data.
	 * <p>
	 * @param	byteGZipData	Byte array containing the input data to be
	 * 							compressed.
	 * <p>
	 * @return		A byte array containing the uncompressed data.
	 */
	
	@SuppressWarnings("null")
	public static byte[] gunzip(final byte[] byteGZipData)
	{
		byte[] byteData = null;
		ByteArrayInputStream bis = null;
		ByteArrayOutputStream bos = null;
		GZIPInputStream gis = null;
		
		try
		{
			if (byteGZipData != null)
			{
				bis = new ByteArrayInputStream(byteGZipData);
				gis = new GZIPInputStream(bis);
				bos = new ByteArrayOutputStream(Defines.IO_BUF_SIZE);

				FileUtil.copy(gis, bos);
				
				byteData = bos.toByteArray();
			}
		}
		catch (IOException ex)
		{
			byteData = null;
		}
		finally
		{
			if (gis != null)
			{
				try { gis.close(); } catch (Throwable ignore) { }
				gis = null;
			}
			if (bis != null)
			{
				try { bis.close(); } catch (Throwable ignore) { }
				bis = null;
			}
			if (bos != null)
			{
				try { bos.close(); } catch (Throwable ignore) { }
				bos = null;
			}
		}
		return byteData;
	}
}
