/**
 * StringUtil.java
 */

package com.gianteagle.is.util;

import java.math.BigDecimal;

/**
 * Class used to maintain various String related utility methods.
 * <p> 
 * @author ReichertSF
 */

public final class StringUtil
{
    /**
     *  Test a String to see if it is either null or empty.
     *  <p>
     *  @param sStr String to test.
     *  <p>
     *  @return <b>False</b> if the argument string is both
     *      non-null and greater than zero length. Otherwise,
     *      <b>true</b> is returned.
     */

    public static boolean isEmpty(final String sStr)
    {
        return (sStr == null || (sStr.length() < 1));
    }  
    
    /**
     *  Test a String to see if it is not null or empty.
     *  <p>
     *  @param sStr String to test.
     *  <p>
     *  @return <b>False</b> if the argument string is both
     *      null and less than zero length. Otherwise,
     *      <b>true</b> is returned.
     */

    public static boolean isNonEmpty(final String sStr)
    {
        return !StringUtil.isEmpty(sStr);
    } 

	/**
	 * Tests whether or not a string consists entirely of digits.
	 * <p>
	 * @param	sStr	The String to test.
	 * <p>
	 * @return	<code>true</code> if the string is composed entirely
	 *			of digits, otherwise <code>false</code>. If the string
	 *			is <code>null</code>, <code>false</code> is returned.
	 */

	public static boolean isNumeric(final String sStr)
	{
		boolean bRval = false;
		int i = 0;

		if (StringUtil.isEmpty(sStr) == false)
		{
			bRval = true;

			for (i = 0 ; i < sStr.length() && bRval == true ; ++i)
			{
				bRval = Character.isDigit(sStr.charAt(i));
			}
		}
		return bRval;
	}
	
	/**
	 * Parses the string argument as a signed decimal integer, in a manner
	 * similar to <code>Integer.parseInt()</code>. The major differences are
	 * that it:
	 * <ul>
	 *  <li>Does not throw a <code>NumberFormatException</code> if it
	 *      occurs when parsing the string.
	 *  <li>Allows you to specify a default value to return if a
	 *      <code>NumberFormatException</code> occurs when parsing
	 *      the string, or if the string is empty (or <code>null</code>).
     * </ul>
	 * @param	str		The string containing the integer.
	 * @param	nDef	The default value to use if the string cannot
	 *					be parsed as a number, or the string is empty.
	 * <p>
	 * @return		The integer value represented by the string.
	 */

	public static int parseInt(final String str, final int nDef)
	{
		int nValue = nDef;

		if (StringUtil.isEmpty(str) == false)
		{
			try
			{
				nValue = Integer.parseInt(str);
			}
			catch (NumberFormatException ex)
			{
				nValue = nDef;
			}
		}
		return nValue;
	}

	/**
	 * Parses the string argument as a signed decimal long in a manner
	 * similar to <code>Long.parseLong()</code>. The major differences are
	 * that it:
	 * <ul>
	 *  <li>Does not throw a <code>NumberFormatException</code> if it
	 *      occurs when parsing the string.
	 *  <li>Allows you to specify a default value to return if a
	 *      <code>NumberFormatException</code> occurs when parsing
	 *      the string, or if the string is empty (or <code>null</code>).
     * </ul>
	 * @param	str		The string containing the long.
	 * @param	nDef	The default value to use if the string cannot
	 *					be parsed as a number, or the string is empty.
	 * <p>
	 * @return		The long value represented by the string.
	 */

	public static long parseLong(final String str, final long nDef)
	{
		long nValue = nDef;

		if (StringUtil.isEmpty(str) == false)
		{
			try
			{
				nValue = Long.parseLong(str);
			}
			catch (NumberFormatException ex)
			{
				nValue = nDef;
			}
		}
		return nValue;
	}

	/**
	 * Returns the boolean value of the specified string. "true" is
	 * returned if and only if the string contains the word "true",
	 * ignoring case.
	 * <p>
	 * @param	sStr	The string to return the value of.
	 * <p>
	 * @return		The boolean value associated with the string.
	 */

	public static boolean parseBoolean(final String sStr)
	{
		boolean bRet = false;
	
		if (sStr != null)
		{
			bRet = sStr.equalsIgnoreCase("true");
		}
		return bRet;
	}

	/**
	 * Method used to format a string for display purposes.
	 * If the string is <code>null</code>, the literal string
	 * <code>{null}</code> is returned. Otherwise the string itself
	 * is returned.
	 * <p>
	 * @param	sStr		String to format.
	 * <p>
	 * @return		The formatted string. Returns the string 
     * 				<code>{null}</code> if the value is <code>null</code>
	 */

	public static String format(final String sStr)
	{
		return (sStr == null ? "{null}" : sStr);
	}

	/**
	 * Format a string for display purposes. If the string is 
	 * <code>null</code>, the specified default is returned, otherwise
	 * the string itself is returned.
	 * <p>
	 * @param	sStr		The String to format.
	 * @param 	sDefault	The default to use.
	 * <p>
	 * @return		The formatted string, or the default value if the
	 * 				string is <code>null</code>.
	 */
	
	public static String format(final String sStr, final String sDefault)
	{
		return (sStr == null ? sDefault : sStr);
	}

	/**
	 * Method used to format a boolean value for display purposes.
	 * <p>
	 * @param	bVal		Boolean value to format.
	 * <p>
	 * @return		The formatted string.
	 */

	public static String format(final boolean bVal)
	{
		return (bVal == true ? "true" : "false");
	}

	/**
	 * Method used to format a Boolean value for display purposes.
	 * <p>
	 * @param	bVal		Boolean value to format.
	 * <p>
	 * @return		The formatted string.
	 */

	public static String format(final Boolean bVal)
	{
		return (bVal == null ? "{null}" : bVal.toString());
	}

	/**
     * Format a BigDecimal for display purposes.
	 * If the decimal is <code>null</code>, the literal string
	 * <code>{null}</code> is returned. Otherwise the string value
	 * is returned.
     * <p>
     * @param	bd		BigDecimal to format.
     * <p>
     * @return		The formatted string. Returns the string 
     * 				<code>{null}</code> if the value is <code>null</code>.
     */
    
    public static String format(final BigDecimal bd)
    {
    	return bd == null ? "{null}" : bd.toString();
    }
    
	/**
	 * Right justifies a string to the specified length using the
	 * specified padding character.
	 * <p>
	 * @param		sText		String to right justify.
	 * @param		nLength		Length to justify to.
	 * @param		cPad		Pad character to use.
	 * <p>
	 * @return		Returns a String object right justified to the
	 *				specified length with the specified pad character.
	 */

	public static String rightJustify(final String sText, final int nLength, 
									  final char cPad)
	{
		String sRet = null;
		StringBuilder sb = null;
		
		try
		{
			if (sText != null)
			{
				if (nLength < 1 || nLength <= sText.length())
				{
					sRet = sText;
				}
				else
				{
					sb = new StringBuilder(nLength);

					for (int i = 0 ; i < (nLength - sText.length()) ; ++i)
					{
						sb.append(cPad);
					}
					sb.append(sText);

					sRet = sb.toString();
				}
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Left justifies a string to the specified length using the
	 * specified padding character.
	 * <p>
	 * @param		sText		String to left justify.
	 * @param		nLength		Length to justify to.
	 * @param		cPad		Pad character to use.
	 * <p>
	 * @return		Returns a String object left justified to the
	 *				specified length with the specified pad character.
	 */

	public static String leftJustify(final String sText, final int nLength, 
									 final char cPad)
	{
		String sRet = null;
		StringBuilder sb = null;
		
		try
		{
			if (sText != null)
			{
				if (nLength < 1 || nLength <= sText.length())
				{
					sRet = sText;
				}
				else
				{
					sb = new StringBuilder(nLength);
					sb.append(sText);

					while (sb.length() < nLength)
					{
						sb.append(cPad);
					}
					sRet = sb.toString();
				}
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Removes all leading occurences of the specified character
	 * from the string.
	 * <p>
	 * @param	ch		The character to remove.
	 * @param	sStr	The string to remove the leading character from.
	 * <p>
	 * @return		A string with the specified leading character removed.
	 */
	
	public static String rmLead(final char ch, final String sStr)
	{
		String sRet = null;
		int ndx = 0;
		
		if (sStr != null)
		{
			while (ndx < sStr.length() && sStr.charAt(ndx) == ch)
			{
				++ndx;
			}
			sRet = sStr.substring(ndx);
		}
		return sRet;
	}
	
	/**
	 * Removes the trailing string from the specified string if it exists.
	 * <p>
	 * @param	sStr	The base string.
	 * @param	sTrail	The trailing string to remove from the base string.
	 * <p>
	 * @return		The base string with the trailing string removed.
	 */

	public static String rmTrail(final String sStr, final String sTrail)
	{
		String sRet = sStr;
		
		if (sStr != null && sTrail != null)
		{
			if (sStr.endsWith(sTrail) == true)
			{
				sRet = sStr.substring(0, sStr.length() - sTrail.length());
			}
		}
		return sRet;
	}
	
	/**
	 * Converts a single String containing a set of tokens which
	 * a separated by the specified delimiter to a array of
	 * Strings containing the tokens. This implementation differs
	 * slightly from that which is provided by both the standard
	 * StringTokenizer and StreamTokenizer. That is, null tokens
	 * are processed correctly. In other words, a pair of
	 * consecutive delimiters (or a trailing delimiter) indicates
	 * a <code>null</code> token.
	 * <p>
	 * For example, if the delimiter is specified as a comma,
	 * the following string:
	 * <pre>
	 *   abc,def,ghi
	 * </pre>
	 * is parsed into the following array of strings:
	 * <pre>
	 *   arg[0] = "abc"
	 *   arg[1] = "def"
	 *   arg[2] = "ghi"
	 * </pre>
	 * As another example using a comma as the delimiter, the
	 * following string:
	 * <pre>
	 *   abc,,ghi,
	 * </pre>
	 * is parsed into the following array of strings:
	 * <pre>
	 *   arg[0] = "abc"
	 *   arg[1] = null
	 *   arg[2] = "ghi"
	 *   arg[3] = null
	 * </pre>
	 * @param	sStr		The String to be parsed.
	 * @param	sDelim		The delimiter separating the tokens.
	 * <p>
	 * @return				An array of String objects containing the
	 *						individual tokesn. Empty tokens are 
	 *						returned in the array as <code>null</code>.
	 */

	public static String[] parseString(final String sStr, final String sDelim)
	{
		String[] args = null;

		if (sStr != null)
		{
			int ndx = 0;				// Current index into string
			int nOfs = 0;				// Current offset of token
			int nCount = 0;				// Number of tokens
			boolean bDone = false;		// Loop control

			// First loop through the string and count the number
			// of tokens. This is so that we can allocate the
			// array that will hold the tokens.

			while (bDone == false)
			{
				ndx = sStr.indexOf(sDelim, nOfs);

				if (ndx < 0)
				{
					++nCount;

					bDone = true;
				}
				else
				{
					++nCount;

					if ((ndx + 1) <= (sStr.length() - 1))
					{
						nOfs = ndx + 1;		// Increment to next token
					}
					else
					{
						// We're at the end of the string, so there
						// is no point in continuing, but we do have
						// to count the last (null) argument.

						++nCount;

						bDone = true;
					}
				}
			}

			args = new String[nCount];		// Allocate the array

			bDone = false;
			ndx = 0;
			nOfs = 0;
			int nElem = 0;

			// Initialize each array element to null.

			for (nElem = 0 ; nElem < nCount ; ++nElem)
			{
				args[nElem] = null;
			}
			
			// Now loop through and extract each token. If one is null,
			// go to the next because the array was already initialized
			// to null.

			for (nElem = 0 ; nElem < nCount && bDone == false ; ++nElem)
			{
				ndx = sStr.indexOf(sDelim, nOfs);

				if (ndx < 0)
				{
					// At the end, get the last token.

					args[nElem] = sStr.substring(nOfs);

					bDone = true;
				}
				else
				{
					if (nOfs < ndx)
					{
						// Get the token and put it in the array

						args[nElem] = sStr.substring(nOfs, ndx);
					}

					if ((ndx + 1) <= (sStr.length() - 1))
					{
						nOfs = ndx + 1;		// Increment to next token
					}
					else
					{
						// The last token is null, no need to
						// keep processing.

						bDone = true;
					}
				}
			}
		}
		return args;
	}

	/**
     *  Converts any specially encoded characters embedded within the argument
     *  string to their original (character) form.  This method handles any
     *  characters expressed with the Java Unicode encoding scheme
	 *  (&#092;u0000 to &#092;uFFFF) as well as the following special
	 *  escape sequences:
     *  <pre>
     *      \b  backspace
     *      \t  tab
     *      \n  linefeed (newline)
     *      \r  carrage return
     *      \"  double quote
     *      \'  single quote
     *      \\  backslash
     *  </pre>
     *  <p>
     *  @param sStr   	String (potentially) containing special character
     *                  escape sequences to be converted.
     *  @return         String with any encoded special characters converted
     *                  to their original form  or <b>null</b> if the
     *                  argument string was null.
     */

    public static String decodeSpecialChars(final String sStr)
    {
    	String sRet = null;
        char aChar;
        int len = 0;
        StringBuilder outBuffer = null;
        
        try
        {
        	if (sStr != null)
        	{
	            len = sStr.length();
		        
		        outBuffer = new StringBuilder(len);
		
		        for(int x=0; x<len; )
		        {
		            aChar = sStr.charAt(x++);
		            if (aChar == '\\' && x < len)           // Need at least 1 more char at this point.
		            {
		                aChar = sStr.charAt(x++);
		                if (aChar == 'u' && x < (len - 3))   // Need at least 4 more chars at this point.
		                {
		                    // Read the xxxx
		                    int value = 0;
		        		    for (int i=0; i<4; i++) 
		                    {
		        		        aChar = sStr.charAt(x++);
		        		        
		        		        switch (aChar)
		                        {
		        		            case '0': 
		        		            case '1': 
		        		            case '2': 
		        		            case '3': 
		        		            case '4':
		        		            case '5': 
		        		            case '6': 
		        		            case '7': 
		        		            case '8': 
		        		            case '9':
		        		                value = (value << 4) + aChar - '0';
		        			            break;
		        			        case 'a': case 'b': case 'c':
		                            case 'd': case 'e': case 'f':
		        			            value = (value << 4) + 10 + aChar - 'a';
		        			            break;
		        			        case 'A': case 'B': case 'C':
		                            case 'D': case 'E': case 'F':
		        			            value = (value << 4) + 10 + aChar - 'A';
		        			            break;
		        			        default:
		                                throw new IllegalArgumentException(
		                                		"Malformed \\uxxxx encoding.");
		                        }
		                    }
		                    outBuffer.append((char)value);
		                } 
		                else 
		                {
		                    if (aChar == 't') aChar = '\t';
		                    else if (aChar == 'r') aChar = '\r';
		                    else if (aChar == 'n') aChar = '\n';
		                    else if (aChar == 'f') aChar = '\f';
		                    outBuffer.append(aChar);
		                }
		            } 
		            else
		            {
		                outBuffer.append(aChar);
		            }    
		        }
		        sRet = outBuffer.toString();
        	}
        }
        finally
        {
        	if (outBuffer != null)
        	{
        		outBuffer.setLength(0);
        		outBuffer = null;
        	}
        }
        return sRet;
    }

    /**
     * Converts any characters in the argument string greater than 7E hex
	 * (126 decimal) or less than 20 hex (32 decimal) to their hex Unicode
	 * (&#092;uxxxx) or special escape sequence encoded form.  If the
	 * bAllUnicode argument is <b>false</b>, the following characters
	 * are specially encoded as indicated:
     *  <pre>
     *      \b  backspace
     *      \t  tab
     *      \n  linefeed (newline)
     *      \r  carrage return
     *      \"  double quote
     *      \'  single quote
     *      \\  backslash
     *  </pre>
     * Otherwise (bAllUnicode is <b>true</b>), all characters outside
	 * the indicated range are encoded in the hex Unicode (&#092;uxxxx)
	 * format.  
     * <p>
     * @param sStr   		String (potentially) containing special
	 *						characters to be converted to escape sequences.
	 * @param bAllUnicode	If <code>true</code> special characters are
	 *						translated to \b, \t, etc. Otherwise, they
	 *						are translated to their unicode value.
	 * <p>
     * @return          	String with any special characters converted
     *                  	to their escape sequence form or <b>null</b>
     *                  	if the argument string was null.
     */

    public static String encodeSpecialChars(final String sStr, 
    										final boolean bAllUnicode)
    {
    	String sRet = null;
        char aChar;
        int len = 0;
        StringBuilder outBuffer = null;
        
        try
        {
	        if (sStr != null)
	        {	
	            len = sStr.length();
		        
		        outBuffer = new StringBuilder(len);
		
		        for(int x = 0 ; x < len ; )
		        {
		            aChar = sStr.charAt(x++);
		                
		            if ( (bAllUnicode == false) &&
						 (StringUtil.SPECIAL_CHARAS.indexOf(aChar) != -1) )
		            {
		                outBuffer.append('\\');
		                switch(aChar)
		                {
		                    case '\'': outBuffer.append('\'');
		                              continue;
		                    case '\"': outBuffer.append('\"');
		                              continue;
		                    case '\\': outBuffer.append('\\');
		                              continue;
		                    case '\t': outBuffer.append('t');
		                              continue;
		                    case '\n': outBuffer.append('n');
		                              continue;
		                    case '\r': outBuffer.append('r');
		                              continue;
		                    case '\f': outBuffer.append('f');
		                              continue;
							default: outBuffer.append(aChar);
									  continue;
		                }
		            }
		            else if ((aChar < 32) || (aChar > 126))
		            {
		                outBuffer.append('\\');
		                outBuffer.append('u');
		                outBuffer.append(toHex((aChar >> 12) & 0xF));
		                outBuffer.append(toHex((aChar >> 8) & 0xF));
		                outBuffer.append(toHex((aChar >> 4) & 0xF));
		                outBuffer.append(toHex((aChar >> 0) & 0xF));
		            }
		            else
		            {
		                outBuffer.append(aChar);
		            }
		        }
		        sRet = outBuffer.toString();
	        }
        }
        finally
        {
        	if (outBuffer != null)
        	{
        		outBuffer.setLength(0);
        		outBuffer = null;
        	}
        }
        return sRet;
    }

    //----------------------------------------------------------------
    // Private methods.
    //----------------------------------------------------------------
    
    /**
     * Convert a nibble to a hex character.
     * <p>
     * @param	nibble	the nibble to convert.
     * <p>
     * @return		The converted character.
     */
    
    private static char toHex(final int nibble)
    {
	    return StringUtil.HEX_DIGITS[(nibble & 0xF)];
    }
    
    //---------------------------------------------------------------
    // Private variables.
    //---------------------------------------------------------------

    private static final String SPECIAL_CHARAS = "\\'\"\t\r\n\f";
    
    /** A table of hex digits */
    
    private static final char[] HEX_DIGITS = 
    	{
    		'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'
    	};

}
