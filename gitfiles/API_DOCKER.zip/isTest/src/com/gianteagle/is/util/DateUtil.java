/**
 * DateUtil.java
 */

package com.gianteagle.is.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Class used to maintain various Date related utility methods.
 * <p>
 * @author ReichertSF
 */

public final class DateUtil
{
	/**
	 * Method used to format a date based on the specified format.
	 * <p>
	 * @param	date		Date object containing the date to be formatted.
	 * @param	dateFormat	Format specifier as a SimpleDateFormat object.
	 * <p>
	 * @return		A string containing the date in the specified format.
	 *				If the date or format specifier is <code>null</code> or
	 *				an error occurs, <code>null</code> is returned.
	 */

	public static String format(final Date date, 
								final SimpleDateFormat dateFormat)
	{
		String sDate = null;

		try
		{
			if (date != null && dateFormat != null)
			{
				sDate = dateFormat.format(date);
			}
		}
		catch (Throwable ignore)
		{
		}
		return sDate;
	}
	/**
	 * Method used to return a string containing the specified date
	 * formatted as follows:
	 * <pre>
	 *  EEE MMM dd, yyyy hh:mm:ss a z
	 * </pre>
	 * @param	d	The date to format.
	 * <p>
	 * @return		A string containing the current date and time.
	 */

	public static String formatDateTime(final Date d)
	{
		return DateUtil.format(d, DateUtil.FULL_DATE_TIME_FORMAT);
	}

	/**
	 * Method used to return a string containing the current date and time.
	 * The format returned is as follows:
	 * <pre>
	 *  EEE MMM dd, yyyy hh:mm:ss a z
	 * </pre>
	 * <p>
	 * @return		A string containing the current formatted date and time.
	 */

	public static String getCurrentDateTime()
	{
		return DateUtil.format(new Date(), DateUtil.FULL_DATE_TIME_FORMAT);
	}

	/**
	 * Formats the current date into the format <code>mm/dd/yyyy</code>.
	 * <p>
 	 * @return			A String containing the date formatted as
	 *					mm/dd/yyyy.
	 */

	public static String formatDate()
	{
		return DateUtil.formatDate(new Date());
	}

	/**
	 * Formats a date, specified in milliseconds, into the format
	 * <code>mm/dd/yyyy</code>.
	 * <p>
	 * @param	nMillis		The time in milliseconds.
	 * <p>
	 * @return			A String containing the date formatted as
	 *					mm/dd/yyyy.
	 */

	public static String formatDate(final long nMillis)
	{
		return DateUtil.formatDate(new Date(nMillis));
	}

	/**
	 * Formats a date, from a Date object, into the format
	 * <code>mm/dd/yyyy</code>.
	 * <p>
	 * @param	d		The Date object.
	 * <p>
	 * @return			A String containing the date formatted as
	 *					mm/dd/yyyy.
	 */

	public static String formatDate(final Date d)
	{
		return DateUtil.format(d, DateUtil.BASIC_DATE_FORMAT);
	}

	/**
	 * Formats the current time into the format <code>hh:mm:ss</code>.
	 * <p>
 	 * @return			A String containing the time formatted as
	 *					<code>hh:mm:ss</code>.
	 */

	public static String formatTime()
	{
		return DateUtil.formatTime(new Date());
	}

	/**
	 * Formats a time, specified in milliseconds, into the format
	 * <code>hh:mm:ss</code>.
	 * <p>
	 * @param	nMillis		The time in milliseconds.
	 * <p>
	 * @return				A String containing the date formatted as
	 *						<code>hh:mm:ss</code>.
	 */

	public static String formatTime(final long nMillis)
	{
		return DateUtil.formatTime(new Date(nMillis));
	}

	/**
	 * Formats a time, from a Date object, into the format
	 * <code>hh:mm:ss</code>.
	 * <p>
	 * @param	d		The Date object.
	 * <p>
	 * @return			A String containing the time formatted as
	 *					<code>HH:mm:ss</code>.
	 */

	public static String formatTime(final Date d)
	{
		return DateUtil.format(d, DateUtil.BASIC_TIME_FORMAT);
	}
	
	/**
	 * Formats a time, from a Date object into the format
	 * <code>HH:mm:ss.SSS</code>.
	 * <p>
	 * @param	d		The Date object.
	 * <p>
	 * @return			A String containing the time formatted as
	 *					<code>HH:mm:ss.SSS</code>.
	 */
	
	public static String formatTimeWithMillis(final Date d)
	{
		return DateUtil.format(d, DateUtil.MILLIS_TIME_FORMAT);
	}

	/**
	 * Formats the current date into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getStandardXmlFormatDate()
	{
		String sRet = null;
		Date d = null;

		try
		{
			d = new Date();			// Current date and time.

			sRet = DateUtil.getStandardXmlFormatDate(d);
		}
		finally
		{
			d = null;
		}
		return sRet;
	}

	/**
	 * Formats the specified time into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * <p>
	 * @param	nTime	The time value to format.
	 * <p>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getStandardXmlFormatDate(final long nTime)
	{
		String sRet = null;
		Date d = null;

		try
		{
			if (nTime >= 0)
			{
				d = new Date(nTime);

				sRet = DateUtil.getStandardXmlFormatDate(d);
			}
		}
		finally
		{
			d = null;
		}
		return sRet;
	}
	
	/**
	 * Formats a Date object into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssz
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-05:00
	 * </pre>
	 * @param	d		The Date object to format.
	 * <p>
	 * @return			A String containing the formatted date and time.
	 */

	public static String getStandardXmlFormatDate(final Date d)
	{
		String sRet = null;
		
		if (d != null)
		{
			sRet = DateUtil.formatStandardDate(d, true);
		}
		return sRet;
	}
	
	/**
	 * Formats the current date into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssZ
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-0500
	 * </pre>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getStandardFormatDate()
	{
		String sRet = null;
		Date d = null;

		try
		{
			d = new Date();			// Current date and time.

			sRet = DateUtil.getStandardFormatDate(d);
		}
		finally
		{
			d = null;
		}
		return sRet;
	}

	/**
	 * Formats the specified time into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssZ
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-0500
	 * </pre>
	 * <p>
	 * @param	nTime	The time value to format.
	 * <p>
	 * @return			A String containing the formatted current
	 *                  date and time.
	 */

	public static String getStandardFormatDate(final long nTime)
	{
		String sRet = null;
		Date d = null;

		try
		{
			if (nTime >= 0)
			{
				d = new Date(nTime);

				sRet = DateUtil.getStandardFormatDate(d);
			}
		}
		finally
		{
			d = null;
		}
		return sRet;
	}
	
	/**
	 * Formats a Date object into the standard format reporting
	 * date, time, and timezone offset. This format is as follows:
	 * <pre>
	 *   yyyy-MM-dd<b>T</b>HH:mm:ssZ
	 * </pre>
	 * A sample string returned by this routine is as follows:
	 * <pre>
 	 *  2003-12-23T11:32:58-0500
	 * </pre>
	 * @param	d		The Date object to format.
	 * <p>
	 * @return			A String containing the formatted date and time.
	 */

	public static String getStandardFormatDate(final Date d)
	{
		String sRet = null;
		
		if (d != null)
		{
			sRet = DateUtil.formatStandardDate(d, false);
		}
		return sRet;
	}

	/**
	 * Method used to parse a standard format date and return
	 * its value as a <code>Date</code>.
	 * <p>
	 * @param	sDate		The date value to parse.
	 * <p>
	 * For what it's worth, this method is probably marginal at best,
	 * simply because parsing the standard format date and time is
	 * a pain in the rear.
	 * <p>
	 * This method should not be used for critical operation.
	 * <p>
	 * @return		A <code>Date</code> object representing this
	 *				date or <code>null</code> if it is invalid
	 *				or could not be parsed.
	 */

	public static Date parseStandardFormatDate(final String sDate)
	{
		Date retDate = null;
		long nTime = 0;
		
		if (StringUtil.isEmpty(sDate) == false)
		{
			nTime = DateUtil.parseStandardFormatDateAsTime(sDate);

			if (nTime > 0)
			{
				retDate = new Date(nTime);
			}
		}
		return retDate;
	}

	/**
	 * Method used to parse a standard format date and return
	 * its value as a long which represents the number of milliseconds
	 * since January 1, 1970, 00:00:00 GMT.
	 * <p>
	 * For what it's worth, this method is probably marginal at best,
	 * simply because parsing the standard format date and time is
	 * a pain in the rear.
	 * <p>
	 * This method should not be used for critical operation.
	 * <p>
	 * @param	sDate		The date value to parse.
	 * <p>
	 * @return		The number of milliseconds since January 1, 1970,
	 *				00:00:00 GMT.
	 */

	@SuppressWarnings("null")
	public static long parseStandardFormatDateAsTime(final String sDate)
	{
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat timeFormat = null;
		String[] sSplitDate = null;
		Date date = null;
		long nTime = 0;

		try
		{
			if (StringUtil.isEmpty(sDate) == false)
			{
				sSplitDate = sDate.split(DateUtil.STD_DATE_TIME_SEP);

				if (sSplitDate != null)
				{
					if (sSplitDate.length == 2)
					{
						/**
						 * Since the standard format date/time is 
						 * specified with an offset to GMT, setup
						 * the formatters with the base UTC time zone.
						 */

						dateFormat = new SimpleDateFormat(STD_DATE_FORMAT);
						dateFormat.setTimeZone(UTC_TIMEZONE);
						timeFormat = new SimpleDateFormat(STD_TIME_FORMAT);
						timeFormat.setTimeZone(UTC_TIMEZONE);

						nTime = 0;

						if (StringUtil.isEmpty(sSplitDate[0]) == false)
						{
							try
							{
								date = dateFormat.parse(sSplitDate[0]);
							}
							catch(ParseException ex)
							{
								date = null;
							}
							if (date != null)
							{
								nTime = date.getTime();

								date = null;
							}
						}
						if (StringUtil.isEmpty(sSplitDate[1]) == false)
						{
							try
							{
								date = timeFormat.parse(sSplitDate[1]);
							}
							catch(ParseException ex)
							{
								date = null;
							}
							if (date != null)
							{
								nTime += date.getTime();
							}
						}
					}
				}
			}
		}
		finally
		{
			dateFormat = null;
			timeFormat = null;
			date = null;
			Util.initArray(sSplitDate);
			sSplitDate = null;
		}
		return nTime;
	}

	/**
	 * Method used to parse a standard XML format date and return
	 * a Date object representing the date.
	 * <p>
	 * The date string must adhere to the XML standard. That means a 'T'
	 * between date and time as well as colon ':' in the time zone offset.
	 * <pre>
	 *   yyyy-MM-ddT:HH:mm:ss-zz:zz
	 * </pre>
	 * <p>
	 * @param	sDate		The date value to parse.
	 * <p>
	 * @return		A date object representing the date string, or null
	 * 				if the date string is invalid.
	 */
	
	public static Date parseStandardXmlFormatDate(final String sDate)
	{
		Date retDate = null;
		long nTime = 0;
		
		if (StringUtil.isEmpty(sDate) == false)
		{
			nTime = DateUtil.parseStandardXmlFormatDateAsTime(sDate);

			if (nTime > 0)
			{
				retDate = new Date(nTime);
			}
		}
		return retDate;
	}
	
	/**
	 * Method used to parse a standard XML format date and return
	 * its value as a long which represents the number of milliseconds
	 * since January 1, 1970, 00:00:00 GMT.
	 * <p>
	 * The date string must adhere to the XML standard. That means a 'T'
	 * between date and time as well as colon ':' in the time zone offset.
	 * <pre>
	 *   yyyy-MM-ddT:HH:mm:ss-zz:zz
	 * </pre>
	 * This method should not be used for critical operation.
	 * <p>
	 * @param	sDate		The date value to parse.
	 * <p>
	 * @return		The number of milliseconds since January 1, 1970,
	 *				00:00:00 GMT.
	 */

	@SuppressWarnings("null")
	public static long parseStandardXmlFormatDateAsTime(final String sDate)
	{
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat timeFormat = null;
		String[] sSplitDate = null;
		Date date = null;
		long nTime = 0;

		try
		{
			if (StringUtil.isEmpty(sDate) == false)
			{
				sSplitDate = sDate.split(DateUtil.STD_DATE_TIME_SEP);

				if (sSplitDate != null)
				{
					if (sSplitDate.length == 2)
					{
						/**
						 * Since the standard format date/time is 
						 * specified with an offset to GMT, setup
						 * the formatters with the base UTC time zone.
						 */

						dateFormat = new SimpleDateFormat(STD_DATE_FORMAT);
						dateFormat.setTimeZone(UTC_TIMEZONE);
						timeFormat = new SimpleDateFormat(STD_TIME_FORMAT);
						timeFormat.setTimeZone(UTC_TIMEZONE);

						nTime = 0;

						if (StringUtil.isEmpty(sSplitDate[0]) == false)
						{
							try
							{
								date = dateFormat.parse(sSplitDate[0]);
							}
							catch(ParseException ex)
							{
								date = null;
							}
							if (date != null)
							{
								nTime = date.getTime();

								date = null;
							}
						}
						if (StringUtil.isEmpty(sSplitDate[1]) == false)
						{
							try
							{
								date = timeFormat.parse(fixXmlTimeZone(sSplitDate[1]));
							}
							catch(ParseException ex)
							{
								date = null;
							}
							if (date != null)
							{
								nTime += date.getTime();
							}
						}
					}
				}
			}
		}
		finally
		{
			dateFormat = null;
			timeFormat = null;
			date = null;
			Util.initArray(sSplitDate);
			sSplitDate = null;
		}
		return nTime;
	}

	//----------------------------------------------------------------
	// Private methods.
	//----------------------------------------------------------------
	
	/**
	 * Formats a Date object into the standard format reporting
	 * date, time, and timezone offset. 
	 * <p>
	 * @param	d				The Date object to format.
	 * @param	bXmlFormat		Format the timezone in standard XML format
	 * 							(include the colon in the timezone).
	 * <p>
	 * @return			A String containing the formatted date and time.
	 */

	private static String formatStandardDate(final Date d, final boolean bXmlFormat)
	{
		String sRet = null;
		StringBuffer sbDate = null;
		SimpleDateFormat dateFormat = null;
		SimpleDateFormat timeFormat = null;
		Calendar cal = null;
		String sTime = null;
		int tzOffset = 0;
		int nOffsetTotalMinutes = 0;
		int nOffsetHours = 0;
		int nOffsetMins = 0;

		try
		{
			if (d != null)
			{
				sbDate = new StringBuffer(Defines.IO_BUF_SIZE);

				dateFormat = new SimpleDateFormat("yyyy-MM-dd");

				timeFormat = new SimpleDateFormat("HH:mm:ss");
	
				sbDate.append(DateUtil.format(d, dateFormat));
				
				sbDate.append("T");
	
				sTime = DateUtil.format(d, timeFormat);
	
				/**
				 * Build the timezone offset. Note that the format
				 * code of "Z" builds this as "nnnn", but "z" will
				 * attempt to put the timezone string EST, CST, etc.
				 * if it exists. We always want the number, so
				 * we use the Calendar to get it uniformly.
				 */ 
	
				cal = Calendar.getInstance();
	
				tzOffset =
					cal.get(
						Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET);
	
				tzOffset /= 1000;			// Milliseconds to seconds
	
				nOffsetTotalMinutes = Math.abs(tzOffset) / 60;
	
				nOffsetHours = nOffsetTotalMinutes / 60;
				nOffsetMins = nOffsetTotalMinutes % 60;
	
				sbDate.append(sTime);
	
				sbDate.append(tzOffset < 0 ? "-" : "+");
					
				sbDate.append(
						StringUtil.rightJustify(
							Integer.toString(nOffsetHours), 2, '0'));
	
				if (bXmlFormat == true)
				{
					/**
					 * Standard XML format date, include the colon.
					 */
					
					sbDate.append(':');
				}
				sbDate.append(
						StringUtil.rightJustify(
							Integer.toString(nOffsetMins), 2, '0'));

				sRet = sbDate.toString();
			}
		}
		finally
		{
			if (sbDate != null)
			{
				sbDate.setLength(0);
				sbDate = null;
			}
			dateFormat = null;
			timeFormat = null;
			cal = null;
			sTime = null;
		}
		return sRet;
	}
	
	/**
	 * Fixes the time zone offset in a standard XML time string. That means
	 * removing the colon between hour and minute in the zone offset, if it
	 * exits.
	 * <pre>
	 *   HH:mm:ss-nn:nn  becomes HH:mm:ss-nnnn
	 * </pre>
	 * @param	sTime		The incoming time string.
	 * <p>
	 * @return		The corrected, if possible, time string.
	 */
	
	private static String fixXmlTimeZone(final String sTime)
	{
		String sRet = null;
		int nColonOffset = 0;
		String sZoneSep = null;
		
		if (StringUtil.isEmpty(sTime) == false)
		{
			nColonOffset = sTime.length() - 3;
			
			if (nColonOffset > 0 && nColonOffset < (sTime.length() - 1))
			{
				sZoneSep = sTime.substring(nColonOffset, (nColonOffset + 1));
				
				if (sZoneSep.equalsIgnoreCase(STD_TIME_HOUR_MIN_SEP) == true)
				{
					sRet = sTime.substring(0, nColonOffset) +
						   sTime.substring(nColonOffset + 1);
				}
			}
		}
		if (sRet == null)
		{
			sRet = sTime;		// Default return.
		}
		return sRet;
	}
	
	/**
	 * Simple main program used to validate parsing of standard date format.
	 * <p>
	 * @param	args	Command line arguments. 1st arg should be a date
	 * 					in the standard date format.
	 */
	
	public static void main(final String[] args)
	{
		Date date = null;
		String sXmlDate = null;
		String sDate = null;
		
		try
		{
			if (args != null)
			{
				if (args.length > 0)
				{
					System.out.print("Original Date: ");
					System.out.println(args[0]);
					System.out.print("Parsed Date: ");
					System.out.println(
							DateUtil.getStandardFormatDate(
									DateUtil.parseStandardFormatDate(args[0])));
				}
				System.out.print("Today's Date: ");
				System.out.println(DateUtil.getStandardFormatDate());
				System.out.print("Today's Date (XML Format): ");
				System.out.println(DateUtil.getStandardXmlFormatDate());
				
				sXmlDate = "2012-08-09T12:31:13-04:00";
				
	        	date = DateUtil.parseStandardXmlFormatDate(sXmlDate);
        	
	        	sDate = DateUtil.getStandardXmlFormatDate(date);
        	
	        	System.out.print("Parsed XML date (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(date.toString());

	        	System.out.print("Parsed XML date back in XML format (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(sDate);

				sXmlDate = "2012-08-09T12:31:13-0400";
				
	        	date = DateUtil.parseStandardXmlFormatDate(sXmlDate);
        	
	        	sDate = DateUtil.getStandardXmlFormatDate(date);
        	
	        	System.out.print("Parsed XML date (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(date.toString());

	        	System.out.print("Parsed XML date back in XML format (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(sDate);

	        	sXmlDate = "2012-08-03T18:13:37-05:00";
				
	        	date = DateUtil.parseStandardXmlFormatDate(sXmlDate);
        	
	        	sDate = DateUtil.getStandardXmlFormatDate(date);
        	
	        	System.out.print("Parsed XML date (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(date.toString());
	        	
	        	System.out.print("Parsed XML date back in XML format (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(sDate);

	        	sXmlDate = "2012-08-03T18:13:37-0500";
				
	        	date = DateUtil.parseStandardXmlFormatDate(sXmlDate);
        	
	        	sDate = DateUtil.getStandardXmlFormatDate(date);
        	
	        	System.out.print("Parsed XML date (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(date.toString());
	        	
	        	System.out.print("Parsed XML date back in XML format (");
	        	System.out.print(sXmlDate);
	        	System.out.print("): ");
	        	System.out.println(sDate);
			}
		}
		catch (Throwable th)
		{
			th.printStackTrace();
		}
		finally
		{
			date = null;
			sDate = null;
		}
	}
	
    //----------------------------------------------------------------
	// Private variables.
	//----------------------------------------------------------------
	
	private static final SimpleDateFormat FULL_DATE_TIME_FORMAT =
						new SimpleDateFormat("EEE MMM dd, yyyy hh:mm:ss a z");
	
	private static final SimpleDateFormat BASIC_DATE_FORMAT = 
								new SimpleDateFormat("MM/dd/yyyy");
	
	private static final SimpleDateFormat BASIC_TIME_FORMAT =
								new SimpleDateFormat("HH:mm:ss");

	private static final SimpleDateFormat MILLIS_TIME_FORMAT =
								new SimpleDateFormat("HH:mm:ss.SSS");
	
	private static final TimeZone UTC_TIMEZONE = TimeZone.getTimeZone("GMT");
	private static final String STD_DATE_FORMAT = "yyyy-MM-dd";
	private static final String STD_TIME_FORMAT = "HH:mm:ssZ";
	private static final String STD_DATE_TIME_SEP = "T";
	private static final String STD_TIME_HOUR_MIN_SEP = ":";
}
