/**
 * LogBuffer.java
 */

package com.gianteagle.is.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

/**
 * Class used to implement a buffer for logging purposes. The intent is that
 * applications can be set to use this as a contiguous buffer that will be
 * committed to a log file at the time the application completes execution.
 * <p>
 * @author	ReichertSF
 */

public final class LogBuffer
{
	/**
	 * Default constructor.
	 */
	
	public LogBuffer()
	{
		this.sw = new StringWriter(Defines.MEM_BUF_SIZE);
		this.pw = new PrintWriter(this.sw);
	}
	
	/**
	 * Destroys the object and releases any resources managed by it.
	 */
	
	public void destroy()
	{
		if (this.pw != null)
		{
			try { this.pw.close(); } catch (Throwable ignore) { }
			this.pw = null;
		}
		if (this.sw != null)
		{
			try { this.sw.close(); } catch (Throwable ignore) { }
			this.sw = null;
		}
	}

	/**
	 * Writes a message to the log buffer.
	 * <p>
	 * @param	sLevel		Log level reference.
	 * @param	obj			Reference to the object that called this method.
	 * @param	sMethod		Name of the method that called the initiated the
	 * 						call.
	 * @param	sMesg		Message to log.
	 * @param	th			The Throwable object to log, if any.
	 */
	
	public void write(final String sLevel, final Object obj, 
			          final String sMethod, final String sMesg, 
			          final Throwable th)
	{
		this.write(sLevel, (obj == null ? null : obj.getClass()), 
				   sMethod, sMesg, th);
	}

	/**
	 * Writes a message to the log buffer.
	 * <p>
	 * @param	sLevel		Log level reference.
	 * @param	clazz		Reference to the class that called this method.
	 * @param	sMethod		Name of the method that called the initiated the
	 * 						call.
	 * @param	sMesg		Message to log.
	 * @param	th			The Throwable object to log, if any.
	 */
	
	public void write(final String sLevel, final Class<?> clazz, 
					  final String sMethod, final String sMesg, 
					  final Throwable th)
	{
		if (this.pw != null)
		{
			if (sMesg != null)
			{
				this.pw.print(LogBuffer.buildMessage(sLevel, clazz, sMethod, sMesg));
				
				if (sMesg.endsWith(Util.lineSeparator()) == false)
				{
					this.pw.println();
				}
				if (th != null)
				{
					th.printStackTrace(this.pw);
				}
			}
		}
	}

	/**
	 * Returns the entire log buffer as a string.
	 * <p>
	 * @return		A string containing the log buffer.
	 */
	
	@Override
	public String toString()
	{
		return this.sw == null ? null : this.sw.toString();
	}

	//----------------------------------------------------------------
	// Private methods
	//----------------------------------------------------------------
	
	/**
	 * Private method used to build a log message from the class,
	 * method name, and message.
	 * <p>
	 * @param	sLevel		Log level reference.
	 * @param	clazz		Reference to the class that called the log method.
	 * @param	sMethod		Name of the method that called the log method.
	 * @param	sMesg		Message to log.
	 * <p>
	 * @return		Returns a String containing the full log message.
	 */
	
	private static String buildMessage(final String sLevel, final Class<?> clazz, 
									   final String sMethod, final String sMesg)
	{
		String sRet = null;
		StringBuilder sb = null;
		StringBuilder sbClassMethod = null;
		Date date = null;
		
		try
		{
			if (StringUtil.isEmpty(sMesg) == false)
			{
				sb = new StringBuilder(Defines.IO_BUF_SIZE);
				sbClassMethod = new StringBuilder(Defines.IO_BUF_SIZE);
				
				date = new Date();
				
				// Build the source name followed by the
				// method name -->  source.method()

				if (clazz != null)
				{
					sbClassMethod.append(clazz.getSimpleName());
				}
				if (StringUtil.isEmpty(sMethod) == false)
				{
					if (sbClassMethod.length() > 0)
					{
						sbClassMethod.append('.');
					}
					sbClassMethod.append(sMethod);
				}
				// Now construct the log line.
				
				sb.append(DateUtil.formatDate(date));
				sb.append(' ');
				sb.append(DateUtil.formatTimeWithMillis(date));
				sb.append(' ');

				if (StringUtil.isEmpty(sLevel) == false)
				{
					sb.append(sLevel);
					sb.append(' ');
				}
				if (sbClassMethod.length() > 0)
				{
					sb.append(sbClassMethod);
					sb.append(": ");
				}
				sb.append(sMesg);
				
				sRet = sb.toString();
			}
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
			if (sbClassMethod != null)
			{
				sbClassMethod.setLength(0);
				sbClassMethod = null;
			}
			date = null;
		}
		return sRet;
	}

	//----------------------------------------------------------------
	// Private member variables.
	//----------------------------------------------------------------
	
	private StringWriter sw = null;
	private PrintWriter pw = null;
}
