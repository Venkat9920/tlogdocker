/**
 * Utility.java
 */

package com.gianteagle.is.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

/**
 * Class used to maintain various utility methods.
 * <p>
 * @author	ReichertSF
 */

public final class Util
{
	/**
     * Constructor is private, because only Class methods and constants
	 * are supported.
	 */

	private Util()
	{
	}

	/**
	 * Public class (static) method used to retrieve the option
	 * specified by the option flag string (sOptionFlag) from
	 * the array of strings (arguments).
	 * <p>
	 * @param	sOptionFlag		Speicifies the option to retrieve,
	 *                          such as <b>-o</b>.
	 * @param	args			Array of strings (command line
	 *                          arguments).
	 * <p>
	 * @return	A string containing the specified option string if
	 *			the option is found in the array of strings, otherwise
	 *			<b>null</b> is returned. For example, if <b>-o</b> is
	 * 			specified as the option flag, and one of the elements
	 * 			of the array contains <b>-oFileName</b>, a string 
	 *			containing <b>FileName</b> is returned.
	 */

	public static String getOption(final String sOptionFlag, 
								   final String[] args)
	{
		String sOption = null;

		if (sOptionFlag != null && args != null)
		{
			for (int i = 0 ; i < args.length && sOption == null ; ++i)
			{
				if (args[i] != null)
				{
					sOption =
						Util.getOptionString(sOptionFlag, args[i].trim());
				}
			}
		}
		return sOption;
	}

	/**
	 * Public class (static) method used to determine if the option
	 * specified by the option flag (sOptionFlag) is contained in
	 * one of the arguments (array of strings). Note that an option
	 * starts at the beginning of an argument.
	 * <p>
	 * @param	sOptionFlag		Specifies the option to search for,
	 *                          such as <b>-v</b>.
	 * @param	args			Array of strings (command line
	 *                          arguments).
	 * <p>
	 * @return	Returns <b>true</b> if the option is contained in
	 *			the array of strings, otherwise <b>false</b> is
	 *			returned.
	 */

	public static boolean isOption(final String sOptionFlag, 
								   final String[] args)
	{
		boolean bRval = false;
		String sArg = null;

		try
		{
			if (args != null && sOptionFlag != null)
			{
				for (int i = 0 ; i < args.length && bRval == false ; ++i)
				{
					if (args[i] != null)
					{
						sArg = args[i].trim();

						bRval = sArg.startsWith(sOptionFlag);

						sArg = null;
					}
				}
			}
		}
		finally
		{
		}
		return bRval;
	}

	/**
	 * Public static method used to convert a Vector to an array of
	 * objects.
	 * <p>
	 * @param	vector	Vector of objects to convert to an array.
	 * <p>
	 * @return			An array containing each of the elements of
	 *					the Vector or <code>null</code> if the Vector
	 *					is <code>null</code> or empty.
	 */

	public static Object[] toArray(final Vector<Object> vector)
	{
		Object[] array = null;
		Enumeration<Object> e = null;
		
		try
		{
			if (vector != null)
			{
				if (vector.size() > 0)
				{
					array = new Object[vector.size()];
					e = vector.elements();
					int index = 0;

					while (e.hasMoreElements() == true)
					{
						array[index] = e.nextElement();
						++index;
					}
				}
			}
		}
		finally
		{
			e = null;
		}
		return array;
	}

	/**
	 * Public static method used to return the line separator sequence
	 * for the system. Rather than hard coding "\r", "\n", or "\r\n".
	 * use this method instead.
	 * <p>
	 * @return		A string object containing the line separator 
	 *				sequence.
	 */

    public static String lineSeparator()
	{
		return System.getProperty("line.separator");
	}

	/**
	 * Public static method used to return the Java Vendor Specific string.
	 * <p>
	 * @return		A String object containing the vendor.
	 */

	public static String javaVendor()
	{
		return System.getProperty("java.vendor");
	}

	/**
	 * Public static method used to return the file separator string.
	 * <p>
	 * @return		A string object containing the file separator.
	 */

	public static String fileSeparator()
	{
		return System.getProperty("file.separator");
	}

	/**
	 * Displays an input prompt, and reads the user's input string
     * from the console.
	 * <p>
	 * @param	sPrompt		String containing the prompt that will
	 *						be displayed for the user.
	 * <p>
	 * @return		A string containing the user's input.
	 */

	public static String getConsoleInput(final String sPrompt)
	{
		String sCommand = null;

		if (sPrompt != null)
		{
			System.out.print(sPrompt);

			// Java 2 can throw an IOException if the stream is 
			// closed before the flush(). Java 1.1 doesn't, so
			// just catch Exception and ignore it.

			try { System.out.flush(); } catch (Exception ignore) { }
		}

		try
		{
			BufferedReader stdin = 
					new BufferedReader(new InputStreamReader(System.in));

			sCommand = stdin.readLine();

			if (sCommand != null)
			{
				sCommand = sCommand.trim();
			}
		}
		catch (IOException ex)
		{
			System.err.println(Util.class.getName()+": Unable to read from Standard Input.");
			System.err.println(Util.class.getName()+": "+ ex);
		}
		catch (NullPointerException ex)
		{
			sCommand = null;
			System.out.println();
		}
		if (sCommand != null)
		{
			if (sCommand.length() == 0)
				sCommand = null;
		}
		return sCommand;
	}

	/**
	 * Generate a string containing the stack trace for a throwable
	 * object.
	 * <p>
	 * @param	throwable	The Throwable object.
	 * <p>
	 * @return	A String containing the stack trace.
	 */

	public static String getStackTrace(final Throwable throwable)
	{
		StringWriter sw = null;	// StringWriter to build with.
		String sStackTrace = null;
		
		try
		{
			if (throwable != null)
			{
				sw = new StringWriter();
				
				try (PrintWriter pw = new PrintWriter(sw))
				{
					throwable.printStackTrace(pw);
				}
				sStackTrace = sw.toString();
			}
		}
		finally
		{
			if (sw != null)
			{
				try { sw.close(); } catch (Throwable ignore) {}
				sw = null;
			}
		}
		return sStackTrace;
	}

	/**
	 * Method used to return a string containing Java version information.
	 * This returns the equivalent of the system property 
	 * <code>java.version</code>.
	 * <p>
	 * @return		A string containing the Java version, or
	 *				<code>null</code> if it is not available.
	 */

	public static String getJavaVersionInfo()
	{
		return System.getProperty("java.version");
	}

	/**
	 * Method used to return a string containing information about
	 * the operationg system. This returns a combination of the 
	 * following system properties in a single string.
	 * <ul>
	 *  <li><code>os.name</code></li>
	 *  <li><code>os.version</code></li>
	 *  <li><code>os.arch</code></li>
	 * </ul>
	 * @return		A string containing information about the
	 *				operating system.
	 */

	public static String getOSInfo()
	{
		final String[] sProp = { "os.name", "os.version", "os.arch" };

		String sRet = null;
		String sTemp = null;
		StringBuffer sb = null;

		try
		{
			sb = new StringBuffer(Defines.IO_BUF_SIZE);

			for (int i = 0 ; i < sProp.length ; ++i)
			{
				sTemp = System.getProperty(sProp[i]);

				if (sTemp != null)
				{
					if (sb.length() > 0)
					{
						sb.append(" ");
					}
					sb.append(sTemp);
					sTemp = null;
				}
			}
			sRet = sb.toString();
		}
		finally
		{
			if (sb != null)
			{
				sb.setLength(0);
				sb = null;
			}
		}
		return sRet;
	}

	/**
	 * Searches a character array for the specified character and returns
	 * the offset of that character within the array. 
	 * <p>
 	 * @param	ch		Array of characters to search.
	 * @param	start	Offset position within the array to start the search.
	 * @param	len		Number of characters to search beginning with the
	 *					starting offset.
	 * @param	c		Character to locate within the array.
	 * <p>
	 * @return			Returns the offset of the character within the
	 *					array, if it is found. Otherwise, a value of 
	 *					<code>-1</code> is returned.
	 */
 
	public static int indexOfChar(final char[] ch, final int start, 
								  final int len, final char c)
	{
		int nOfs = -1;

		if (ch != null)
		{
			if (start < ch.length && (start + len) <= ch.length)
			{
				int i = start;

				while (i < (start + len) && ch[i] != c)
				{
					++i;
				}
				if (i < (start + len))
				{
					if (ch[i] == c)
					{
						nOfs = i;
					}
				}
			}
		}
		return nOfs;
	}
	
	/**
	 * Initializes each element of a Object array to <code>null</code>.
	 * <p>
	 * @param	oArray	Object array to initialize.
	 */

	public static void initArray(Object[] oArray)
	{
		if (oArray != null)
		{
			for (int i = 0 ; i < oArray.length ; ++i)
			{
				oArray[i] = null;
			}
		}
	}
	
	/**
	 * Provides the MD5 Checksum for the specified byte array.
	 * <p>
	 * @param	data	The data to provide the checksum for.
	 * <p>
	 * @return		The MD5 Checksum for the data.
	 */
	
    public static String getMD5Checksum(final byte[] data)
    {
        String sRet = null;
        MessageDigest md = null;
        byte[] digest = null;

        try
        {   
            md = MessageDigest.getInstance("MD5");
            
            if (md != null)
            {
            	md.update(data);
            	digest = md.digest();
            	
            	if (digest != null)
            	{
            		sRet = HexBinary.printHexBinary(digest);
            		
            		if (sRet != null) sRet = sRet.toLowerCase();
            	}
            }
        }
        catch (NoSuchAlgorithmException ex)
        {
        }
        finally
        {
            md = null;
            digest = null;
        }
        return sRet;
    }

    //----------------------------------------------------------------
    // Private methods.
    //----------------------------------------------------------------

	/**
	 * Public class (static) method used to help in the parsing of
	 * of options passed on a command line, such as <tt>-oOption</tt>.
	 * The method extracts the string after the option flag and returns
	 * it to the caller.
	 * <p>
	 * @param	sOptionFlag		String which specifies the option flag.
	 * @param	sOptionString	String which contains both the flag and
	 *                          the option.
	 * <p>
	 * @return	Returns a string containing the portion of the option
	 *          string that occurs after the option flag. For example,
	 *          in the string <tt>-oOption</tt>, the string <tt>Option</tt>
	 *          is returned. If the option flag specified by 
	 *          <b>sOptionFlag</b> does not occur in the option string,
	 *          <b>null</b> is returned.
	 */

	private static String getOptionString(final String sOptionFlag,
									      final String sOptionString)
	{
		String sOption = null;

		if (sOptionFlag != null && sOptionString != null)
		{
			int nOffset = sOptionString.indexOf(sOptionFlag);

			if (nOffset == 0 && 
				sOptionFlag.length() < sOptionString.length())
			{
				sOption = 
					sOptionString.substring(nOffset + sOptionFlag.length());
			}
		}
		return sOption;
	}
	
	/**
	 * Returns the low value from a set of strings representing
	 * integer values.
	 * <p>
	 * @param	c		Collection containing the set of strings
	 * 					representing integer values.
	 * <p>
	 * @return			The low value as an integer.
	 */
	
	public static int getLowValue(final Collection<?> c)
	{
		int nRet = 0;
		int nVal = 0;
		Iterator<?> it = null;
		Object o = null;
		
		try
		{
			if (c != null)
			{
				for (it = c.iterator() ; it.hasNext() ;)
				{
					o = it.next();
					
					nVal = StringUtil.parseInt(o.toString(), 0);
					
					if (nRet == 0)
					{
						nRet = nVal;
					}
					else if (nVal < nRet)
					{
						nRet = nVal;
					}
				}
			}
		}
		finally
		{
			o = null;
			it = null;
		}
		return nRet;
	}
	
	/**
	 * Returns the high value from a set of strings representing
	 * integer values.
	 * <p>
	 * @param	c		Collection containing the set of strings
	 * 					representing integer values.
	 * <p>
	 * @return			The high value as an integer.
	 */
	
	public static int getHighValue(final Collection<?> c)
	{
		int nRet = 0;
		int nVal = 0;
		Iterator<?> it = null;
		Object o = null;
		
		try
		{
			if (c != null)
			{
				for (it = c.iterator() ; it.hasNext() ;)
				{
					o = it.next();
					
					nVal = StringUtil.parseInt(o.toString(), 0);
					
					if (nVal > nRet)
					{
						nRet = nVal;
					}
				}
			}
		}
		finally
		{
			o = null;
			it = null;
		}
		return nRet;
	}
	
	/**
	 * Returns the true is all objects in parameter list
	 * are non-null values.
	 * <p>
	 * @param	objects objects.
	 * <p>
	 * @return			true is all objects are non-null
	 * 					otherwise returns false.
	 */
	
	public static boolean checkAllNonNull(Object...objects ){
		boolean rtn = true;
		
		if(objects != null){
			if( objects.length > 1)
			{
				for(Object obj: objects)
				{
					if(obj == null)
					{
						rtn = false;
					}
				}
			}
		}
		
		return rtn;
	}
	

}
