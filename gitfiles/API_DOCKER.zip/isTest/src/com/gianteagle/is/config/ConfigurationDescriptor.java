package com.gianteagle.is.config;

import com.gianteagle.is.util.Util;

/**
 * Class used to hold critical parameters for configuration
 * to work.
 * <p>
 * @author	SandersJL
 */

public class ConfigurationDescriptor {

	 /**
	  * Constructor.
	  * 
	  * @param nameSpace    	namespace of configuration object
	  * @param envVar       	environment variable pointing to base folder for service
	  * @param baseConfigFile 	base configuration file
	  * @param customConfigFile custom/override configuration file 
	  * @param logInterface  	logging interface for calling back to base logger
	  * <p>
	  * @exception java.lang.NullPointerException 	If any argument is <code>null</code>. 
	  */
	
	public ConfigurationDescriptor(final String nameSpace, 
								   final String envVar,
								   final String baseConfigFile, 
								   final String customConfigFile,
								   final LoggingInterface logInterface) throws NullPointerException
	{
		boolean isNonNull = Util.checkAllNonNull(nameSpace, envVar, 
												 baseConfigFile, customConfigFile, 
												 logInterface);
		
		if(isNonNull)
		{
			this.nameSpace = nameSpace;
			this.envVar = envVar;
			this.baseConfigFile = baseConfigFile;
			this.customConfigFile = customConfigFile;
			this.logInterface = logInterface;
		}
		else
		{			
			throw new NullPointerException("Configuration Descriptor can not be initialized with a null paramters");
		}
	}


	 /**
	  * Constructor.
	  * 
	  * @param nameSpace    	namespace of configuration object
	  * @param envVar       	environment variable pointing to base folder for service
	  * @param baseConfigFile 	base configuration file
	  * @param customConfigFile custom/override configuration file 
	  * @param logInterface  	logging interface for calling back to base logger
	  * <p>
	  * @return		The ConfigurationDescriptor.
	  * <p>
	  * @exception java.lang.NullPointerException 	If any argument is <code>null</code>. 
	  */
	
	public static ConfigurationDescriptor buildConfigurationDescriptor(final String nameSpace, 
								   final String envVar,
								   final String baseConfigFile, 
								   final String customConfigFile,
								   final LoggingInterface logInterface) throws NullPointerException
	{
		ConfigurationDescriptor cd = null;

		cd = new ConfigurationDescriptor(nameSpace, envVar, baseConfigFile, customConfigFile, logInterface);

		ConfigManager.addConfiguration(cd);

		return cd;
	}

	/**
	 * Returns namespace of configuration. 
	 * This was passed in with constructor.
	 * <p>
	 * @return		The name space of the configuration.
	 */
	
	public String getNameSpace() 
	{
		return this.nameSpace;
	}

	/**
	 * Returns envVar of configuration. 
	 * This was passed in with constructor.
	 * <p>
	 * @return	The Environment variable definining the configuraton location.
	 */
	
	public String getEnvVar() 
	{
		return this.envVar;
	}

	/**
	 * Returns baseConfigFile of configuration. 
	 * This was passed in with constructor.
	 * <p>
	 * @return		The base config file.
	 */
	
	public String getBaseConfigFile() 
	{
		return this.baseConfigFile;
	}

	/**
	 * Returns customConfigFile of configuration. 
	 * This was passed in with constructor.
	 * <p>
	 * @return	The custom config file.
	 */
	
	public String getCustomConfigFile() 
	{
		return this.customConfigFile;
	}

	/**
	 * Returns logInterface of configuration. 
	 * This was passed in with constructor.
	 * <p>
	 * @return		The LogInterface.
	 */
	
	public LoggingInterface getLogInterface() {
		return this.logInterface;
	}

	/**
	 * Returns boolean indicating if every instance
	 * variable is non-null 
	 * @return boolean true is every instance variable is non-null
	 *                 otherwise false
	 */
	
	public boolean isComplete(){
		boolean rtn = this.nameSpace != null &&
                this.envVar != null &&
                this.baseConfigFile != null &&
                this.logInterface != null;

        return rtn;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------

	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private final String nameSpace;
	private final String envVar;
	private final String baseConfigFile;
	private final String customConfigFile;
	private final LoggingInterface logInterface;
}
