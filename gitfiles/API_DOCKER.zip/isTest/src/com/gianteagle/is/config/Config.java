package com.gianteagle.is.config;

import java.io.File;
import java.util.LinkedHashMap;

import com.gianteagle.is.config.util.ConfigUtil;
import com.gianteagle.is.util.FileUtil;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class used to represent Configuration
 * objects and access its values
 * <p>
 * @author	SandersJL
 */

final class Config {
	
	/**
	  * Constructor.
	  * 
	  * @param name    			name space of configuration object
	  * @param envVar       	environment variable pointing to base folder for service
	  * @param baseFileName 	base configuration file
	  * @param customFileName   custom/override configuration file 
	  * @param logInterface  	logging interface for calling back to base logger
	  */
	
	public Config(final String name, final String envVar, final String baseFileName, 
				  final String customFileName, final LoggingInterface logInterface)
	{
		this.name = name;
		this.ENV_VARIABLE = envVar;
		this.baseFileName = baseFileName;
		this.customFileName = customFileName;
		this.logInterface = logInterface;	
		
		this.BASE_DIR = System.getenv(this.ENV_VARIABLE);
		
		File file = new File(this.BASE_DIR + Util.fileSeparator() + Config.CONFIG_DIR);
		
		if(!file.exists())
		{
			//This will be the case for ESB only.
			this.BASE_DIR = System.getenv(this.ENV_VARIABLE) + Util.fileSeparator() + this.name;
		}
		
		if(this.BASE_DIR == null )
		{
			System.err.println(Config.class.getName() + " : Current System Environment:" +System.getenv().toString());
		}
		
		this.reloadConfiguration();
		
	}
	
	/**
	 * Returns name of configuration object passed in through constructor	 
	 * <p>
	 * @return		Returns name of configuration object
	 */
	
	public String getName() 
	{
		return this.name;
	}
	
	/**
	 * Returns base file name of configuration object passed in through constructor	 
	 * <p>
	 * @return		Returns base file name of configuration object
	 */
	
	public String getBaseFileName() {
		return this.baseFileName;
	}

	/**
	 * Returns custom file name of configuration object passed in through constructor	 
	 * <p>
	 * @return		Returns custom file name of configuration object
	 */
	
	public String getCustomFileName() 
	{
		return this.customFileName;
	}

	/**
	 * Returns ServiceConfiguration object which is a pojo
	 * representation of xml configuration xml file(s)	 
	 * <p>
	 * @return		Returns ServiceConfiguration object
	 */

	public ServiceConfiguration getConfigurationObject() 
	{
		return this.configurationObject;
	}

	/**
	 * Reloads xml configuration files and combines them
	 * to create the ServiceConfiguration object 
	 */

	public void reloadConfiguration()
	{		
		// load configuration files into ServiceConfiguration objects
		ServiceConfiguration customConfig = ConfigUtil.loadConfigFromFile(this.getConfigDirectory() + Util.fileSeparator() +  this.customFileName);
		ServiceConfiguration baseConfig = ConfigUtil.loadConfigFromFile(this.getConfigDirectory() + Util.fileSeparator() + this.baseFileName);		
		
		// combine ServiceConfiguration objects
		this.configurationObject = ConfigUtil.combineConfigurations(baseConfig, customConfig,this.getConfigDirectory());
		
		// get variables to setup logging interface
		PropertyElement loggerConfigFile = this.configurationObject.getSystemNode().getPropertyMap().get("loggerConfigFile");
		String log4jFileName = loggerConfigFile!=null?loggerConfigFile.getValue():"";
		String loggerName = "";
		
		if(log4jFileName==null || log4jFileName.isEmpty())
		{
			log4jFileName = this.getConfigDirectory() + Util.fileSeparator() + this.configurationObject.getApplicationPropertyValueByName(this.name, ConfigEnums.LoggingPropertyFileName.toString());
			loggerName = this.configurationObject.getApplicationPropertyValueByName(this.name,ConfigEnums.LoggerName.toString());
		}
		
		this.logInterface.logMessage(this.name, this.configurationObject.toString(),loggerName,log4jFileName);
		
		// Register the files for changes so that new changes are loaded automatically.
		String momConfigXML = this.configurationObject.getApplicationPropertyValueByName(this.getName(),"MOMConfigListType");
		String interfaceConfigXML = this.configurationObject.getApplicationPropertyValueByName(this.getName(),"InterfaceListType");
		String errorConfigXML = this.configurationObject.getApplicationPropertyValueByName(this.getName(),"ErrorListType");
		String extraFieldConfigXML = this.configurationObject.getApplicationPropertyValueByName(this.getName(),"ExtensionListType");
		
			
		if(momConfigXML!=null && !momConfigXML.isEmpty())
		{		
			ConfigWithFileList.getInstance().addFileToList(this.getConfigDirectory(), momConfigXML, this);
		}
		
		if(interfaceConfigXML!=null && !interfaceConfigXML.isEmpty())
		{		
			ConfigWithFileList.getInstance().addFileToList(this.getConfigDirectory(), interfaceConfigXML, this);
		}
		
		if(errorConfigXML!=null && !errorConfigXML.isEmpty())
		{		
			ConfigWithFileList.getInstance().addFileToList(this.getConfigDirectory(), errorConfigXML, this);
		}
		
		if(extraFieldConfigXML!=null && !extraFieldConfigXML.isEmpty())
		{		
			ConfigWithFileList.getInstance().addFileToList(this.getConfigDirectory(), extraFieldConfigXML, this);
		}
		
		baseConfig = null;
		customConfig = null;
	}

	/**
	 * Returns base directory	 
	 * <p>
	 * @return		Returns base directory
	 */
	
	public String getBaseDirectory()
	{		
		return this.BASE_DIR;
	}
	
	/**
	 * Returns configuration file directory	 
	 * <p>
	 * @return		Returns configuration file directory
	 */
	
	public String getConfigDirectory()
	{
		return FileUtil.makeFileName(this.BASE_DIR, Config.CONFIG_DIR);
	}
	
	/**
	 * Returns log file directory	 
	 * <p>
	 * @return		Returns log file directory
	 */
	
	public String getLogDirectory()
	{
		return FileUtil.makeFileName(this.BASE_DIR, Config.LOG_DIR);
	}

	/**
	 * Returns data/files directory	 
	 * <p>
	 * @return		Returns data/files directory
	 */
	
	public String getDataFileDirectory()
	{
		return FileUtil.makeFileName(this.BASE_DIR, Config.DATA_FILE_DIR);
	}
	
	/**
	 * Returns inbound xfer directory	 
	 * <p>
	 * @return		Returns inbound xfer directory
	 */
	
	public String getInboundXferDirectory()
	{
		return FileUtil.makeFileName(this.getXferDirectory(), Config.INBOUND_XFER_DIR);
	}

	/**
	 * Returns outbound xfer directory	 
	 * <p>
	 * @return		Returns outbound xfer directory
	 */
	
	public String getOutboundXferDirectory()
	{
		return FileUtil.makeFileName(this.getXferDirectory(), Config.OUTBOUND_XFER_DIR);
	}

	/**
	 * Returns temp directory	 
	 * <p>
	 * @return		Returns temp directory
	 */
	
	public String getTempDirectory()
	{
		return FileUtil.makeFileName(this.BASE_DIR, Config.TMP_DIR);
	}
	
	/**
	 * Returns xfer directory	 
	 * <p>
	 * @return		Returns xfer directory
	 */
	
	public String getXferDirectory()
	{
		return FileUtil.makeFileName(this.BASE_DIR, Config.XFER_DIR);
	}
	
	/**
	 * Returns the map of System property values.
	 * <p>
	 * @return		Returns the map of System property values.
	 */
	
	public final LinkedHashMap<String, String> getSystemProperties()
	{
		LinkedHashMap<String, String> map = new LinkedHashMap<>();
		map.putAll(this.configurationObject.getSystemProperties());

		map.put(ConfigConstants.BASE_DIRECTORY,
				   StringUtil.format(this.getBaseDirectory()));
		
		map.put(ConfigConstants.CONFIG_DIRECTORY,
				   StringUtil.format(this.getConfigDirectory()));
		
		map.put(ConfigConstants.LOG_DIRECTORY,
				   StringUtil.format(this.getLogDirectory()));
		
		map.put(ConfigConstants.DATA_FILE_DIRECTORY,
				   StringUtil.format(this.getDataFileDirectory()));
		
		map.put(ConfigConstants.TEMP_DIRECTORY,
				   StringUtil.format(this.getTempDirectory()));
		
		map.put(ConfigConstants.XFER_DIRECTORY,
				   StringUtil.format(this.getXferDirectory()));
	
		map.put(ConfigConstants.OUTBOUND_XFER_DIRECTORY,
				   StringUtil.format(this.getOutboundXferDirectory()));
		
		map.put(ConfigConstants.INBOUND_XFER_DIRECTORY,
				   StringUtil.format(this.getInboundXferDirectory()));
		
		return map;
	}

	/**
	 * Returns logging interface directory	 
	 * <p>
	 * @return		logging interface directory
	 */
	
	public LoggingInterface getLogInterface() 
	{
		return this.logInterface;
	}
	
	/**
	 * Returns xmlString of config 
	 * <p>
	 * @return		xmlString of config
	 */
	public String toXmlString()
	{
		String rtn = null;
		StringBuilder xmlString = new StringBuilder();
		
		// opening tag
		xmlString.append("<config name='");
		xmlString.append(this.name);
		xmlString.append("' >");
		
		
		xmlString.append("<baseFileName value='");
		xmlString.append(this.baseFileName);
		xmlString.append("' />");
		
		xmlString.append("<customFileName value='");
		xmlString.append(this.customFileName);
		xmlString.append("/>");
		
		xmlString.append("<BASE_DIR value='");
		xmlString.append(this.BASE_DIR);
		xmlString.append("' />");
		
		xmlString.append("<ENV_VARIABLE value='");
		xmlString.append(this.ENV_VARIABLE);
		xmlString.append("' />");
		
		xmlString.append(ConfigUtil.configToString(this.configurationObject));
		
		xmlString.append("</config>");
		
		rtn = xmlString.toString();
		
		return rtn;
	}
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------
	
	private final String name;
	
	private final String baseFileName;
	private final String customFileName;
	private final LoggingInterface logInterface;
	private String BASE_DIR;
	private final String ENV_VARIABLE;
	private static final String LOG_DIR = "logs";
	private static final String CONFIG_DIR = "config";
	private static final String DATA_FILE_DIR = "files";
	private static final String TMP_DIR = "tmp";
	private static final String XFER_DIR = "xfer";
	private static final String OUTBOUND_XFER_DIR = "outbound";
	private static final String INBOUND_XFER_DIR = "inbound";
	
	private ServiceConfiguration configurationObject;	
}
