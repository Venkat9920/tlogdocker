package com.gianteagle.is.config;

/**
 * Interface used as a "callback" for logging
 * <p>
 * @author	SandersJL
 */

public interface LoggingInterface {
	void logMessage(String applicationName, String message, String loggerName, String log4jfilename);
	
	void logError(String applicationName, String message, String loggerName, String log4jfilename);
}
