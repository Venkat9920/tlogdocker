package com.gianteagle.is.config;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Singleton class used to map configuration xml files
 * to config objects
 * <p>
 * @author	SandersJL
 */

public class ConfigWithFileList {	

	/**
	  * Constructor.
	  */
	
	private ConfigWithFileList()
	{
		
	}
	
	/**
	 * Returns this instance of class
	 * @return 	Singleton instance
	 */
	
	public static ConfigWithFileList getInstance()
	{
		return instance;
	}
	
	/**
	 * Gets fileList
	 * @return HashMap of the configuration.
	 */
	
	public HashMap<String, ArrayList<Config>> getFileList() 
	{
		if(this.fileList == null)
		{
			synchronized (this.fileList) 
			{			
				if(this.fileList == null)
				{
					this.fileList = new HashMap<>();
				}
			}
		}
		
		return this.fileList;
	}
	 
	
	/**
	 * Add configuration file to list if not already present.  
	 * Furthermore, add configuration object to list of configuration
	 * objects associated with file
	 * <p>
	 * @param configPath	Path to folder of configuration file 
	 * @param fileName		File name of configuration to watch for changes in
	 * @param cm			Configuration object that will be updated upon
	 * 						change in configuration file
	 */
	
	public void addFileToList(final String configPath, 
							  final String fileName, 
							  final Config cm)
	{
		ArrayList<Config> cmList;
		
		// 
		ConfigFileWatcher.getInstance().RegisterPath(configPath);
		
		synchronized (this.fileList) 
		{		
			// create filelist if it does not exist
			if(this.fileList == null)
			{
				this.fileList = new HashMap<>();
			}
			
			// check to see if fileName in map
			cmList = this.fileList.get(fileName);
			
			if(cmList == null)
			{
				// file is not in the list yet
				cmList = new ArrayList<>();
				cmList.add(cm); 
				this.fileList.put(fileName, cmList);
			} 
			else 
			{
				// fileName is already in list
				// check for cm in List<>
				if(!cmList.contains(cm))
				{
					// config manager is not already in list
					// go ahead and add it
					cmList.add(cm);
				}
			}
		}
	}
	
	/**
	 * Removes configuration object from list of config
	 * objects associated with fileName, if it is present in the list
	 * @param fileName		Name of file
	 * @param cm			Config object to remove
	 */
	
	public void removeFromCmFromList(String fileName,Config cm)
	{
		ArrayList<Config> cmList = null;
		
		// check to see if fileList exists
		if(this.fileList != null)
		{
			// get list of config object assocatied with fileName
			cmList = this.fileList.get(fileName);
			
			// attempt to remove cm from list 
			if(cmList != null)
			{		
					cmList.remove(cm);
			}
		}
	}
	
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	
	private static final ConfigWithFileList instance = new ConfigWithFileList();
	private HashMap<String, ArrayList<Config>> fileList = new HashMap<>();	
	
}