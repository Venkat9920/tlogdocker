package com.gianteagle.is.config;

import java.util.concurrent.ConcurrentHashMap;

import com.gianteagle.is.util.StringUtil;

/**
 * Singleton class used fold Config objects.
 * <p>
 * 
 * @author SandersJL
 */

final class ConfigList {

	/**
	 * Constructor.
	 */

	private ConfigList() {

	}

	/**
	 * Returns this instance of class
	 * 
	 * @return Singleton instance
	 */

	public static ConfigList getInstance() {
		return ConfigList.instance;
	}

	/**
	 * Gets current list of Config objects. If list is null it initializes
	 * 
	 * @return map of configuration objects
	 */

	public ConcurrentHashMap<String, Config> getCmList() {
		if (this.cmList == null) {
			synchronized (this.cmList) {
				if (this.cmList == null) {
					this.cmList = new ConcurrentHashMap<String, Config>(16, 0.9f, 1);
				}
			}
		}

		return this.cmList;
	}

	/**
	 * Adds Config Object in to map of Config objects with key of nameSpace
	 * 
	 * @param nameSpace nameSpace of config object
	 * @param cm        Config object to be added
	 */

	public void addConfigManagerToList(final String nameSpace, final Config cm) {
		synchronized (this.cmList) {
			this.cmList.put(nameSpace, cm);
		}
	}

	/**
	 * Reset the config list by clearing all the keys.
	 */
	public void resetConfigList() {

		synchronized (this.cmList) {
			if (this.cmList != null) {
				this.cmList.clear();

				System.out.println(ConfigList.class.getName() + ": Config List has been reset on request.");
			}

		}
	}

	/**
	 * Remove a given namespace from the existing config list.
	 * 
	 * @param namespace name of the config list to remove.
	 */
	public void removeConfigManagerInList(String namespace) {
		synchronized (this.cmList) {
			if (this.cmList != null) {

				this.cmList.remove(namespace);

				System.out.println(ConfigList.class.getName() + ": Removed " + StringUtil.format(namespace)
						+ " from the Config List on request.");
			}

		}
	}

	// ---------------------------------------------------------------
	// Private methods.
	// ---------------------------------------------------------------

	// ---------------------------------------------------------------
	// Private member variables.
	// ---------------------------------------------------------------

	private static final ConfigList instance = new ConfigList();
	// private TreeMap<String, Config> cmList = new TreeMap<>();
	private ConcurrentHashMap<String, Config> cmList = new ConcurrentHashMap<String, Config>(16, 0.9f, 1);

}
