package com.gianteagle.is.config;

import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.gianteagle.is.util.StringUtil;

/**
 * Singleton class used to monitor configuration folders for files
 * registered with ConfigWithFileList.  
 * <p>
 * @author	SandersJL
 */

public class ConfigFileWatcher implements Runnable {

	/**
	  * Constructor.
	  * Creates a thread to run file watcher service in
	  */
	
	private ConfigFileWatcher() 
	{
		try 
		{
			this.watcher = FileSystems.getDefault().newWatchService();
			this.keys = new HashMap<>();
			this.watcherThread = new Thread(this, ConfigConstants.CONFIG_FILE_WATCHER_THREAD_NAME);
			this.watcherThread.start();
		} 
		catch (IOException e) 
		{		
			System.err.println(ConfigFileWatcher.class.getName() +": Catastrophic error in creating file water thread: " + e.getStackTrace());
		}

	}

	/**
	 * Returns this instance of class
	 * @return Singleton instance
	 */
	
	public static ConfigFileWatcher getInstance() 
	{
		return instance;
	}

	/**
	 * Registers folder to monitor for file change events.
	 * If file is registered with ConfigWithFileList each
	 * 
	 * @param filePath	The path to monitor.
	 */
	
	public void RegisterPath(String filePath) 
	{
		Path dir = Paths.get(filePath);
		WatchKey key;
		
		try 
		{
			// Sanity check - Check if path is a folder
			Boolean isFolder = (Boolean) Files.getAttribute(dir,
															"basic:isDirectory", 
															NOFOLLOW_LINKS);
			
			if (!isFolder.booleanValue()) 
			{
				throw new IllegalArgumentException("Path: " + dir
													+ " is not a folder");
			}

			// only register directory is its a new directory
			if (!this.keys.containsValue(dir)) 
			{
				key = dir.register(this.watcher, 
								   ENTRY_CREATE, ENTRY_DELETE,
								   ENTRY_MODIFY);
				
				this.keys.put(key, dir);
			}
		} 
		catch (IOException e) 
		{
			System.err.println(ConfigFileWatcher.class.getName() +": Catastrophic error in regestering folder for " 
							 + " file watcher service: " + e.getStackTrace());
		}

	}

	/**
	 * Run function for file watcher thread
	 */
	@Override
	public void run() 
	{
		for (;;) 
		{
			// wait for key to be signaled
			WatchKey key;
			
			try 
			{
				key = this.watcher.take();
			} 
			catch (InterruptedException x) 
			{
				return;
			}
			
			Path dir = this.keys.get(key);
			
			if (dir == null) 
			{
				System.err.println(ConfigFileWatcher.class.getName() +": WatchKey not recognized!!");
				continue;
			}

			for (WatchEvent<?> watchEvent : key.pollEvents()) 
			{
				// Get the type of the event
				Kind<?> kind = watchEvent.kind();

				if (OVERFLOW == kind) {
					continue; // loop
				}
				
				// A new Path was created
				@SuppressWarnings("unchecked")
				Path newPath = ((WatchEvent<Path>) watchEvent).context();

				// Output
				String fileName = newPath.toString();
				
				// get list of associated configuration managers
				ArrayList<Config> cmList = ConfigWithFileList.getInstance()
															 .getFileList().get(fileName);
				
				if (cmList != null) 
				{
					for (Config cm : cmList) 
					{
						System.out.println(ConfigFileWatcher.class.getName()+": Configuration for " + StringUtil.format(cm.getName() + " is being reloaded because of a change to file: " + StringUtil.format(fileName)));
						cm .reloadConfiguration(); 
					}
				}

			}

			if (!key.reset()) {
				break;
			}
		}
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	
	private static final ConfigFileWatcher instance = new ConfigFileWatcher();
	private WatchService watcher;
	private Map<WatchKey, Path> keys;
	private Thread watcherThread;

}
