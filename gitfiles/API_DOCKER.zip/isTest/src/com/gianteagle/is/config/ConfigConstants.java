package com.gianteagle.is.config;

/**
 * Class used to hold constants needed for configuration
 * management
 * <p>
 * @author	SandersJL
 */

public interface ConfigConstants {
	String CONFIG_FILE_WATCHER_THREAD_NAME = "FileWatcher";
	
	String SYSTEM = "SYSTEM" ;
	
	String TRUE = "TRUE";
	
	enum FOLDER_TYPE {
		BASE,
		CONFIG,
		LOG,
		DATA,
		TEMP,
		XFER,
		OUTBOUND,
		INBOUND
	}
	
	/**
	 * Constant string used to identify the base directory.
	 */
	
	String BASE_DIRECTORY = "BaseDirectory";
	
	/**
	 * Constant string used to identify the configuration directory.
	 */
	
	String CONFIG_DIRECTORY = "ConfigDirectory";
	
	/**
	 * Constant string used to identify the log directory.
	 */
	
	String LOG_DIRECTORY = "LogDirectory";

	/**
	 * Constant string used to identify the data file directory.
	 */
	
	String DATA_FILE_DIRECTORY = "DataFileDirectory";

	/**
	 * Constant string used to identify the temporary directory.
	 */
	
	String TEMP_DIRECTORY = "TempDirectory";
	
	/**
	 * Constant string used to identify the xfer (transfer) directory.
	 */
	
	String XFER_DIRECTORY = "XferDirectory";
	
	/**
	 * Constant string used to identify the out-bound xfer (transfer) directory.
	 */
	
	String OUTBOUND_XFER_DIRECTORY = "OutBoundXferDirectory";
	
	/**
	 * Constant string used to identify the in-bound xfer (transfer) directory.
	 */
	
	String INBOUND_XFER_DIRECTORY = "InBoundXferDirectory";

}
