package com.gianteagle.is.config;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.gianteagle.is.config.SystemNode;
import com.gianteagle.is.config.jaxb.ConnectionListType;
import com.gianteagle.is.config.jaxb.ErrorHandlingType;
import com.gianteagle.is.config.jaxb.ExtensionListType;
import com.gianteagle.is.config.jaxb.MOMConfigListType;
import com.gianteagle.is.config.jaxb.TimingExtraFieldListType;
import com.gianteagle.is.config.jaxb.TimingMetricListType;
import com.gianteagle.is.util.StringUtil;

/**
 * Class used to represent xml configuration file(s)
 * as a set of maps
 * <p>
 * @author	SandersJL
 */

public class ServiceConfiguration 
{
	
	/**
	  * Constructor.
	  * Initializes systemNode and applicationMap to empyt/null
	  * objects.
	  */
	
	public ServiceConfiguration() 
	{
		this.systemNode = new SystemNode();
		this.applicationMap = new TreeMap<>();
	}

	/**
	 * Gets SystemNode instance variable
	 * <p>
	 * @return SystemNode
	 */
	
	public SystemNode getSystemNode() 
	{
		return this.systemNode;
	}

	/**
	 * Sets sysemtNode.
	 * @param systemNode		The SystemNode.
	 */
	
	public void setSystemNode(final SystemNode systemNode) 
	{
		this.systemNode = systemNode;
	}

	/**
	 * Gets applicationMap, a map of ApplicationNodes with 
	 * service/application name as the key
	 * <p>
	 * @return map of ApplicationNodes
	 */
	
	public TreeMap<String, ApplicationNode> getApplicationMap() 
	{
		return this.applicationMap;
	}

	/**
	 * Sets applicationMap, a map of ApplicationNodes with 
	 * service/application name as the key
	 * @param applicationMap	map of ApplicationNodes
	 */
	
	public void setApplicationMap(final TreeMap<String, ApplicationNode> applicationMap) 
	{
		this.applicationMap = applicationMap;
	}

	/**
	 * Gets property value from System node as a string
	 * @param propertyName
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public String getSystemPropertyValue(final String propertyName)
	{
		String systemProperty = null;
		
		TreeMap<String, PropertyElement> systemNode = null;
		
		systemNode = this.systemNode.getPropertyMap();
		
		if(systemNode != null && !systemNode.isEmpty())
		{
			PropertyElement pe = systemNode.get(propertyName);
			
			if(pe != null)
			{
				systemProperty = pe.getValue();
			}
		}
		
		return systemProperty;
	}
	
	/**
	 * Gets property value from Application node as a string
	 * @param applicationName		name of application
	 * @param propertyName			name of property
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public String getApplicationPropertyValueByName(final String applicationName, 
													final String propertyName)
	{
		String applicationProperty = null;
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);
		
		if(appNode != null)
		{
			TreeMap<String, PropertyElement> applicationProperties = appNode.getPropertyMap();
			
			if(applicationProperties != null)
			{
				PropertyElement pe = applicationProperties.get(propertyName);
				
				if(pe != null)
				{
					applicationProperty =  pe.getValue();
					
				}				
			}
		}	
		
		return applicationProperty;
	}
	
	/**
	 * Gets property list from Application node as a map
	 * @param applicationName		name of application
	 * @param propertyListName		name of property List
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public TreeMap<String, String> getApplicationPropertyList(final String applicationName, 
															  final String propertyListName)
	{
		TreeMap<String, String> propertyList = new TreeMap<>();
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);
		
		if(appNode != null)
		{
			propertyList = appNode.getPropertyListMap().get(propertyListName);
		} 
		else 
		{
			propertyList =  null;
		}
		
		return propertyList;
	}

	/**
	 * Gets property list size from Application node as an int
	 * @param applicationName		name of application
	 * @param propertyListName		name of property List
	 * <p>
	 * @return value of size if present, otherwise return 0
	 */
	
	public int getApplicationPropertyListSize(final String applicationName, final String propertyListName)
	{
		int propertyListSize = 0;
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);
		
		if(appNode != null )
		{
			propertyListSize = appNode.getPropertyListMap().get(propertyListName).size();
		} 
		
		return propertyListSize;
	}
	
	/**
	 * Gets TimingExtraFieldListType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public TimingExtraFieldListType getApplicationTimingExtraFieldList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			TreeMap<String, String> propertyList = appNode.getPropertyListMap()
														  .get(ConfigEnums.TimingExtraFieldList.toString());
			
			if(appNode.getTimginExtraFieldListType() == null && propertyList != null)
			{
				TimingExtraFieldListType timingExtraFieldListType = new TimingExtraFieldListType();
				
				for(Map.Entry<String, String> propertyListValue : propertyList.entrySet())
				{				
					timingExtraFieldListType.getTimingExtraField().add(propertyListValue.getValue());
				}
				
				appNode.setTimginExtraFieldListType(timingExtraFieldListType);			
			}
			
			return appNode.getTimginExtraFieldListType();
		}
		
		return null;
	}

	/**
	 * Gets TimingMetricListType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public TimingMetricListType getApplicationTimingMetricList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			
			TreeMap<String, String> propertyList = appNode.getPropertyListMap().get(ConfigEnums.TimingMetricList.toString());
			
			if(appNode.getTimginExtraFieldListType() == null && propertyList != null)
			{
				TimingMetricListType timingMetricListType = new TimingMetricListType();
				
				for(Map.Entry<String, String> propertyListValue : propertyList.entrySet())
				{			
					timingMetricListType.getTimingMetric().add(propertyListValue.getValue());
				}
				
				appNode.setTimingListType(timingMetricListType);
			}
			
			return appNode.getTimingListType();
		}
		
		return null;
	}
	
	/**
	 * Gets MOMConfigListType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public MOMConfigListType getApplicationMOMConfigList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			return appNode.getMomConfigListType();
		}
		
		return null;
	}
	
	/**
	 * Gets ConnectionListType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public ConnectionListType getApplicationInterfaceList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			return appNode.getInterfaceListType();
		}
		
		return null;
	}
	
	/**
	 * Gets ErrorHandlingType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public ErrorHandlingType getApplicationErrorList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			return appNode.getErrorListType();
		}
		
		return null;
	}
	
	/**
	 * Gets ExtensionListType from Application node 
	 * @param applicationName		name of application
	 * <p>
	 * @return value of property if present, otherwise return null
	 */
	
	public ExtensionListType getApplicationExtensionList(final String applicationName)
	{
				
		ApplicationNode appNode = this.applicationMap.get(applicationName);
			
		if(appNode != null)
		{
			return appNode.getExtensionListType();
		}
		
		return null;
	}
	
	/**
	 * Gets key of entry in specified propertyList in specified Application
	 * at specified index
	 * @param applicationName		name of application
	 * @param propertyListName		name of property list
	 * @param index					index of entry
	 * <p>
	 * @return value of parameter if present, otherwise return null
	 */
	
	public String getApplicationPropertyListKeyByIndex(final String applicationName, 
													   final String propertyListName, 
													   final int index)
	{
		String itemValue = null;
		int propertyListSize = 0;
		TreeMap<String, String> itemMap = new TreeMap<>();
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);
		
		try 
		{
			if(appNode != null)
			{
				itemMap = appNode.getPropertyListMap().get(propertyListName);

				if(itemMap != null)
				{
					propertyListSize = itemMap.size();
					@SuppressWarnings("unchecked")
					Entry<String, String>[] itemArray = itemMap.entrySet().toArray(new Map.Entry[propertyListSize]);
					itemValue = itemArray[index].getKey();
				}
			}
		} 
		catch (Exception e) 
		{
			itemValue = null;
		} 
		
		return itemValue;
	}
	
	/**
	 * Gets value of entry in specified propertyList in specified Application
	 * at specified index
	 * @param applicationName		name of application
	 * @param propertyListName		name of property list
	 * @param itemName				name of key
	 * <p>
	 * @return value of parameter if present, otherwise return null
	 */
	
	public String getApplicationPropertyListValueByName(final String applicationName, 
														final String propertyListName, 
														final String itemName)
	{
		String itemValue = null;
		TreeMap<String, TreeMap<String, String>> propertyListMap;
		TreeMap<String, String> propertyListMapProperties;
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);

		if(appNode != null)
		{
			propertyListMap = appNode.getPropertyListMap();
			
			if(propertyListMap != null)
			{
				propertyListMapProperties = propertyListMap.get(propertyListName);
				
				if(propertyListMapProperties != null)
				{					
					itemValue = propertyListMapProperties.get(itemName);					
				}
			}
		} 
		
		return itemValue;
	}
	
	/**
	 * Gets value of entry in specified propertyList in specified Application
	 * at specified index
	 * @param applicationName		name of application
	 * @param propertyListName		name of property list
	 * @param index					index of entry
	 * <p>
	 * @return value of parameter if present, otherwise return null
	 */
	
	public String getApplicationPropertyListValueByIndex(final String applicationName, 
														 final String propertyListName, 
														 final int index)
	{
		String itemValue = null;
		int propertyListSize = 0;
		TreeMap<String, String> itemMap = new TreeMap<>();
		
		ApplicationNode appNode = this.applicationMap.get(applicationName);
		
		try {
			if(appNode != null){
				itemMap = appNode.getPropertyListMap().get(propertyListName);
				
				if(itemMap != null)
				{
					propertyListSize = itemMap.size();
					@SuppressWarnings("unchecked")
					Entry<String, String>[] itemArray = itemMap.entrySet().toArray(new Map.Entry[propertyListSize]);
					itemValue = itemArray[index].getValue();
				}
			}
		} 
		catch (Exception e) 
		{
			itemValue = null;
		} 
		
		return itemValue;
	}

	/**
	 * Returns the set of system properties for this configuration.
	 * <p>
	 * @return	The set of system properties as a <code>LinkedHashMap</code>,
	 * 			which maintains the order in which the list was prepared.
	 */
	
	public final LinkedHashMap<String, String> getSystemProperties()
	{
		LinkedHashMap<String, String> map = null;
		
		map = new LinkedHashMap<>();
		
		for(Map.Entry<String, PropertyElement> systemProperty: this.systemNode.getPropertyMap().entrySet())
		{
			map.put(systemProperty.getKey(),  StringUtil.format(systemProperty.getValue().getValue()));
		}
	
		return map;
	}
	
	/**
	 * Returns the set of components and their associated properties.
	 * <p>
	 * @return		The set of components and their associated properties.
	 */
		
	public LinkedHashMap<String, LinkedHashMap<String, String>> getComponentProperties()
	{
		LinkedHashMap<String, LinkedHashMap<String, String>> map = null;
		LinkedHashMap<String, String> prop = null;
		String applicationName = null;
		ApplicationNode application = null;
		
		try
		{
			map = new LinkedHashMap<>();			
			prop = new LinkedHashMap<>();
			
			for(Map.Entry<String, ApplicationNode> applicationEntry : this.applicationMap.entrySet())
			{
				applicationName = applicationEntry.getKey();				
				application = applicationEntry.getValue();
				prop =  new LinkedHashMap<>();
				
				// cycle through all the properties
				if(application.getPropertyMap().size() > 0)
				{					
					for(Map.Entry<String, PropertyElement> property : application.getPropertyMap().entrySet())
					{
						prop.put(property.getKey(), property.getValue().getValue());						
					}
				} 				
				
				// cycle through all the property lists	
				int index;
				String propertyListName;
				
				if(application.getPropertyListMap().size() > 0)
				{					
					for(Map.Entry<String, TreeMap<String, String>> propertylist : application.getPropertyListMap().entrySet())
					{
						index = 0;				
						propertyListName = propertylist.getKey();
						
						for(Map.Entry<String,String> item : propertylist.getValue().entrySet())
						{							
							prop.put(propertyListName + "[" + index + "]", item.getKey()+"="+item.getValue());
							
							index++;
						}
						
					}
				} 
				
				map.put(applicationName, prop);	
			}
		}
		finally
		{
			prop = null;
		}
		
		return map;
	}
	
	/**
	 * Returns String representation of ServiceConfiguration object
	 */
	@Override
	public String toString()
	{
		String configString = null;
		ApplicationNode app;
		
		configString = "****** SYSTEM ******\n";
		
		for(Map.Entry<String, PropertyElement> propertyEntry : this.systemNode.getPropertyMap().entrySet()){
			configString += "\n\tName: " + propertyEntry.getKey() + " Value: " + propertyEntry.getValue().getValue() + " Value: " + propertyEntry.getValue().getType();
		}
		
		configString += "\n\n**************************";
		configString += "\n****** Applications ******";
		configString += "\n**************************\n";
		
		for(Map.Entry<String, ApplicationNode> applicationEntry : this.applicationMap.entrySet()){
			configString += "\n\nApplication Name: " + applicationEntry.getKey();
			configString += "\n\t\t****** Properties ****** ";
			
			app = applicationEntry.getValue();
			
			// cycle through all the properties
			if(app.getPropertyMap().size() > 0){
				for(Map.Entry<String, PropertyElement> property : app.getPropertyMap().entrySet()){
					configString += "\n\t\tName: " + property.getKey() + " Value: " + property.getValue().getValue();
				}
			} else {
				configString += "\n\t\t NONE ";
			}
			
			
			// cycle through all the property lists
			configString += "\n\n\t\t****** Property List ****** ";		
			
			if(app.getPropertyListMap().size() > 0){
				for(Map.Entry<String, TreeMap<String, String>> propertylist : app.getPropertyListMap().entrySet()){
					configString += "\n\t\tName: " + propertylist.getKey();
					
					for(Map.Entry<String,String> item : propertylist.getValue().entrySet()){
						configString += "\n\t\t\tKey: " + item.getKey() + " Value: " + item.getValue();
					}
					
				}
			} else {
				configString += "\n\t\t NONE ";
			}
			
			configString += "\n******************************************************************************\n";
		}
		
		return configString;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------

	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	private SystemNode systemNode;
	private TreeMap<String, ApplicationNode> applicationMap;
}
