package com.gianteagle.is.config.util;

import java.io.File;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.gianteagle.is.config.ApplicationNode;
import com.gianteagle.is.config.PropertyElement;
import com.gianteagle.is.config.ServiceConfiguration;
import com.gianteagle.is.config.SystemNode;
import com.gianteagle.is.config.jaxb.Application;
import com.gianteagle.is.config.jaxb.ConnectionListType;
import com.gianteagle.is.config.jaxb.ErrorHandlingType;
import com.gianteagle.is.config.jaxb.ExtensionListType;
import com.gianteagle.is.config.jaxb.Item;
import com.gianteagle.is.config.jaxb.MOMConfigListType;
import com.gianteagle.is.config.jaxb.Property;
import com.gianteagle.is.config.jaxb.PropertyList;
import com.gianteagle.is.config.jaxb.ServiceConfig;
import com.gianteagle.is.config.jaxb.SystemElement;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class of utility functions used to aid in configuration management.
 * Specifically with loading configurations from files, combiniing configurations,
 * and writing configurations back to files.
 * file/object
 * <p> 
 * @author SandersJL 
 */

public class ConfigUtil {
	
	/**
	 * Loads an xml conifguration file into a ServiceConfiguration object.
	 * If configuration file is not valid ServiceConfiguration object is still returned.
	 * Its internal map will be empty.
	 * @param fileName		file name ( path included) of configuration xml to be loaded
	 * <p>
	 * @return ServiceConfiguration		object which represents valid 
	 * 									configuration xml file
	 */
	
	public static synchronized ServiceConfiguration loadConfigFromFile(final String fileName) 
	{
		File file;
		Unmarshaller jaxbUnmarshaller;
		ServiceConfig config;
		ServiceConfiguration cm = new ServiceConfiguration();
		TreeMap<String, PropertyElement> applicationPropertyMap = null;
		String propListName = null;
		String applicationName = null;
		TreeMap<String, String> itemMap = null;
		ApplicationNode appNode = null;
		List<Application> appList = null;
		SystemNode newSystem = null;
		TreeMap<String, PropertyElement> systemPropertyMap;
		List<Property> propertyListFromConfig = null;

		try 
		{			
			file = new File(fileName);
			
			ConfigUtil.jaxbMap.putIfAbsent("context",
										   JAXBContext.newInstance("com.gianteagle.is.config.jaxb",
												   					com.gianteagle.is.config.jaxb.ServiceConfig.class.getClassLoader()
												   				   )
										  );
					
			ConfigUtil.umMap.putIfAbsent("unmarshaller", ConfigUtil.jaxbMap.get("context").createUnmarshaller());
			
			jaxbUnmarshaller = ConfigUtil.umMap.get("unmarshaller");
			
			config = (ServiceConfig) jaxbUnmarshaller.unmarshal(file);
			
			if(config.getSystem() != null)
			{
				propertyListFromConfig = config.getSystem().getPropertyList();

				// convert SystemNode JAXB to SystemNode object
				systemPropertyMap = ConfigUtil.convertPropertyListToMap(propertyListFromConfig);

				newSystem = new SystemNode(systemPropertyMap);
				cm.setSystemNode(newSystem);
			}
			
			
			// convert list of Application JAXB objects to Application JAXB
			appList = config.getApplicationList();
			
			for (Application app : appList) 
			{
				appNode = new ApplicationNode();

				applicationName = app.getName();
				appNode.setName(applicationName);

				// convert property application property nodes to map
				List<Property> propertyList = app.getPropertyList();
				applicationPropertyMap = ConfigUtil.convertPropertyListToMap(propertyList);

				appNode.setPropertyMap(applicationPropertyMap);

				// convert any application property list nodes to map
				if (app.getPropertyListList().size() > 0) 
				{
					List<PropertyList> propertyListList = app.getPropertyListList();

					for (PropertyList propList : propertyListList) 
					{
						propListName = propList.getName();

						itemMap = ConfigUtil.convertItemListToMap(propList.getItemList());

						appNode.getPropertyListMap().put(propListName, itemMap);
					}

				}

				cm.getApplicationMap().put(applicationName, appNode);
			}

		} 
		catch (JAXBException e) 
		{
			System.err.println(ConfigUtil.class.getName() + ": File: " + StringUtil.format(fileName) + " had a JAXB exception.");
		} 
		catch (Exception e) 
		{
			System.err.println(ConfigUtil.class.getName() + ": File: " + StringUtil.format(fileName) + " had a general exception.");
		} 
		finally 
		{
			jaxbUnmarshaller = null;
			propertyListFromConfig = null;
			systemPropertyMap = null;
			newSystem = null;
			appList = null;
			applicationPropertyMap = null;
			propListName = null;
			itemMap = null;
			appNode = null;
			applicationName = null;
		}

		return cm;
	}

	/**
	 * Writes ServiceConfiguration objects into an xml file
	 * located in /tmp/configmanger.xml
	 * @param configurationObject		ServiceConfiguration object to be written to a file.
	 */
	
	public static void writeConfigtoFile(final ServiceConfiguration configurationObject) 
	{
		
		ServiceConfig sigServiceConfig = new ServiceConfig();
		SystemElement systemElement = new SystemElement();
		ArrayList<Property> systemPropertyList = new ArrayList<>();
		ArrayList<Application> applicationList = new ArrayList<>();
		Application applicationElement;
		ArrayList<Property> applicationPropertyList;
		ArrayList<PropertyList> applicationPropertyListList = new ArrayList<>();
		PropertyList applicationPropertyListElement;

		// create system node
		systemPropertyList = ConfigUtil.convertMapToPropertyList(
									configurationObject.getSystemNode().getPropertyMap());
		
		systemElement.setPropertyList(systemPropertyList);

		// create application list
		for (Map.Entry<String, ApplicationNode> application : 
			 configurationObject.getApplicationMap().entrySet()) 
		{
			applicationElement = new Application();

			// convert application property map to property list
			applicationPropertyList = new ArrayList<>();
			applicationPropertyList = ConfigUtil
					.convertMapToPropertyList(application.getValue()
							.getPropertyMap());

			// add objects to application element
			applicationElement.setName(application.getKey());
			applicationElement.setPropertyList(applicationPropertyList);

			// cycle through propertyList map
			for (Map.Entry<String, TreeMap<String, String>> propertyList : 
				 application.getValue().getPropertyListMap().entrySet()) 
			{
				applicationPropertyListElement = new PropertyList();

				applicationPropertyListElement.setName(propertyList.getKey());
				applicationPropertyListElement.setItemList(ConfigUtil.convertMapToItemList(propertyList.getValue()));

				applicationPropertyListList.add(applicationPropertyListElement);
			}

			applicationElement.setPropertyListList(applicationPropertyListList);

			// add application to application list
			applicationList.add(applicationElement);
		}

		// add elements to root node
		sigServiceConfig.setSystem(systemElement);
		sigServiceConfig.setApplicationList(applicationList);

		try 
		{

			File file = new File("/tmp/configmanger.xml");
			
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceConfig.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			jaxbMarshaller.marshal(sigServiceConfig, file);
			jaxbMarshaller.marshal(sigServiceConfig, System.out);

		} 
		catch (JAXBException e)
		{
			e.printStackTrace();
		}

	}

	/**
	 * Converts ServiceConfiguration objects into an xml string
	 * located in /tmp/configmanger.xml
	 * @param configurationObject		ServiceConfiguration object to be written to a file.
	 * @return 	xmlString of config
	 */
	
	public static String configToString(final ServiceConfiguration configurationObject) 
	{
		
		ServiceConfig sigServiceConfig = new ServiceConfig();
		SystemElement systemElement = new SystemElement();
		ArrayList<Property> systemPropertyList = new ArrayList<>();
		ArrayList<Application> applicationList = new ArrayList<>();
		Application applicationElement;
		ArrayList<Property> applicationPropertyList;
		ArrayList<PropertyList> applicationPropertyListList = new ArrayList<>();
		PropertyList applicationPropertyListElement;

		// create system node
		systemPropertyList = ConfigUtil.convertMapToPropertyList(
									configurationObject.getSystemNode().getPropertyMap());
		
		systemElement.setPropertyList(systemPropertyList);

		// create application list
		for (Map.Entry<String, ApplicationNode> application : 
			 configurationObject.getApplicationMap().entrySet()) 
		{
			applicationElement = new Application();

			// convert application property map to property list
			applicationPropertyList = new ArrayList<>();
			applicationPropertyList = ConfigUtil
					.convertMapToPropertyList(application.getValue()
							.getPropertyMap());

			// add objects to application element
			applicationElement.setName(application.getKey());
			applicationElement.setPropertyList(applicationPropertyList);

			// cycle through propertyList map
			for (Map.Entry<String, TreeMap<String, String>> propertyList : 
				 application.getValue().getPropertyListMap().entrySet()) 
			{
				applicationPropertyListElement = new PropertyList();

				applicationPropertyListElement.setName(propertyList.getKey());
				applicationPropertyListElement.setItemList(ConfigUtil.convertMapToItemList(propertyList.getValue()));

				applicationPropertyListList.add(applicationPropertyListElement);
			}

			applicationElement.setPropertyListList(applicationPropertyListList);

			// add application to application list
			applicationList.add(applicationElement);
		}

		// add elements to root node
		sigServiceConfig.setSystem(systemElement);
		sigServiceConfig.setApplicationList(applicationList);

		String xmlString = "";
		
		try 
		{
			StringWriter sw = new StringWriter();
			JAXBContext jaxbContext = JAXBContext.newInstance(ServiceConfig.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			
			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
			jaxbMarshaller.marshal(sigServiceConfig, sw);
			
			xmlString = sw.toString();

		} 
		catch (JAXBException e)
		{
			e.printStackTrace();
		}

		return xmlString;
	}
	/**
	 * Combines two ServiceConfiguration objects into a 
	 * single ServiceConfiguration object 
	 * @param baseConfig				base ServiceConfiguration object
	 * @param customConfig				override ServiceConfiguration object
	 * @param configDirectoryPath		path to config folder where additional 
	 * 									configuration files can be found		
	 * <p>
	 * @return ServiceConfiguration
	 */
	
	public static ServiceConfiguration combineConfigurations(final ServiceConfiguration baseConfig,
															 final ServiceConfiguration customConfig, 
															 final String configDirectoryPath)
	{
		ServiceConfiguration combinedConfig = new ServiceConfiguration();
		PropertyElement propertyElement = null;
		String propertyValue= null;
		// get ApplicationMaps
		TreeMap<String, ApplicationNode> baseApplicationMap = baseConfig
				.getApplicationMap();
		TreeMap<String, ApplicationNode> combinedApplicationMap = new TreeMap<>();
		String applicationName;
		String propertyListName;
		String itemName;

		// Overlay custom.system is present

		SystemNode customSystemNode = customConfig.getSystemNode();
		SystemNode baseSystemNode = baseConfig.getSystemNode();
		SystemNode combinedSystemNode = new SystemNode();
		
		// start by getting copy from base config
		combinedSystemNode.getPropertyMap().putAll(baseSystemNode.getPropertyMap());

		// process only if there is a system node in the custom file
		if (customSystemNode != null) 
		{

			// only process properties that appear in the base file
			for (Map.Entry<String, PropertyElement> combinedProperty : 
				 combinedSystemNode.getPropertyMap().entrySet()) 
			{

				// check to see if key (property name) is in custom config
				propertyElement = customSystemNode.getPropertyMap().get(combinedProperty.getKey());
				
				if (propertyElement != null) 
				{
					combinedProperty.setValue(propertyElement);
				}
			}
		}

		combinedApplicationMap.putAll(baseApplicationMap);		
		
		// Cycle through base.applications. this will ensure only those
		// applications can get modified.
		// anything in custom that is not in base will be ignored
		for (Map.Entry<String, ApplicationNode> application : combinedApplicationMap.entrySet()) 
		{
			// get application from custom

			// cycle through property list first
			applicationName = application.getKey();			
			
			TreeMap<String, PropertyElement> applicationPropertyMap = application.getValue().getPropertyMap();
			TreeMap<String, TreeMap<String, String>> applicationPropertyListMap= application.getValue().getPropertyListMap();
			
			// cycle through properties in base and update with custom
			for (Map.Entry<String, PropertyElement> combinedApplicationProperty : applicationPropertyMap.entrySet()) 
			{
				
				// check to see if key (property name) is in custom config
				ApplicationNode appNode =customConfig.getApplicationMap().get(applicationName); 
				
				propertyElement = (appNode==null)?null:appNode.getPropertyMap().get(combinedApplicationProperty.getKey());
			
				if (propertyElement != null) 
				{
					combinedApplicationProperty.setValue(propertyElement);
				}
			}
			
			// cycle through property Lists in custom and update base
			for (Map.Entry<String, TreeMap<String, String>> combinedApplicationPropertyList : applicationPropertyListMap.entrySet()) 
			{
				// have a propertyList entry. now need to process the list of
				// item values
				propertyListName = combinedApplicationPropertyList.getKey();

				for (Map.Entry<String, String> itemList : combinedApplicationPropertyList.getValue().entrySet()) 
				{
									
					// check to see if key (property name) is in custom config
					itemName = itemList.getKey();
					propertyValue = customConfig.getApplicationPropertyListValueByName(applicationName, 
																					   propertyListName, 
																					   itemName);
					
					if (propertyValue != null) 
					{
						itemList.setValue(propertyValue);
					}
				}
			}
		}

		Unmarshaller unmarshaller=null;
		try 
		{
			
			ConfigUtil.jaxbMap.putIfAbsent("context" ,JAXBContext.newInstance("com.gianteagle.is.config.jaxb",com.gianteagle.is.config.jaxb.ServiceConfig.class.getClassLoader()));
			ConfigUtil.umMap.putIfAbsent("unmarshaller", ConfigUtil.jaxbMap.get("context").createUnmarshaller());
			
			unmarshaller = ConfigUtil.umMap.get("unmarshaller");
		
		} 
		catch (JAXBException e) 
		{			
			e.printStackTrace();			
		}
		
		for(Map.Entry<String, ApplicationNode> application : combinedApplicationMap.entrySet())
		{
			for(Map.Entry<String, PropertyElement> property : application.getValue().getPropertyMap().entrySet())
			{				
				String currentPropertyType = property.getValue().getName();
				
				//If the config file has MOMConfigList, InterfaceList, ErrorList and ExtensionList then load all the 
				//defined files into their respective JAXB objects and store them in the current ApplicationNode. 
				try
				{
					if(unmarshaller!=null && (currentPropertyType.equalsIgnoreCase("MOMConfigListType") 
										|| currentPropertyType.equalsIgnoreCase("InterfaceListType")
										|| currentPropertyType.equalsIgnoreCase("ErrorListType")
										|| currentPropertyType.equalsIgnoreCase("ExtensionListType")))
					{
						PropertyElement listTypelement = property.getValue();
													
						File xmlFile = new File(configDirectoryPath + Util.fileSeparator() + listTypelement.getValue());			
						
						//Converts the loaded file to specified JAXB objects and store them in the current ApplicationNode
						Object unmarshalledObj = unmarshaller.unmarshal(xmlFile);
						
						if(currentPropertyType.equalsIgnoreCase("MOMConfigListType"))
						{				
							MOMConfigListType momConfigListTypeObj =  (MOMConfigListType)unmarshalledObj;
	
							application.getValue().setMomConfigListType(momConfigListTypeObj);
						}
						else if(currentPropertyType.equalsIgnoreCase("InterfaceListType"))
						{
							ConnectionListType interfaceListTypeObj = (ConnectionListType)unmarshalledObj;
	
							application.getValue().setInterfaceListType(interfaceListTypeObj);
						}
						else if(currentPropertyType.equalsIgnoreCase("ErrorListType"))
						{
							ErrorHandlingType errorListTypeObj = (ErrorHandlingType)unmarshalledObj;
	
							application.getValue().setErrorListType(errorListTypeObj);
						}
						else if(currentPropertyType.equalsIgnoreCase("ExtensionListType"))
						{
							ExtensionListType extensionListTypeObj = (ExtensionListType)unmarshalledObj;
	
							application.getValue().setExtensionListType(extensionListTypeObj);
						}
						
						
					}
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			
			}
			
		}
		
		// add system node to combined
		combinedConfig.setSystemNode(combinedSystemNode);
		combinedConfig.setApplicationMap(combinedApplicationMap);

		
		return combinedConfig;
	}
	
	/**
	 * Used for testing purposes only.
	 * <p>
	 * @param	args	Command line arguments.
	 */
	public static void main(String[] args)
	{
		/*ENABLE ONLY FOR TESTING PURPOSES
		File momXMLFile = new File("/opt/soaApps/IIB/KrJewelryInventoryPUB/config/MOMConfigList.xml");		
		//momXMLFile = new File("/opt/soaApps/IIB/KrJewelryInventoryPUB/config/InterfaceList.xml");
		//momXMLFile = new File("/opt/soaApps/IIB/KrJewelryInventoryPUB/config/ErrorList.xml");
		//momXMLFile = new File("/opt/soaApps/IIB/KrJewelryInventoryPUB/config/ExtensionList.xml");
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(new Class[]{MOMConfigListType.class,ConnectionListType.class,ErrorHandlingType.class,ExtensionListType.class});
	
		Unmarshaller momUnmarshaller = context.createUnmarshaller();
							
		@SuppressWarnings("unchecked")
		MOMConfigListType o =  (MOMConfigListType)momUnmarshaller.unmarshal(momXMLFile);	
		String test = o.getMOMConfig().get(0).getMOMActionCode();
		
		//ConnectionListType o =  (ConnectionListType)momUnmarshaller.unmarshal(momXMLFile);	
		//String test = o.getInterface().get(0).getInterfaceName();
		
		//ErrorHandlingType o =  (ErrorHandlingType)momUnmarshaller.unmarshal(momXMLFile);	
		//String test = o.getErrorCode().get(0).getErrorNumber();
		
		//ExtensionListType o =  (ExtensionListType)momUnmarshaller.unmarshal(momXMLFile);	
		//String test = o.getExtension().get(0).getName();
		
		
		System.out.println(test);
		
		} catch (JAXBException e) {
			e.printStackTrace();
		} */
		
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	/**
	 * Converts List of Property objects into a TreeMap<String, PropertyElement>.
	 * This function is intended to be used when converting jaxb
	 * representation of configuration xml into a ServiceConfiguration
	 * object
	 * @return				TreeMap<String, String>
	 */
	
	private static TreeMap<String, PropertyElement> convertPropertyListToMap(final List<Property> propertyList) 
	{
		PropertyElement propElement;
		
		TreeMap<String, PropertyElement> convertedMap = new TreeMap<>();

		for (Property prop : propertyList) 
		{
			propElement =  new PropertyElement();
			propElement.setName(prop.getName());
			propElement.setValue(prop.getValue());
			propElement.setType(prop.getType());
			convertedMap.put(prop.getName(), propElement);
		}

		return convertedMap;
	}

	/**
	 * Converts List of Item objects into a TreeMap<String, String>.
	 * This function is intended to be used when converting jaxb
	 * representation of configuration xml into a ServiceConfiguration
	 * object
	 * @param itemList		list of Item objects to be converted
	 * <p>
	 * @return				TreeMap<String, String>
	 */
	
	private static TreeMap<String, String> convertItemListToMap(final List<Item> itemList) 
	{
		TreeMap<String, String> convertedMap = new TreeMap<>();

		for (Item item : itemList) 
		{
			convertedMap.put(item.getKey(), item.getValue());
		}

		return convertedMap;
	}

	/**
	 * Converts TreeMap<String, PropertyElement> into ArrayList of Property elements.
	 * This function is intended to be used in converting
	 * configuration objects back into jaxb structure for writing 
	 * configuration to a file.
	 * @param propertyMap		TreeMap<String, String> to be converted
	 * <p>
	 * @return list representation of map
	 */
	
	private static ArrayList<Property> convertMapToPropertyList(final TreeMap<String, PropertyElement> propertyMap) 
	{
		ArrayList<Property> propertyList = new ArrayList<>();
		Property propertyElement;

		for (Map.Entry<String, PropertyElement> property : propertyMap.entrySet()) 
		{
			propertyElement = new Property();
			propertyElement.setName(property.getValue().getName());
			propertyElement.setValue(property.getValue().getValue());
			propertyElement.setType(property.getValue().getType());

			propertyList.add(propertyElement);
		}

		return propertyList;
	}

	/**
	 * Converts TreeMap into ArrayList of Item objects.
	 * This function is intended to be used in converting
	 * configuration objects back into jaxb structure for writing 
	 * configuration to a file.
	 * @param propertyMap		TreeMap to be converted
	 * <p>
	 * @return list representation of map
	 */
	
	public static ArrayList<Item> convertMapToItemList(final TreeMap<String, String> propertyMap) 
	{
		ArrayList<Item> itemList = new ArrayList<>();
		Item itemElement;

		for (Map.Entry<String, String> property : propertyMap.entrySet()) 
		{
			itemElement = new Item();
			
			itemElement.setKey(property.getKey());
			itemElement.setValue(property.getValue());

			itemList.add(itemElement);
		}

		return itemList;
	}
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	
	static private final ConcurrentHashMap<String, JAXBContext> jaxbMap = new ConcurrentHashMap<String, JAXBContext>();
	static private final ConcurrentHashMap<String, Unmarshaller> umMap = new ConcurrentHashMap<String, Unmarshaller>();

}
