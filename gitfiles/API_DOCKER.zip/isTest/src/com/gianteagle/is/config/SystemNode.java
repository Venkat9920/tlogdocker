package com.gianteagle.is.config;

import java.util.TreeMap;

/**
 * Class used to represent System node of a configuration
 * file/object
 * <p>
 * @author	SandersJL
 */

public class SystemNode {
	
	/**
	  * Constructor.
	  * Initializes propertyMap to empty map
	  */
	
	public SystemNode()
	{
		this.propertyMap = new TreeMap<>();
	}
	
	/**
	  * Constructor.
	  * Initializes propertyMap to map passed in
	  * <p>
	  * @param propertyMap		The property map.
	  */
	
	public SystemNode(TreeMap<String, PropertyElement> propertyMap)
	{
		this.propertyMap = propertyMap;
	}

	/**
	 * Gets propertyMap 
	 * @return map of propertyElements with element name as the key
	 */
	public TreeMap<String, PropertyElement> getPropertyMap() 
	{
		return this.propertyMap;
	}

	/**
	 * Sets propertyMap 
	 * @param propertyMap	The property map.
	 */
	public void setPropertyMap(TreeMap<String, PropertyElement> propertyMap) 
	{
		this.propertyMap = propertyMap;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------
	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	
	private TreeMap<String, PropertyElement> propertyMap;
}
