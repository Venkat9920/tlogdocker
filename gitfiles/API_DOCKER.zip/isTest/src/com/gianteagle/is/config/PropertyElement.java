package com.gianteagle.is.config;

/**
 * Class used to represent property element/node
 * of configuration file/object
 * <p>
 * @author	SandersJL
 */

public class PropertyElement {

    /**
     * Gets value
     * @return String
     */
	
	public String getValue() 
	{
		return value;
	}
	
	/**
	 * Sets value
	 * @param value		The property value.
	 */
	public void setValue(final String value) 
	{
		this.value = value;
	}
	
	/**
	 * Gets type
	 * @return String
	 */
	public String getType() 
	{
		return type;
	}
	
	/**
	 * Sets type
	 * @param type		The property type.
	 */
	public void setType(final String type) 
	{
		this.type = type;
	}
	
	/**
	 * Gets name
	 * @return String
	 */
	public String getName() 
	{
		return name;
	}
	
	/**
	 * Sets name
	 * @param name	The property name.
	 */
	public void setName(final String name) 
	{
		this.name = name;
	}
    
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------

	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	

	private String value;    
    private String type;
    private String name;
}
