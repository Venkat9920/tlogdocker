
package com.gianteagle.is.config.jaxb;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name= "MOMConfigList")
public class MOMConfigListType {

   
	@XmlElement(name = "MOMConfig", required = true)
    protected List<MOMType> momConfig;

   
    public List<MOMType> getMOMConfig() {
        if (momConfig == null) {
            momConfig = new ArrayList<MOMType>();
        }
        return this.momConfig;
    }
    

}
