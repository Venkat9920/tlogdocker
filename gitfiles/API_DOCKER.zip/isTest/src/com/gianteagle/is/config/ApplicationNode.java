package com.gianteagle.is.config;

import java.util.TreeMap;

import com.gianteagle.is.config.jaxb.ConnectionListType;
import com.gianteagle.is.config.jaxb.ErrorHandlingType;
import com.gianteagle.is.config.jaxb.ExtensionListType;
import com.gianteagle.is.config.jaxb.MOMConfigListType;
import com.gianteagle.is.config.jaxb.TimingExtraFieldListType;
import com.gianteagle.is.config.jaxb.TimingMetricListType;

/**
 * Class used to represent Application node of a configuration
 * file/object
 * <p>
 * @author	SandersJL
 */

public class ApplicationNode {

	/**
	 * Gets timginExtraFieldList 
	 * @return TimingExtraFieldListType
	 */
	
	public TimingExtraFieldListType getTimginExtraFieldListType() 
	{
		return this.timginExtraFieldList;
	}

	/**
	 * Sets timginExtraFieldList 
	 * @param timginExtraFieldList		The timing extra field list.
	 */
	
	public void setTimginExtraFieldListType(TimingExtraFieldListType timginExtraFieldList) 
	{
		this.timginExtraFieldList = timginExtraFieldList;
	}

	/**
	 * Gets timingList
	 * @return TimingMetricListType
	 */
	
	public TimingMetricListType getTimingListType() 
	{
		return this.timingList;
	}

	/**
	 * Sets timingList 
	 * @param timingList		The Timing metric list.
	 */
	
	public void setTimingListType(TimingMetricListType timingList) 
	{
		this.timingList = timingList;
	}

	/**
	 * Gets extensionList
	 * @return ExtensionListType
	 */
	
	public ExtensionListType getExtensionListType() 
	{
		return this.extensionList;
	}

	/**
	 * Sets extensionList 
	 * @param extensionList		The extension list.
	 */
	
	public void setExtensionListType(ExtensionListType extensionList) 
	{
		this.extensionList = extensionList;
	}

	/**
	 * Gets errorList
	 * @return ErrorHandlingType
	 */
	
	public ErrorHandlingType getErrorListType() 
	{
		return this.errorList;
	}

	/**
	 * Sets errorList 
	 * @param errorList		The error handling list.
	 */
	
	public void setErrorListType(ErrorHandlingType errorList) 
	{
		this.errorList = errorList;
	}

	/**
	 * Gets interfaceList
	 * @return ConnectionListType
	 */
	
	public ConnectionListType getInterfaceListType() 
	{
		return this.interfaceList;
	}

	/**
	 * Sets interfaceList 
	 * @param interfaceList		The connection list interface.
	 */
	
	public void setInterfaceListType(ConnectionListType interfaceList) 
	{
		this.interfaceList = interfaceList;
	}

	/**
	 * Gets momConfigList
	 * @return MOMConfigListType
	 */
	
	public MOMConfigListType getMomConfigListType() 
	{
		return this.momConfigList;
	}

	/**
	 * Sets momConfigList 
	 * @param momConfigList		The MOM configuration list.
	 */
	
	public void setMomConfigListType(MOMConfigListType momConfigList) 
	{
		this.momConfigList = momConfigList;
	}

	/**
	 * Gets name 
	 * @return name
	 */
	
	public String getName() 
	{
		return this.name;
	}

	/**
	 * Sets name 
	 * @param name	sets the property name.
	 */
	
	public void setName(String name) 
	{
		this.name = name;
	}

	/**
	 * Gets propertyMap 
	 * @return TreeMap containing the property map.
	 */
	
	public TreeMap<String, PropertyElement> getPropertyMap() 
	{
		return this.propertyMap;
	}

	/**
	 * Sets propertyMap 
	 * @param propertyMap	The property map.
	 */
	
	public void setPropertyMap(TreeMap<String, PropertyElement> propertyMap)
	{
		this.propertyMap = propertyMap;
	}

	/**
	 * Gets propertyListMap 
	 * @return TreeMap containg the property list map.
	 */
	
	public TreeMap<String, TreeMap<String, String>> getPropertyListMap() 
	{
		return this.propertyListMap;
	}

	/**
	 * Sets propertyListMap 
	 * <p>
	 * @param	propertyListMap		The property list map.
	 */
	
	public void setPropertyListMap(
			TreeMap<String, TreeMap<String, String>> propertyListMap) 
	{
		this.propertyListMap = propertyListMap;
	}
	
	//---------------------------------------------------------------
	// Private methods.
	//---------------------------------------------------------------

	
	//---------------------------------------------------------------
	// Private member variables.
	//---------------------------------------------------------------	
	
	private String name = null;
	private TreeMap<String, PropertyElement> propertyMap = new TreeMap<>();
	private TreeMap<String, TreeMap<String, String>> propertyListMap = new TreeMap<>();
	private MOMConfigListType momConfigList = null;
	private ConnectionListType interfaceList = null;
	private ErrorHandlingType errorList = null;
	private ExtensionListType extensionList = null;
	private TimingMetricListType timingList = null;
	private TimingExtraFieldListType timginExtraFieldList = null;
}