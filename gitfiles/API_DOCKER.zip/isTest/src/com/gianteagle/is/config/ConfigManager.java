package com.gianteagle.is.config;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import com.gianteagle.is.config.jaxb.ConnectionListType;
import com.gianteagle.is.config.jaxb.ErrorHandlingType;
import com.gianteagle.is.config.jaxb.ExtensionListType;
import com.gianteagle.is.config.jaxb.MOMConfigListType;
import com.gianteagle.is.config.jaxb.TimingExtraFieldListType;
import com.gianteagle.is.config.jaxb.TimingMetricListType;
import com.gianteagle.is.util.StringUtil;
import com.gianteagle.is.util.Util;

/**
 * Class used to manage creating new Configuration objects and access its values
 * <p>
 * 
 * @author SandersJL
 */

public class ConfigManager {

	/**
	 * Returns TimingMetricListType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return TimingMetricListType Returns a valid TimingMetricListType object if
	 *         found otherwise returns null
	 */

	public static TimingMetricListType getTimingMetricList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {
		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationTimingMetricList(applicationName);
		}

		return null;
	}

	/**
	 * Returns TimingExtraFieldListType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return TimingExtraFieldListType Returns a valid TimingExtraFieldListType
	 *         object if found otherwise returns null
	 */

	public static TimingExtraFieldListType getTimingExtraFieldList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {
		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationTimingExtraFieldList(applicationName);
		}

		return null;
	}

	/**
	 * Returns MOMConfigListType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return MOMConfigListType Returns a valid MOMConfigListType object if found
	 *         otherwise returns null
	 */

	public static MOMConfigListType getMOMConfigTypeList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {

		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationMOMConfigList(applicationName);
		}

		return null;
	}

	/**
	 * Returns ConnectionListType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return ConnectionListType Returns a valid ConnectionListType object if found
	 *         otherwise returns null
	 */

	public static ConnectionListType getInterfaceTypeList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {

		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationInterfaceList(applicationName);
		}

		return null;
	}

	/**
	 * Returns ErrorHandlingType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return ErrorHandlingType Returns a valid ErrorHandlingType object if found
	 *         otherwise returns null
	 */

	public static ErrorHandlingType getErrorTypeList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {

		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationErrorList(applicationName);
		}

		return null;
	}

	/**
	 * Returns ExtensionListType from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param applicationName  Name of application
	 *                         <p>
	 * @return ExtensionListType Returns a valid ExtensionListType object if found
	 *         otherwise returns null
	 */

	public static ExtensionListType getExtensionTypeList(final ConfigurationDescriptor configDescriptor,
			final String applicationName) {

		ConfigManager.addConfiguration(configDescriptor);

		Config cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			return cm.getConfigurationObject().getApplicationExtensionList(applicationName);
		}

		return null;
	}

	/**
	 * Returns Boolean from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param sysApp           Name of application or System namespace
	 * @param propertyName     Name of property
	 *                         <p>
	 * @return Boolean Returns a valid Boolean object if found otherwise returns
	 *         null
	 */

	public static Boolean getBooleanProperty(final ConfigurationDescriptor configDescriptor, final String sysApp,
			final String propertyName) {
		boolean rtn = false;
		String propertyValue = "false";
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			if (sysApp.equalsIgnoreCase(ConfigConstants.SYSTEM)) {
				propertyValue = cm.getConfigurationObject().getSystemPropertyValue(propertyName);

			} else {
				propertyValue = cm.getConfigurationObject().getApplicationPropertyValueByName(sysApp, propertyName);
			}

            rtn = propertyValue.equalsIgnoreCase(ConfigConstants.TRUE);
		}

		return Boolean.valueOf(rtn);
	}

	/**
	 * Returns String from application in configuration Object.
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 * @param sysApp           Name of application or System namespace
	 * @param propertyName     Name of property
	 *                         <p>
	 * @return String Returns a valid String object if found otherwise returns null
	 */

	public static String getStringProperty(final ConfigurationDescriptor configDescriptor, final String sysApp,
			final String propertyName) {

		String sRet = null;
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			if (sysApp.equalsIgnoreCase(ConfigConstants.SYSTEM)) {
				sRet = cm.getConfigurationObject().getSystemPropertyValue(propertyName);

			} else {
				sRet = cm.getConfigurationObject().getApplicationPropertyValueByName(sysApp, propertyName);
			}

		}

		return sRet;
	}

	/**
	 * Returns the specified property as a Long.
	 * <p>
	 * 
	 * @param configDescriptor Configuration Descriptor.
	 * @param sysApp           System/Application.
	 * @param propertyName     Name of the property.
	 *                         <p>
	 * @return The value of the property as a Long.
	 */

	public static Long getLongProperty(final ConfigurationDescriptor configDescriptor, final String sysApp,
			final String propertyName) {
		Long nRet = null;
		String sValue = null;

		try {
			sValue = ConfigManager.getStringProperty(configDescriptor, sysApp, propertyName);

			nRet = Long.valueOf(StringUtil.parseLong(sValue, 0));
		} finally {
			sValue = null;
		}
		return nRet;
	}

	/**
	 * Returns the size of specified propertyList as a Long.
	 * <p>
	 * 
	 * @param configDescriptor Configuration Descriptor.
	 * @param applicationName  Name of application.
	 * @param propertyListName Name of the propertyList.
	 *                         <p>
	 * @return The value of the property as a Long.
	 */

	public static Long getLongPropertyListSize(final ConfigurationDescriptor configDescriptor,
			final String applicationName, final String propertyListName) {

		Long nRet = null;
		int propertyListSize = 0;
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {

			propertyListSize = cm.getConfigurationObject().getApplicationPropertyListSize(applicationName,
					propertyListName);

			nRet = Long.valueOf(propertyListSize);
		}

		return nRet;
	}

	/**
	 * Returns the key from specified propertyList as a String.
	 * <p>
	 * 
	 * @param configDescriptor Configuration Descriptor.
	 * @param applicationName  Name of application.
	 * @param propertyListName Name of the propertyList.
	 * @param ndx              index of key.
	 *                         <p>
	 * @return The key value of the propertyList[ndx] as a String.
	 */

	public static String getStringPropertyListKeyByIndex(final ConfigurationDescriptor configDescriptor,
			final String applicationName, final String propertyListName, final int ndx) {

		String sRet = null;
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			sRet = cm.getConfigurationObject().getApplicationPropertyListKeyByIndex(applicationName, propertyListName,
					ndx);
		}

		return sRet;
	}

	/**
	 * Returns the entry from specified propertyList as a String.
	 * <p>
	 * 
	 * @param configDescriptor Configuration Descriptor.
	 * @param applicationName  Name of application.
	 * @param propertyListName Name of the propertyList.
	 * @param ndx              index of value.
	 *                         <p>
	 * @return The entry value of the propertyList[ndx] as a String.
	 */

	public static String getStringPropertyListValueByIndex(final ConfigurationDescriptor configDescriptor,
			final String applicationName, final String propertyListName, final int ndx) {
		String sRet = null;
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			sRet = cm.getConfigurationObject().getApplicationPropertyListValueByIndex(applicationName, propertyListName,
					ndx);
		}

		return sRet;
	}

	/**
	 * Returns the entry from specified propertyList as a String.
	 * <p>
	 * 
	 * @param configDescriptor Configuration Descriptor.
	 * @param applicationName  Name of application.
	 * @param propertyListName Name of the propertyList.
	 * @param itemName         index of key.
	 *                         <p>
	 * @return The entry value of the propertyList[itemName] as a String.
	 */

	public static String getStringPropertyListValueByKey(final ConfigurationDescriptor configDescriptor,
			final String applicationName, final String propertyListName, final String itemName) {
		String sRet = null;
		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {

			sRet = cm.getConfigurationObject().getApplicationPropertyListValueByName(applicationName, propertyListName,
					itemName);
		}

		return sRet;
	}

	/**
	 * Returns the map of System property values.
	 * <p>
	 * 
	 * @param configDescriptor The configuration descriptor.
	 *                         <p>
	 * @return Returns the map of System property values.
	 */

	public static final LinkedHashMap<String, String> getSystemProperties(
			final ConfigurationDescriptor configDescriptor) {
		LinkedHashMap<String, String> systemProperties = null;

		Config cm = null;

		// check to see if need to load config manager
		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			systemProperties = new LinkedHashMap<>();
			systemProperties = cm.getSystemProperties();
		}

		return systemProperties;
	}

	/**
	 * Returns the folder path to specified folder type as a String.
	 * <p>
	 * 
	 * @param configDescriptor The configuration descriptor.
	 * @param folderType       The enum representing type of descriptor.
	 *                         <p>
	 * @return Returns the folder path to specified folder type as a String.
	 */

	public static final String getFolderPath(final ConfigurationDescriptor configDescriptor,
			final ConfigConstants.FOLDER_TYPE folderType) {
		String folderPath = null;

		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			switch (folderType) {
			case BASE:
				folderPath = cm.getBaseDirectory();
				break;
			case CONFIG:
				folderPath = cm.getConfigDirectory();
				break;
			case LOG:
				folderPath = cm.getLogDirectory();
				break;
			case DATA:
				folderPath = cm.getDataFileDirectory();
				break;
			case TEMP:
				folderPath = cm.getTempDirectory();
				break;
			case XFER:
				folderPath = cm.getXferDirectory();
				break;
			case OUTBOUND:
				folderPath = cm.getOutboundXferDirectory();
				break;
			case INBOUND:
				folderPath = cm.getInboundXferDirectory();
				break;
			default:
				folderPath = null;
			}
		}

		return folderPath;
	}

	/**
	 * Returns a map of maps representing the component (application) properties.
	 * <p>
	 * 
	 * @param configDescriptor The configuration descriptor.
	 *                         <p>
	 * @return Returns a map of maps representing the component properties.
	 */

	public static final LinkedHashMap<String, LinkedHashMap<String, String>> getComponentProperties(
			final ConfigurationDescriptor configDescriptor) {
		LinkedHashMap<String, LinkedHashMap<String, String>> componentProperties = null;

		Config cm = null;

		ConfigManager.addConfiguration(configDescriptor);

		cm = ConfigList.getInstance().getCmList().get(configDescriptor.getNameSpace());

		if (cm != null) {
			componentProperties = new LinkedHashMap<>();
			componentProperties = cm.getConfigurationObject().getComponentProperties();
		}

		return componentProperties;
	}

	/**
	 * Returns a Xml string representing all the config objects.
	 * <p>
	 * 
	 * @return Returns a Xml string representing the component properties.
	 */
	public static final String getAllConfigObjectsAsXml() {
		String rtn = null;
		StringBuilder sb = new StringBuilder();

		sb.append("<configList>");

		for (Map.Entry<String, Config> configObject : ConfigList.getInstance().getCmList().entrySet()) {
			sb.append(configObject.getValue().toXmlString());
		}

		sb.append("</configList>");

		rtn = sb.toString();

		return rtn;
	}

	// ---------------------------------------------------------------
	// Private methods.
	// ---------------------------------------------------------------

	/**
	 * If configuration object does not exist for configDescriptor.namespace then
	 * create a configuration object. Verify the existence of baseConfig before
	 * adding new configurationObject to ConfigList
	 * 
	 * @param configDescriptor ConfigurationDescriptor describing config object
	 */

	static void addConfiguration(final ConfigurationDescriptor configDescriptor) {
		Config configObject;

		boolean configObjectExists = false;

		configObjectExists = ConfigList.getInstance().getCmList().containsKey(configDescriptor.getNameSpace());

		if (!configObjectExists) {
			synchronized (ConfigManager.class) {
				configObjectExists = ConfigList.getInstance().getCmList().containsKey(configDescriptor.getNameSpace());

				System.out.println(ConfigManager.class.getName() + ": Config: "
						+ StringUtil.format(configDescriptor.getNameSpace()) + " loaded through ConfigManager.");

				if (!configObjectExists && configDescriptor.isComplete()) {
					configObject = new Config(configDescriptor.getNameSpace(), configDescriptor.getEnvVar(),
							configDescriptor.getBaseConfigFile(), configDescriptor.getCustomConfigFile(),
							configDescriptor.getLogInterface());

					String configFilePath = configObject.getConfigDirectory() + Util.fileSeparator();
					File baseFile = new File(configFilePath + configDescriptor.getBaseConfigFile());

					if (baseFile.isFile()) {
						ConfigList.getInstance().addConfigManagerToList(configDescriptor.getNameSpace(), configObject);

						ConfigWithFileList.getInstance().addFileToList(configFilePath,
								configDescriptor.getBaseConfigFile(), configObject);

						ConfigWithFileList.getInstance().addFileToList(configFilePath,
								configDescriptor.getCustomConfigFile(), configObject);

					} else {
						System.err.println(ConfigManager.class.getName()
								+ ": The config object did not have a valid base config file.  It was not added to the system");
					}
				}
			}

		}

	}

	// ---------------------------------------------------------------
	// Private member variables.
	// ---------------------------------------------------------------

}
