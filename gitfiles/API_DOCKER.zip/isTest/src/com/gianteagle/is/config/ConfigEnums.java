package com.gianteagle.is.config;

/**
 * Enum used to represent various configuration components
 * <p>
 * @author	SandersJL
 */

public enum ConfigEnums {
	LogicalID,
	ServiceID,
	LoggerName,
	LoggingPropertyFileName,
	EnableLogging,
	LogVersion,
	TimingMetricList,
	TimingExtraFieldList,
	MOMConfigListType,
	ErrorListType,
	InterfaceListType,
	ExtensionListType
}
